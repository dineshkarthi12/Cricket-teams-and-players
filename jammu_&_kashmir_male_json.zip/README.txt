This zip archive contains data files from Cricsheet in JSON format. This
archive contains 31 Jammu & Kashmir matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/jammu_&_kashmir_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-25 - club - SMA - male - 1383527 - Jammu & Kashmir vs Mizoram
2023-10-23 - club - SMA - male - 1383509 - Meghalaya vs Jammu & Kashmir
2023-10-21 - club - SMA - male - 1383488 - Mumbai vs Jammu & Kashmir
2023-10-16 - club - SMA - male - 1383437 - Baroda vs Jammu & Kashmir
2021-11-09 - club - SMA - male - 1280282 - Jammu & Kashmir vs Jharkhand
2021-11-06 - club - SMA - male - 1280242 - Haryana vs Jammu & Kashmir
2021-11-05 - club - SMA - male - 1280223 - Jammu & Kashmir vs Rajasthan
2021-01-18 - club - SMA - male - 1244382 - Railways vs Jammu & Kashmir
2021-01-16 - club - SMA - male - 1244365 - Jammu & Kashmir vs Punjab
2021-01-12 - club - SMA - male - 1244326 - Tripura vs Jammu & Kashmir
2021-01-10 - club - SMA - male - 1244306 - Karnataka vs Jammu & Kashmir
2019-11-18 - club - SMA - male - 1205741 - Jammu & Kashmir vs Gujarat
2019-11-17 - club - SMA - male - 1205831 - Saurashtra vs Jammu & Kashmir
2019-11-15 - club - SMA - male - 1205820 - Nagaland vs Jammu & Kashmir
2019-11-12 - club - SMA - male - 1205784 - Jammu & Kashmir vs Odisha
2019-02-28 - club - SMA - male - 1157178 - Manipur vs Jammu & Kashmir
2019-02-27 - club - SMA - male - 1157161 - Kerala vs Jammu & Kashmir
2019-02-25 - club - SMA - male - 1157143 - Andhra vs Jammu & Kashmir
2019-02-24 - club - SMA - male - 1157125 - Jammu & Kashmir vs Delhi
2019-02-22 - club - SMA - male - 1157109 - Jammu & Kashmir vs Jharkhand
2019-02-21 - club - SMA - male - 1157093 - Nagaland vs Jammu & Kashmir
2018-01-14 - club - SMA - male - 1130713 - Jammu & Kashmir vs Punjab
2018-01-12 - club - SMA - male - 1130695 - Jammu & Kashmir vs Delhi
2018-01-09 - club - SMA - male - 1130678 - Himachal vs Jammu & Kashmir
2018-01-08 - club - SMA - male - 1130669 - Jammu & Kashmir vs Services
2016-01-10 - club - SMA - male - 902233 - Rajasthan vs Jammu & Kashmir
2016-01-07 - club - SMA - male - 902189 - Jharkhand vs Jammu & Kashmir
2016-01-06 - club - SMA - male - 902169 - Jammu & Kashmir vs Tripura
2016-01-04 - club - SMA - male - 902141 - Saurashtra vs Jammu & Kashmir
2016-01-03 - club - SMA - male - 902117 - Jammu & Kashmir vs Punjab
2016-01-02 - club - SMA - male - 902095 - Jammu & Kashmir vs Kerala
