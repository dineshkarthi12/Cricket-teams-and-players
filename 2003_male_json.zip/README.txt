This zip archive contains data files from Cricsheet in JSON format. This
archive contains 139 matches of all types from 2003.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/2003_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2003-12-18 - international - Test - male - 64058 - England vs Sri Lanka
2003-12-12 - international - Test - male - 64063 - South Africa vs West Indies
2003-12-05 - international - ODI - male - 64855 - New Zealand vs Pakistan
2003-12-04 - international - Test - male - 64059 - Australia vs India
2003-12-01 - international - ODI - male - 64853 - Pakistan vs New Zealand
2003-11-30 - international - ODI - male - 64852 - Zimbabwe vs West Indies
2003-11-29 - international - ODI - male - 64851 - West Indies vs Zimbabwe
2003-11-29 - international - ODI - male - 64850 - New Zealand vs Pakistan
2003-11-26 - international - ODI - male - 64849 - Zimbabwe vs West Indies
2003-11-23 - international - ODI - male - 64848 - West Indies vs Zimbabwe
2003-11-18 - international - ODI - male - 64846 - England vs Sri Lanka
2003-11-15 - international - ODI - male - 66372 - India vs New Zealand
2003-11-12 - international - Test - male - 64055 - West Indies vs Zimbabwe
2003-11-12 - international - ODI - male - 64845 - Bangladesh vs England
2003-11-10 - international - ODI - male - 64844 - Bangladesh vs England
2003-11-07 - international - ODI - male - 64843 - Bangladesh vs England
2003-11-06 - international - ODI - male - 66369 - India vs New Zealand
2003-11-03 - international - ODI - male - 66368 - New Zealand vs Australia
2003-11-01 - international - ODI - male - 66367 - Australia vs India
2003-10-29 - international - Test - male - 64053 - England vs Bangladesh
2003-10-29 - international - ODI - male - 66366 - New Zealand vs Australia
2003-10-26 - international - ODI - male - 66365 - India vs Australia
2003-10-24 - international - Test - male - 64051 - South Africa vs Pakistan
2003-10-23 - international - ODI - male - 66364 - India vs New Zealand
2003-10-21 - international - Test - male - 64052 - Bangladesh vs England
2003-10-17 - international - Test - male - 64050 - South Africa vs Pakistan
2003-10-17 - international - Test - male - 64049 - Zimbabwe vs Australia
2003-10-16 - international - Test - male - 64047 - New Zealand vs India
2003-10-12 - international - ODI - male - 64842 - Pakistan vs South Africa
2003-10-10 - international - ODI - male - 64841 - Pakistan vs South Africa
2003-10-09 - international - Test - male - 64048 - Australia vs Zimbabwe
2003-10-07 - international - ODI - male - 64840 - Pakistan vs South Africa
2003-10-05 - international - ODI - male - 64839 - Pakistan vs South Africa
2003-10-03 - international - ODI - male - 64838 - Pakistan vs South Africa
2003-09-21 - international - ODI - male - 64837 - Pakistan vs Bangladesh
2003-09-18 - international - ODI - male - 64836 - Bangladesh vs Pakistan
2003-09-09 - international - ODI - male - 64833 - Pakistan vs Bangladesh
2003-09-04 - international - Test - male - 64042 - South Africa vs England
2003-09-03 - international - Test - male - 64045 - Bangladesh vs Pakistan
2003-08-21 - international - Test - male - 64041 - South Africa vs England
2003-08-14 - international - Test - male - 64040 - England vs South Africa
2003-08-06 - international - ODI - male - 64832 - Australia vs Bangladesh
2003-08-03 - international - ODI - male - 64831 - Bangladesh vs Australia
2003-08-02 - international - ODI - male - 64830 - Bangladesh vs Australia
2003-07-24 - international - Test - male - 64038 - South Africa vs England
2003-07-18 - international - Test - male - 64036 - Bangladesh vs Australia
2003-07-12 - international - ODI - male - 66302 - South Africa vs England
2003-07-10 - international - ODI - male - 66301 - Zimbabwe vs South Africa
2003-07-06 - international - ODI - male - 66299 - Zimbabwe vs England
2003-07-03 - international - ODI - male - 66297 - England vs South Africa
2003-07-01 - international - ODI - male - 66296 - England vs Zimbabwe
2003-06-29 - international - ODI - male - 66295 - South Africa vs Zimbabwe
2003-06-28 - international - ODI - male - 66294 - South Africa vs England
2003-06-26 - international - ODI - male - 66293 - England vs Zimbabwe
2003-06-22 - international - ODI - male - 65031 - Pakistan vs England
2003-06-20 - international - ODI - male - 65030 - Pakistan vs England
2003-06-17 - international - ODI - male - 65029 - England vs Pakistan
2003-06-11 - international - ODI - male - 64829 - Sri Lanka vs West Indies
2003-06-07 - international - ODI - male - 64827 - Sri Lanka vs West Indies
2003-06-01 - international - ODI - male - 64826 - Australia vs West Indies
2003-05-30 - international - ODI - male - 64825 - Australia vs West Indies
2003-05-23 - international - ODI - male - 66363 - Pakistan vs New Zealand
2003-05-19 - international - ODI - male - 66361 - New Zealand vs Sri Lanka
2003-05-17 - international - ODI - male - 64820 - Australia vs West Indies
2003-05-11 - international - ODI - male - 66358 - Pakistan vs New Zealand
2003-05-10 - international - ODI - male - 66357 - Pakistan vs Sri Lanka
2003-05-09 - international - Test - male - 64027 - Australia vs West Indies
2003-04-21 - international - ODI - male - 66356 - India vs South Africa
2003-04-10 - international - ODI - male - 65809 - Zimbabwe vs Pakistan
2003-04-08 - international - ODI - male - 65808 - Pakistan vs Kenya
2003-04-07 - international - ODI - male - 65807 - Sri Lanka vs Zimbabwe
2003-04-06 - international - ODI - male - 65806 - Sri Lanka vs Kenya
2003-04-05 - international - ODI - male - 65805 - Kenya vs Zimbabwe
2003-04-04 - international - ODI - male - 65804 - Sri Lanka vs Pakistan
2003-04-03 - international - ODI - male - 65803 - Pakistan vs Zimbabwe
2003-03-23 - international - ODI - male - 65286 - Australia vs India
2003-03-20 - international - ODI - male - 65285 - India vs Kenya
2003-03-18 - international - ODI - male - 65284 - Australia vs Sri Lanka
2003-03-15 - international - ODI - male - 65283 - Kenya vs Australia
2003-03-15 - international - ODI - male - 65282 - Sri Lanka vs Zimbabwe
2003-03-14 - international - ODI - male - 65281 - New Zealand vs India
2003-03-12 - international - ODI - male - 65280 - Zimbabwe vs Kenya
2003-03-11 - international - ODI - male - 65279 - Australia vs New Zealand
2003-03-10 - international - ODI - male - 65278 - India vs Sri Lanka
2003-03-08 - international - ODI - male - 65277 - Zimbabwe vs New Zealand
2003-03-07 - international - ODI - male - 65276 - Kenya vs India
2003-03-07 - international - ODI - male - 65275 - Australia vs Sri Lanka
2003-03-04 - international - ODI - male - 65273 - Pakistan vs Zimbabwe
2003-03-03 - international - ODI - male - 65272 - Sri Lanka vs South Africa
2003-03-03 - international - ODI - male - 65271 - Netherlands vs Namibia
2003-03-03 - international - ODI - male - 65270 - Canada vs New Zealand
2003-03-02 - international - ODI - male - 65269 - England vs Australia
2003-03-01 - international - ODI - male - 65268 - Pakistan vs India
2003-03-01 - international - ODI - male - 65267 - Kenya vs Bangladesh
2003-02-28 - international - ODI - male - 65266 - Sri Lanka vs West Indies
2003-02-28 - international - ODI - male - 65265 - Zimbabwe vs Netherlands
2003-02-27 - international - ODI - male - 65264 - South Africa vs Canada
2003-02-27 - international - ODI - male - 65263 - Australia vs Namibia
2003-02-26 - international - ODI - male - 65262 - India vs England
2003-02-26 - international - ODI - male - 65261 - Bangladesh vs New Zealand
2003-02-25 - international - ODI - male - 65260 - Pakistan vs Netherlands
2003-02-24 - international - ODI - male - 65259 - Zimbabwe vs Australia
2003-02-24 - international - ODI - male - 65258 - Kenya vs Sri Lanka
2003-02-23 - international - ODI - male - 65257 - India vs Namibia
2003-02-23 - international - ODI - male - 65256 - Canada vs West Indies
2003-02-22 - international - ODI - male - 65255 - England vs Pakistan
2003-02-22 - international - ODI - male - 65254 - Bangladesh vs South Africa
2003-02-19 - international - ODI - male - 65252 - England vs Namibia
2003-02-19 - international - ODI - male - 65251 - Canada vs Sri Lanka
2003-02-19 - international - ODI - male - 65250 - India vs Zimbabwe
2003-02-18 - international - ODI - male - 65249 - West Indies vs Bangladesh
2003-02-16 - international - ODI - male - 65248 - South Africa vs New Zealand
2003-02-16 - international - ODI - male - 65247 - Pakistan vs Namibia
2003-02-16 - international - ODI - male - 65246 - Netherlands vs England
2003-02-15 - international - ODI - male - 65245 - Canada vs Kenya
2003-02-15 - international - ODI - male - 65244 - India vs Australia
2003-02-13 - international - ODI - male - 65242 - New Zealand vs West Indies
2003-02-12 - international - ODI - male - 65241 - India vs Netherlands
2003-02-12 - international - ODI - male - 65240 - Kenya vs South Africa
2003-02-11 - international - ODI - male - 65239 - Canada vs Bangladesh
2003-02-11 - international - ODI - male - 65238 - Australia vs Pakistan
2003-02-10 - international - ODI - male - 65237 - Sri Lanka vs New Zealand
2003-02-10 - international - ODI - male - 65236 - Zimbabwe vs Namibia
2003-02-09 - international - ODI - male - 65235 - West Indies vs South Africa
2003-01-25 - international - ODI - male - 65642 - Australia vs England
2003-01-23 - international - ODI - male - 65641 - England vs Australia
2003-01-21 - international - ODI - male - 65640 - Sri Lanka vs Australia
2003-01-19 - international - ODI - male - 65639 - England vs Australia
2003-01-17 - international - ODI - male - 65638 - England vs Sri Lanka
2003-01-15 - international - ODI - male - 65637 - Sri Lanka vs Australia
2003-01-14 - international - ODI - male - 64819 - India vs New Zealand
2003-01-13 - international - ODI - male - 65636 - Sri Lanka vs England
2003-01-11 - international - ODI - male - 65635 - Australia vs England
2003-01-09 - international - ODI - male - 65634 - Sri Lanka vs Australia
2003-01-08 - international - ODI - male - 64817 - New Zealand vs India
2003-01-04 - international - ODI - male - 64816 - India vs New Zealand
2003-01-02 - international - Test - male - 64023 - South Africa vs Pakistan
2003-01-02 - international - Test - male - 64013 - England vs Australia
2003-01-01 - international - ODI - male - 64815 - India vs New Zealand
