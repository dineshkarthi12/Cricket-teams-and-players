This zip archive contains data files from Cricsheet in YAML format. This
archive contains 31 Chhattisgarh matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/chhattisgarh_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-25 - club - SMA - male - 1383526 - Chhattisgarh vs Baroda
2023-10-19 - club - SMA - male - 1383472 - Chhattisgarh vs Hyderabad (India)
2023-10-17 - club - SMA - male - 1383453 - Haryana vs Chhattisgarh
2022-10-30 - club - SMA - male - 1333047 - Chhattisgarh vs Vidarbha
2021-11-09 - club - SMA - male - 1280278 - Chhattisgarh vs Services
2021-11-08 - club - SMA - male - 1280260 - Chhattisgarh vs Mumbai
2021-11-06 - club - SMA - male - 1280241 - Chhattisgarh vs Baroda
2021-11-05 - club - SMA - male - 1280220 - Chhattisgarh vs Karnataka
2021-11-04 - club - SMA - male - 1280201 - Chhattisgarh vs Bengal
2021-01-18 - club - SMA - male - 1244389 - Uttarakhand vs Chhattisgarh
2021-01-16 - club - SMA - male - 1244371 - Chhattisgarh vs Gujarat
2021-01-14 - club - SMA - male - 1244350 - Chhattisgarh vs Baroda
2021-01-12 - club - SMA - male - 1244331 - Chhattisgarh vs Maharashtra
2021-01-10 - club - SMA - male - 1244313 - Himachal vs Chhattisgarh
2019-11-15 - club - SMA - male - 1205809 - Punjab vs Chhattisgarh
2019-11-14 - club - SMA - male - 1205790 - Chhattisgarh vs Chandigarh
2019-11-12 - club - SMA - male - 1205773 - Chhattisgarh vs Maharashtra
2019-11-11 - club - SMA - male - 1205754 - Chhattisgarh vs Railways
2019-11-09 - club - SMA - male - 1205737 - Himachal vs Chhattisgarh
2019-11-08 - club - SMA - male - 1205718 - Arunachal Pradesh vs Chhattisgarh
2019-03-02 - club - SMA - male - 1157203 - Chhattisgarh vs Mizoram
2019-02-28 - club - SMA - male - 1157186 - Bengal vs Chhattisgarh
2019-02-27 - club - SMA - male - 1157169 - Chhattisgarh vs Karnataka
2019-02-25 - club - SMA - male - 1157152 - Haryana vs Chhattisgarh
2019-02-24 - club - SMA - male - 1157134 - Chhattisgarh vs Assam
2019-02-21 - club - SMA - male - 1157101 - Odisha vs Chhattisgarh
2018-01-16 - club - SMA - male - 1130724 - Chhattisgarh vs Uttar Pradesh
2018-01-14 - club - SMA - male - 1130709 - Chhattisgarh vs Madhya Pradesh
2018-01-12 - club - SMA - male - 1130698 - Chhattisgarh vs Rajasthan
2018-01-10 - club - SMA - male - 1130685 - Chhattisgarh vs Railways
2018-01-08 - club - SMA - male - 1130668 - Vidarbha vs Chhattisgarh
