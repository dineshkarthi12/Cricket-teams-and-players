This zip archive contains data files from Cricsheet in JSON format. This
archive contains 26 Manipur matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/manipur_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-23 - club - SMA - male - 1383517 - Andhra vs Manipur
2023-10-21 - club - SMA - male - 1383496 - Manipur vs Punjab
2023-10-16 - club - SMA - male - 1383445 - Manipur vs Railways
2022-10-20 - club - SMA - male - 1333013 - Manipur vs Tripura
2022-10-18 - club - SMA - male - 1332993 - Manipur vs Punjab
2021-11-09 - club - SMA - male - 1280290 - Manipur vs Mizoram
2021-11-08 - club - SMA - male - 1280273 - Vidarbha vs Manipur
2021-11-06 - club - SMA - male - 1280251 - Tripura vs Manipur
2021-11-05 - club - SMA - male - 1280234 - Arunachal Pradesh vs Manipur
2021-01-19 - club - SMA - male - 1244400 - Manipur vs Nagaland
2021-01-17 - club - SMA - male - 1244378 - Manipur vs Bihar
2021-01-15 - club - SMA - male - 1244362 - Manipur vs Arunachal Pradesh
2021-01-13 - club - SMA - male - 1244341 - Chandigarh vs Manipur
2021-01-11 - club - SMA - male - 1244322 - Meghalaya vs Manipur
2019-11-15 - club - SMA - male - 1205807 - Manipur vs Uttar Pradesh
2019-11-14 - club - SMA - male - 1205797 - Manipur vs Tamil Nadu
2019-11-12 - club - SMA - male - 1205770 - Kerala vs Manipur
2019-11-11 - club - SMA - male - 1205752 - Vidarbha vs Manipur
2019-11-09 - club - SMA - male - 1205734 - Manipur vs Tripura
2019-11-08 - club - SMA - male - 1205725 - Rajasthan vs Manipur
2019-03-02 - club - SMA - male - 1157195 - Andhra vs Manipur
2019-02-28 - club - SMA - male - 1157178 - Manipur vs Jammu & Kashmir
2019-02-25 - club - SMA - male - 1157144 - Nagaland vs Manipur
2019-02-24 - club - SMA - male - 1157126 - Jharkhand vs Manipur
2019-02-22 - club - SMA - male - 1157108 - Manipur vs Delhi
2019-02-21 - club - SMA - male - 1157092 - Kerala vs Manipur
