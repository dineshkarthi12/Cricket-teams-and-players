This zip archive contains data files from Cricsheet in JSON format. This
archive contains 20 Sharjah Warriors matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/sharjah_warriors_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2024-02-11 - club - ILT - male - 1406918 - Sharjah Warriors vs Desert Vipers
2024-02-07 - club - ILT - male - 1406913 - Abu Dhabi Knight Riders vs Sharjah Warriors
2024-02-05 - club - ILT - male - 1406911 - Sharjah Warriors vs Abu Dhabi Knight Riders
2024-02-04 - club - ILT - male - 1406910 - Gulf Giants vs Sharjah Warriors
2024-02-02 - club - ILT - male - 1406906 - Sharjah Warriors vs MI Emirates
2024-01-29 - club - ILT - male - 1406902 - Dubai Capitals vs Sharjah Warriors
2024-01-28 - club - ILT - male - 1406901 - Sharjah Warriors vs Desert Vipers
2024-01-26 - club - ILT - male - 1406897 - MI Emirates vs Sharjah Warriors
2024-01-22 - club - ILT - male - 1406893 - Dubai Capitals vs Sharjah Warriors
2024-01-19 - club - ILT - male - 1406889 - Gulf Giants vs Sharjah Warriors
2023-02-06 - club - ILT - male - 1346945 - Sharjah Warriors vs Gulf Giants
2023-02-04 - club - ILT - male - 1346943 - Sharjah Warriors vs Abu Dhabi Knight Riders
2023-01-31 - club - ILT - male - 1346938 - Desert Vipers vs Sharjah Warriors
2023-01-28 - club - ILT - male - 1346934 - Abu Dhabi Knight Riders vs Sharjah Warriors
2023-01-26 - club - ILT - male - 1346932 - Dubai Capitals vs Sharjah Warriors
2023-01-23 - club - ILT - male - 1346929 - Sharjah Warriors vs Gulf Giants
2023-01-21 - club - ILT - male - 1346925 - Dubai Capitals vs Sharjah Warriors
2023-01-17 - club - ILT - male - 1346921 - Sharjah Warriors vs MI Emirates
2023-01-15 - club - ILT - male - 1346919 - Sharjah Warriors vs Desert Vipers
2023-01-14 - club - ILT - male - 1346917 - MI Emirates vs Sharjah Warriors
