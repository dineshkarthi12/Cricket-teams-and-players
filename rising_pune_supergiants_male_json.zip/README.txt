This zip archive contains data files from Cricsheet in JSON format. This
archive contains 14 Rising Pune Supergiants matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/rising_pune_supergiants_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2016-05-21 - club - IPL - male - 981005 - Rising Pune Supergiants vs Kings XI Punjab
2016-05-17 - club - IPL - male - 980997 - Rising Pune Supergiants vs Delhi Daredevils
2016-05-14 - club - IPL - male - 980989 - Kolkata Knight Riders vs Rising Pune Supergiants
2016-05-10 - club - IPL - male - 980979 - Rising Pune Supergiants vs Sunrisers Hyderabad
2016-05-07 - club - IPL - male - 980969 - Royal Challengers Bangalore vs Rising Pune Supergiants
2016-05-05 - club - IPL - male - 980965 - Delhi Daredevils vs Rising Pune Supergiants
2016-05-01 - club - IPL - male - 980957 - Rising Pune Supergiants vs Mumbai Indians
2016-04-29 - club - IPL - male - 980949 - Rising Pune Supergiants vs Gujarat Lions
2016-04-26 - club - IPL - male - 980943 - Sunrisers Hyderabad vs Rising Pune Supergiants
2016-04-24 - club - IPL - male - 980939 - Rising Pune Supergiants vs Kolkata Knight Riders
2016-04-22 - club - IPL - male - 980931 - Rising Pune Supergiants vs Royal Challengers Bangalore
2016-04-17 - club - IPL - male - 980919 - Kings XI Punjab vs Rising Pune Supergiants
2016-04-14 - club - IPL - male - 980911 - Gujarat Lions vs Rising Pune Supergiants
2016-04-09 - club - IPL - male - 980901 - Mumbai Indians vs Rising Pune Supergiants
