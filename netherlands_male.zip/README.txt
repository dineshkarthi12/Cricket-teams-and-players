This zip archive contains data files from Cricsheet in YAML format. This
archive contains 247 Netherlands matches of all types. A further 10 matches
have been withheld due to either featuring the Afghanistan men's team or being
played in the Afghanistan Premier League, due to the Cricsheet policy to no
longer feature matches involving Afghanistan men or played in Afghanistan
Premier League (see https://cricsheet.org/withheld-matches for more
information).


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/netherlands_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-07-31 - international - ODI - male - 1544129 - Netherlands vs Namibia
2026-07-29 - international - ODI - male - 1544128 - Netherlands vs Nepal
2026-07-25 - international - ODI - male - 1544126 - Netherlands vs Namibia
2026-07-23 - international - ODI - male - 1544125 - Nepal vs Netherlands
2026-06-16 - international - ODI - male - 1538430 - Netherlands vs Canada
2026-06-10 - international - ODI - male - 1538427 - Netherlands vs Canada
2026-06-08 - international - ODI - male - 1538426 - Netherlands vs United States of America
2026-02-18 - international - T20 - male - 1512754 - India vs Netherlands
2026-02-13 - international - T20 - male - 1512739 - United States of America vs Netherlands
2026-02-10 - international - T20 - male - 1512728 - Namibia vs Netherlands
2026-02-07 - international - T20 - male - 1512719 - Netherlands vs Pakistan
2025-09-03 - international - T20 - male - 1498664 - Bangladesh vs Netherlands
2025-09-01 - international - T20 - male - 1498663 - Netherlands vs Bangladesh
2025-08-30 - international - T20 - male - 1498662 - Netherlands vs Bangladesh
2025-07-11 - international - T20 - male - 1490480 - Italy vs Netherlands
2025-07-09 - international - T20 - male - 1490478 - Netherlands vs Guernsey
2025-07-08 - international - T20 - male - 1490476 - Scotland vs Netherlands
2025-07-05 - international - T20 - male - 1490471 - Jersey vs Netherlands
2025-06-19 - international - T20 - male - 1485941 - Netherlands vs Nepal
2025-06-18 - international - T20 - male - 1485942 - Netherlands vs Scotland
2025-06-16 - international - T20 - male - 1485939 - Netherlands vs Nepal
2025-06-15 - international - T20 - male - 1485938 - Scotland vs Netherlands
2025-06-12 - international - ODI - male - 1486777 - Scotland vs Netherlands
2025-06-10 - international - ODI - male - 1486776 - Nepal vs Netherlands
2025-06-06 - international - ODI - male - 1486774 - Scotland vs Netherlands
2025-06-04 - international - ODI - male - 1486773 - Netherlands vs Nepal
2025-05-16 - international - ODI - male - 1481535 - Scotland vs Netherlands
2025-05-12 - international - ODI - male - 1481533 - United Arab Emirates vs Netherlands
2025-05-10 - international - ODI - male - 1481532 - Netherlands vs Scotland
2025-05-06 - international - ODI - male - 1481530 - Netherlands vs United Arab Emirates
2025-03-13 - international - ODI - male - 1474413 - Namibia vs Netherlands
2025-03-07 - international - ODI - male - 1474410 - Netherlands vs Namibia
2024-11-16 - international - T20 - male - 1454821 - Netherlands vs Oman
2024-11-14 - international - T20 - male - 1454820 - Netherlands vs Oman
2024-11-13 - international - T20 - male - 1454819 - Netherlands vs Oman
2024-11-11 - international - ODI - male - 1457469 - Oman vs Netherlands
2024-11-09 - international - ODI - male - 1457468 - Netherlands vs United Arab Emirates
2024-11-05 - international - ODI - male - 1457466 - Netherlands vs Oman
2024-11-03 - international - ODI - male - 1457465 - United Arab Emirates vs Netherlands
2024-08-28 - international - T20 - male - 1446766 - Netherlands vs United States of America
2024-08-26 - international - T20 - male - 1446764 - Canada vs Netherlands
2024-08-25 - international - T20 - male - 1446763 - Netherlands vs United States of America
2024-08-23 - international - T20 - male - 1446761 - Canada vs Netherlands
2024-08-21 - international - ODI - male - 1445039 - Netherlands vs United States of America
2024-08-17 - international - ODI - male - 1445037 - Netherlands vs Canada
2024-08-15 - international - ODI - male - 1445036 - Netherlands vs United States of America
2024-08-11 - international - ODI - male - 1445034 - Canada vs Netherlands
2024-06-16 - international - T20 - male - 1415738 - Sri Lanka vs Netherlands
2024-06-13 - international - T20 - male - 1415727 - Bangladesh vs Netherlands
2024-06-08 - international - T20 - male - 1415716 - Netherlands vs South Africa
2024-06-04 - international - T20 - male - 1415707 - Nepal vs Netherlands
2024-05-24 - international - T20 - male - 1428156 - Ireland vs Netherlands
2024-05-22 - international - T20 - male - 1428154 - Scotland vs Netherlands
2024-05-19 - international - T20 - male - 1428152 - Ireland vs Netherlands
2024-05-18 - international - T20 - male - 1428151 - Netherlands vs Scotland
2024-03-05 - international - T20 - male - 1422043 - Nepal vs Netherlands
2024-03-03 - international - T20 - male - 1422042 - Namibia vs Netherlands
2024-03-02 - international - T20 - male - 1422041 - Netherlands vs Nepal
2024-02-29 - international - T20 - male - 1422039 - Netherlands vs Namibia
2024-02-28 - international - T20 - male - 1422038 - Netherlands vs Nepal
2024-02-25 - international - ODI - male - 1420534 - Nepal vs Netherlands
2024-02-23 - international - ODI - male - 1420533 - Namibia vs Netherlands
2024-02-19 - international - ODI - male - 1420531 - Namibia vs Netherlands
2024-02-17 - international - ODI - male - 1420530 - Netherlands vs Nepal
2023-11-12 - international - ODI - male - 1384436 - India vs Netherlands
2023-11-08 - international - ODI - male - 1384431 - England vs Netherlands
2023-10-28 - international - ODI - male - 1384419 - Netherlands vs Bangladesh
2023-10-25 - international - ODI - male - 1384415 - Australia vs Netherlands
2023-10-21 - international - ODI - male - 1384410 - Netherlands vs Sri Lanka
2023-10-17 - international - ODI - male - 1384406 - Netherlands vs South Africa
2023-10-09 - international - ODI - male - 1384397 - New Zealand vs Netherlands
2023-10-06 - international - ODI - male - 1384393 - Pakistan vs Netherlands
2023-07-09 - international - ODI - male - 1377779 - Sri Lanka vs Netherlands
2023-07-06 - international - ODI - male - 1377776 - Scotland vs Netherlands
2023-07-03 - international - ODI - male - 1377772 - Netherlands vs Oman
2023-06-30 - international - ODI - male - 1377767 - Sri Lanka vs Netherlands
2023-06-26 - international - ODI - male - 1377763 - West Indies vs Netherlands
2023-06-24 - international - ODI - male - 1377759 - Nepal vs Netherlands
2023-06-22 - international - ODI - male - 1377755 - United States of America vs Netherlands
2023-06-20 - international - ODI - male - 1377750 - Netherlands vs Zimbabwe
2023-04-02 - international - ODI - male - 1339608 - South Africa vs Netherlands
2023-03-31 - international - ODI - male - 1339607 - Netherlands vs South Africa
2023-03-25 - international - ODI - male - 1362381 - Netherlands vs Zimbabwe
2023-03-23 - international - ODI - male - 1362380 - Zimbabwe vs Netherlands
2023-03-21 - international - ODI - male - 1362379 - Zimbabwe vs Netherlands
2022-11-06 - international - T20 - male - 1298174 - Netherlands vs South Africa
2022-11-02 - international - T20 - male - 1298168 - Zimbabwe vs Netherlands
2022-10-30 - international - T20 - male - 1298163 - Netherlands vs Pakistan
2022-10-27 - international - T20 - male - 1298157 - India vs Netherlands
2022-10-24 - international - T20 - male - 1298151 - Bangladesh vs Netherlands
2022-10-20 - international - T20 - male - 1298143 - Sri Lanka vs Netherlands
2022-10-18 - international - T20 - male - 1298139 - Namibia vs Netherlands
2022-10-16 - international - T20 - male - 1298136 - United Arab Emirates vs Netherlands
2022-08-21 - international - ODI - male - 1311739 - Pakistan vs Netherlands
2022-08-18 - international - ODI - male - 1311738 - Netherlands vs Pakistan
2022-08-16 - international - ODI - male - 1311737 - Pakistan vs Netherlands
2022-08-05 - international - T20 - male - 1310902 - Netherlands vs New Zealand
2022-08-04 - international - T20 - male - 1310901 - New Zealand vs Netherlands
2022-07-17 - international - T20 - male - 1321484 - Zimbabwe vs Netherlands
2022-07-15 - international - T20 - male - 1321480 - United States of America vs Netherlands
2022-07-14 - international - T20 - male - 1321473 - Netherlands vs Uganda
2022-07-12 - international - T20 - male - 1321471 - Hong Kong vs Netherlands
2022-07-11 - international - T20 - male - 1321467 - Netherlands vs Papua New Guinea
2022-06-22 - international - ODI - male - 1281446 - Netherlands vs England
2022-06-19 - international - ODI - male - 1281445 - Netherlands vs England
2022-06-17 - international - ODI - male - 1281444 - England vs Netherlands
2022-06-04 - international - ODI - male - 1302351 - West Indies vs Netherlands
2022-06-02 - international - ODI - male - 1302350 - Netherlands vs West Indies
2022-05-31 - international - ODI - male - 1302349 - Netherlands vs West Indies
2022-04-04 - international - ODI - male - 1288989 - New Zealand vs Netherlands
2022-04-02 - international - ODI - male - 1288988 - New Zealand vs Netherlands
2022-03-29 - international - ODI - male - 1288987 - Netherlands vs New Zealand
2021-11-26 - international - ODI - male - 1277073 - South Africa vs Netherlands
2021-10-22 - international - T20 - male - 1273723 - Netherlands vs Sri Lanka
2021-10-20 - international - T20 - male - 1273718 - Netherlands vs Namibia
2021-10-18 - international - T20 - male - 1273714 - Netherlands vs Ireland
2021-06-07 - international - ODI - male - 1251964 - Ireland vs Netherlands
2021-06-04 - international - ODI - male - 1251963 - Netherlands vs Ireland
2021-06-02 - international - ODI - male - 1251962 - Netherlands vs Ireland
2021-05-20 - international - ODI - male - 1260085 - Netherlands vs Scotland
2021-05-19 - international - ODI - male - 1260084 - Netherlands vs Scotland
2021-04-24 - international - T20 - male - 1257951 - Nepal vs Netherlands
2021-04-21 - international - T20 - male - 1257949 - Netherlands vs Malaysia
2021-04-20 - international - T20 - male - 1257948 - Nepal vs Netherlands
2021-04-18 - international - T20 - male - 1257946 - Netherlands vs Malaysia
2021-04-17 - international - T20 - male - 1257945 - Netherlands vs Nepal
2019-11-02 - international - T20 - male - 1199549 - Netherlands vs Papua New Guinea
2019-11-01 - international - T20 - male - 1199546 - Ireland vs Netherlands
2019-10-29 - international - T20 - male - 1199541 - United Arab Emirates vs Netherlands
2019-10-27 - international - T20 - male - 1199539 - Netherlands vs Scotland
2019-10-26 - international - T20 - male - 1199534 - Bermuda vs Netherlands
2019-10-24 - international - T20 - male - 1199525 - Netherlands vs Papua New Guinea
2019-10-22 - international - T20 - male - 1199518 - Netherlands vs Singapore
2019-10-19 - international - T20 - male - 1199505 - Namibia vs Netherlands
2019-10-18 - international - T20 - male - 1199501 - Kenya vs Netherlands
2019-10-10 - international - T20 - male - 1197528 - Hong Kong vs Netherlands
2019-10-09 - international - T20 - male - 1197527 - Oman vs Netherlands
2019-10-07 - international - T20 - male - 1197524 - Nepal vs Netherlands
2019-10-05 - international - T20 - male - 1197521 - Ireland vs Netherlands
2019-09-19 - international - T20 - male - 1200428 - Netherlands vs Scotland
2019-09-18 - international - T20 - male - 1200427 - Ireland vs Netherlands
2019-09-16 - international - T20 - male - 1200425 - Netherlands vs Scotland
2019-08-08 - international - T20 - male - 1191008 - Netherlands vs United Arab Emirates
2019-08-05 - international - T20 - male - 1191006 - Netherlands vs United Arab Emirates
2019-06-25 - international - T20 - male - 1188380 - Netherlands vs Zimbabwe
2019-06-23 - international - T20 - male - 1188379 - Netherlands vs Zimbabwe
2019-06-21 - international - ODI - male - 1188378 - Netherlands vs Zimbabwe
2019-06-19 - international - ODI - male - 1188377 - Netherlands vs Zimbabwe
2019-02-17 - international - T20 - male - 1172509 - Ireland vs Netherlands
2019-02-15 - international - T20 - male - 1172507 - Oman vs Netherlands
2019-02-13 - international - T20 - male - 1172505 - Netherlands vs Scotland
2018-07-29 - international - T20 - male - 1141835 - Netherlands vs Nepal
2018-06-20 - international - T20 - male - 1142506 - Scotland vs Netherlands
2018-06-19 - international - T20 - male - 1142505 - Netherlands vs Scotland
2018-06-13 - international - T20 - male - 1142502 - Ireland vs Netherlands
2018-06-12 - international - T20 - male - 1142501 - Netherlands vs Ireland
2018-03-17 - international - ODM - male - 1133024 - Netherlands vs Nepal
2018-03-15 - international - ODM - male - 1133021 - Netherlands vs Hong Kong
2018-03-12 - international - ODM - male - 1133014 - West Indies vs Netherlands
2018-03-10 - international - ODM - male - 1133011 - Papua New Guinea vs Netherlands
2018-03-08 - international - ODM - male - 1133006 - Netherlands vs United Arab Emirates
2018-03-04 - international - ODM - male - 1132999 - Ireland vs Netherlands
2017-10-08 - international - ODM - male - 1105008 - Netherlands vs Kenya
2017-10-06 - international - ODM - male - 1105007 - Kenya vs Netherlands
2017-08-15 - international - MDM - male - 1105000 - Ireland vs Netherlands
2017-02-18 - international - ODM - male - 1068732 - Hong Kong vs Netherlands
2017-02-16 - international - ODM - male - 1068731 - Hong Kong vs Netherlands
2017-02-10 - international - MDM - male - 1068730 - Hong Kong vs Netherlands
2017-01-18 - international - T20 - male - 1074966 - Hong Kong vs Netherlands
2017-01-17 - international - T20 - male - 1074964 - Netherlands vs Scotland
2017-01-15 - international - T20 - male - 1074959 - Netherlands vs Oman
2016-08-13 - international - ODM - male - 1004261 - Netherlands vs Nepal
2016-03-13 - international - T20 - male - 951325 - Ireland vs Netherlands
2016-03-09 - international - T20 - male - 951309 - Bangladesh vs Netherlands
2016-02-03 - international - T20 - male - 967081 - United Arab Emirates vs Netherlands
2016-01-29 - international - ODM - male - 952191 - United Arab Emirates vs Netherlands
2016-01-27 - international - ODM - male - 952189 - United Arab Emirates vs Netherlands
2015-09-14 - international - ODM - male - 911037 - Netherlands vs Scotland
2015-07-25 - international - T20 - male - 875553 - Ireland vs Netherlands
2015-07-21 - international - IT20 - male - 875543 - Namibia vs Netherlands
2015-07-18 - international - IT20 - male - 875533 - Kenya vs Netherlands
2015-07-17 - international - IT20 - male - 875517 - Canada vs Netherlands
2015-07-14 - international - IT20 - male - 875495 - Netherlands vs Oman
2015-07-12 - international - T20 - male - 875481 - Netherlands vs United Arab Emirates
2015-07-11 - international - T20 - male - 875471 - Scotland vs Netherlands
2015-07-02 - international - T20 - male - 883345 - Netherlands vs Nepal
2015-07-01 - international - T20 - male - 883343 - Netherlands vs Nepal
2015-06-24 - international - ODM - male - 870887 - Netherlands vs Papua New Guinea
2015-01-24 - international - ODM - male - 812809 - Namibia vs Netherlands
2015-01-23 - international - ODM - male - 812799 - Netherlands vs Uganda
2015-01-20 - international - ODM - male - 812791 - Namibia vs Netherlands
2015-01-18 - international - ODM - male - 812783 - Netherlands vs Nepal
2015-01-17 - international - ODM - male - 812777 - Canada vs Netherlands
2014-03-31 - international - T20 - male - 682953 - England vs Netherlands
2014-03-29 - international - T20 - male - 682945 - Netherlands vs New Zealand
2014-03-27 - international - T20 - male - 682937 - Netherlands vs South Africa
2014-03-24 - international - T20 - male - 682933 - Netherlands vs Sri Lanka
2014-03-21 - international - T20 - male - 682919 - Ireland vs Netherlands
2014-03-19 - international - T20 - male - 682909 - Netherlands vs Zimbabwe
2014-03-17 - international - T20 - male - 682903 - Netherlands vs United Arab Emirates
2014-01-28 - international - ODI - male - 696747 - Canada vs Netherlands
2014-01-23 - international - ODI - male - 696733 - Netherlands vs Kenya
2013-11-28 - international - T20 - male - 660223 - Netherlands vs Scotland
2013-11-27 - international - IT20 - male - 660217 - United Arab Emirates vs Netherlands
2013-11-23 - international - T20 - male - 660185 - Kenya vs Netherlands
2013-11-22 - international - T20 - male - 660173 - Netherlands vs Scotland
2013-11-20 - international - IT20 - male - 660159 - Netherlands vs Nepal
2013-11-19 - international - IT20 - male - 660143 - Denmark vs Netherlands
2013-08-29 - international - ODI - male - 660827 - Canada vs Netherlands
2013-08-27 - international - ODI - male - 660825 - Canada vs Netherlands
2013-07-07 - international - ODI - male - 631138 - Netherlands vs Ireland
2013-04-20 - international - T20 - male - 592276 - Kenya vs Netherlands
2013-04-19 - international - T20 - male - 630951 - Kenya vs Netherlands
2013-04-18 - international - ODM - male - 592275 - Namibia vs Netherlands
2013-04-16 - international - ODM - male - 592274 - Netherlands vs Namibia
2012-07-26 - international - T20 - male - 573672 - Netherlands vs Bangladesh
2012-07-25 - international - T20 - male - 567205 - Netherlands vs Bangladesh
2012-03-23 - international - T20 - male - 546470 - Ireland vs Netherlands
2012-03-13 - international - T20 - male - 546410 - Canada vs Netherlands
2011-06-29 - international - ODI - male - 504779 - Scotland vs Netherlands
2011-03-18 - international - ODI - male - 433595 - Ireland vs Netherlands
2011-03-14 - international - ODI - male - 433590 - Bangladesh vs Netherlands
2011-03-09 - international - ODI - male - 433582 - India vs Netherlands
2011-03-03 - international - ODI - male - 433573 - Netherlands vs South Africa
2011-02-28 - international - ODI - male - 433569 - Netherlands vs West Indies
2011-02-22 - international - ODI - male - 433562 - England vs Netherlands
2010-08-18 - international - ODI - male - 464720 - Ireland vs Netherlands
2010-02-20 - international - MDM - male - 438938 - Netherlands vs Kenya
2010-02-13 - international - T20 - male - 439510 - Ireland vs Netherlands
2010-02-09 - international - T20 - male - 439497 - Canada vs Netherlands
2009-06-09 - international - T20 - male - 355999 - Netherlands vs Pakistan
2009-06-05 - international - T20 - male - 355991 - England vs Netherlands
2008-08-04 - international - T20 - male - 361531 - Netherlands vs Scotland
2008-07-29 - international - ODI - male - 325579 - Netherlands vs Scotland
2007-07-13 - international - ODI - male - 295785 - Netherlands vs Scotland
2007-03-22 - international - ODI - male - 247474 - Netherlands vs Scotland
2007-03-18 - international - ODI - male - 247466 - Australia vs Netherlands
2007-03-16 - international - ODI - male - 247462 - Netherlands vs South Africa
2007-02-04 - international - ODI - male - 267387 - Bermuda vs Netherlands
2006-12-05 - international - MDM - male - 247219 - Canada vs Netherlands
2006-12-02 - international - ODI - male - 259389 - Bermuda vs Netherlands
2006-12-01 - international - ODI - male - 259391 - Canada vs Netherlands
2003-03-03 - international - ODI - male - 65271 - Netherlands vs Namibia
2003-02-28 - international - ODI - male - 65265 - Zimbabwe vs Netherlands
2003-02-25 - international - ODI - male - 65260 - Pakistan vs Netherlands
2003-02-16 - international - ODI - male - 65246 - Netherlands vs England
2003-02-12 - international - ODI - male - 65241 - India vs Netherlands
