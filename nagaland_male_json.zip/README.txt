This zip archive contains data files from Cricsheet in JSON format. This
archive contains 25 Nagaland matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/nagaland_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-21 - club - SMA - male - 1383504 - Uttar Pradesh vs Nagaland
2023-10-17 - club - SMA - male - 1383469 - Nagaland vs Tripura
2022-10-22 - club - SMA - male - 1333041 - Nagaland vs Himachal Pradesh
2022-10-16 - club - SMA - male - 1332987 - Nagaland vs Andhra
2022-10-12 - club - SMA - male - 1332952 - Nagaland vs Bihar
2022-10-11 - club - SMA - male - 1332934 - Nagaland vs Baroda
2021-11-09 - club - SMA - male - 1280289 - Nagaland vs Tripura
2021-11-08 - club - SMA - male - 1280271 - Nagaland vs Arunachal Pradesh
2021-11-05 - club - SMA - male - 1280233 - Nagaland vs Vidarbha
2021-01-19 - club - SMA - male - 1244400 - Manipur vs Nagaland
2021-01-17 - club - SMA - male - 1244381 - Nagaland vs Mizoram
2021-01-15 - club - SMA - male - 1244361 - Nagaland vs Sikkim
2021-01-13 - club - SMA - male - 1244343 - Arunachal Pradesh vs Nagaland
2019-11-17 - club - SMA - male - 1205839 - Odisha vs Nagaland
2019-11-15 - club - SMA - male - 1205820 - Nagaland vs Jammu & Kashmir
2019-11-14 - club - SMA - male - 1205802 - Nagaland vs Jharkhand
2019-11-11 - club - SMA - male - 1205758 - Nagaland vs Delhi
2019-11-09 - club - SMA - male - 1205749 - Sikkim vs Nagaland
2019-11-08 - club - SMA - male - 1205731 - Nagaland vs Saurashtra
2019-03-02 - club - SMA - male - 1157193 - Nagaland vs Delhi
2019-02-28 - club - SMA - male - 1157177 - Nagaland vs Kerala
2019-02-27 - club - SMA - male - 1157160 - Jharkhand vs Nagaland
2019-02-25 - club - SMA - male - 1157144 - Nagaland vs Manipur
2019-02-22 - club - SMA - male - 1157110 - Andhra vs Nagaland
2019-02-21 - club - SMA - male - 1157093 - Nagaland vs Jammu & Kashmir
