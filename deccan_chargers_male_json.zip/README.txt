This zip archive contains data files from Cricsheet in JSON format. This
archive contains 75 Deccan Chargers matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/deccan_chargers_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2012-05-20 - club - IPL - male - 548376 - Deccan Chargers vs Royal Challengers Bangalore
2012-05-18 - club - IPL - male - 548373 - Deccan Chargers vs Rajasthan Royals
2012-05-13 - club - IPL - male - 548366 - Kings XI Punjab vs Deccan Chargers
2012-05-10 - club - IPL - male - 548329 - Deccan Chargers vs Delhi Daredevils
2012-05-08 - club - IPL - male - 548359 - Deccan Chargers vs Kings XI Punjab
2012-05-06 - club - IPL - male - 548356 - Royal Challengers Bangalore vs Deccan Chargers
2012-05-04 - club - IPL - male - 548352 - Chennai Super Kings vs Deccan Chargers
2012-05-01 - club - IPL - male - 548348 - Deccan Chargers vs Pune Warriors
2012-04-29 - club - IPL - male - 548346 - Mumbai Indians vs Deccan Chargers
2012-04-26 - club - IPL - male - 548341 - Pune Warriors vs Deccan Chargers
2012-04-22 - club - IPL - male - 548335 - Deccan Chargers vs Kolkata Knight Riders
2012-04-19 - club - IPL - male - 548321 - Delhi Daredevils vs Deccan Chargers
2012-04-17 - club - IPL - male - 548326 - Rajasthan Royals vs Deccan Chargers
2012-04-09 - club - IPL - male - 548314 - Deccan Chargers vs Mumbai Indians
2012-04-07 - club - IPL - male - 548311 - Deccan Chargers vs Chennai Super Kings
2011-05-21 - club - IPL - male - 501264 - Kings XI Punjab vs Deccan Chargers
2011-05-16 - club - IPL - male - 501259 - Pune Warriors vs Deccan Chargers
2011-05-14 - club - IPL - male - 501256 - Mumbai Indians vs Deccan Chargers
2011-05-10 - club - IPL - male - 501250 - Deccan Chargers vs Pune Warriors
2011-05-05 - club - IPL - male - 501243 - Deccan Chargers vs Delhi Daredevils
2011-05-03 - club - IPL - male - 501239 - Deccan Chargers vs Kolkata Knight Riders
2011-05-01 - club - IPL - male - 501236 - Chennai Super Kings vs Deccan Chargers
2011-04-27 - club - IPL - male - 501229 - Kochi Tuskers Kerala vs Deccan Chargers
2011-04-24 - club - IPL - male - 501224 - Deccan Chargers vs Mumbai Indians
2011-04-19 - club - IPL - male - 501216 - Delhi Daredevils vs Deccan Chargers
2011-04-16 - club - IPL - male - 501212 - Deccan Chargers vs Kings XI Punjab
2011-04-14 - club - IPL - male - 501208 - Deccan Chargers vs Royal Challengers Bangalore
2011-04-11 - club - IPL - male - 501203 - Kolkata Knight Riders vs Deccan Chargers
2011-04-09 - club - IPL - male - 501199 - Deccan Chargers vs Rajasthan Royals
2010-04-24 - club - IPL - male - 419164 - Royal Challengers Bangalore vs Deccan Chargers
2010-04-22 - club - IPL - male - 419163 - Chennai Super Kings vs Deccan Chargers
2010-04-18 - club - IPL - male - 419160 - Delhi Daredevils vs Deccan Chargers
2010-04-16 - club - IPL - male - 419156 - Kings XI Punjab vs Deccan Chargers
2010-04-12 - club - IPL - male - 419151 - Deccan Chargers vs Royal Challengers Bangalore
2010-04-10 - club - IPL - male - 419147 - Deccan Chargers vs Chennai Super Kings
2010-04-08 - club - IPL - male - 419145 - Royal Challengers Bangalore vs Deccan Chargers
2010-04-05 - club - IPL - male - 419141 - Deccan Chargers vs Rajasthan Royals
2010-04-03 - club - IPL - male - 419138 - Mumbai Indians vs Deccan Chargers
2010-04-01 - club - IPL - male - 419135 - Kolkata Knight Riders vs Deccan Chargers
2010-03-28 - club - IPL - male - 419130 - Deccan Chargers vs Mumbai Indians
2010-03-26 - club - IPL - male - 419126 - Rajasthan Royals vs Deccan Chargers
2010-03-21 - club - IPL - male - 419120 - Deccan Chargers vs Delhi Daredevils
2010-03-19 - club - IPL - male - 419117 - Deccan Chargers vs Kings XI Punjab
2010-03-14 - club - IPL - male - 419110 - Chennai Super Kings vs Deccan Chargers
2010-03-12 - club - IPL - male - 419106 - Deccan Chargers vs Kolkata Knight Riders
2009-05-24 - club - IPL - male - 392239 - Royal Challengers Bangalore vs Deccan Chargers
2009-05-22 - club - IPL - male - 392237 - Delhi Daredevils vs Deccan Chargers
2009-05-21 - club - IPL - male - 392236 - Royal Challengers Bangalore vs Deccan Chargers
2009-05-17 - club - IPL - male - 392229 - Deccan Chargers vs Kings XI Punjab
2009-05-16 - club - IPL - male - 392228 - Deccan Chargers vs Kolkata Knight Riders
2009-05-13 - club - IPL - male - 392223 - Deccan Chargers vs Delhi Daredevils
2009-05-11 - club - IPL - male - 392220 - Deccan Chargers vs Rajasthan Royals
2009-05-09 - club - IPL - male - 392216 - Deccan Chargers vs Kings XI Punjab
2009-05-06 - club - IPL - male - 392212 - Deccan Chargers vs Mumbai Indians
2009-05-04 - club - IPL - male - 392209 - Chennai Super Kings vs Deccan Chargers
2009-05-02 - club - IPL - male - 392205 - Deccan Chargers vs Rajasthan Royals
2009-04-30 - club - IPL - male - 392201 - Deccan Chargers vs Delhi Daredevils
2009-04-27 - club - IPL - male - 392196 - Chennai Super Kings vs Deccan Chargers
2009-04-25 - club - IPL - male - 392192 - Deccan Chargers vs Mumbai Indians
2009-04-22 - club - IPL - male - 392188 - Royal Challengers Bangalore vs Deccan Chargers
2009-04-19 - club - IPL - male - 392184 - Deccan Chargers vs Kolkata Knight Riders
2008-05-27 - club - IPL - male - 336037 - Deccan Chargers vs Chennai Super Kings
2008-05-25 - club - IPL - male - 336002 - Deccan Chargers vs Royal Challengers Bangalore
2008-05-23 - club - IPL - male - 336031 - Kings XI Punjab vs Deccan Chargers
2008-05-18 - club - IPL - male - 336024 - Deccan Chargers vs Mumbai Indians
2008-05-15 - club - IPL - male - 336020 - Delhi Daredevils vs Deccan Chargers
2008-05-11 - club - IPL - male - 336014 - Deccan Chargers vs Kolkata Knight Riders
2008-05-09 - club - IPL - male - 336011 - Rajasthan Royals vs Deccan Chargers
2008-05-06 - club - IPL - male - 336007 - Chennai Super Kings vs Deccan Chargers
2008-05-03 - club - IPL - male - 336034 - Royal Challengers Bangalore vs Deccan Chargers
2008-05-01 - club - IPL - male - 335999 - Deccan Chargers vs Kings XI Punjab
2008-04-27 - club - IPL - male - 335994 - Mumbai Indians vs Deccan Chargers
2008-04-24 - club - IPL - male - 335990 - Deccan Chargers vs Rajasthan Royals
2008-04-22 - club - IPL - male - 335988 - Deccan Chargers vs Delhi Daredevils
2008-04-20 - club - IPL - male - 335986 - Kolkata Knight Riders vs Deccan Chargers
