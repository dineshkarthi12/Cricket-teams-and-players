This zip archive contains data files from Cricsheet in YAML format. This
archive contains 88 Punjab Kings matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/punjab_kings_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-05-23 - club - IPL - male - 1529311 - Lucknow Super Giants vs Punjab Kings
2026-05-17 - club - IPL - male - 1529304 - Royal Challengers Bengaluru vs Punjab Kings
2026-05-14 - club - IPL - male - 1529301 - Punjab Kings vs Mumbai Indians
2026-05-11 - club - IPL - male - 1529298 - Punjab Kings vs Delhi Capitals
2026-05-06 - club - IPL - male - 1529292 - Sunrisers Hyderabad vs Punjab Kings
2026-05-03 - club - IPL - male - 1529289 - Punjab Kings vs Gujarat Titans
2026-04-28 - club - IPL - male - 1529283 - Punjab Kings vs Rajasthan Royals
2026-04-25 - club - IPL - male - 1529278 - Delhi Capitals vs Punjab Kings
2026-04-19 - club - IPL - male - 1529272 - Punjab Kings vs Lucknow Super Giants
2026-04-16 - club - IPL - male - 1529267 - Mumbai Indians vs Punjab Kings
2026-04-11 - club - IPL - male - 1527690 - Sunrisers Hyderabad vs Punjab Kings
2026-04-06 - club - IPL - male - 1527685 - Kolkata Knight Riders vs Punjab Kings
2026-04-03 - club - IPL - male - 1527680 - Chennai Super Kings vs Punjab Kings
2026-03-31 - club - IPL - male - 1527677 - Gujarat Titans vs Punjab Kings
2025-06-03 - club - IPL - male - 1473511 - Royal Challengers Bengaluru vs Punjab Kings
2025-06-01 - club - IPL - male - 1473510 - Mumbai Indians vs Punjab Kings
2025-05-29 - club - IPL - male - 1473508 - Punjab Kings vs Royal Challengers Bengaluru
2025-05-26 - club - IPL - male - 1473506 - Mumbai Indians vs Punjab Kings
2025-05-24 - club - IPL - male - 1485779 - Punjab Kings vs Delhi Capitals
2025-05-18 - club - IPL - male - 1473497 - Punjab Kings vs Rajasthan Royals
2025-05-08 - club - IPL - male - 1473495 - Punjab Kings vs Delhi Capitals
2025-05-04 - club - IPL - male - 1473491 - Punjab Kings vs Lucknow Super Giants
2025-04-30 - club - IPL - male - 1473486 - Chennai Super Kings vs Punjab Kings
2025-04-26 - club - IPL - male - 1473481 - Punjab Kings vs Kolkata Knight Riders
2025-04-20 - club - IPL - male - 1473474 - Punjab Kings vs Royal Challengers Bengaluru
2025-04-18 - club - IPL - male - 1473471 - Royal Challengers Bengaluru vs Punjab Kings
2025-04-15 - club - IPL - male - 1473468 - Punjab Kings vs Kolkata Knight Riders
2025-04-12 - club - IPL - male - 1473464 - Punjab Kings vs Sunrisers Hyderabad
2025-04-08 - club - IPL - male - 1473459 - Punjab Kings vs Chennai Super Kings
2025-04-05 - club - IPL - male - 1473455 - Rajasthan Royals vs Punjab Kings
2025-04-01 - club - IPL - male - 1473450 - Lucknow Super Giants vs Punjab Kings
2025-03-25 - club - IPL - male - 1473442 - Punjab Kings vs Gujarat Titans
2024-05-19 - club - IPL - male - 1426307 - Punjab Kings vs Sunrisers Hyderabad
2024-05-15 - club - IPL - male - 1426303 - Rajasthan Royals vs Punjab Kings
2024-05-09 - club - IPL - male - 1426296 - Royal Challengers Bengaluru vs Punjab Kings
2024-05-05 - club - IPL - male - 1426291 - Chennai Super Kings vs Punjab Kings
2024-05-01 - club - IPL - male - 1426287 - Chennai Super Kings vs Punjab Kings
2024-04-26 - club - IPL - male - 1426280 - Kolkata Knight Riders vs Punjab Kings
2024-04-21 - club - IPL - male - 1426275 - Punjab Kings vs Gujarat Titans
2024-04-18 - club - IPL - male - 1426271 - Mumbai Indians vs Punjab Kings
2024-04-13 - club - IPL - male - 1426265 - Punjab Kings vs Rajasthan Royals
2024-04-09 - club - IPL - male - 1426261 - Sunrisers Hyderabad vs Punjab Kings
2024-04-04 - club - IPL - male - 1422135 - Gujarat Titans vs Punjab Kings
2024-03-30 - club - IPL - male - 1422129 - Lucknow Super Giants vs Punjab Kings
2024-03-25 - club - IPL - male - 1422124 - Punjab Kings vs Royal Challengers Bengaluru
2024-03-23 - club - IPL - male - 1422120 - Delhi Capitals vs Punjab Kings
2023-05-19 - club - IPL - male - 1359540 - Punjab Kings vs Rajasthan Royals
2023-05-17 - club - IPL - male - 1359538 - Delhi Capitals vs Punjab Kings
2023-05-13 - club - IPL - male - 1359533 - Punjab Kings vs Delhi Capitals
2023-05-08 - club - IPL - male - 1359527 - Punjab Kings vs Kolkata Knight Riders
2023-05-03 - club - IPL - male - 1359520 - Punjab Kings vs Mumbai Indians
2023-04-30 - club - IPL - male - 1359515 - Chennai Super Kings vs Punjab Kings
2023-04-28 - club - IPL - male - 1359512 - Lucknow Super Giants vs Punjab Kings
2023-04-22 - club - IPL - male - 1359505 - Punjab Kings vs Mumbai Indians
2023-04-20 - club - IPL - male - 1359501 - Royal Challengers Bangalore vs Punjab Kings
2023-04-15 - club - IPL - male - 1359495 - Lucknow Super Giants vs Punjab Kings
2023-04-13 - club - IPL - male - 1359492 - Punjab Kings vs Gujarat Titans
2023-04-09 - club - IPL - male - 1359488 - Punjab Kings vs Sunrisers Hyderabad
2023-04-05 - club - IPL - male - 1359482 - Punjab Kings vs Rajasthan Royals
2023-04-01 - club - IPL - male - 1359476 - Punjab Kings vs Kolkata Knight Riders
2022-05-22 - club - IPL - male - 1304116 - Sunrisers Hyderabad vs Punjab Kings
2022-05-16 - club - IPL - male - 1304110 - Delhi Capitals vs Punjab Kings
2022-05-13 - club - IPL - male - 1304106 - Punjab Kings vs Royal Challengers Bangalore
2022-05-07 - club - IPL - male - 1304098 - Punjab Kings vs Rajasthan Royals
2022-05-03 - club - IPL - male - 1304094 - Gujarat Titans vs Punjab Kings
2022-04-29 - club - IPL - male - 1304088 - Lucknow Super Giants vs Punjab Kings
2022-04-25 - club - IPL - male - 1304084 - Punjab Kings vs Chennai Super Kings
2022-04-20 - club - IPL - male - 1304078 - Punjab Kings vs Delhi Capitals
2022-04-17 - club - IPL - male - 1304074 - Punjab Kings vs Sunrisers Hyderabad
2022-04-13 - club - IPL - male - 1304069 - Punjab Kings vs Mumbai Indians
2022-04-08 - club - IPL - male - 1304062 - Punjab Kings vs Gujarat Titans
2022-04-03 - club - IPL - male - 1304057 - Punjab Kings vs Chennai Super Kings
2022-04-01 - club - IPL - male - 1304054 - Punjab Kings vs Kolkata Knight Riders
2022-03-27 - club - IPL - male - 1304049 - Royal Challengers Bangalore vs Punjab Kings
2021-10-07 - club - IPL - male - 1254094 - Chennai Super Kings vs Punjab Kings
2021-10-03 - club - IPL - male - 1254090 - Royal Challengers Bangalore vs Punjab Kings
2021-10-01 - club - IPL - male - 1254102 - Kolkata Knight Riders vs Punjab Kings
2021-09-28 - club - IPL - male - 1254099 - Punjab Kings vs Mumbai Indians
2021-09-25 - club - IPL - male - 1254107 - Punjab Kings vs Sunrisers Hyderabad
2021-09-21 - club - IPL - male - 1254111 - Rajasthan Royals vs Punjab Kings
2021-05-02 - club - IPL - male - 1254086 - Punjab Kings vs Delhi Capitals
2021-04-30 - club - IPL - male - 1254083 - Punjab Kings vs Royal Challengers Bangalore
2021-04-26 - club - IPL - male - 1254078 - Punjab Kings vs Kolkata Knight Riders
2021-04-23 - club - IPL - male - 1254074 - Mumbai Indians vs Punjab Kings
2021-04-21 - club - IPL - male - 1254071 - Punjab Kings vs Sunrisers Hyderabad
2021-04-18 - club - IPL - male - 1254068 - Punjab Kings vs Delhi Capitals
2021-04-16 - club - IPL - male - 1254065 - Punjab Kings vs Chennai Super Kings
2021-04-12 - club - IPL - male - 1254061 - Punjab Kings vs Rajasthan Royals
