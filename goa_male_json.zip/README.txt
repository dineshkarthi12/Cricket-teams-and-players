This zip archive contains data files from Cricsheet in JSON format. This
archive contains 37 Goa matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/goa_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-21 - club - SMA - male - 1383499 - Arunachal Pradesh vs Goa
2023-10-19 - club - SMA - male - 1383480 - Gujarat vs Goa
2022-10-22 - club - SMA - male - 1333031 - Puducherry vs Goa
2022-10-20 - club - SMA - male - 1333012 - Goa vs Delhi
2022-10-14 - club - SMA - male - 1332956 - Hyderabad (India) vs Goa
2021-11-09 - club - SMA - male - 1280275 - Maharashtra vs Goa
2021-11-08 - club - SMA - male - 1280255 - Tamil Nadu vs Goa
2021-11-06 - club - SMA - male - 1280236 - Punjab vs Goa
2021-11-05 - club - SMA - male - 1280219 - Goa vs Puducherry
2021-11-04 - club - SMA - male - 1280200 - Goa vs Odisha
2021-01-17 - club - SMA - male - 1244372 - Goa vs Rajasthan
2021-01-15 - club - SMA - male - 1244355 - Saurashtra vs Goa
2021-01-13 - club - SMA - male - 1244335 - Services vs Goa
2021-01-11 - club - SMA - male - 1244317 - Madhya Pradesh vs Goa
2019-11-17 - club - SMA - male - 1205823 - Karnataka vs Goa
2019-11-15 - club - SMA - male - 1205804 - Goa vs Andhra
2019-11-14 - club - SMA - male - 1205786 - Services vs Goa
2019-11-12 - club - SMA - male - 1205778 - Goa vs Uttarakhand
2019-11-09 - club - SMA - male - 1205733 - Goa vs Bihar
2019-11-08 - club - SMA - male - 1205724 - Baroda vs Goa
2019-03-02 - club - SMA - male - 1157201 - Goa vs Saurashtra
2019-02-28 - club - SMA - male - 1157182 - Punjab vs Goa
2019-02-27 - club - SMA - male - 1157165 - Goa vs Madhya Pradesh
2019-02-25 - club - SMA - male - 1157149 - Goa vs Mumbai
2019-02-24 - club - SMA - male - 1157133 - Goa vs Railways
2019-02-22 - club - SMA - male - 1157116 - Sikkim vs Goa
2018-01-14 - club - SMA - male - 1130715 - Andhra vs Goa
2018-01-12 - club - SMA - male - 1130696 - Goa vs Kerala
2018-01-11 - club - SMA - male - 1130692 - Tamil Nadu vs Goa
2018-01-09 - club - SMA - male - 1130679 - Hyderabad (India) vs Goa
2018-01-08 - club - SMA - male - 1130665 - Karnataka vs Goa
2016-01-10 - club - SMA - male - 902239 - Andhra vs Goa
2016-01-09 - club - SMA - male - 902219 - Delhi vs Goa
2016-01-07 - club - SMA - male - 902195 - Railways vs Goa
2016-01-06 - club - SMA - male - 902175 - Baroda vs Goa
2016-01-04 - club - SMA - male - 902147 - Goa vs Assam
2016-01-03 - club - SMA - male - 902123 - Goa vs Madhya Pradesh
