This zip archive contains data files from Cricsheet in JSON format. This
archive contains 23 Arunachal Pradesh matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/arunachal_pradesh_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-23 - club - SMA - male - 1383515 - Arunachal Pradesh vs Saurashtra
2023-10-21 - club - SMA - male - 1383499 - Arunachal Pradesh vs Goa
2021-11-09 - club - SMA - male - 1280292 - Meghalaya vs Arunachal Pradesh
2021-11-08 - club - SMA - male - 1280271 - Nagaland vs Arunachal Pradesh
2021-11-05 - club - SMA - male - 1280234 - Arunachal Pradesh vs Manipur
2021-11-04 - club - SMA - male - 1280213 - Vidarbha vs Arunachal Pradesh
2021-01-17 - club - SMA - male - 1244379 - Arunachal Pradesh vs Meghalaya
2021-01-15 - club - SMA - male - 1244362 - Manipur vs Arunachal Pradesh
2021-01-13 - club - SMA - male - 1244343 - Arunachal Pradesh vs Nagaland
2021-01-11 - club - SMA - male - 1244323 - Bihar vs Arunachal Pradesh
2019-11-17 - club - SMA - male - 1205826 - Arunachal Pradesh vs Chandigarh
2019-11-15 - club - SMA - male - 1205808 - Arunachal Pradesh vs Hyderabad (India)
2019-11-14 - club - SMA - male - 1205798 - Arunachal Pradesh vs Himachal
2019-11-12 - club - SMA - male - 1205772 - Arunachal Pradesh vs Railways
2019-11-11 - club - SMA - male - 1205762 - Arunachal Pradesh vs Maharashtra
2019-11-09 - club - SMA - male - 1205736 - Arunachal Pradesh vs Punjab
2019-11-08 - club - SMA - male - 1205718 - Arunachal Pradesh vs Chhattisgarh
2019-03-02 - club - SMA - male - 1157202 - Arunachal Pradesh vs Assam
2019-02-28 - club - SMA - male - 1157188 - Mizoram vs Arunachal Pradesh
2019-02-27 - club - SMA - male - 1157171 - Bengal vs Arunachal Pradesh
2019-02-25 - club - SMA - male - 1157153 - Arunachal Pradesh vs Odisha
2019-02-24 - club - SMA - male - 1157137 - Karnataka vs Arunachal Pradesh
2019-02-21 - club - SMA - male - 1157102 - Arunachal Pradesh vs Haryana
