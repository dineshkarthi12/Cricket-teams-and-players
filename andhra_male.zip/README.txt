This zip archive contains data files from Cricsheet in YAML format. This
archive contains 36 Andhra matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/andhra_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-23 - club - SMA - male - 1383517 - Andhra vs Manipur
2023-10-17 - club - SMA - male - 1383460 - Punjab vs Andhra
2022-10-20 - club - SMA - male - 1333022 - Andhra vs Gujarat
2022-10-18 - club - SMA - male - 1333006 - Bihar vs Andhra
2022-10-16 - club - SMA - male - 1332987 - Nagaland vs Andhra
2021-11-09 - club - SMA - male - 1280280 - Himachal vs Andhra
2021-11-08 - club - SMA - male - 1280263 - Rajasthan vs Andhra
2021-11-06 - club - SMA - male - 1280243 - Andhra vs Jharkhand
2021-11-05 - club - SMA - male - 1280225 - Andhra vs Haryana
2021-01-19 - club - SMA - male - 1244396 - Andhra vs Mumbai
2021-01-17 - club - SMA - male - 1244376 - Kerala vs Andhra
2021-01-15 - club - SMA - male - 1244358 - Andhra vs Puducherry
2021-01-13 - club - SMA - male - 1244337 - Andhra vs Delhi
2021-01-11 - club - SMA - male - 1244318 - Andhra vs Haryana
2019-11-17 - club - SMA - male - 1205832 - Andhra vs Services
2019-11-15 - club - SMA - male - 1205804 - Goa vs Andhra
2019-11-14 - club - SMA - male - 1205787 - Uttarakhand vs Andhra
2019-11-12 - club - SMA - male - 1205768 - Andhra vs Baroda
2019-11-08 - club - SMA - male - 1205715 - Bihar vs Andhra
2019-03-02 - club - SMA - male - 1157195 - Andhra vs Manipur
2019-02-28 - club - SMA - male - 1157176 - Andhra vs Jharkhand
2019-02-27 - club - SMA - male - 1157159 - Delhi vs Andhra
2019-02-25 - club - SMA - male - 1157143 - Andhra vs Jammu & Kashmir
2019-02-24 - club - SMA - male - 1157127 - Kerala vs Andhra
2019-02-22 - club - SMA - male - 1157110 - Andhra vs Nagaland
2018-01-14 - club - SMA - male - 1130715 - Andhra vs Goa
2018-01-12 - club - SMA - male - 1130701 - Hyderabad (India) vs Andhra
2018-01-11 - club - SMA - male - 1130691 - Kerala vs Andhra
2018-01-09 - club - SMA - male - 1130680 - Karnataka vs Andhra
2018-01-08 - club - SMA - male - 1130671 - Andhra vs Tamil Nadu
2016-01-10 - club - SMA - male - 902239 - Andhra vs Goa
2016-01-09 - club - SMA - male - 902223 - Andhra vs Baroda
2016-01-07 - club - SMA - male - 902199 - Andhra vs Assam
2016-01-04 - club - SMA - male - 902151 - Railways vs Andhra
2016-01-03 - club - SMA - male - 902125 - Delhi vs Andhra
2016-01-02 - club - SMA - male - 902099 - Andhra vs Madhya Pradesh
