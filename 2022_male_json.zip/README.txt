This zip archive contains data files from Cricsheet in JSON format. This
archive contains 1516 matches of all types from 2022. A further 30 matches
have been withheld due to either featuring the Afghanistan men's team or being
played in the Afghanistan Premier League, due to the Cricsheet policy to no
longer feature matches involving Afghanistan men or played in Afghanistan
Premier League (see https://cricsheet.org/withheld-matches for more
information).


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/2022_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2022-12-31 - club - SSM - male - 1341201 - Northern Districts vs Central Districts
2022-12-31 - club - BBL - male - 1324646 - Melbourne Stars vs Adelaide Strikers
2022-12-31 - club - BBL - male - 1324645 - Sydney Thunder vs Hobart Hurricanes
2022-12-30 - club - SSM - male - 1341200 - Canterbury vs Central Districts
2022-12-30 - club - BBL - male - 1324644 - Melbourne Renegades vs Sydney Sixers
2022-12-29 - club - SSM - male - 1341199 - Otago vs Auckland
2022-12-29 - club - BBL - male - 1324643 - Melbourne Stars vs Perth Scorchers
2022-12-29 - club - BBL - male - 1324642 - Sydney Thunder vs Brisbane Heat
2022-12-28 - club - SSM - male - 1341198 - Otago vs Northern Districts
2022-12-28 - club - BBL - male - 1324641 - Sydney Sixers vs Melbourne Renegades
2022-12-27 - club - SSM - male - 1341197 - Wellington vs Central Districts
2022-12-27 - club - BBL - male - 1324640 - Brisbane Heat vs Sydney Thunder
2022-12-26 - international - Test - male - 1339609 - Pakistan vs New Zealand
2022-12-26 - international - Test - male - 1317493 - South Africa vs Australia
2022-12-26 - club - SSM - male - 1341196 - Canterbury vs Auckland
2022-12-26 - club - BBL - male - 1324639 - Adelaide Strikers vs Perth Scorchers
2022-12-26 - club - BBL - male - 1324638 - Melbourne Stars vs Sydney Sixers
2022-12-24 - club - SSM - male - 1341195 - Wellington vs Otago
2022-12-24 - club - BBL - male - 1324637 - Hobart Hurricanes vs Melbourne Renegades
2022-12-23 - international - T20 - male - 1349391 - Malaysia vs Bahrain
2022-12-23 - international - T20 - male - 1349390 - Singapore vs Qatar
2022-12-23 - international - T20 - male - 1349140 - Uganda vs Rwanda
2022-12-23 - club - SSM - male - 1341194 - Northern Districts vs Canterbury
2022-12-23 - club - LPL - male - 1324542 - Colombo Stars vs Jaffna Kings
2022-12-23 - club - BBL - male - 1324636 - Brisbane Heat vs Adelaide Strikers
2022-12-23 - club - BBL - male - 1324635 - Perth Scorchers vs Melbourne Stars
2022-12-22 - international - Test - male - 1340849 - Bangladesh vs India
2022-12-22 - international - T20 - male - 1349389 - Bahrain vs Qatar
2022-12-22 - international - T20 - male - 1349388 - Malaysia vs Singapore
2022-12-22 - international - T20 - male - 1349139 - Uganda vs Tanzania
2022-12-22 - international - T20 - male - 1349138 - Tanzania vs Rwanda
2022-12-22 - club - LPL - male - 1324541 - Kandy Falcons vs Colombo Stars
2022-12-22 - club - BBL - male - 1324634 - Sydney Sixers vs Hobart Hurricanes
2022-12-21 - international - T20 - male - 1349387 - Malaysia vs Qatar
2022-12-21 - international - T20 - male - 1349386 - Singapore vs Bahrain
2022-12-21 - club - LPL - male - 1324540 - Galle Gladiators vs Colombo Stars
2022-12-21 - club - LPL - male - 1324539 - Kandy Falcons vs Jaffna Kings
2022-12-21 - club - BBL - male - 1324633 - Brisbane Heat vs Melbourne Renegades
2022-12-20 - international - T20 - male - 1349137 - Rwanda vs Uganda
2022-12-20 - international - T20 - male - 1349136 - Tanzania vs Rwanda
2022-12-20 - club - BBL - male - 1324632 - Sydney Thunder vs Adelaide Strikers
2022-12-19 - international - T20 - male - 1349385 - Bahrain vs Malaysia
2022-12-19 - international - T20 - male - 1349384 - Singapore vs Qatar
2022-12-19 - international - T20 - male - 1349134 - Uganda vs Tanzania
2022-12-19 - club - LPL - male - 1324538 - Galle Gladiators vs Dambulla Aura
2022-12-19 - club - LPL - male - 1324537 - Colombo Stars vs Jaffna Kings
2022-12-19 - club - BBL - male - 1324631 - Hobart Hurricanes vs Perth Scorchers
2022-12-18 - international - T20 - male - 1349383 - Malaysia vs Singapore
2022-12-18 - international - T20 - male - 1349382 - Bahrain vs Qatar
2022-12-18 - international - T20 - male - 1349133 - Rwanda vs Tanzania
2022-12-18 - international - T20 - male - 1349132 - Uganda vs Tanzania
2022-12-18 - club - LPL - male - 1324536 - Kandy Falcons vs Dambulla Aura
2022-12-18 - club - LPL - male - 1324535 - Jaffna Kings vs Galle Gladiators
2022-12-18 - club - BBL - male - 1324630 - Sydney Thunder vs Melbourne Renegades
2022-12-17 - international - Test - male - 1330873 - Pakistan vs England
2022-12-17 - international - Test - male - 1317492 - South Africa vs Australia
2022-12-17 - club - LPL - male - 1324534 - Colombo Stars vs Kandy Falcons
2022-12-17 - club - LPL - male - 1324533 - Dambulla Aura vs Galle Gladiators
2022-12-17 - club - BBL - male - 1324629 - Perth Scorchers vs Sydney Sixers
2022-12-16 - international - T20 - male - 1349380 - Qatar vs Malaysia
2022-12-16 - international - T20 - male - 1349131 - Rwanda vs Tanzania
2022-12-16 - club - BBL - male - 1324628 - Adelaide Strikers vs Sydney Thunder
2022-12-16 - club - BBL - male - 1324627 - Melbourne Stars vs Hobart Hurricanes
2022-12-15 - international - T20 - male - 1349379 - Singapore vs Qatar
2022-12-15 - international - T20 - male - 1349129 - Uganda vs Tanzania
2022-12-15 - international - T20 - male - 1349128 - Uganda vs Rwanda
2022-12-15 - club - BBL - male - 1324626 - Melbourne Renegades vs Brisbane Heat
2022-12-14 - international - Test - male - 1340848 - India vs Bangladesh
2022-12-14 - international - T20 - male - 1349127 - Tanzania vs Uganda
2022-12-14 - international - T20 - male - 1349126 - Uganda vs Rwanda
2022-12-14 - club - LPL - male - 1324532 - Dambulla Aura vs Colombo Stars
2022-12-14 - club - LPL - male - 1324531 - Kandy Falcons vs Jaffna Kings
2022-12-14 - club - BBL - male - 1324625 - Adelaide Strikers vs Sydney Sixers
2022-12-13 - international - T20 - male - 1349124 - Tanzania vs Rwanda
2022-12-13 - international - ODM - male - 1343844 - Canada vs Malaysia
2022-12-13 - club - LPL - male - 1324530 - Galle Gladiators vs Colombo Stars
2022-12-13 - club - LPL - male - 1324529 - Kandy Falcons vs Dambulla Aura
2022-12-13 - club - BBL - male - 1324624 - Melbourne Stars vs Sydney Thunder
2022-12-12 - international - ODM - male - 1343842 - Qatar vs Singapore
2022-12-12 - club - LPL - male - 1324528 - Jaffna Kings vs Colombo Stars
2022-12-12 - club - LPL - male - 1324527 - Galle Gladiators vs Kandy Falcons
2022-12-11 - club - LPL - male - 1324526 - Jaffna Kings vs Dambulla Aura
2022-12-11 - club - LPL - male - 1324525 - Galle Gladiators vs Colombo Stars
2022-12-10 - international - ODM - male - 1343840 - Denmark vs Vanuatu
2022-12-10 - international - ODM - male - 1343839 - Singapore vs Malaysia
2022-12-10 - international - ODI - male - 1340847 - India vs Bangladesh
2022-12-10 - club - LPL - male - 1324524 - Jaffna Kings vs Kandy Falcons
2022-12-09 - international - Test - male - 1330872 - England vs Pakistan
2022-12-09 - international - T20 - male - 1343795 - Tanzania vs Cameroon
2022-12-09 - international - T20 - male - 1343794 - Ghana vs Nigeria
2022-12-09 - international - T20 - male - 1343793 - Gambia vs Cameroon
2022-12-09 - international - ODM - male - 1343838 - Qatar vs Malaysia
2022-12-09 - international - ODM - male - 1343837 - Denmark vs Canada
2022-12-08 - international - Test - male - 1317485 - Australia vs West Indies
2022-12-08 - international - T20 - male - 1343791 - Mozambique vs Gambia
2022-12-08 - international - T20 - male - 1343790 - Nigeria vs Tanzania
2022-12-08 - international - T20 - male - 1343788 - Ghana vs Gambia
2022-12-08 - international - ODI - male - 1341980 - Nepal vs Scotland
2022-12-08 - club - LPL - male - 1324523 - Colombo Stars vs Dambulla Aura
2022-12-07 - international - ODM - male - 1343836 - Singapore vs Denmark
2022-12-07 - international - ODI - male - 1341979 - Namibia vs Nepal
2022-12-07 - international - ODI - male - 1340846 - Bangladesh vs India
2022-12-07 - club - LPL - male - 1324522 - Galle Gladiators vs Kandy Falcons
2022-12-07 - club - LPL - male - 1324521 - Dambulla Aura vs Jaffna Kings
2022-12-06 - international - T20 - male - 1343786 - Gambia vs Tanzania
2022-12-06 - international - T20 - male - 1343785 - Gambia vs Sierra Leone
2022-12-06 - international - T20 - male - 1343784 - Tanzania vs Eswatini
2022-12-06 - international - ODM - male - 1343834 - Vanuatu vs Malaysia
2022-12-06 - international - ODM - male - 1343833 - Canada vs Singapore
2022-12-06 - club - LPL - male - 1324520 - Kandy Falcons vs Colombo Stars
2022-12-06 - club - LPL - male - 1324519 - Jaffna Kings vs Galle Gladiators
2022-12-05 - international - T20 - male - 1343783 - Ghana vs Sierra Leone
2022-12-05 - international - T20 - male - 1343782 - Cameroon vs Nigeria
2022-12-05 - international - T20 - male - 1343781 - Sierra Leone vs Eswatini
2022-12-05 - international - T20 - male - 1343780 - Mozambique vs Tanzania
2022-12-05 - international - ODI - male - 1341978 - Scotland vs Namibia
2022-12-04 - international - T20 - male - 1343778 - Ghana vs Tanzania
2022-12-04 - international - T20 - male - 1343777 - Nigeria vs Eswatini
2022-12-04 - international - T20 - male - 1343776 - Cameroon vs Mozambique
2022-12-04 - international - ODM - male - 1343832 - Qatar vs Canada
2022-12-04 - international - ODM - male - 1343831 - Denmark vs Malaysia
2022-12-04 - international - ODI - male - 1341977 - Nepal vs Scotland
2022-12-04 - international - ODI - male - 1340845 - India vs Bangladesh
2022-12-03 - international - ODM - male - 1343830 - Vanuatu vs Singapore
2022-12-02 - international - T20 - male - 1343775 - Eswatini vs Mozambique
2022-12-02 - international - T20 - male - 1343774 - Cameroon vs Sierra Leone
2022-12-02 - international - T20 - male - 1343773 - Ghana vs Mozambique
2022-12-02 - international - T20 - male - 1343772 - Sierra Leone vs Nigeria
2022-12-02 - international - ODI - male - 1341976 - Nepal vs Namibia
2022-12-01 - international - Test - male - 1330871 - England vs Pakistan
2022-12-01 - international - T20 - male - 1343771 - Gambia vs Eswatini
2022-12-01 - international - T20 - male - 1343770 - Mozambique vs Nigeria
2022-12-01 - international - T20 - male - 1343768 - Sierra Leone vs Tanzania
2022-12-01 - international - ODI - male - 1341975 - Namibia vs Scotland
2022-12-01 - club - SSH - male - 1322413 - Queensland vs Western Australia
2022-12-01 - club - SSH - male - 1322412 - South Australia vs Tasmania
2022-12-01 - club - SSH - male - 1322411 - Victoria vs New South Wales
2022-11-30 - international - Test - male - 1317484 - Australia vs West Indies
2022-11-30 - international - ODI - male - 1322280 - India vs New Zealand
2022-11-27 - international - ODI - male - 1322279 - India vs New Zealand
2022-11-27 - club - ODC - male - 1322388 - Queensland vs New South Wales
2022-11-26 - international - ODI - male - 1341974 - United States of America vs Namibia
2022-11-25 - international - T20 - male - 1343767 - Rwanda vs Lesotho
2022-11-25 - international - T20 - male - 1343764 - Seychelles vs Kenya
2022-11-25 - international - ODI - male - 1341973 - United States of America vs Papua New Guinea
2022-11-25 - international - ODI - male - 1322278 - India vs New Zealand
2022-11-24 - international - T20 - male - 1343763 - Mali vs Rwanda
2022-11-24 - international - T20 - male - 1343762 - Botswana vs Kenya
2022-11-24 - international - T20 - male - 1343761 - Rwanda vs Seychelles
2022-11-24 - international - T20 - male - 1343760 - St Helena vs Malawi
2022-11-24 - club - SSH - male - 1322410 - Victoria vs Tasmania
2022-11-23 - international - ODI - male - 1341972 - Papua New Guinea vs Namibia
2022-11-22 - international - T20 - male - 1343758 - Seychelles vs Malawi
2022-11-22 - international - T20 - male - 1343757 - St Helena vs Lesotho
2022-11-22 - international - T20 - male - 1343756 - Mali vs Botswana
2022-11-22 - international - T20 - male - 1322277 - New Zealand vs India
2022-11-22 - international - ODI - male - 1341971 - Papua New Guinea vs United States of America
2022-11-22 - international - ODI - male - 1317491 - Australia vs England
2022-11-22 - club - SSH - male - 1322409 - Western Australia vs New South Wales
2022-11-21 - international - T20 - male - 1344795 - Oman vs Canada
2022-11-21 - international - T20 - male - 1344794 - Saudi Arabia vs Bahrain
2022-11-21 - international - T20 - male - 1343753 - Kenya vs Lesotho
2022-11-20 - international - T20 - male - 1344793 - Bahrain vs Saudi Arabia
2022-11-20 - international - T20 - male - 1344792 - Oman vs Canada
2022-11-20 - international - T20 - male - 1343750 - Rwanda vs Kenya
2022-11-20 - international - T20 - male - 1343749 - Mali vs Kenya
2022-11-20 - international - T20 - male - 1322276 - India vs New Zealand
2022-11-20 - international - ODI - male - 1341970 - United States of America vs Namibia
2022-11-20 - club - SSH - male - 1322408 - South Australia vs Queensland
2022-11-19 - international - T20 - male - 1344791 - Oman vs Bahrain
2022-11-19 - international - T20 - male - 1344790 - Canada vs Saudi Arabia
2022-11-19 - international - ODI - male - 1341969 - Papua New Guinea vs Namibia
2022-11-19 - international - ODI - male - 1317490 - Australia vs England
2022-11-18 - international - T20 - male - 1343747 - Seychelles vs Mali
2022-11-18 - international - T20 - male - 1343746 - Kenya vs Malawi
2022-11-18 - international - T20 - male - 1343745 - Lesotho vs Botswana
2022-11-18 - international - T20 - male - 1343744 - Rwanda vs St Helena
2022-11-18 - international - ODI - male - 1343685 - United Arab Emirates vs Nepal
2022-11-17 - international - T20 - male - 1344789 - Canada vs Bahrain
2022-11-17 - international - T20 - male - 1344788 - Saudi Arabia vs Oman
2022-11-17 - international - T20 - male - 1343743 - Botswana vs Seychelles
2022-11-17 - international - T20 - male - 1343742 - Kenya vs St Helena
2022-11-17 - international - T20 - male - 1343741 - Lesotho vs Mali
2022-11-17 - international - T20 - male - 1343740 - Botswana vs Rwanda
2022-11-17 - international - ODI - male - 1317489 - England vs Australia
2022-11-17 - club - ODC - male - 1322387 - New South Wales vs Tasmania
2022-11-16 - international - T20 - male - 1344787 - Canada vs Oman
2022-11-16 - international - T20 - male - 1344786 - Bahrain vs Saudi Arabia
2022-11-16 - international - ODI - male - 1343684 - United Arab Emirates vs Nepal
2022-11-16 - club - ODC - male - 1322386 - South Australia vs Western Australia
2022-11-15 - international - T20 - male - 1344785 - Oman vs Bahrain
2022-11-15 - international - T20 - male - 1344784 - Canada vs Saudi Arabia
2022-11-15 - club - ODC - male - 1322385 - Victoria vs Queensland
2022-11-14 - international - T20 - male - 1344783 - Bahrain vs Canada
2022-11-14 - international - T20 - male - 1344782 - Saudi Arabia vs Oman
2022-11-14 - international - ODI - male - 1343683 - United Arab Emirates vs Nepal
2022-11-14 - club - PKS - male - 1328688 - Otago Volts vs Northern Districts
2022-11-14 - club - PKS - male - 1328687 - Canterbury vs Auckland Aces
2022-11-14 - club - PKS - male - 1328686 - Central Stags vs Wellington Firebirds
2022-11-13 - international - T20 - male - 1298179 - Pakistan vs England
2022-11-12 - club - SSH - male - 1322407 - Tasmania vs New South Wales
2022-11-11 - club - SSH - male - 1322406 - South Australia vs Western Australia
2022-11-10 - international - T20 - male - 1298178 - India vs England
2022-11-10 - club - SSH - male - 1322405 - Victoria vs Queensland
2022-11-09 - international - T20 - male - 1298177 - New Zealand vs Pakistan
2022-11-06 - international - T20 - male - 1339210 - Italy vs Spain
2022-11-06 - international - T20 - male - 1339209 - Spain vs Germany
2022-11-06 - international - T20 - male - 1298176 - India vs Zimbabwe
2022-11-06 - international - T20 - male - 1298175 - Bangladesh vs Pakistan
2022-11-06 - international - T20 - male - 1298174 - Netherlands vs South Africa
2022-11-05 - international - T20 - male - 1339208 - Germany vs Spain
2022-11-05 - international - T20 - male - 1339207 - Italy vs Spain
2022-11-05 - international - T20 - male - 1298173 - Sri Lanka vs England
2022-11-05 - club - SMA - male - 1333055 - Himachal Pradesh vs Mumbai
2022-11-05 - club - PKS - male - 1328685 - Canterbury vs Otago Volts
2022-11-05 - club - PKS - male - 1328684 - Wellington Firebirds vs Auckland Aces
2022-11-05 - club - PKS - male - 1328683 - Central Stags vs Northern Districts
2022-11-05 - club - ODC - male - 1322384 - Western Australia vs Queensland
2022-11-05 - club - ODC - male - 1322383 - South Australia vs New South Wales
2022-11-05 - club - CTC - male - 1334921 - Dolphins vs Titans
2022-11-04 - international - T20 - male - 1339206 - Italy vs Germany
2022-11-04 - international - T20 - male - 1339205 - Italy vs Germany
2022-11-04 - international - T20 - male - 1298171 - New Zealand vs Ireland
2022-11-03 - international - T20 - male - 1298170 - Pakistan vs South Africa
2022-11-03 - club - SMA - male - 1333054 - Vidarbha vs Mumbai
2022-11-03 - club - SMA - male - 1333053 - Himachal Pradesh vs Punjab
2022-11-02 - international - T20 - male - 1298169 - India vs Bangladesh
2022-11-02 - international - T20 - male - 1298168 - Zimbabwe vs Netherlands
2022-11-02 - club - CTC - male - 1334920 - Dolphins vs Boland
2022-11-02 - club - CTC - male - 1334919 - Titans vs Knights
2022-11-01 - international - T20 - male - 1298167 - England vs New Zealand
2022-11-01 - club - SMA - male - 1333052 - Saurashtra vs Mumbai
2022-11-01 - club - SMA - male - 1333050 - Vidarbha vs Delhi
2022-11-01 - club - SMA - male - 1333049 - Punjab vs Karnataka
2022-11-01 - club - CTC - male - 1334917 - North West vs Knights
2022-10-31 - international - T20 - male - 1298165 - Australia vs Ireland
2022-10-31 - club - SSH - male - 1322404 - Queensland vs Western Australia
2022-10-31 - club - SSH - male - 1322403 - New South Wales vs South Australia
2022-10-31 - club - CTC - male - 1334916 - Lions vs Western Province
2022-10-31 - club - CTC - male - 1334915 - Titans vs Knights
2022-10-30 - international - T20 - male - 1298164 - India vs South Africa
2022-10-30 - international - T20 - male - 1298163 - Netherlands vs Pakistan
2022-10-30 - international - T20 - male - 1298162 - Bangladesh vs Zimbabwe
2022-10-30 - club - SMA - male - 1333048 - Saurashtra vs Kerala
2022-10-30 - club - SMA - male - 1333047 - Chhattisgarh vs Vidarbha
2022-10-30 - club - SMA - male - 1333046 - Punjab vs Haryana
2022-10-30 - club - CTC - male - 1334914 - Warriors vs North West
2022-10-29 - international - T20 - male - 1298161 - New Zealand vs Sri Lanka
2022-10-29 - club - SSH - male - 1322402 - Victoria vs Tasmania
2022-10-29 - club - CTC - male - 1334913 - Western Province vs Dolphins
2022-10-29 - club - CTC - male - 1334912 - North West vs Boland
2022-10-28 - club - CTC - male - 1334911 - Knights vs Dolphins
2022-10-28 - club - CTC - male - 1334910 - Warriors vs Titans
2022-10-27 - international - T20 - male - 1298158 - Zimbabwe vs Pakistan
2022-10-27 - international - T20 - male - 1298157 - India vs Netherlands
2022-10-27 - international - T20 - male - 1298156 - South Africa vs Bangladesh
2022-10-27 - club - CTC - male - 1334909 - Western Province vs North West
2022-10-26 - international - T20 - male - 1298154 - Ireland vs England
2022-10-26 - club - PKS - male - 1328682 - Wellington Firebirds vs Canterbury
2022-10-26 - club - PKS - male - 1328681 - Northern Districts vs Otago Volts
2022-10-26 - club - ODC - male - 1322382 - Victoria vs Tasmania
2022-10-26 - club - CTC - male - 1334908 - Knights vs Boland
2022-10-26 - club - CTC - male - 1334907 - Lions vs Dolphins
2022-10-25 - international - T20 - male - 1298153 - Sri Lanka vs Australia
2022-10-25 - club - PKS - male - 1328680 - Auckland Aces vs Central Stags
2022-10-25 - club - CTC - male - 1334906 - Boland vs Titans
2022-10-24 - international - T20 - male - 1298152 - Zimbabwe vs South Africa
2022-10-24 - international - T20 - male - 1298151 - Bangladesh vs Netherlands
2022-10-23 - international - T20 - male - 1298150 - Pakistan vs India
2022-10-23 - international - T20 - male - 1298149 - Ireland vs Sri Lanka
2022-10-23 - club - CTC - male - 1334903 - Knights vs Lions
2022-10-22 - international - T20 - male - 1298147 - New Zealand vs Australia
2022-10-22 - club - SMA - male - 1333041 - Nagaland vs Himachal Pradesh
2022-10-22 - club - SMA - male - 1333040 - Bihar vs Gujarat
2022-10-22 - club - SMA - male - 1333035 - Railways vs Vidarbha
2022-10-22 - club - SMA - male - 1333033 - Madhya Pradesh vs Assam
2022-10-22 - club - SMA - male - 1333031 - Puducherry vs Goa
2022-10-22 - club - SMA - male - 1333029 - Uttar Pradesh vs Punjab
2022-10-22 - club - ODC - male - 1322381 - Victoria vs Western Australia
2022-10-22 - club - CTC - male - 1334902 - North West vs Titans
2022-10-22 - club - CTC - male - 1334901 - Dolphins vs Boland
2022-10-21 - international - T20 - male - 1298146 - Scotland vs Zimbabwe
2022-10-21 - international - T20 - male - 1298145 - West Indies vs Ireland
2022-10-21 - club - ODC - male - 1322380 - Tasmania vs South Australia
2022-10-21 - club - CTC - male - 1334900 - Warriors vs Lions
2022-10-21 - club - CTC - male - 1334899 - Titans vs Western Province
2022-10-20 - international - T20 - male - 1298144 - United Arab Emirates vs Namibia
2022-10-20 - international - T20 - male - 1298143 - Sri Lanka vs Netherlands
2022-10-20 - club - SMA - male - 1333024 - Baroda vs Himachal Pradesh
2022-10-20 - club - SMA - male - 1333022 - Andhra vs Gujarat
2022-10-20 - club - SMA - male - 1333017 - Uttarakhand vs Mizoram
2022-10-20 - club - SMA - male - 1333016 - Mumbai vs Railways
2022-10-20 - club - SMA - male - 1333013 - Manipur vs Tripura
2022-10-20 - club - SMA - male - 1333012 - Goa vs Delhi
2022-10-20 - club - CTC - male - 1334898 - Warriors vs Boland
2022-10-20 - club - CTC - male - 1334897 - Western Province vs Knights
2022-10-19 - international - T20 - male - 1298142 - West Indies vs Zimbabwe
2022-10-19 - international - T20 - male - 1298141 - Scotland vs Ireland
2022-10-19 - club - CTC - male - 1334896 - Dolphins vs North West
2022-10-19 - club - CTC - male - 1334895 - Titans vs Lions
2022-10-18 - international - T20 - male - 1336956 - South Korea vs Indonesia
2022-10-18 - international - T20 - male - 1336955 - Japan vs Indonesia
2022-10-18 - international - T20 - male - 1298140 - Sri Lanka vs United Arab Emirates
2022-10-18 - international - T20 - male - 1298139 - Namibia vs Netherlands
2022-10-18 - club - SSH - male - 1322401 - New South Wales vs Queensland
2022-10-18 - club - SMA - male - 1333006 - Bihar vs Andhra
2022-10-18 - club - SMA - male - 1333005 - Himachal Pradesh vs Saurashtra
2022-10-18 - club - SMA - male - 1332999 - Vidarbha vs Uttarakhand
2022-10-18 - club - SMA - male - 1332997 - Mizoram vs Madhya Pradesh
2022-10-18 - club - SMA - male - 1332995 - Tripura vs Puducherry
2022-10-18 - club - SMA - male - 1332993 - Manipur vs Punjab
2022-10-18 - club - PKS - male - 1328679 - Wellington Firebirds vs Northern Districts
2022-10-18 - club - PKS - male - 1328678 - Auckland Aces vs Otago Volts
2022-10-18 - club - PKS - male - 1328677 - Central Stags vs Canterbury
2022-10-18 - club - CTC - male - 1334894 - Western Province vs Boland
2022-10-18 - club - CTC - male - 1334893 - Warriors vs Knights
2022-10-17 - international - T20 - male - 1298138 - Zimbabwe vs Ireland
2022-10-17 - international - T20 - male - 1298137 - Scotland vs West Indies
2022-10-17 - club - SSH - male - 1322400 - Western Australia vs Victoria
2022-10-17 - club - CTC - male - 1334892 - Lions vs North West
2022-10-17 - club - CTC - male - 1334891 - Titans vs Dolphins
2022-10-16 - international - T20 - male - 1336953 - Indonesia vs Japan
2022-10-16 - international - T20 - male - 1298136 - United Arab Emirates vs Netherlands
2022-10-16 - international - T20 - male - 1298135 - Namibia vs Sri Lanka
2022-10-16 - club - SSH - male - 1322399 - South Australia vs Tasmania
2022-10-16 - club - SMA - male - 1332987 - Nagaland vs Andhra
2022-10-16 - club - SMA - male - 1332986 - Gujarat vs Saurashtra
2022-10-16 - club - SMA - male - 1332981 - Mizoram vs Assam
2022-10-16 - club - SMA - male - 1332978 - Rajasthan vs Uttarakhand
2022-10-15 - international - T20 - male - 1336952 - Japan vs South Korea
2022-10-15 - international - T20 - male - 1336951 - Indonesia vs South Korea
2022-10-14 - international - T20 - male - 1322340 - New Zealand vs Pakistan
2022-10-14 - international - T20 - male - 1317488 - England vs Australia
2022-10-14 - club - SMA - male - 1332968 - Baroda vs Gujarat
2022-10-14 - club - SMA - male - 1332962 - Mumbai vs Assam
2022-10-14 - club - SMA - male - 1332960 - Rajasthan vs Railways
2022-10-14 - club - SMA - male - 1332958 - Delhi vs Uttar Pradesh
2022-10-14 - club - SMA - male - 1332956 - Hyderabad (India) vs Goa
2022-10-13 - international - T20 - male - 1322339 - Bangladesh vs Pakistan
2022-10-12 - international - T20 - male - 1322338 - New Zealand vs Bangladesh
2022-10-12 - international - T20 - male - 1317487 - England vs Australia
2022-10-12 - club - SMA - male - 1332952 - Nagaland vs Bihar
2022-10-12 - club - SMA - male - 1332950 - Baroda vs Saurashtra
2022-10-12 - club - SMA - male - 1332943 - Madhya Pradesh vs Mumbai
2022-10-12 - club - SMA - male - 1332939 - Delhi vs Punjab
2022-10-12 - club - SMA - male - 1332938 - Hyderabad (India) vs Puducherry
2022-10-11 - international - T20 - male - 1333932 - Japan vs Indonesia
2022-10-11 - international - T20 - male - 1322337 - Pakistan vs New Zealand
2022-10-11 - international - ODI - male - 1327511 - South Africa vs India
2022-10-11 - club - SMA - male - 1332934 - Nagaland vs Baroda
2022-10-11 - club - SMA - male - 1332927 - Railways vs Uttarakhand
2022-10-11 - club - SMA - male - 1332920 - Punjab vs Hyderabad (India)
2022-10-10 - international - T20 - male - 1333931 - Japan vs Indonesia
2022-10-09 - international - T20 - male - 1322336 - Bangladesh vs New Zealand
2022-10-09 - international - T20 - male - 1317486 - England vs Australia
2022-10-09 - international - ODI - male - 1327510 - South Africa vs India
2022-10-08 - international - T20 - male - 1322335 - New Zealand vs Pakistan
2022-10-07 - international - T20 - male - 1322334 - Pakistan vs Bangladesh
2022-10-07 - international - T20 - male - 1317483 - Australia vs West Indies
2022-10-06 - international - ODI - male - 1327509 - South Africa vs India
2022-10-06 - club - SSH - male - 1322398 - Victoria vs South Australia
2022-10-06 - club - SSH - male - 1322397 - Tasmania vs Queensland
2022-10-05 - international - T20 - male - 1317482 - West Indies vs Australia
2022-10-04 - international - T20 - male - 1327508 - South Africa vs India
2022-10-03 - club - SSH - male - 1322396 - New South Wales vs Western Australia
2022-10-02 - international - T20 - male - 1327507 - India vs South Africa
2022-10-02 - international - T20 - male - 1327234 - England vs Pakistan
2022-10-01 - club - ODC - male - 1322379 - New South Wales vs Western Australia
2022-09-30 - international - T20 - male - 1327233 - Pakistan vs England
2022-09-30 - club - ODC - male - 1322378 - Queensland vs Tasmania
2022-09-30 - club - CPL - male - 1323177 - Barbados Royals vs Jamaica Tallawahs
2022-09-28 - international - T20 - male - 1327506 - South Africa vs India
2022-09-28 - international - T20 - male - 1327232 - Pakistan vs England
2022-09-28 - club - ODC - male - 1322377 - South Australia vs Tasmania
2022-09-28 - club - CPL - male - 1323176 - Jamaica Tallawahs vs Guyana Amazon Warriors
2022-09-27 - international - T20 - male - 1336032 - Bangladesh vs United Arab Emirates
2022-09-27 - club - CPL - male - 1323175 - Jamaica Tallawahs vs St Lucia Kings
2022-09-27 - club - CPL - male - 1323174 - Barbados Royals vs Guyana Amazon Warriors
2022-09-26 - club - ODC - male - 1322376 - South Australia vs Queensland
2022-09-26 - club - CCH - male - 1297793 - Essex vs Northamptonshire
2022-09-26 - club - CCH - male - 1297792 - Lancashire vs Surrey
2022-09-26 - club - CCH - male - 1297791 - Warwickshire vs Hampshire
2022-09-26 - club - CCH - male - 1297790 - Gloucestershire vs Yorkshire
2022-09-26 - club - CCH - male - 1297789 - Leicestershire vs Derbyshire
2022-09-26 - club - CCH - male - 1297788 - Nottinghamshire vs Durham
2022-09-26 - club - CCH - male - 1297787 - Glamorgan vs Sussex
2022-09-26 - club - CCH - male - 1297786 - Worcestershire vs Middlesex
2022-09-26 - club - CCH - male - 1297785 - Somerset vs Kent
2022-09-25 - international - T20 - male - 1336031 - Bangladesh vs United Arab Emirates
2022-09-25 - international - T20 - male - 1327505 - Australia vs India
2022-09-25 - international - T20 - male - 1327231 - Pakistan vs England
2022-09-25 - club - ODC - male - 1322375 - Victoria vs Western Australia
2022-09-25 - club - CPL - male - 1323173 - Barbados Royals vs Guyana Amazon Warriors
2022-09-24 - club - CPL - male - 1323171 - Guyana Amazon Warriors vs Trinbago Knight Riders
2022-09-23 - international - T20 - male - 1327504 - Australia vs India
2022-09-23 - international - T20 - male - 1327230 - England vs Pakistan
2022-09-23 - club - ODC - male - 1322374 - New South Wales vs Victoria
2022-09-22 - international - T20 - male - 1332510 - Tanzania vs Uganda
2022-09-22 - international - T20 - male - 1327229 - England vs Pakistan
2022-09-22 - club - CPL - male - 1323170 - St Lucia Kings vs Guyana Amazon Warriors
2022-09-22 - club - CPL - male - 1323169 - St Kitts and Nevis Patriots vs Trinbago Knight Riders
2022-09-21 - international - T20 - male - 1332509 - Botswana vs Tanzania
2022-09-21 - international - T20 - male - 1332508 - Kenya vs Uganda
2022-09-21 - international - ODI - male - 1331370 - Namibia vs Papua New Guinea
2022-09-21 - club - CPL - male - 1323168 - Guyana Amazon Warriors vs Jamaica Tallawahs
2022-09-21 - club - CPL - male - 1323167 - Barbados Royals vs St Kitts and Nevis Patriots
2022-09-20 - international - T20 - male - 1332505 - Tanzania vs Malawi
2022-09-20 - international - T20 - male - 1332501 - Ghana vs Uganda
2022-09-20 - international - T20 - male - 1327503 - India vs Australia
2022-09-20 - international - T20 - male - 1327228 - Pakistan vs England
2022-09-20 - international - ODI - male - 1331369 - Namibia vs Papua New Guinea
2022-09-20 - club - CCH - male - 1297784 - Kent vs Hampshire
2022-09-20 - club - CCH - male - 1297783 - Lancashire vs Essex
2022-09-20 - club - CCH - male - 1297782 - Worcestershire vs Nottinghamshire
2022-09-20 - club - CCH - male - 1297781 - Middlesex vs Leicestershire
2022-09-20 - club - CCH - male - 1297780 - Glamorgan vs Derbyshire
2022-09-20 - club - CCH - male - 1297779 - Sussex vs Durham
2022-09-20 - club - CCH - male - 1297778 - Somerset vs Northamptonshire
2022-09-20 - club - CCH - male - 1297777 - Warwickshire vs Gloucestershire
2022-09-20 - club - CCH - male - 1297776 - Surrey vs Yorkshire
2022-09-19 - international - T20 - male - 1332506 - Cameroon vs Kenya
2022-09-19 - international - T20 - male - 1332504 - Botswana vs Mozambique
2022-09-18 - international - T20 - male - 1332507 - Botswana vs Ghana
2022-09-18 - international - T20 - male - 1332503 - Uganda vs Mozambique
2022-09-18 - club - CPL - male - 1323166 - St Lucia Kings vs Trinbago Knight Riders
2022-09-18 - club - CPL - male - 1323165 - Barbados Royals vs Guyana Amazon Warriors
2022-09-17 - international - T20 - male - 1332497 - Kenya vs Tanzania
2022-09-17 - international - ODI - male - 1331368 - Namibia vs United States of America
2022-09-17 - club - CPL - male - 1323164 - Jamaica Tallawahs vs Trinbago Knight Riders
2022-09-17 - club - CPL - male - 1323163 - St Lucia Kings vs St Kitts and Nevis Patriots
2022-09-16 - international - T20 - male - 1332498 - Ghana vs Mozambique
2022-09-15 - international - T20 - male - 1333929 - Vanuatu vs Cook Islands
2022-09-15 - international - T20 - male - 1333928 - Fiji vs Samoa
2022-09-15 - international - T20 - male - 1332496 - Botswana vs Uganda
2022-09-15 - international - ODI - male - 1331367 - Namibia vs United States of America
2022-09-15 - club - CPL - male - 1323162 - Barbados Royals vs Jamaica Tallawahs
2022-09-14 - international - T20 - male - 1333927 - Fiji vs Cook Islands
2022-09-14 - international - T20 - male - 1333926 - Samoa vs Vanuatu
2022-09-14 - club - CPL - male - 1323161 - Trinbago Knight Riders vs Guyana Amazon Warriors
2022-09-14 - club - CPL - male - 1323160 - Jamaica Tallawahs vs St Kitts and Nevis Patriots
2022-09-13 - international - T20 - male - 1333925 - Vanuatu vs Fiji
2022-09-13 - international - T20 - male - 1333924 - Samoa vs Cook Islands
2022-09-13 - international - ODI - male - 1331366 - Papua New Guinea vs United States of America
2022-09-13 - club - CPL - male - 1323159 - Trinbago Knight Riders vs Barbados Royals
2022-09-12 - club - CCH - male - 1297775 - Glamorgan vs Middlesex
2022-09-12 - club - CCH - male - 1297774 - Somerset vs Warwickshire
2022-09-12 - club - CCH - male - 1297773 - Northamptonshire vs Surrey
2022-09-12 - club - CCH - male - 1297772 - Leicestershire vs Durham
2022-09-12 - club - CCH - male - 1297771 - Sussex vs Worcestershire
2022-09-12 - club - CCH - male - 1297770 - Yorkshire vs Essex
2022-09-11 - international - T20 - male - 1333923 - Samoa vs Fiji
2022-09-11 - international - T20 - male - 1333922 - Vanuatu vs Cook Islands
2022-09-11 - international - T20 - male - 1327281 - Sri Lanka vs Pakistan
2022-09-11 - international - ODI - male - 1331365 - United States of America vs Papua New Guinea
2022-09-11 - international - ODI - male - 1317481 - Australia vs New Zealand
2022-09-11 - club - CPL - male - 1323158 - St Lucia Kings vs St Kitts and Nevis Patriots
2022-09-11 - club - CPL - male - 1323157 - Jamaica Tallawahs vs Barbados Royals
2022-09-10 - international - T20 - male - 1333921 - Samoa vs Vanuatu
2022-09-10 - international - T20 - male - 1333920 - Cook Islands vs Fiji
2022-09-10 - club - CPL - male - 1323156 - St Lucia Kings vs Guyana Amazon Warriors
2022-09-10 - club - CPL - male - 1323155 - Jamaica Tallawahs vs Trinbago Knight Riders
2022-09-09 - international - T20 - male - 1327280 - Pakistan vs Sri Lanka
2022-09-08 - international - Test - male - 1276918 - South Africa vs England
2022-09-08 - international - ODI - male - 1317480 - Australia vs New Zealand
2022-09-08 - club - CPL - male - 1323154 - St Lucia Kings vs Barbados Royals
2022-09-08 - club - CPL - male - 1323153 - Guyana Amazon Warriors vs St Kitts and Nevis Patriots
2022-09-07 - club - CPL - male - 1323152 - Jamaica Tallawahs vs St Lucia Kings
2022-09-07 - club - CPL - male - 1323151 - Barbados Royals vs Trinbago Knight Riders
2022-09-06 - international - T20 - male - 1327277 - India vs Sri Lanka
2022-09-06 - international - ODI - male - 1317479 - New Zealand vs Australia
2022-09-05 - club - CCH - male - 1297769 - Hampshire vs Northamptonshire
2022-09-05 - club - CCH - male - 1297768 - Essex vs Kent
2022-09-05 - club - CCH - male - 1297767 - Lancashire vs Yorkshire
2022-09-05 - club - CCH - male - 1297766 - Gloucestershire vs Somerset
2022-09-05 - club - CCH - male - 1297765 - Derbyshire vs Durham
2022-09-05 - club - CCH - male - 1297764 - Worcestershire vs Glamorgan
2022-09-05 - club - CCH - male - 1297763 - Nottinghamshire vs Leicestershire
2022-09-04 - international - T20 - male - 1327276 - India vs Pakistan
2022-09-04 - club - CPL - male - 1323149 - Barbados Royals vs St Lucia Kings
2022-09-03 - international - ODI - male - 1317478 - Australia vs Zimbabwe
2022-09-03 - club - HND - male - 1299204 - Manchester Originals vs Trent Rockets
2022-09-03 - club - CPL - male - 1323147 - Guyana Amazon Warriors vs Jamaica Tallawahs
2022-09-02 - international - T20 - male - 1327274 - Pakistan vs Hong Kong
2022-09-02 - club - HND - male - 1299203 - London Spirit vs Manchester Originals
2022-09-01 - international - T20 - male - 1327273 - Bangladesh vs Sri Lanka
2022-09-01 - club - CPL - male - 1323146 - St Kitts and Nevis Patriots vs Barbados Royals
2022-09-01 - club - CPL - male - 1323145 - St Lucia Kings vs Trinbago Knight Riders
2022-08-31 - international - T20 - male - 1327272 - India vs Hong Kong
2022-08-31 - international - ODI - male - 1317477 - Zimbabwe vs Australia
2022-08-31 - club - HND - male - 1299202 - Oval Invincibles vs Manchester Originals
2022-08-31 - club - HND - male - 1299201 - Northern Superchargers vs Southern Brave
2022-08-31 - club - CPL - male - 1323144 - Jamaica Tallawahs vs St Kitts and Nevis Patriots
2022-08-30 - international - T20 - male - 1328478 - Nepal vs Kenya
2022-08-30 - club - RLC - male - 1298032 - Lancashire vs Sussex
2022-08-30 - club - RLC - male - 1298031 - Hampshire vs Kent
2022-08-30 - club - HND - male - 1299200 - London Spirit vs Birmingham Phoenix
2022-08-29 - international - T20 - male - 1328477 - Kenya vs Nepal
2022-08-29 - club - HND - male - 1299199 - Trent Rockets vs Welsh Fire
2022-08-28 - international - T20 - male - 1328476 - Kenya vs Nepal
2022-08-28 - international - T20 - male - 1327270 - Pakistan vs India
2022-08-28 - international - ODI - male - 1317476 - Zimbabwe vs Australia
2022-08-28 - club - HND - male - 1299198 - Manchester Originals vs Birmingham Phoenix
2022-08-27 - club - HND - male - 1299197 - London Spirit vs Oval Invincibles
2022-08-26 - club - RLC - male - 1298030 - Kent vs Leicestershire
2022-08-26 - club - RLC - male - 1298029 - Nottinghamshire vs Lancashire
2022-08-26 - club - HND - male - 1299196 - Welsh Fire vs Northern Superchargers
2022-08-25 - international - Test - male - 1276917 - South Africa vs England
2022-08-25 - international - T20 - male - 1328474 - Kenya vs Nepal
2022-08-25 - club - HND - male - 1299195 - Trent Rockets vs Southern Brave
2022-08-24 - international - T20 - male - 1328854 - United Arab Emirates vs Hong Kong
2022-08-24 - international - T20 - male - 1328853 - Singapore vs Kuwait
2022-08-24 - club - HND - male - 1299194 - London Spirit vs Welsh Fire
2022-08-23 - international - T20 - male - 1328852 - Kuwait vs Hong Kong
2022-08-23 - club - RLC - male - 1298028 - Hampshire vs Yorkshire
2022-08-23 - club - RLC - male - 1298027 - Glamorgan vs Worcestershire
2022-08-23 - club - RLC - male - 1298026 - Somerset vs Warwickshire
2022-08-23 - club - RLC - male - 1298025 - Sussex vs Middlesex
2022-08-23 - club - RLC - male - 1298024 - Surrey vs Nottinghamshire
2022-08-23 - club - RLC - male - 1298023 - Northamptonshire vs Derbyshire
2022-08-23 - club - RLC - male - 1298022 - Durham vs Leicestershire
2022-08-23 - club - RLC - male - 1298021 - Lancashire vs Kent
2022-08-23 - club - HND - male - 1299193 - Birmingham Phoenix vs Oval Invincibles
2022-08-22 - international - T20 - male - 1328851 - United Arab Emirates vs Singapore
2022-08-22 - international - ODI - male - 1325551 - India vs Zimbabwe
2022-08-22 - club - HND - male - 1299192 - Welsh Fire vs Southern Brave
2022-08-21 - international - T20 - male - 1328850 - United Arab Emirates vs Kuwait
2022-08-21 - international - ODI - male - 1317913 - West Indies vs New Zealand
2022-08-21 - international - ODI - male - 1311739 - Pakistan vs Netherlands
2022-08-21 - club - RLC - male - 1298020 - Warwickshire vs Durham
2022-08-21 - club - RLC - male - 1298019 - Middlesex vs Gloucestershire
2022-08-21 - club - RLC - male - 1298018 - Essex vs Hampshire
2022-08-21 - club - RLC - male - 1298017 - Derbyshire vs Yorkshire
2022-08-21 - club - HND - male - 1299191 - Manchester Originals vs Northern Superchargers
2022-08-20 - international - T20 - male - 1328849 - Hong Kong vs Singapore
2022-08-20 - international - ODI - male - 1325550 - Zimbabwe vs India
2022-08-20 - club - RLC - male - 1298016 - Nottinghamshire vs Leicestershire
2022-08-20 - club - HND - male - 1299190 - London Spirit vs Trent Rockets
2022-08-19 - international - ODI - male - 1317912 - New Zealand vs West Indies
2022-08-19 - club - RLC - male - 1298015 - Essex vs Worcestershire
2022-08-19 - club - RLC - male - 1298014 - Surrey vs Gloucestershire
2022-08-19 - club - RLC - male - 1298013 - Sussex vs Somerset
2022-08-19 - club - RLC - male - 1298012 - Middlesex vs Warwickshire
2022-08-19 - club - RLC - male - 1298011 - Northamptonshire vs Lancashire
2022-08-19 - club - RLC - male - 1298010 - Yorkshire vs Kent
2022-08-19 - club - RLC - male - 1298009 - Hampshire vs Glamorgan
2022-08-19 - club - HND - male - 1299189 - Northern Superchargers vs Birmingham Phoenix
2022-08-18 - international - ODI - male - 1325549 - Zimbabwe vs India
2022-08-18 - international - ODI - male - 1311738 - Netherlands vs Pakistan
2022-08-18 - club - HND - male - 1299188 - Manchester Originals vs Southern Brave
2022-08-17 - international - Test - male - 1276916 - England vs South Africa
2022-08-17 - international - T20 - male - 1328473 - Kuwait vs Bahrain
2022-08-17 - international - ODI - male - 1322041 - Scotland vs United States of America
2022-08-17 - international - ODI - male - 1317911 - New Zealand vs West Indies
2022-08-17 - club - RLC - male - 1298008 - Warwickshire vs Nottinghamshire
2022-08-17 - club - RLC - male - 1298007 - Surrey vs Somerset
2022-08-17 - club - RLC - male - 1298006 - Northamptonshire vs Worcestershire
2022-08-17 - club - RLC - male - 1298005 - Gloucestershire vs Leicestershire
2022-08-17 - club - RLC - male - 1298004 - Glamorgan vs Lancashire
2022-08-17 - club - RLC - male - 1298003 - Essex vs Yorkshire
2022-08-17 - club - RLC - male - 1298002 - Durham vs Sussex
2022-08-17 - club - HND - male - 1299187 - Trent Rockets vs Oval Invincibles
2022-08-16 - international - ODI - male - 1311737 - Pakistan vs Netherlands
2022-08-16 - club - HND - male - 1299186 - Manchester Originals vs Welsh Fire
2022-08-15 - club - HND - male - 1299185 - Trent Rockets vs Birmingham Phoenix
2022-08-14 - international - T20 - male - 1328471 - Bahrain vs Kuwait
2022-08-14 - international - T20 - male - 1317910 - New Zealand vs West Indies
2022-08-14 - international - ODM - male - 1326870 - Jersey vs Kenya
2022-08-14 - international - ODI - male - 1322039 - Scotland vs United Arab Emirates
2022-08-14 - club - RLC - male - 1298000 - Derbyshire vs Worcestershire
2022-08-14 - club - RLC - male - 1297999 - Sussex vs Surrey
2022-08-14 - club - RLC - male - 1297998 - Somerset vs Middlesex
2022-08-14 - club - RLC - male - 1297997 - Durham vs Nottinghamshire
2022-08-14 - club - RLC - male - 1297996 - Leicestershire vs Warwickshire
2022-08-14 - club - RLC - male - 1297995 - Northamptonshire vs Kent
2022-08-14 - club - RLC - male - 1297994 - Lancashire vs Hampshire
2022-08-14 - club - RLC - male - 1297993 - Essex vs Glamorgan
2022-08-14 - club - HND - male - 1299184 - Southern Brave vs Oval Invincibles
2022-08-14 - club - HND - male - 1299183 - Northern Superchargers vs London Spirit
2022-08-13 - international - T20 - male - 1328470 - Kuwait vs Bahrain
2022-08-13 - international - ODM - male - 1326869 - Jersey vs Italy
2022-08-13 - international - ODI - male - 1322038 - United States of America vs Scotland
2022-08-13 - club - HND - male - 1299182 - Birmingham Phoenix vs Welsh Fire
2022-08-13 - club - HND - male - 1299181 - Manchester Originals vs Trent Rockets
2022-08-12 - international - T20 - male - 1317909 - New Zealand vs West Indies
2022-08-12 - club - RLC - male - 1297992 - Warwickshire vs Sussex
2022-08-12 - club - RLC - male - 1297991 - Middlesex vs Nottinghamshire
2022-08-12 - club - RLC - male - 1297990 - Glamorgan vs Northamptonshire
2022-08-12 - club - RLC - male - 1297989 - Leicestershire vs Somerset
2022-08-12 - club - RLC - male - 1297988 - Gloucestershire vs Durham
2022-08-12 - club - RLC - male - 1297987 - Derbyshire vs Hampshire
2022-08-12 - club - HND - male - 1299180 - London Spirit vs Southern Brave
2022-08-11 - international - ODM - male - 1326867 - Bermuda vs Kenya
2022-08-11 - international - ODI - male - 1322037 - United Arab Emirates vs United States of America
2022-08-11 - club - RLC - male - 1297986 - Essex vs Kent
2022-08-11 - club - HND - male - 1299179 - Northern Superchargers vs Oval Invincibles
2022-08-10 - international - T20 - male - 1317908 - New Zealand vs West Indies
2022-08-10 - international - ODM - male - 1326865 - Hong Kong vs Jersey
2022-08-10 - international - ODM - male - 1326864 - Kenya vs Uganda
2022-08-10 - international - ODI - male - 1323294 - Bangladesh vs Zimbabwe
2022-08-10 - international - ODI - male - 1322036 - Scotland vs United Arab Emirates
2022-08-10 - club - RLC - male - 1297985 - Durham vs Somerset
2022-08-10 - club - RLC - male - 1297984 - Middlesex vs Surrey
2022-08-10 - club - RLC - male - 1297983 - Worcestershire vs Lancashire
2022-08-10 - club - RLC - male - 1297982 - Nottinghamshire vs Gloucestershire
2022-08-10 - club - RLC - male - 1297981 - Yorkshire vs Glamorgan
2022-08-10 - club - HND - male - 1299178 - Birmingham Phoenix vs Southern Brave
2022-08-09 - club - RLC - male - 1297980 - Hampshire vs Northamptonshire
2022-08-09 - club - HND - male - 1299177 - Northern Superchargers vs Trent Rockets
2022-08-08 - international - ODM - male - 1326863 - Kenya vs Italy
2022-08-08 - club - HND - male - 1299176 - London Spirit vs Manchester Originals
2022-08-07 - international - T20 - male - 1317907 - India vs West Indies
2022-08-07 - international - ODM - male - 1326860 - Italy vs Uganda
2022-08-07 - international - ODI - male - 1323293 - Bangladesh vs Zimbabwe
2022-08-07 - club - RLC - male - 1297979 - Worcestershire vs Yorkshire
2022-08-07 - club - RLC - male - 1297978 - Leicestershire vs Sussex
2022-08-07 - club - RLC - male - 1297977 - Warwickshire vs Surrey
2022-08-07 - club - RLC - male - 1297976 - Essex vs Northamptonshire
2022-08-07 - club - RLC - male - 1297975 - Lancashire vs Derbyshire
2022-08-07 - club - RLC - male - 1297974 - Hampshire vs Kent
2022-08-07 - club - RLC - male - 1297973 - Somerset vs Gloucestershire
2022-08-07 - club - RLC - male - 1297972 - Durham vs Middlesex
2022-08-07 - club - HND - male - 1299175 - Oval Invincibles vs Welsh Fire
2022-08-06 - international - T20 - male - 1317906 - India vs West Indies
2022-08-06 - international - ODM - male - 1326351 - Vanuatu vs Singapore
2022-08-06 - international - ODM - male - 1326350 - Qatar vs Malaysia
2022-08-06 - club - HND - male - 1299174 - Birmingham Phoenix vs Trent Rockets
2022-08-05 - international - T20 - male - 1310902 - Netherlands vs New Zealand
2022-08-05 - international - T20 - male - 1303316 - South Africa vs Ireland
2022-08-05 - international - ODM - male - 1326859 - Uganda vs Jersey
2022-08-05 - international - ODM - male - 1326349 - Denmark vs Malaysia
2022-08-05 - international - ODM - male - 1326348 - Canada vs Vanuatu
2022-08-05 - international - ODI - male - 1323292 - Bangladesh vs Zimbabwe
2022-08-05 - club - RLC - male - 1297971 - Sussex vs Gloucestershire
2022-08-05 - club - RLC - male - 1297970 - Hampshire vs Worcestershire
2022-08-05 - club - RLC - male - 1297969 - Derbyshire vs Essex
2022-08-05 - club - HND - male - 1299173 - Manchester Originals vs Northern Superchargers
2022-08-04 - international - T20 - male - 1310901 - New Zealand vs Netherlands
2022-08-04 - international - ODM - male - 1326857 - Italy vs Bermuda
2022-08-04 - club - RLC - male - 1297968 - Yorkshire vs Lancashire
2022-08-04 - club - RLC - male - 1297967 - Somerset vs Nottinghamshire
2022-08-04 - club - RLC - male - 1297966 - Leicestershire vs Middlesex
2022-08-04 - club - RLC - male - 1297965 - Kent vs Glamorgan
2022-08-04 - club - RLC - male - 1297964 - Durham vs Surrey
2022-08-04 - club - HND - male - 1299172 - London Spirit vs Oval Invincibles
2022-08-03 - international - T20 - male - 1303315 - South Africa vs Ireland
2022-08-03 - international - ODM - male - 1326347 - Canada vs Qatar
2022-08-03 - international - ODM - male - 1326346 - Denmark vs Singapore
2022-08-03 - club - HND - male - 1299171 - Welsh Fire vs Southern Brave
2022-08-02 - international - T20 - male - 1323297 - Zimbabwe vs Bangladesh
2022-08-02 - international - T20 - male - 1317905 - West Indies vs India
2022-08-02 - international - ODM - male - 1326344 - Malaysia vs Singapore
2022-08-02 - club - RLC - male - 1297963 - Yorkshire vs Northamptonshire
2022-08-02 - club - RLC - male - 1297962 - Worcestershire vs Kent
2022-08-02 - club - RLC - male - 1297961 - Surrey vs Leicestershire
2022-08-02 - club - RLC - male - 1297960 - Nottinghamshire vs Sussex
2022-08-02 - club - RLC - male - 1297958 - Gloucestershire vs Warwickshire
2022-08-02 - club - RLC - male - 1297957 - Derbyshire vs Glamorgan
2022-08-01 - international - T20 - male - 1317904 - India vs West Indies
2022-07-31 - international - T20 - male - 1323296 - Zimbabwe vs Bangladesh
2022-07-31 - international - T20 - male - 1321304 - Norway vs Austria
2022-07-31 - international - T20 - male - 1321303 - Luxembourg vs Switzerland
2022-07-31 - international - T20 - male - 1321302 - Guernsey vs France
2022-07-31 - international - T20 - male - 1321301 - Bulgaria vs Czech Republic
2022-07-31 - international - T20 - male - 1276915 - South Africa vs England
2022-07-31 - international - ODM - male - 1326343 - Denmark vs Qatar
2022-07-31 - international - ODM - male - 1326342 - Canada vs Malaysia
2022-07-31 - international - ODI - male - 1307479 - Scotland vs New Zealand
2022-07-30 - international - T20 - male - 1323295 - Zimbabwe vs Bangladesh
2022-07-30 - international - T20 - male - 1321299 - Luxembourg vs Slovenia
2022-07-30 - international - T20 - male - 1321298 - Switzerland vs Czech Republic
2022-07-30 - international - ODM - male - 1326341 - Singapore vs Canada
2022-07-30 - international - ODM - male - 1326340 - Denmark vs Vanuatu
2022-07-29 - international - T20 - male - 1317903 - India vs West Indies
2022-07-29 - international - T20 - male - 1307478 - New Zealand vs Scotland
2022-07-29 - club - IPT - male - 1305451 - Northern Knights vs Leinster Lightning
2022-07-29 - club - IPT - male - 1305450 - North-West Warriors vs Munster Reds
2022-07-28 - international - T20 - male - 1321296 - Slovenia vs Guernsey
2022-07-28 - international - T20 - male - 1321295 - Czech Republic vs Estonia
2022-07-28 - international - T20 - male - 1321294 - Luxembourg vs Bulgaria
2022-07-28 - international - T20 - male - 1321293 - Norway vs Switzerland
2022-07-28 - international - T20 - male - 1276914 - South Africa vs England
2022-07-28 - international - ODM - male - 1326338 - Singapore vs Qatar
2022-07-28 - club - IPT - male - 1305449 - Leinster Lightning vs North-West Warriors
2022-07-28 - club - IPT - male - 1305448 - Northern Knights vs Munster Reds
2022-07-27 - international - T20 - male - 1321292 - France vs Norway
2022-07-27 - international - T20 - male - 1321291 - Slovenia vs Bulgaria
2022-07-27 - international - T20 - male - 1321290 - Switzerland vs Estonia
2022-07-27 - international - T20 - male - 1321289 - Guernsey vs Austria
2022-07-27 - international - T20 - male - 1307477 - New Zealand vs Scotland
2022-07-27 - international - T20 - male - 1276913 - England vs South Africa
2022-07-27 - international - ODI - male - 1317902 - India vs West Indies
2022-07-27 - club - IPT - male - 1305447 - North-West Warriors vs Northern Knights
2022-07-27 - club - IPT - male - 1305446 - Munster Reds vs Leinster Lightning
2022-07-26 - club - CCH - male - 1297762 - Nottinghamshire vs Sussex
2022-07-25 - international - T20 - male - 1321288 - Guernsey vs Luxembourg
2022-07-25 - international - T20 - male - 1321287 - France vs Switzerland
2022-07-25 - international - T20 - male - 1321286 - Austria vs Slovenia
2022-07-25 - club - CCH - male - 1297761 - Warwickshire vs Surrey
2022-07-25 - club - CCH - male - 1297760 - Gloucestershire vs Northamptonshire
2022-07-25 - club - CCH - male - 1297759 - Yorkshire vs Hampshire
2022-07-25 - club - CCH - male - 1297758 - Essex vs Somerset
2022-07-25 - club - CCH - male - 1297757 - Durham vs Middlesex
2022-07-25 - club - CCH - male - 1297756 - Derbyshire vs Worcestershire
2022-07-25 - club - CCH - male - 1297755 - Lancashire vs Kent
2022-07-24 - international - Test - male - 1320954 - Sri Lanka vs Pakistan
2022-07-24 - international - T20 - male - 1321284 - France vs Czech Republic
2022-07-24 - international - T20 - male - 1321283 - Guernsey vs Bulgaria
2022-07-24 - international - T20 - male - 1321282 - Estonia vs Norway
2022-07-24 - international - T20 - male - 1321281 - Austria vs Luxembourg
2022-07-24 - international - ODI - male - 1317901 - West Indies vs India
2022-07-24 - international - ODI - male - 1276912 - South Africa vs England
2022-07-22 - international - T20 - male - 1303314 - Ireland vs New Zealand
2022-07-22 - international - ODI - male - 1317900 - India vs West Indies
2022-07-22 - international - ODI - male - 1276911 - England vs South Africa
2022-07-20 - international - T20 - male - 1303313 - New Zealand vs Ireland
2022-07-20 - club - CCH - male - 1297754 - Leicestershire vs Glamorgan
2022-07-19 - international - T20 - male - 1321280 - Isle of Man vs Italy
2022-07-19 - international - T20 - male - 1321279 - Romania vs Sweden
2022-07-19 - international - T20 - male - 1321278 - Finland vs Cyprus
2022-07-19 - international - T20 - male - 1321277 - Serbia vs Croatia
2022-07-19 - international - ODI - male - 1276910 - South Africa vs England
2022-07-19 - club - CCH - male - 1297753 - Northamptonshire vs Lancashire
2022-07-19 - club - CCH - male - 1297752 - Sussex vs Middlesex
2022-07-19 - club - CCH - male - 1297751 - Nottinghamshire vs Derbyshire
2022-07-19 - club - CCH - male - 1297750 - Kent vs Warwickshire
2022-07-19 - club - CCH - male - 1297749 - Essex vs Surrey
2022-07-19 - club - CCH - male - 1297748 - Somerset vs Yorkshire
2022-07-19 - club - CCH - male - 1297747 - Hampshire vs Gloucestershire
2022-07-18 - international - T20 - male - 1321276 - Isle of Man vs Turkey
2022-07-18 - international - T20 - male - 1321275 - Croatia vs Finland
2022-07-18 - international - T20 - male - 1321274 - Cyprus vs Serbia
2022-07-18 - international - T20 - male - 1321273 - Sweden vs Greece
2022-07-18 - international - T20 - male - 1303312 - New Zealand vs Ireland
2022-07-17 - international - T20 - male - 1321484 - Zimbabwe vs Netherlands
2022-07-17 - international - T20 - male - 1321483 - Papua New Guinea vs United States of America
2022-07-17 - international - T20 - male - 1321482 - Singapore vs Jersey
2022-07-17 - international - T20 - male - 1321481 - Uganda vs Hong Kong
2022-07-17 - international - ODI - male - 1322035 - Nepal vs Scotland
2022-07-17 - international - ODI - male - 1276909 - England vs India
2022-07-16 - international - Test - male - 1320953 - Sri Lanka vs Pakistan
2022-07-16 - international - T20 - male - 1321272 - Italy vs Croatia
2022-07-16 - international - T20 - male - 1321271 - Cyprus vs Turkey
2022-07-16 - international - T20 - male - 1321270 - Finland vs Greece
2022-07-16 - international - T20 - male - 1321269 - Romania vs Serbia
2022-07-16 - international - ODI - male - 1322034 - Namibia vs Nepal
2022-07-16 - international - ODI - male - 1317154 - West Indies vs Bangladesh
2022-07-16 - club - NTB - male - 1297926 - Hampshire vs Lancashire
2022-07-16 - club - NTB - male - 1297925 - Hampshire vs Somerset
2022-07-16 - club - NTB - male - 1297924 - Yorkshire vs Lancashire
2022-07-15 - international - T20 - male - 1321480 - United States of America vs Netherlands
2022-07-15 - international - T20 - male - 1321479 - Zimbabwe vs Papua New Guinea
2022-07-15 - international - T20 - male - 1321478 - Singapore vs Hong Kong
2022-07-15 - international - T20 - male - 1321477 - Uganda vs Jersey
2022-07-15 - international - T20 - male - 1321268 - Romania vs Isle of Man
2022-07-15 - international - T20 - male - 1321267 - Croatia vs Greece
2022-07-15 - international - T20 - male - 1321266 - Turkey vs Serbia
2022-07-15 - international - T20 - male - 1321265 - Italy vs Sweden
2022-07-15 - international - ODI - male - 1303311 - New Zealand vs Ireland
2022-07-14 - international - T20 - male - 1321475 - Zimbabwe vs United States of America
2022-07-14 - international - T20 - male - 1321474 - Papua New Guinea vs Hong Kong
2022-07-14 - international - T20 - male - 1321473 - Netherlands vs Uganda
2022-07-14 - international - ODI - male - 1322033 - Namibia vs Scotland
2022-07-14 - international - ODI - male - 1276908 - England vs India
2022-07-13 - international - T20 - male - 1321264 - Finland vs Italy
2022-07-13 - international - T20 - male - 1321263 - Isle of Man vs Serbia
2022-07-13 - international - T20 - male - 1321262 - Croatia vs Sweden
2022-07-13 - international - T20 - male - 1321261 - Cyprus vs Romania
2022-07-13 - international - ODI - male - 1322032 - Scotland vs Nepal
2022-07-13 - international - ODI - male - 1317153 - West Indies vs Bangladesh
2022-07-12 - international - T20 - male - 1321472 - Uganda vs Papua New Guinea
2022-07-12 - international - T20 - male - 1321471 - Hong Kong vs Netherlands
2022-07-12 - international - T20 - male - 1321470 - United States of America vs Singapore
2022-07-12 - international - T20 - male - 1321469 - Zimbabwe vs Jersey
2022-07-12 - international - T20 - male - 1321260 - Romania vs Turkey
2022-07-12 - international - T20 - male - 1321259 - Finland vs Sweden
2022-07-12 - international - T20 - male - 1321258 - Cyprus vs Isle of Man
2022-07-12 - international - ODI - male - 1303310 - Ireland vs New Zealand
2022-07-12 - international - ODI - male - 1276907 - England vs India
2022-07-11 - international - T20 - male - 1322010 - Bhutan vs Malaysia
2022-07-11 - international - T20 - male - 1321468 - Hong Kong vs Uganda
2022-07-11 - international - T20 - male - 1321467 - Netherlands vs Papua New Guinea
2022-07-11 - international - T20 - male - 1321466 - Jersey vs United States of America
2022-07-11 - international - T20 - male - 1321465 - Zimbabwe vs Singapore
2022-07-11 - international - ODI - male - 1322031 - Namibia vs Nepal
2022-07-11 - club - CCH - male - 1297746 - Glamorgan vs Nottinghamshire
2022-07-11 - club - CCH - male - 1297745 - Yorkshire vs Surrey
2022-07-11 - club - CCH - male - 1297744 - Northamptonshire vs Kent
2022-07-11 - club - CCH - male - 1297743 - Sussex vs Leicestershire
2022-07-11 - club - CCH - male - 1297742 - Derbyshire vs Durham
2022-07-11 - club - CCH - male - 1297741 - Middlesex vs Worcestershire
2022-07-11 - club - CCH - male - 1297740 - Gloucestershire vs Essex
2022-07-11 - club - CCH - male - 1297739 - Warwickshire vs Hampshire
2022-07-11 - club - CCH - male - 1297738 - Somerset vs Lancashire
2022-07-10 - international - T20 - male - 1321310 - Austria vs Czech Republic
2022-07-10 - international - T20 - male - 1321309 - Czech Republic vs Luxembourg
2022-07-10 - international - T20 - male - 1276906 - England vs India
2022-07-10 - international - ODI - male - 1317152 - West Indies vs Bangladesh
2022-07-10 - international - ODI - male - 1303309 - Ireland vs New Zealand
2022-07-09 - international - T20 - male - 1323552 - Bulgaria vs Serbia
2022-07-09 - international - T20 - male - 1323551 - Bulgaria vs Serbia
2022-07-09 - international - T20 - male - 1322009 - Bhutan vs Thailand
2022-07-09 - international - T20 - male - 1321308 - Austria vs Luxembourg
2022-07-09 - international - T20 - male - 1321307 - Czech Republic vs Austria
2022-07-09 - international - T20 - male - 1276905 - India vs England
2022-07-09 - club - NTB - male - 1297923 - Somerset vs Derbyshire
2022-07-08 - international - Test - male - 1307302 - Australia vs Sri Lanka
2022-07-08 - international - T20 - male - 1323550 - Bulgaria vs Serbia
2022-07-08 - international - T20 - male - 1322007 - Maldives vs Thailand
2022-07-08 - international - T20 - male - 1321306 - Luxembourg vs Czech Republic
2022-07-08 - international - T20 - male - 1321305 - Luxembourg vs Austria
2022-07-08 - club - NTB - male - 1297922 - Essex vs Lancashire
2022-07-07 - international - T20 - male - 1322006 - Thailand vs Malaysia
2022-07-07 - international - T20 - male - 1322005 - Bhutan vs Maldives
2022-07-07 - international - T20 - male - 1317151 - Bangladesh vs West Indies
2022-07-07 - international - T20 - male - 1276904 - India vs England
2022-07-07 - club - NTB - male - 1297921 - Hampshire vs Birmingham Bears
2022-07-06 - international - T20 - male - 1322004 - Maldives vs Malaysia
2022-07-06 - international - T20 - male - 1322003 - Thailand vs Bhutan
2022-07-06 - club - NTB - male - 1297920 - Yorkshire vs Surrey
2022-07-04 - international - T20 - male - 1322002 - Bhutan vs Maldives
2022-07-04 - international - T20 - male - 1322001 - Thailand vs Malaysia
2022-07-04 - international - T20 - male - 1320988 - Portugal vs Denmark
2022-07-04 - international - T20 - male - 1320986 - Spain vs Belgium
2022-07-04 - club - IPO - male - 1305433 - Leinster Lightning vs Northern Knights
2022-07-03 - international - T20 - male - 1322012 - Singapore vs Papua New Guinea
2022-07-03 - international - T20 - male - 1320987 - Gibraltar vs Malta
2022-07-03 - international - T20 - male - 1320985 - Israel vs Hungary
2022-07-03 - international - T20 - male - 1317150 - West Indies vs Bangladesh
2022-07-03 - club - NTB - male - 1297919 - Leicestershire vs Yorkshire
2022-07-03 - club - NTB - male - 1297918 - Durham vs Derbyshire
2022-07-03 - club - NTB - male - 1297917 - Somerset vs Surrey
2022-07-03 - club - NTB - male - 1297916 - Sussex vs Hampshire
2022-07-03 - club - NTB - male - 1297915 - Worcestershire vs Nottinghamshire
2022-07-03 - club - NTB - male - 1297914 - Birmingham Bears vs Lancashire
2022-07-03 - club - NTB - male - 1297913 - Glamorgan vs Kent
2022-07-03 - club - NTB - male - 1297912 - Middlesex vs Gloucestershire
2022-07-02 - international - T20 - male - 1322011 - Singapore vs Papua New Guinea
2022-07-02 - international - T20 - male - 1321998 - Malaysia vs Bhutan
2022-07-02 - international - T20 - male - 1320984 - Denmark vs Spain
2022-07-02 - international - T20 - male - 1320982 - Belgium vs Portugal
2022-07-02 - international - T20 - male - 1317149 - Bangladesh vs West Indies
2022-07-02 - club - NTB - male - 1297911 - Essex vs Glamorgan
2022-07-01 - international - Test - male - 1320741 - India vs England
2022-07-01 - international - T20 - male - 1320980 - Belgium vs Denmark
2022-07-01 - international - T20 - male - 1320979 - Malta vs Israel
2022-07-01 - international - T20 - male - 1320978 - Hungary vs Gibraltar
2022-07-01 - international - T20 - male - 1320977 - Portugal vs Spain
2022-07-01 - club - NTB - male - 1297910 - Leicestershire vs Northamptonshire
2022-07-01 - club - NTB - male - 1297909 - Durham vs Nottinghamshire
2022-07-01 - club - NTB - male - 1297908 - Essex vs Sussex
2022-07-01 - club - NTB - male - 1297907 - Worcestershire vs Lancashire
2022-07-01 - club - NTB - male - 1297906 - Middlesex vs Somerset
2022-07-01 - club - NTB - male - 1297905 - Kent vs Surrey
2022-07-01 - club - NTB - male - 1297904 - Birmingham Bears vs Yorkshire
2022-07-01 - club - NTB - male - 1297903 - Hampshire vs Gloucestershire
2022-06-30 - international - T20 - male - 1321313 - Singapore vs Malaysia
2022-06-29 - international - Test - male - 1307301 - Sri Lanka vs Australia
2022-06-29 - international - T20 - male - 1321312 - Malaysia vs Singapore
2022-06-29 - international - T20 - male - 1320976 - Hungary vs Belgium
2022-06-29 - international - T20 - male - 1320975 - Israel vs Spain
2022-06-29 - international - T20 - male - 1320974 - Denmark vs Gibraltar
2022-06-29 - international - T20 - male - 1320973 - Portugal vs Malta
2022-06-28 - international - T20 - male - 1321311 - Malaysia vs Singapore
2022-06-28 - international - T20 - male - 1320969 - Gibraltar vs Belgium
2022-06-28 - international - T20 - male - 1303308 - India vs Ireland
2022-06-26 - international - T20 - male - 1317139 - Serbia vs Bulgaria
2022-06-26 - international - T20 - male - 1303307 - Ireland vs India
2022-06-26 - international - ODM - male - 1317961 - Kenya vs Uganda
2022-06-26 - club - CCH - male - 1297737 - Gloucestershire vs Lancashire
2022-06-26 - club - CCH - male - 1297736 - Northamptonshire vs Warwickshire
2022-06-26 - club - CCH - male - 1297735 - Essex vs Hampshire
2022-06-26 - club - CCH - male - 1297734 - Worcestershire vs Glamorgan
2022-06-26 - club - CCH - male - 1297733 - Derbyshire vs Sussex
2022-06-26 - club - CCH - male - 1297732 - Nottinghamshire vs Middlesex
2022-06-26 - club - CCH - male - 1297731 - Surrey vs Kent
2022-06-25 - international - T20 - male - 1317138 - Serbia vs Bulgaria
2022-06-25 - international - T20 - male - 1317137 - Serbia vs Bulgaria
2022-06-24 - international - Test - male - 1317148 - Bangladesh vs West Indies
2022-06-24 - international - T20 - male - 1317136 - Serbia vs Bulgaria
2022-06-24 - international - ODM - male - 1317960 - Italy vs Uganda
2022-06-24 - international - ODI - male - 1307300 - Sri Lanka vs Australia
2022-06-24 - club - NTB - male - 1297902 - Derbyshire vs Lancashire
2022-06-24 - club - NTB - male - 1297901 - Yorkshire vs Northamptonshire
2022-06-24 - club - NTB - male - 1297900 - Essex vs Surrey
2022-06-24 - club - NTB - male - 1297899 - Somerset vs Glamorgan
2022-06-24 - club - NTB - male - 1297898 - Nottinghamshire vs Durham
2022-06-24 - club - NTB - male - 1297897 - Birmingham Bears vs Worcestershire
2022-06-24 - club - NTB - male - 1297896 - Sussex vs Kent
2022-06-24 - club - NTB - male - 1297895 - Hampshire vs Gloucestershire
2022-06-23 - international - Test - male - 1276903 - New Zealand vs England
2022-06-23 - international - ODM - male - 1317957 - Kenya vs Italy
2022-06-23 - club - NTB - male - 1297894 - Nottinghamshire vs Derbyshire
2022-06-23 - club - NTB - male - 1297893 - Hampshire vs Somerset
2022-06-23 - club - NTB - male - 1297892 - Sussex vs Surrey
2022-06-23 - club - NTB - male - 1297891 - Lancashire vs Durham
2022-06-23 - club - NTB - male - 1297890 - Worcestershire vs Yorkshire
2022-06-23 - club - NTB - male - 1297889 - Essex vs Middlesex
2022-06-22 - international - ODI - male - 1281446 - Netherlands vs England
2022-06-22 - club - NTB - male - 1297888 - Northamptonshire vs Birmingham Bears
2022-06-21 - international - ODM - male - 1317956 - Jersey vs Italy
2022-06-21 - international - ODM - male - 1317955 - Bermuda vs Uganda
2022-06-21 - international - ODI - male - 1307299 - Sri Lanka vs Australia
2022-06-21 - club - NTB - male - 1297887 - Leicestershire vs Nottinghamshire
2022-06-21 - club - NTB - male - 1297886 - Northamptonshire vs Derbyshire
2022-06-21 - club - NTB - male - 1297885 - Middlesex vs Glamorgan
2022-06-21 - club - NTB - male - 1297884 - Somerset vs Surrey
2022-06-21 - club - NTB - male - 1297883 - Gloucestershire vs Kent
2022-06-20 - international - ODM - male - 1317954 - Uganda vs Hong Kong
2022-06-20 - international - ODM - male - 1317953 - Jersey vs Kenya
2022-06-19 - international - T20 - male - 1278691 - India vs South Africa
2022-06-19 - international - ODI - male - 1307298 - Australia vs Sri Lanka
2022-06-19 - international - ODI - male - 1281445 - Netherlands vs England
2022-06-19 - club - NTB - male - 1297882 - Essex vs Somerset
2022-06-19 - club - NTB - male - 1297881 - Nottinghamshire vs Lancashire
2022-06-19 - club - NTB - male - 1297880 - Sussex vs Glamorgan
2022-06-19 - club - NTB - male - 1297879 - Leicestershire vs Durham
2022-06-19 - club - NTB - male - 1297878 - Kent vs Middlesex
2022-06-19 - club - NTB - male - 1297877 - Birmingham Bears vs Derbyshire
2022-06-19 - club - NTB - male - 1297876 - Hampshire vs Surrey
2022-06-18 - international - ODM - male - 1317952 - Bermuda vs Kenya
2022-06-18 - international - ODM - male - 1317951 - Hong Kong vs Italy
2022-06-18 - club - NTB - male - 1297874 - Yorkshire vs Derbyshire
2022-06-17 - international - T20 - male - 1278690 - India vs South Africa
2022-06-17 - international - ODM - male - 1317950 - Jersey vs Uganda
2022-06-17 - international - ODI - male - 1281444 - England vs Netherlands
2022-06-17 - club - NTB - male - 1297872 - Worcestershire vs Leicestershire
2022-06-17 - club - NTB - male - 1297871 - Birmingham Bears vs Nottinghamshire
2022-06-17 - club - NTB - male - 1297870 - Lancashire vs Northamptonshire
2022-06-17 - club - NTB - male - 1297869 - Somerset vs Gloucestershire
2022-06-17 - club - NTB - male - 1297868 - Essex vs Sussex
2022-06-17 - club - NTB - male - 1297867 - Yorkshire vs Durham
2022-06-17 - club - NTB - male - 1297866 - Middlesex vs Surrey
2022-06-17 - club - NTB - male - 1297865 - Hampshire vs Kent
2022-06-16 - international - Test - male - 1317147 - Bangladesh vs West Indies
2022-06-16 - international - ODI - male - 1307297 - Sri Lanka vs Australia
2022-06-15 - international - ODI - male - 1312809 - United States of America vs Nepal
2022-06-14 - international - T20 - male - 1278689 - India vs South Africa
2022-06-14 - international - ODI - male - 1312808 - Oman vs Nepal
2022-06-14 - international - ODI - male - 1307296 - Sri Lanka vs Australia
2022-06-12 - international - T20 - male - 1278688 - India vs South Africa
2022-06-12 - international - ODI - male - 1315040 - Pakistan vs West Indies
2022-06-12 - international - ODI - male - 1312807 - Oman vs United States of America
2022-06-12 - club - CCH - male - 1297730 - Middlesex vs Derbyshire
2022-06-12 - club - CCH - male - 1297729 - Leicestershire vs Nottinghamshire
2022-06-12 - club - CCH - male - 1297728 - Gloucestershire vs Kent
2022-06-12 - club - CCH - male - 1297727 - Warwickshire vs Lancashire
2022-06-12 - club - CCH - male - 1297726 - Durham vs Worcestershire
2022-06-12 - club - CCH - male - 1297725 - Yorkshire vs Hampshire
2022-06-12 - club - CCH - male - 1297724 - Sussex vs Glamorgan
2022-06-12 - club - CCH - male - 1297723 - Somerset vs Surrey
2022-06-11 - international - T20 - male - 1318362 - Germany vs Sweden
2022-06-11 - international - T20 - male - 1318361 - Austria vs Sweden
2022-06-11 - international - T20 - male - 1307295 - Australia vs Sri Lanka
2022-06-11 - international - ODI - male - 1312806 - Nepal vs United States of America
2022-06-10 - international - Test - male - 1276902 - New Zealand vs England
2022-06-10 - international - T20 - male - 1318360 - Austria vs Sweden
2022-06-10 - international - T20 - male - 1318359 - Austria vs Germany
2022-06-10 - international - ODI - male - 1315039 - Pakistan vs West Indies
2022-06-10 - club - NTB - male - 1297864 - Leicestershire vs Nottinghamshire
2022-06-10 - club - NTB - male - 1297863 - Kent vs Somerset
2022-06-10 - club - NTB - male - 1297862 - Essex vs Middlesex
2022-06-10 - club - NTB - male - 1297861 - Gloucestershire vs Sussex
2022-06-10 - club - NTB - male - 1297860 - Hampshire vs Glamorgan
2022-06-10 - club - NTB - male - 1297859 - Lancashire vs Durham
2022-06-10 - club - NTB - male - 1297858 - Derbyshire vs Worcestershire
2022-06-10 - club - NTB - male - 1297857 - Birmingham Bears vs Yorkshire
2022-06-10 - club - IPT - male - 1305441 - Leinster Lightning vs Munster Reds
2022-06-10 - club - IPT - male - 1305440 - Northern Knights vs North-West Warriors
2022-06-09 - international - T20 - male - 1318358 - Sweden vs Germany
2022-06-09 - international - T20 - male - 1318357 - Germany vs Austria
2022-06-09 - international - T20 - male - 1278687 - India vs South Africa
2022-06-09 - international - ODI - male - 1312805 - Oman vs Nepal
2022-06-09 - club - NTB - male - 1297856 - Leicestershire vs Derbyshire
2022-06-09 - club - NTB - male - 1297855 - Northamptonshire vs Worcestershire
2022-06-09 - club - NTB - male - 1297854 - Surrey vs Middlesex
2022-06-09 - club - NTB - male - 1297853 - Gloucestershire vs Somerset
2022-06-09 - club - NTB - male - 1297852 - Hampshire vs Essex
2022-06-08 - international - T20 - male - 1307294 - Sri Lanka vs Australia
2022-06-08 - international - ODI - male - 1315038 - West Indies vs Pakistan
2022-06-08 - international - ODI - male - 1312804 - United States of America vs Oman
2022-06-08 - club - NTB - male - 1297851 - Durham vs Birmingham Bears
2022-06-08 - club - NTB - male - 1297850 - Sussex vs Surrey
2022-06-08 - club - NTB - male - 1297849 - Lancashire vs Yorkshire
2022-06-07 - international - T20 - male - 1307293 - Sri Lanka vs Australia
2022-06-07 - club - NTB - male - 1297848 - Leicestershire vs Lancashire
2022-06-07 - club - NTB - male - 1297847 - Derbyshire vs Northamptonshire
2022-06-07 - club - NTB - male - 1297846 - Kent vs Essex
2022-06-07 - club - NTB - male - 1297845 - Glamorgan vs Gloucestershire
2022-06-07 - club - NTB - male - 1297844 - Middlesex vs Hampshire
2022-06-07 - club - IPO - male - 1305431 - Leinster Lightning vs Munster Reds
2022-06-06 - club - NTB - male - 1297843 - Yorkshire vs Nottinghamshire
2022-06-05 - club - NTB - male - 1297842 - Surrey vs Glamorgan
2022-06-05 - club - NTB - male - 1297841 - Durham vs Northamptonshire
2022-06-05 - club - NTB - male - 1297840 - Leicestershire vs Worcestershire
2022-06-05 - club - NTB - male - 1297839 - Birmingham Bears vs Nottinghamshire
2022-06-05 - club - NTB - male - 1297838 - Kent vs Middlesex
2022-06-04 - international - ODI - male - 1312803 - United States of America vs United Arab Emirates
2022-06-04 - international - ODI - male - 1302351 - West Indies vs Netherlands
2022-06-04 - club - NTB - male - 1297837 - Hampshire vs Sussex
2022-06-03 - international - ODI - male - 1312802 - Scotland vs United Arab Emirates
2022-06-03 - club - NTB - male - 1297836 - Derbyshire vs Nottinghamshire
2022-06-03 - club - NTB - male - 1297835 - Glamorgan vs Somerset
2022-06-03 - club - NTB - male - 1297834 - Middlesex vs Sussex
2022-06-03 - club - NTB - male - 1297833 - Worcestershire vs Birmingham Bears
2022-06-03 - club - NTB - male - 1297832 - Durham vs Yorkshire
2022-06-03 - club - NTB - male - 1297831 - Northamptonshire vs Lancashire
2022-06-03 - club - NTB - male - 1297830 - Surrey vs Kent
2022-06-02 - international - Test - male - 1276901 - New Zealand vs England
2022-06-02 - international - ODI - male - 1302350 - Netherlands vs West Indies
2022-06-02 - club - NTB - male - 1297828 - Essex vs Glamorgan
2022-06-02 - club - NTB - male - 1297827 - Surrey vs Hampshire
2022-06-02 - club - NTB - male - 1297826 - Leicestershire vs Birmingham Bears
2022-06-02 - club - IPO - male - 1305430 - North-West Warriors vs Northern Knights
2022-06-01 - international - ODI - male - 1312801 - United Arab Emirates vs United States of America
2022-06-01 - club - NTB - male - 1297825 - Northamptonshire vs Leicestershire
2022-06-01 - club - NTB - male - 1297824 - Sussex vs Somerset
2022-06-01 - club - NTB - male - 1297823 - Durham vs Worcestershire
2022-06-01 - club - NTB - male - 1297822 - Lancashire vs Derbyshire
2022-06-01 - club - NTB - male - 1297821 - Kent vs Gloucestershire
2022-05-31 - international - ODI - male - 1312800 - United Arab Emirates vs Scotland
2022-05-31 - international - ODI - male - 1302349 - Netherlands vs West Indies
2022-05-31 - club - NTB - male - 1297820 - Lancashire vs Nottinghamshire
2022-05-31 - club - NTB - male - 1297819 - Hampshire vs Essex
2022-05-31 - club - NTB - male - 1297818 - Surrey vs Gloucestershire
2022-05-31 - club - NTB - male - 1297817 - Yorkshire vs Derbyshire
2022-05-30 - club - NTB - male - 1297816 - Hampshire vs Somerset
2022-05-30 - club - NTB - male - 1297815 - Nottinghamshire vs Northamptonshire
2022-05-29 - international - ODI - male - 1312799 - Scotland vs United States of America
2022-05-29 - club - NTB - male - 1297814 - Essex vs Somerset
2022-05-29 - club - NTB - male - 1297813 - Sussex vs Kent
2022-05-29 - club - NTB - male - 1297812 - Glamorgan vs Middlesex
2022-05-29 - club - NTB - male - 1297811 - Leicestershire vs Yorkshire
2022-05-29 - club - NTB - male - 1297810 - Lancashire vs Worcestershire
2022-05-29 - club - NTB - male - 1297809 - Durham vs Birmingham Bears
2022-05-29 - club - IPT - male - 1305439 - Leinster Lightning vs Northern Knights
2022-05-29 - club - IPT - male - 1305438 - Munster Reds vs North-West Warriors
2022-05-29 - club - IPL - male - 1312200 - Rajasthan Royals vs Gujarat Titans
2022-05-28 - international - ODI - male - 1312798 - United States of America vs Scotland
2022-05-28 - club - NTB - male - 1297808 - Derbyshire vs Leicestershire
2022-05-28 - club - IPT - male - 1305437 - Northern Knights vs Munster Reds
2022-05-28 - club - IPT - male - 1305436 - North-West Warriors vs Leinster Lightning
2022-05-27 - club - NTB - male - 1297807 - Worcestershire vs Nottinghamshire
2022-05-27 - club - NTB - male - 1297806 - Birmingham Bears vs Derbyshire
2022-05-27 - club - NTB - male - 1297805 - Northamptonshire vs Durham
2022-05-27 - club - NTB - male - 1297804 - Glamorgan vs Surrey
2022-05-27 - club - NTB - male - 1297803 - Lancashire vs Yorkshire
2022-05-27 - club - NTB - male - 1297802 - Kent vs Essex
2022-05-27 - club - NTB - male - 1297801 - Gloucestershire vs Sussex
2022-05-27 - club - NTB - male - 1297800 - Middlesex vs Hampshire
2022-05-27 - club - IPT - male - 1305435 - Leinster Lightning vs Munster Reds
2022-05-27 - club - IPT - male - 1305434 - Northern Knights vs North-West Warriors
2022-05-27 - club - IPL - male - 1312199 - Royal Challengers Bangalore vs Rajasthan Royals
2022-05-26 - club - NTB - male - 1297799 - Durham vs Leicestershire
2022-05-26 - club - NTB - male - 1297798 - Sussex vs Glamorgan
2022-05-26 - club - NTB - male - 1297797 - Middlesex vs Gloucestershire
2022-05-26 - club - NTB - male - 1297796 - Birmingham Bears vs Northamptonshire
2022-05-25 - club - NTB - male - 1297795 - Worcestershire vs Yorkshire
2022-05-25 - club - NTB - male - 1297794 - Kent vs Somerset
2022-05-25 - club - IPL - male - 1312198 - Royal Challengers Bangalore vs Lucknow Super Giants
2022-05-24 - international - T20 - male - 1310942 - Namibia vs Zimbabwe
2022-05-24 - club - IPO - male - 1305429 - Munster Reds vs Northern Knights
2022-05-24 - club - IPL - male - 1312197 - Rajasthan Royals vs Gujarat Titans
2022-05-23 - international - Test - male - 1308489 - Bangladesh vs Sri Lanka
2022-05-22 - international - T20 - male - 1310941 - Zimbabwe vs Namibia
2022-05-22 - club - IPL - male - 1304116 - Sunrisers Hyderabad vs Punjab Kings
2022-05-21 - international - T20 - male - 1310940 - Namibia vs Zimbabwe
2022-05-21 - club - IPL - male - 1304115 - Delhi Capitals vs Mumbai Indians
2022-05-20 - international - T20 - male - 1310188 - Jersey vs Guernsey
2022-05-20 - club - IPL - male - 1304114 - Chennai Super Kings vs Rajasthan Royals
2022-05-19 - international - T20 - male - 1310939 - Zimbabwe vs Namibia
2022-05-19 - club - IPO - male - 1305427 - North-West Warriors vs Munster Reds
2022-05-19 - club - IPL - male - 1304113 - Gujarat Titans vs Royal Challengers Bangalore
2022-05-19 - club - CCH - male - 1297722 - Essex vs Lancashire
2022-05-19 - club - CCH - male - 1297721 - Leicestershire vs Worcestershire
2022-05-19 - club - CCH - male - 1297720 - Derbyshire vs Nottinghamshire
2022-05-19 - club - CCH - male - 1297719 - Durham vs Middlesex
2022-05-19 - club - CCH - male - 1297718 - Warwickshire vs Yorkshire
2022-05-19 - club - CCH - male - 1297717 - Somerset vs Hampshire
2022-05-19 - club - CCH - male - 1297716 - Kent vs Northamptonshire
2022-05-18 - club - IPL - male - 1304112 - Lucknow Super Giants vs Kolkata Knight Riders
2022-05-17 - international - T20 - male - 1310938 - Zimbabwe vs Namibia
2022-05-17 - club - IPO - male - 1305426 - Leinster Lightning vs Northern Knights
2022-05-17 - club - IPL - male - 1304111 - Sunrisers Hyderabad vs Mumbai Indians
2022-05-16 - club - IPL - male - 1304110 - Delhi Capitals vs Punjab Kings
2022-05-15 - international - Test - male - 1308488 - Sri Lanka vs Bangladesh
2022-05-15 - international - T20 - male - 1310187 - Romania vs Malta
2022-05-15 - international - T20 - male - 1310186 - Czech Republic vs Hungary
2022-05-15 - international - T20 - male - 1310185 - Gibraltar vs Bulgaria
2022-05-15 - club - IPL - male - 1304109 - Rajasthan Royals vs Lucknow Super Giants
2022-05-15 - club - IPL - male - 1304108 - Chennai Super Kings vs Gujarat Titans
2022-05-14 - international - T20 - male - 1310184 - Bulgaria vs Malta
2022-05-14 - international - T20 - male - 1310183 - Gibraltar vs Romania
2022-05-14 - international - T20 - male - 1310182 - Hungary vs Czech Republic
2022-05-14 - club - IPL - male - 1304107 - Kolkata Knight Riders vs Sunrisers Hyderabad
2022-05-13 - international - T20 - male - 1310181 - Bulgaria vs Romania
2022-05-13 - international - T20 - male - 1310180 - Romania vs Czech Republic
2022-05-13 - international - T20 - male - 1310179 - Gibraltar vs Bulgaria
2022-05-13 - club - IPL - male - 1304106 - Punjab Kings vs Royal Challengers Bangalore
2022-05-12 - international - T20 - male - 1310178 - Romania vs Hungary
2022-05-12 - international - T20 - male - 1310177 - Czech Republic vs Bulgaria
2022-05-12 - international - T20 - male - 1310176 - Malta vs Czech Republic
2022-05-12 - club - IPO - male - 1305425 - Northern Knights vs North-West Warriors
2022-05-12 - club - IPL - male - 1304105 - Chennai Super Kings vs Mumbai Indians
2022-05-12 - club - CCH - male - 1297715 - Somerset vs Gloucestershire
2022-05-12 - club - CCH - male - 1297714 - Nottinghamshire vs Middlesex
2022-05-12 - club - CCH - male - 1297713 - Leicestershire vs Sussex
2022-05-12 - club - CCH - male - 1297712 - Durham vs Glamorgan
2022-05-12 - club - CCH - male - 1297711 - Worcestershire vs Derbyshire
2022-05-12 - club - CCH - male - 1297710 - Lancashire vs Yorkshire
2022-05-12 - club - CCH - male - 1297709 - Surrey vs Kent
2022-05-12 - club - CCH - male - 1297708 - Northamptonshire vs Warwickshire
2022-05-11 - international - T20 - male - 1310175 - Hungary vs Bulgaria
2022-05-11 - international - T20 - male - 1310174 - Czech Republic vs Gibraltar
2022-05-11 - international - T20 - male - 1310173 - Romania vs Malta
2022-05-11 - club - IPL - male - 1304104 - Rajasthan Royals vs Delhi Capitals
2022-05-10 - international - T20 - male - 1310172 - Gibraltar vs Hungary
2022-05-10 - international - T20 - male - 1310171 - Malta vs Hungary
2022-05-10 - international - T20 - male - 1310170 - Gibraltar vs Malta
2022-05-10 - club - IPO - male - 1305424 - Leinster Lightning vs Munster Reds
2022-05-10 - club - IPL - male - 1304103 - Gujarat Titans vs Lucknow Super Giants
2022-05-09 - club - IPL - male - 1304102 - Kolkata Knight Riders vs Mumbai Indians
2022-05-08 - international - T20 - male - 1310169 - Denmark vs Finland
2022-05-08 - club - IPL - male - 1304101 - Chennai Super Kings vs Delhi Capitals
2022-05-08 - club - IPL - male - 1304100 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2022-05-07 - international - T20 - male - 1310168 - Denmark vs Finland
2022-05-07 - international - T20 - male - 1310167 - Denmark vs Finland
2022-05-07 - club - IPL - male - 1304099 - Lucknow Super Giants vs Kolkata Knight Riders
2022-05-07 - club - IPL - male - 1304098 - Punjab Kings vs Rajasthan Royals
2022-05-06 - club - IPL - male - 1304097 - Mumbai Indians vs Gujarat Titans
2022-05-05 - club - IPO - male - 1305423 - Northern Knights vs Munster Reds
2022-05-05 - club - IPL - male - 1304096 - Delhi Capitals vs Sunrisers Hyderabad
2022-05-05 - club - CCH - male - 1297707 - Essex vs Yorkshire
2022-05-05 - club - CCH - male - 1297706 - Durham vs Worcestershire
2022-05-05 - club - CCH - male - 1297705 - Sussex vs Middlesex
2022-05-05 - club - CCH - male - 1297704 - Leicestershire vs Glamorgan
2022-05-05 - club - CCH - male - 1297703 - Surrey vs Northamptonshire
2022-05-05 - club - CCH - male - 1297702 - Hampshire vs Gloucestershire
2022-05-05 - club - CCH - male - 1297701 - Warwickshire vs Lancashire
2022-05-04 - club - IPL - male - 1304095 - Royal Challengers Bangalore vs Chennai Super Kings
2022-05-03 - club - IPO - male - 1305422 - North-West Warriors vs Leinster Lightning
2022-05-03 - club - IPL - male - 1304094 - Gujarat Titans vs Punjab Kings
2022-05-02 - club - IPL - male - 1304093 - Rajasthan Royals vs Kolkata Knight Riders
2022-05-01 - international - T20 - male - 1310166 - Spain vs Norway
2022-05-01 - international - T20 - male - 1310165 - Spain vs Guernsey
2022-05-01 - club - IPL - male - 1304092 - Chennai Super Kings vs Sunrisers Hyderabad
2022-05-01 - club - IPL - male - 1304091 - Lucknow Super Giants vs Delhi Capitals
2022-04-30 - international - T20 - male - 1310164 - Guernsey vs Spain
2022-04-30 - international - T20 - male - 1310163 - Norway vs Guernsey
2022-04-30 - international - T20 - male - 1310162 - Spain vs Norway
2022-04-30 - club - IPL - male - 1304090 - Rajasthan Royals vs Mumbai Indians
2022-04-30 - club - IPL - male - 1304089 - Royal Challengers Bangalore vs Gujarat Titans
2022-04-29 - international - T20 - male - 1310161 - Norway vs Guernsey
2022-04-29 - club - IPL - male - 1304088 - Lucknow Super Giants vs Punjab Kings
2022-04-28 - club - IPL - male - 1304087 - Kolkata Knight Riders vs Delhi Capitals
2022-04-28 - club - CCH - male - 1297700 - Leicestershire vs Middlesex
2022-04-28 - club - CCH - male - 1297699 - Durham vs Sussex
2022-04-28 - club - CCH - male - 1297698 - Derbyshire vs Glamorgan
2022-04-28 - club - CCH - male - 1297697 - Kent vs Yorkshire
2022-04-28 - club - CCH - male - 1297696 - Somerset vs Warwickshire
2022-04-28 - club - CCH - male - 1297695 - Hampshire vs Lancashire
2022-04-28 - club - CCH - male - 1297694 - Surrey vs Gloucestershire
2022-04-28 - club - CCH - male - 1297693 - Northamptonshire vs Essex
2022-04-28 - club - CCH - male - 1297692 - Worcestershire vs Nottinghamshire
2022-04-27 - club - IPL - male - 1304086 - Sunrisers Hyderabad vs Gujarat Titans
2022-04-26 - club - IPL - male - 1304085 - Rajasthan Royals vs Royal Challengers Bangalore
2022-04-25 - club - IPL - male - 1304084 - Punjab Kings vs Chennai Super Kings
2022-04-24 - club - IPL - male - 1304083 - Lucknow Super Giants vs Mumbai Indians
2022-04-23 - club - IPL - male - 1304082 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2022-04-23 - club - IPL - male - 1304081 - Gujarat Titans vs Kolkata Knight Riders
2022-04-22 - club - IPL - male - 1304080 - Rajasthan Royals vs Delhi Capitals
2022-04-21 - club - IPL - male - 1304079 - Mumbai Indians vs Chennai Super Kings
2022-04-21 - club - CCH - male - 1297691 - Yorkshire vs Northamptonshire
2022-04-21 - club - CCH - male - 1297690 - Gloucestershire vs Lancashire
2022-04-21 - club - CCH - male - 1297689 - Somerset vs Surrey
2022-04-21 - club - CCH - male - 1297688 - Essex vs Warwickshire
2022-04-21 - club - CCH - male - 1297687 - Glamorgan vs Middlesex
2022-04-21 - club - CCH - male - 1297686 - Leicestershire vs Derbyshire
2022-04-21 - club - CCH - male - 1297685 - Worcestershire vs Sussex
2022-04-21 - club - CCH - male - 1297684 - Kent vs Hampshire
2022-04-21 - club - CCH - male - 1297683 - Durham vs Nottinghamshire
2022-04-20 - club - IPL - male - 1304078 - Punjab Kings vs Delhi Capitals
2022-04-19 - club - IPL - male - 1304077 - Royal Challengers Bangalore vs Lucknow Super Giants
2022-04-18 - club - IPL - male - 1304076 - Rajasthan Royals vs Kolkata Knight Riders
2022-04-17 - club - IPL - male - 1304075 - Chennai Super Kings vs Gujarat Titans
2022-04-17 - club - IPL - male - 1304074 - Punjab Kings vs Sunrisers Hyderabad
2022-04-16 - international - ODI - male - 1308249 - Oman vs Papua New Guinea
2022-04-16 - club - IPL - male - 1304073 - Royal Challengers Bangalore vs Delhi Capitals
2022-04-16 - club - IPL - male - 1304072 - Lucknow Super Giants vs Mumbai Indians
2022-04-15 - international - ODI - male - 1308248 - Oman vs Scotland
2022-04-15 - club - IPL - male - 1304071 - Kolkata Knight Riders vs Sunrisers Hyderabad
2022-04-14 - club - IPL - male - 1304070 - Gujarat Titans vs Rajasthan Royals
2022-04-14 - club - CCH - male - 1297682 - Surrey vs Hampshire
2022-04-14 - club - CCH - male - 1297681 - Gloucestershire vs Yorkshire
2022-04-14 - club - CCH - male - 1297680 - Somerset vs Essex
2022-04-14 - club - CCH - male - 1297679 - Derbyshire vs Sussex
2022-04-14 - club - CCH - male - 1297678 - Durham vs Leicestershire
2022-04-14 - club - CCH - male - 1297677 - Nottinghamshire vs Glamorgan
2022-04-14 - club - CCH - male - 1297676 - Lancashire vs Kent
2022-04-13 - international - ODI - male - 1308247 - Scotland vs Papua New Guinea
2022-04-13 - club - IPL - male - 1304069 - Punjab Kings vs Mumbai Indians
2022-04-12 - international - ODI - male - 1308246 - Papua New Guinea vs Oman
2022-04-12 - club - PKS - male - 1279987 - Canterbury vs Auckland Aces
2022-04-12 - club - IPL - male - 1304068 - Chennai Super Kings vs Royal Challengers Bangalore
2022-04-11 - club - IPL - male - 1304067 - Gujarat Titans vs Sunrisers Hyderabad
2022-04-10 - international - T20 - male - 1309703 - Namibia vs Uganda
2022-04-10 - international - ODI - male - 1308245 - Scotland vs Oman
2022-04-10 - club - IPL - male - 1304066 - Rajasthan Royals vs Lucknow Super Giants
2022-04-10 - club - IPL - male - 1304065 - Delhi Capitals vs Kolkata Knight Riders
2022-04-09 - international - T20 - male - 1309702 - Namibia vs Uganda
2022-04-09 - international - ODI - male - 1308244 - Scotland vs Papua New Guinea
2022-04-09 - club - IPL - male - 1304064 - Mumbai Indians vs Royal Challengers Bangalore
2022-04-09 - club - IPL - male - 1304063 - Chennai Super Kings vs Sunrisers Hyderabad
2022-04-08 - international - Test - male - 1277101 - South Africa vs Bangladesh
2022-04-08 - international - T20 - male - 1309701 - Uganda vs Namibia
2022-04-08 - club - IPL - male - 1304062 - Punjab Kings vs Gujarat Titans
2022-04-07 - club - IPL - male - 1304061 - Delhi Capitals vs Lucknow Super Giants
2022-04-07 - club - CCH - male - 1297675 - Essex vs Kent
2022-04-07 - club - CCH - male - 1297674 - Sussex vs Nottinghamshire
2022-04-07 - club - CCH - male - 1297673 - Middlesex vs Derbyshire
2022-04-07 - club - CCH - male - 1297672 - Worcestershire vs Leicestershire
2022-04-07 - club - CCH - male - 1297671 - Glamorgan vs Durham
2022-04-07 - club - CCH - male - 1297670 - Surrey vs Warwickshire
2022-04-07 - club - CCH - male - 1297669 - Gloucestershire vs Northamptonshire
2022-04-07 - club - CCH - male - 1297668 - Somerset vs Hampshire
2022-04-06 - club - PKS - male - 1279991 - Northern Districts vs Wellington Firebirds
2022-04-06 - club - IPL - male - 1304060 - Mumbai Indians vs Kolkata Knight Riders
2022-04-05 - international - T20 - male - 1288316 - Pakistan vs Australia
2022-04-05 - club - PKS - male - 1279980 - Auckland Aces vs Central Stags
2022-04-05 - club - IPL - male - 1304059 - Rajasthan Royals vs Royal Challengers Bangalore
2022-04-04 - international - T20 - male - 1305504 - Nepal vs Papua New Guinea
2022-04-04 - international - ODI - male - 1288989 - New Zealand vs Netherlands
2022-04-04 - club - IPL - male - 1304058 - Lucknow Super Giants vs Sunrisers Hyderabad
2022-04-03 - club - IPL - male - 1304057 - Punjab Kings vs Chennai Super Kings
2022-04-02 - international - T20 - male - 1305503 - Nepal vs Malaysia
2022-04-02 - international - ODI - male - 1288988 - New Zealand vs Netherlands
2022-04-02 - international - ODI - male - 1288315 - Australia vs Pakistan
2022-04-02 - club - IPL - male - 1304056 - Gujarat Titans vs Delhi Capitals
2022-04-02 - club - IPL - male - 1304055 - Rajasthan Royals vs Mumbai Indians
2022-04-01 - international - T20 - male - 1305502 - Malaysia vs Papua New Guinea
2022-04-01 - club - IPL - male - 1304054 - Punjab Kings vs Kolkata Knight Riders
2022-03-31 - international - Test - male - 1277100 - South Africa vs Bangladesh
2022-03-31 - international - T20 - male - 1305501 - Nepal vs Papua New Guinea
2022-03-31 - international - ODI - male - 1288314 - Australia vs Pakistan
2022-03-31 - club - SSH - male - 1270465 - Western Australia vs Victoria
2022-03-31 - club - IPL - male - 1304053 - Chennai Super Kings vs Lucknow Super Giants
2022-03-30 - international - T20 - male - 1305500 - Malaysia vs Nepal
2022-03-30 - club - IPL - male - 1304052 - Kolkata Knight Riders vs Royal Challengers Bangalore
2022-03-29 - international - T20 - male - 1305499 - Malaysia vs Papua New Guinea
2022-03-29 - international - ODI - male - 1288987 - Netherlands vs New Zealand
2022-03-29 - international - ODI - male - 1288313 - Australia vs Pakistan
2022-03-29 - club - PKS - male - 1280010 - Canterbury vs Otago Volts
2022-03-29 - club - PKS - male - 1280009 - Northern Districts vs Central Stags
2022-03-29 - club - IPL - male - 1304051 - Rajasthan Royals vs Sunrisers Hyderabad
2022-03-28 - international - T20 - male - 1305498 - Nepal vs Papua New Guinea
2022-03-28 - club - PKS - male - 1280008 - Auckland Aces vs Wellington Firebirds
2022-03-28 - club - IPL - male - 1304050 - Lucknow Super Giants vs Gujarat Titans
2022-03-27 - club - IPL - male - 1304049 - Royal Challengers Bangalore vs Punjab Kings
2022-03-27 - club - IPL - male - 1304048 - Mumbai Indians vs Delhi Capitals
2022-03-26 - international - ODI - male - 1305497 - Nepal vs Papua New Guinea
2022-03-26 - club - IPL - male - 1304047 - Chennai Super Kings vs Kolkata Knight Riders
2022-03-25 - international - ODI - male - 1305496 - Papua New Guinea vs Nepal
2022-03-24 - international - Test - male - 1256728 - England vs West Indies
2022-03-23 - international - ODI - male - 1277099 - South Africa vs Bangladesh
2022-03-23 - club - SSH - male - 1270461 - Victoria vs Western Australia
2022-03-23 - club - SSH - male - 1270455 - Queensland vs Tasmania
2022-03-23 - club - SSH - male - 1270438 - New South Wales vs South Australia
2022-03-22 - international - ODI - male - 1302628 - Papua New Guinea vs Nepal
2022-03-21 - international - Test - male - 1288312 - Australia vs Pakistan
2022-03-21 - international - ODI - male - 1302627 - United Arab Emirates vs Nepal
2022-03-20 - international - ODI - male - 1277098 - Bangladesh vs South Africa
2022-03-20 - club - PKS - male - 1280007 - Wellington Firebirds vs Otago Volts
2022-03-20 - club - PKS - male - 1280006 - Canterbury vs Central Stags
2022-03-19 - international - ODI - male - 1302626 - United Arab Emirates vs Papua New Guinea
2022-03-18 - international - ODI - male - 1302625 - United Arab Emirates vs Nepal
2022-03-18 - international - ODI - male - 1277097 - Bangladesh vs South Africa
2022-03-16 - international - Test - male - 1256727 - England vs West Indies
2022-03-16 - international - ODI - male - 1302624 - Papua New Guinea vs Nepal
2022-03-15 - international - ODI - male - 1302623 - Papua New Guinea vs United Arab Emirates
2022-03-15 - club - SSH - male - 1270445 - Western Australia vs New South Wales
2022-03-15 - club - SSH - male - 1270440 - Tasmania vs Victoria
2022-03-14 - international - ODI - male - 1302622 - Oman vs Namibia
2022-03-12 - international - Test - male - 1288311 - Australia vs Pakistan
2022-03-12 - international - Test - male - 1278683 - India vs Sri Lanka
2022-03-12 - international - ODI - male - 1302621 - United Arab Emirates vs Namibia
2022-03-11 - international - ODI - male - 1302620 - Namibia vs Oman
2022-03-11 - club - PKS - male - 1280002 - Northern Districts vs Central Stags
2022-03-11 - club - PKS - male - 1279993 - Auckland Aces vs Otago Volts
2022-03-11 - club - ODC - male - 1270466 - Western Australia vs New South Wales
2022-03-09 - international - ODI - male - 1302619 - Oman vs United Arab Emirates
2022-03-08 - international - Test - male - 1256726 - England vs West Indies
2022-03-08 - international - ODI - male - 1302618 - Namibia vs United Arab Emirates
2022-03-08 - club - ODC - male - 1270475 - Victoria vs Western Australia
2022-03-06 - international - ODI - male - 1302617 - Namibia vs Oman
2022-03-06 - club - ODC - male - 1270486 - Tasmania vs Victoria
2022-03-05 - international - ODI - male - 1302616 - Oman vs United Arab Emirates
2022-03-04 - international - Test - male - 1288310 - Pakistan vs Australia
2022-03-04 - international - Test - male - 1278682 - India vs Sri Lanka
2022-03-03 - club - PKS - male - 1280000 - Northern Districts vs Wellington Firebirds
2022-03-03 - club - PKS - male - 1279999 - Auckland Aces vs Canterbury
2022-02-27 - international - T20 - male - 1278686 - Sri Lanka vs India
2022-02-27 - club - PSL - male - 1293033 - Lahore Qalandars vs Multan Sultans
2022-02-27 - club - CTC - male - 1299632 - Boland vs Titans
2022-02-26 - international - T20 - male - 1278685 - Sri Lanka vs India
2022-02-25 - international - Test - male - 1288982 - South Africa vs New Zealand
2022-02-25 - club - PSL - male - 1293032 - Lahore Qalandars vs Islamabad United
2022-02-25 - club - CTC - male - 1299631 - Western Province vs Boland
2022-02-25 - club - CTC - male - 1299630 - Dolphins vs Titans
2022-02-24 - international - T20 - male - 1299585 - Ireland vs United Arab Emirates
2022-02-24 - international - T20 - male - 1299584 - Oman vs Nepal
2022-02-24 - international - T20 - male - 1299583 - Philippines vs Germany
2022-02-24 - international - T20 - male - 1299582 - Bahrain vs Canada
2022-02-24 - international - T20 - male - 1278684 - India vs Sri Lanka
2022-02-24 - club - PSL - male - 1293031 - Peshawar Zalmi vs Islamabad United
2022-02-23 - club - PSL - male - 1293030 - Multan Sultans vs Lahore Qalandars
2022-02-23 - club - ODC - male - 1270481 - Queensland vs Victoria
2022-02-23 - club - CTC - male - 1299629 - North West vs Warriors
2022-02-23 - club - CTC - male - 1299628 - Dolphins vs Western Province
2022-02-22 - international - T20 - male - 1299581 - Ireland vs Oman
2022-02-22 - international - T20 - male - 1299580 - United Arab Emirates vs Nepal
2022-02-22 - international - T20 - male - 1299579 - Bahrain vs Philippines
2022-02-22 - international - T20 - male - 1299578 - Germany vs Canada
2022-02-22 - club - CTC - male - 1299627 - Knights vs Boland
2022-02-22 - club - CTC - male - 1299626 - Titans vs North West
2022-02-21 - international - T20 - male - 1299577 - Philippines vs Oman
2022-02-21 - international - T20 - male - 1299576 - Canada vs Nepal
2022-02-21 - international - T20 - male - 1299575 - Bahrain vs United Arab Emirates
2022-02-21 - international - T20 - male - 1299574 - Germany vs Ireland
2022-02-21 - club - PSL - male - 1293029 - Peshawar Zalmi vs Lahore Qalandars
2022-02-20 - international - T20 - male - 1278681 - India vs West Indies
2022-02-20 - international - T20 - male - 1263475 - Australia vs Sri Lanka
2022-02-20 - club - PSL - male - 1293028 - Islamabad United vs Multan Sultans
2022-02-20 - club - PSL - male - 1293027 - Quetta Gladiators vs Karachi Kings
2022-02-20 - club - CTC - male - 1299625 - Knights vs Lions
2022-02-20 - club - CTC - male - 1299624 - Boland vs Dolphins
2022-02-19 - international - T20 - male - 1299573 - Ireland vs Bahrain
2022-02-19 - international - T20 - male - 1299572 - United Arab Emirates vs Germany
2022-02-19 - international - T20 - male - 1299571 - Nepal vs Philippines
2022-02-19 - international - T20 - male - 1299570 - Canada vs Oman
2022-02-19 - club - PSL - male - 1293026 - Lahore Qalandars vs Islamabad United
2022-02-19 - club - CTC - male - 1299623 - Lions vs Warriors
2022-02-19 - club - CTC - male - 1299622 - Western Province vs Titans
2022-02-18 - international - T20 - male - 1299569 - Germany vs Bahrain
2022-02-18 - international - T20 - male - 1299568 - United Arab Emirates vs Ireland
2022-02-18 - international - T20 - male - 1299567 - Canada vs Philippines
2022-02-18 - international - T20 - male - 1299566 - Nepal vs Oman
2022-02-18 - international - T20 - male - 1278680 - India vs West Indies
2022-02-18 - international - T20 - male - 1263474 - Sri Lanka vs Australia
2022-02-18 - club - SSH - male - 1270453 - Queensland vs Victoria
2022-02-18 - club - SSH - male - 1270447 - New South Wales vs Tasmania
2022-02-18 - club - PSL - male - 1293025 - Karachi Kings vs Lahore Qalandars
2022-02-18 - club - PSL - male - 1293024 - Multan Sultans vs Quetta Gladiators
2022-02-18 - club - CTC - male - 1299621 - North West vs Dolphins
2022-02-18 - club - CTC - male - 1299620 - Knights vs Western Province
2022-02-18 - club - BPL - male - 1296718 - Comilla Victorians vs Fortune Barishal
2022-02-17 - international - Test - male - 1288981 - South Africa vs New Zealand
2022-02-17 - club - PSL - male - 1293023 - Peshawar Zalmi vs Islamabad United
2022-02-17 - club - CTC - male - 1299619 - Warriors vs Boland
2022-02-17 - club - CTC - male - 1299618 - Lions vs Titans
2022-02-16 - international - T20 - male - 1278679 - West Indies vs India
2022-02-16 - club - PSL - male - 1293022 - Karachi Kings vs Multan Sultans
2022-02-16 - club - BPL - male - 1296717 - Chattogram Challengers vs Comilla Victorians
2022-02-15 - international - T20 - male - 1263473 - Sri Lanka vs Australia
2022-02-15 - club - PSL - male - 1293021 - Peshawar Zalmi vs Quetta Gladiators
2022-02-15 - club - ODC - male - 1270468 - South Australia vs Victoria
2022-02-15 - club - CTC - male - 1299617 - Western Province vs North West
2022-02-15 - club - CTC - male - 1299616 - Boland vs Lions
2022-02-14 - international - T20 - male - 1299596 - Ireland vs Nepal
2022-02-14 - international - T20 - male - 1299595 - United Arab Emirates vs Oman
2022-02-14 - club - PSL - male - 1293020 - Islamabad United vs Karachi Kings
2022-02-14 - club - CTC - male - 1299615 - Warriors vs Knights
2022-02-14 - club - CTC - male - 1299614 - Dolphins vs Titans
2022-02-14 - club - BPL - male - 1296716 - Fortune Barishal vs Comilla Victorians
2022-02-14 - club - BPL - male - 1296715 - Chattogram Challengers vs Khulna Tigers
2022-02-13 - international - T20 - male - 1299592 - United Arab Emirates vs Ireland
2022-02-13 - international - T20 - male - 1263472 - Australia vs Sri Lanka
2022-02-13 - club - PSL - male - 1293019 - Quetta Gladiators vs Lahore Qalandars
2022-02-13 - club - PSL - male - 1293018 - Peshawar Zalmi vs Karachi Kings
2022-02-13 - club - CTC - male - 1299613 - Boland vs North West
2022-02-13 - club - CTC - male - 1299612 - Lions vs Western Province
2022-02-12 - international - T20 - male - 1299638 - United Arab Emirates vs Nepal
2022-02-12 - international - T20 - male - 1299594 - Oman vs Ireland
2022-02-12 - club - PSL - male - 1293017 - Islamabad United vs Quetta Gladiators
2022-02-12 - club - CTC - male - 1299611 - Titans vs Knights
2022-02-12 - club - CTC - male - 1299610 - Dolphins vs Warriors
2022-02-12 - club - BPL - male - 1296714 - Comilla Victorians vs Khulna Tigers
2022-02-12 - club - BPL - male - 1296713 - Sylhet Sunrisers vs Chattogram Challengers
2022-02-11 - international - T20 - male - 1299593 - Oman vs Nepal
2022-02-11 - international - T20 - male - 1263471 - Australia vs Sri Lanka
2022-02-11 - international - ODI - male - 1278678 - India vs West Indies
2022-02-11 - club - PSL - male - 1293016 - Lahore Qalandars vs Multan Sultans
2022-02-11 - club - PKS - male - 1280004 - Auckland Aces vs Otago Volts
2022-02-11 - club - BPL - male - 1296712 - Minister Group Dhaka vs Fortune Barishal
2022-02-11 - club - BPL - male - 1296711 - Comilla Victorians vs Khulna Tigers
2022-02-10 - club - PSL - male - 1293015 - Multan Sultans vs Peshawar Zalmi
2022-02-10 - club - CTC - male - 1299609 - Lions vs Dolphins
2022-02-10 - club - CTC - male - 1299608 - Knights vs North West
2022-02-09 - international - ODI - male - 1278677 - India vs West Indies
2022-02-09 - club - SSH - male - 1270459 - Queensland vs New South Wales
2022-02-09 - club - SSH - male - 1270451 - South Australia vs Victoria
2022-02-09 - club - CTC - male - 1299607 - Warriors vs Western Province
2022-02-09 - club - CTC - male - 1299606 - Titans vs Boland
2022-02-09 - club - BPL - male - 1296710 - Sylhet Sunrisers vs Comilla Victorians
2022-02-09 - club - BPL - male - 1296709 - Khulna Tigers vs Minister Group Dhaka
2022-02-08 - international - ODI - male - 1299588 - Oman vs United Arab Emirates
2022-02-08 - club - CTC - male - 1299605 - Knights vs Dolphins
2022-02-08 - club - CTC - male - 1299604 - North West vs Lions
2022-02-08 - club - BPL - male - 1296708 - Fortune Barishal vs Sylhet Sunrisers
2022-02-08 - club - BPL - male - 1296707 - Chattogram Challengers vs Minister Group Dhaka
2022-02-07 - club - PSL - male - 1293014 - Lahore Qalandars vs Quetta Gladiators
2022-02-07 - club - CTC - male - 1299603 - Warriors vs Titans
2022-02-07 - club - CTC - male - 1299602 - Boland vs Western Province
2022-02-07 - club - BPL - male - 1296706 - Khulna Tigers vs Sylhet Sunrisers
2022-02-07 - club - BPL - male - 1296705 - Fortune Barishal vs Comilla Victorians
2022-02-06 - international - ODI - male - 1299587 - Oman vs United Arab Emirates
2022-02-06 - international - ODI - male - 1278676 - West Indies vs India
2022-02-06 - club - PSL - male - 1293013 - Islamabad United vs Karachi Kings
2022-02-05 - international - ODI - male - 1299586 - Oman vs United Arab Emirates
2022-02-05 - club - PSL - male - 1293012 - Multan Sultans vs Peshawar Zalmi
2022-02-05 - club - PSL - male - 1293011 - Lahore Qalandars vs Islamabad United
2022-02-04 - club - PSL - male - 1293010 - Peshawar Zalmi vs Karachi Kings
2022-02-04 - club - PKS - male - 1279996 - Northern Districts vs Auckland Aces
2022-02-03 - club - PSL - male - 1293009 - Islamabad United vs Quetta Gladiators
2022-02-03 - club - BPL - male - 1296702 - Chattogram Challengers vs Comilla Victorians
2022-02-03 - club - BPL - male - 1296701 - Sylhet Sunrisers vs Khulna Tigers
2022-02-02 - club - PSL - male - 1293008 - Lahore Qalandars vs Peshawar Zalmi
2022-02-01 - club - PSL - male - 1293007 - Multan Sultans vs Islamabad United
2022-02-01 - club - BPL - male - 1296700 - Fortune Barishal vs Chattogram Challengers
2022-02-01 - club - BPL - male - 1296699 - Minister Group Dhaka vs Comilla Victorians
2022-01-31 - club - PSL - male - 1293006 - Multan Sultans vs Quetta Gladiators
2022-01-31 - club - BPL - male - 1296698 - Fortune Barishal vs Khulna Tigers
2022-01-31 - club - BPL - male - 1296697 - Comilla Victorians vs Chattogram Challengers
2022-01-30 - international - T20 - male - 1256724 - West Indies vs England
2022-01-30 - club - PSL - male - 1293005 - Karachi Kings vs Lahore Qalandars
2022-01-30 - club - PSL - male - 1293004 - Peshawar Zalmi vs Islamabad United
2022-01-29 - international - T20 - male - 1256723 - England vs West Indies
2022-01-29 - club - SSM - male - 1289634 - Northern Districts vs Canterbury
2022-01-29 - club - PSL - male - 1293003 - Karachi Kings vs Quetta Gladiators
2022-01-29 - club - PSL - male - 1293002 - Lahore Qalandars vs Multan Sultans
2022-01-29 - club - BPL - male - 1296696 - Chattogram Challengers vs Sylhet Sunrisers
2022-01-29 - club - BPL - male - 1296695 - Fortune Barishal vs Khulna Tigers
2022-01-28 - club - PSL - male - 1293001 - Quetta Gladiators vs Peshawar Zalmi
2022-01-28 - club - BPL - male - 1296694 - Sylhet Sunrisers vs Minister Group Dhaka
2022-01-28 - club - BPL - male - 1296693 - Chattogram Challengers vs Khulna Tigers
2022-01-28 - club - BBL - male - 1269698 - Perth Scorchers vs Sydney Sixers
2022-01-27 - club - SSM - male - 1289633 - Wellington vs Canterbury
2022-01-27 - club - PSL - male - 1293000 - Karachi Kings vs Multan Sultans
2022-01-26 - international - T20 - male - 1256722 - West Indies vs England
2022-01-26 - club - BBL - male - 1269697 - Adelaide Strikers vs Sydney Sixers
2022-01-25 - club - BPL - male - 1296692 - Comilla Victorians vs Fortune Barishal
2022-01-25 - club - BPL - male - 1296691 - Minister Group Dhaka vs Sylhet Sunrisers
2022-01-24 - club - SSM - male - 1289632 - Wellington vs Northern Districts
2022-01-24 - club - BPL - male - 1296690 - Chattogram Challengers vs Khulna Tigers
2022-01-24 - club - BPL - male - 1296689 - Fortune Barishal vs Minister Group Dhaka
2022-01-23 - international - T20 - male - 1256721 - England vs West Indies
2022-01-23 - international - ODI - male - 1277084 - South Africa vs India
2022-01-23 - club - SSM - male - 1289631 - Otago vs Canterbury
2022-01-23 - club - BBL - male - 1269696 - Adelaide Strikers vs Sydney Thunder
2022-01-22 - international - T20 - male - 1256720 - England vs West Indies
2022-01-22 - club - SSM - male - 1289630 - Central Districts vs Auckland
2022-01-22 - club - BPL - male - 1296688 - Chattogram Challengers vs Minister Group Dhaka
2022-01-22 - club - BPL - male - 1296687 - Sylhet Sunrisers vs Comilla Victorians
2022-01-22 - club - BBL - male - 1269695 - Perth Scorchers vs Sydney Sixers
2022-01-21 - international - ODI - male - 1294971 - Sri Lanka vs Zimbabwe
2022-01-21 - international - ODI - male - 1277083 - India vs South Africa
2022-01-21 - club - SSM - male - 1289629 - Canterbury vs Northern Districts
2022-01-21 - club - BPL - male - 1296686 - Minister Group Dhaka vs Khulna Tigers
2022-01-21 - club - BPL - male - 1296685 - Chattogram Challengers vs Fortune Barishal
2022-01-21 - club - BBL - male - 1269671 - Adelaide Strikers vs Hobart Hurricanes
2022-01-20 - club - SSM - male - 1289610 - Auckland vs Wellington
2022-01-19 - international - ODI - male - 1277082 - South Africa vs India
2022-01-19 - club - BBL - male - 1269694 - Sydney Thunder vs Melbourne Renegades
2022-01-19 - club - BBL - male - 1269693 - Melbourne Stars vs Hobart Hurricanes
2022-01-19 - club - BBL - male - 1269692 - Sydney Sixers vs Brisbane Heat
2022-01-18 - international - ODI - male - 1294970 - Zimbabwe vs Sri Lanka
2022-01-18 - club - SSM - male - 1289607 - Canterbury vs Auckland
2022-01-18 - club - BBL - male - 1269691 - Hobart Hurricanes vs Melbourne Renegades
2022-01-17 - club - BBL - male - 1269690 - Brisbane Heat vs Perth Scorchers
2022-01-17 - club - BBL - male - 1269689 - Sydney Sixers vs Adelaide Strikers
2022-01-16 - international - ODI - male - 1294969 - Zimbabwe vs Sri Lanka
2022-01-16 - international - ODI - male - 1277087 - West Indies vs Ireland
2022-01-16 - club - SSM - male - 1289628 - Wellington vs Northern Districts
2022-01-16 - club - BBL - male - 1269688 - Brisbane Heat vs Melbourne Stars
2022-01-15 - club - SSM - male - 1289627 - Otago vs Auckland
2022-01-15 - club - BBL - male - 1269687 - Sydney Sixers vs Sydney Thunder
2022-01-15 - club - BBL - male - 1269676 - Adelaide Strikers vs Melbourne Stars
2022-01-14 - international - Test - male - 1263466 - Australia vs England
2022-01-14 - club - SSM - male - 1289626 - Northern Districts vs Central Districts
2022-01-14 - club - BBL - male - 1269686 - Perth Scorchers vs Adelaide Strikers
2022-01-13 - international - ODI - male - 1277086 - West Indies vs Ireland
2022-01-13 - club - BBL - male - 1269685 - Melbourne Renegades vs Melbourne Stars
2022-01-13 - club - BBL - male - 1269684 - Hobart Hurricanes vs Sydney Thunder
2022-01-12 - club - BBL - male - 1269683 - Adelaide Strikers vs Brisbane Heat
2022-01-11 - international - Test - male - 1277081 - India vs South Africa
2022-01-11 - club - BBL - male - 1269682 - Sydney Sixers vs Melbourne Renegades
2022-01-11 - club - BBL - male - 1269664 - Perth Scorchers vs Melbourne Stars
2022-01-10 - club - BBL - male - 1269681 - Hobart Hurricanes vs Sydney Thunder
2022-01-10 - club - BBL - male - 1269680 - Adelaide Strikers vs Melbourne Stars
2022-01-09 - international - Test - male - 1288980 - New Zealand vs Bangladesh
2022-01-09 - club - BBL - male - 1269679 - Sydney Sixers vs Perth Scorchers
2022-01-08 - international - ODI - male - 1277085 - West Indies vs Ireland
2022-01-08 - club - SSM - male - 1289625 - Central Districts vs Wellington
2022-01-08 - club - BBL - male - 1269678 - Brisbane Heat vs Hobart Hurricanes
2022-01-08 - club - BBL - male - 1269677 - Sydney Thunder vs Melbourne Renegades
2022-01-07 - club - SSM - male - 1289624 - Auckland vs Canterbury
2022-01-06 - club - SSM - male - 1289623 - Otago vs Wellington
2022-01-06 - club - BBL - male - 1269674 - Brisbane Heat vs Melbourne Renegades
2022-01-06 - club - BBL - male - 1269673 - Perth Scorchers vs Sydney Thunder
2022-01-05 - international - Test - male - 1263465 - Australia vs England
2022-01-05 - club - BBL - male - 1269672 - Hobart Hurricanes vs Adelaide Strikers
2022-01-04 - club - BBL - male - 1269675 - Perth Scorchers vs Sydney Sixers
2022-01-03 - international - Test - male - 1277080 - India vs South Africa
2022-01-03 - club - BBL - male - 1269670 - Melbourne Stars vs Melbourne Renegades
2022-01-02 - club - BBL - male - 1269669 - Sydney Thunder vs Adelaide Strikers
2022-01-02 - club - BBL - male - 1269668 - Perth Scorchers vs Melbourne Stars
2022-01-01 - international - Test - male - 1288979 - New Zealand vs Bangladesh
2022-01-01 - club - BBL - male - 1269666 - Brisbane Heat vs Hobart Hurricanes
