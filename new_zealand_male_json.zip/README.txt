This zip archive contains data files from Cricsheet in JSON format. This
archive contains 830 New Zealand matches of all types. A further 6 matches
have been withheld due to either featuring the Afghanistan men's team or being
played in the Afghanistan Premier League, due to the Cricsheet policy to no
longer feature matches involving Afghanistan men or played in Afghanistan
Premier League (see https://cricsheet.org/withheld-matches for more
information).


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/new_zealand_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-07-21 - international - ODI - male - 1538628 - New Zealand vs West Indies
2026-07-19 - international - ODI - male - 1538627 - West Indies vs New Zealand
2026-07-16 - international - ODI - male - 1538626 - West Indies vs New Zealand
2026-07-13 - international - ODI - male - 1538625 - West Indies vs New Zealand
2026-07-11 - international - ODI - male - 1538624 - New Zealand vs West Indies
2026-06-25 - international - Test - male - 1496573 - New Zealand vs England
2026-06-17 - international - Test - male - 1496572 - New Zealand vs England
2026-06-04 - international - Test - male - 1496571 - England vs New Zealand
2026-05-27 - international - Test - male - 1528547 - New Zealand vs Ireland
2026-05-02 - international - T20 - male - 1528277 - Bangladesh vs New Zealand
2026-04-27 - international - T20 - male - 1528275 - New Zealand vs Bangladesh
2026-04-23 - international - ODI - male - 1528274 - Bangladesh vs New Zealand
2026-04-20 - international - ODI - male - 1528273 - New Zealand vs Bangladesh
2026-04-17 - international - ODI - male - 1528272 - New Zealand vs Bangladesh
2026-03-25 - international - T20 - male - 1491739 - South Africa vs New Zealand
2026-03-22 - international - T20 - male - 1491738 - South Africa vs New Zealand
2026-03-20 - international - T20 - male - 1491737 - South Africa vs New Zealand
2026-03-17 - international - T20 - male - 1491736 - New Zealand vs South Africa
2026-03-15 - international - T20 - male - 1491735 - New Zealand vs South Africa
2026-03-08 - international - T20 - male - 1512773 - India vs New Zealand
2026-03-04 - international - T20 - male - 1512771 - South Africa vs New Zealand
2026-02-27 - international - T20 - male - 1512767 - New Zealand vs England
2026-02-25 - international - T20 - male - 1512764 - New Zealand vs Sri Lanka
2026-02-17 - international - T20 - male - 1512749 - Canada vs New Zealand
2026-02-14 - international - T20 - male - 1512742 - New Zealand vs South Africa
2026-02-10 - international - T20 - male - 1512729 - United Arab Emirates vs New Zealand
2026-01-31 - international - T20 - male - 1490238 - India vs New Zealand
2026-01-28 - international - T20 - male - 1490237 - New Zealand vs India
2026-01-25 - international - T20 - male - 1490236 - New Zealand vs India
2026-01-23 - international - T20 - male - 1490235 - New Zealand vs India
2026-01-21 - international - T20 - male - 1490234 - India vs New Zealand
2026-01-18 - international - ODI - male - 1490233 - New Zealand vs India
2026-01-14 - international - ODI - male - 1490232 - India vs New Zealand
2026-01-11 - international - ODI - male - 1490231 - New Zealand vs India
2025-12-18 - international - Test - male - 1491734 - New Zealand vs West Indies
2025-12-10 - international - Test - male - 1491733 - West Indies vs New Zealand
2025-12-02 - international - Test - male - 1491732 - New Zealand vs West Indies
2025-11-22 - international - ODI - male - 1491730 - West Indies vs New Zealand
2025-11-19 - international - ODI - male - 1491729 - West Indies vs New Zealand
2025-11-16 - international - ODI - male - 1491728 - New Zealand vs West Indies
2025-11-13 - international - T20 - male - 1491727 - West Indies vs New Zealand
2025-11-10 - international - T20 - male - 1491726 - West Indies vs New Zealand
2025-11-09 - international - T20 - male - 1491725 - New Zealand vs West Indies
2025-11-06 - international - T20 - male - 1491724 - New Zealand vs West Indies
2025-11-05 - international - T20 - male - 1491723 - West Indies vs New Zealand
2025-11-01 - international - ODI - male - 1491722 - England vs New Zealand
2025-10-29 - international - ODI - male - 1491721 - England vs New Zealand
2025-10-26 - international - ODI - male - 1491720 - England vs New Zealand
2025-10-23 - international - T20 - male - 1491719 - New Zealand vs England
2025-10-20 - international - T20 - male - 1491718 - England vs New Zealand
2025-10-18 - international - T20 - male - 1491717 - England vs New Zealand
2025-10-04 - international - T20 - male - 1491716 - New Zealand vs Australia
2025-10-03 - international - T20 - male - 1491715 - Australia vs New Zealand
2025-10-01 - international - T20 - male - 1491714 - New Zealand vs Australia
2025-08-07 - international - Test - male - 1478873 - Zimbabwe vs New Zealand
2025-07-30 - international - Test - male - 1478872 - Zimbabwe vs New Zealand
2025-07-26 - international - T20 - male - 1478871 - New Zealand vs South Africa
2025-07-24 - international - T20 - male - 1478870 - New Zealand vs Zimbabwe
2025-07-22 - international - T20 - male - 1478869 - South Africa vs New Zealand
2025-07-18 - international - T20 - male - 1478867 - Zimbabwe vs New Zealand
2025-07-16 - international - T20 - male - 1478866 - New Zealand vs South Africa
2025-04-05 - international - ODI - male - 1443556 - New Zealand vs Pakistan
2025-04-02 - international - ODI - male - 1443555 - New Zealand vs Pakistan
2025-03-29 - international - ODI - male - 1443554 - New Zealand vs Pakistan
2025-03-26 - international - T20 - male - 1443553 - Pakistan vs New Zealand
2025-03-23 - international - T20 - male - 1443552 - New Zealand vs Pakistan
2025-03-21 - international - T20 - male - 1443551 - New Zealand vs Pakistan
2025-03-18 - international - T20 - male - 1443550 - Pakistan vs New Zealand
2025-03-16 - international - T20 - male - 1443549 - Pakistan vs New Zealand
2025-03-09 - international - ODI - male - 1466428 - New Zealand vs India
2025-03-05 - international - ODI - male - 1466427 - New Zealand vs South Africa
2025-03-02 - international - ODI - male - 1466425 - India vs New Zealand
2025-02-24 - international - ODI - male - 1466419 - Bangladesh vs New Zealand
2025-02-19 - international - ODI - male - 1466414 - New Zealand vs Pakistan
2025-02-14 - international - ODI - male - 1442223 - Pakistan vs New Zealand
2025-02-10 - international - ODI - male - 1442221 - South Africa vs New Zealand
2025-02-08 - international - ODI - male - 1442220 - New Zealand vs Pakistan
2025-01-11 - international - ODI - male - 1443548 - Sri Lanka vs New Zealand
2025-01-08 - international - ODI - male - 1443547 - New Zealand vs Sri Lanka
2025-01-05 - international - ODI - male - 1443546 - Sri Lanka vs New Zealand
2025-01-02 - international - T20 - male - 1443545 - Sri Lanka vs New Zealand
2024-12-30 - international - T20 - male - 1443544 - New Zealand vs Sri Lanka
2024-12-28 - international - T20 - male - 1443543 - New Zealand vs Sri Lanka
2024-12-14 - international - Test - male - 1428556 - New Zealand vs England
2024-12-06 - international - Test - male - 1428555 - England vs New Zealand
2024-11-28 - international - Test - male - 1428554 - New Zealand vs England
2024-11-19 - international - ODI - male - 1456445 - New Zealand vs Sri Lanka
2024-11-17 - international - ODI - male - 1456444 - New Zealand vs Sri Lanka
2024-11-13 - international - ODI - male - 1456443 - Sri Lanka vs New Zealand
2024-11-10 - international - T20 - male - 1456442 - New Zealand vs Sri Lanka
2024-11-09 - international - T20 - male - 1456441 - New Zealand vs Sri Lanka
2024-11-01 - international - Test - male - 1439898 - New Zealand vs India
2024-10-24 - international - Test - male - 1439897 - New Zealand vs India
2024-10-16 - international - Test - male - 1439896 - India vs New Zealand
2024-09-26 - international - Test - male - 1447097 - Sri Lanka vs New Zealand
2024-09-18 - international - Test - male - 1447096 - Sri Lanka vs New Zealand
2024-06-17 - international - T20 - male - 1415739 - Papua New Guinea vs New Zealand
2024-06-14 - international - T20 - male - 1415732 - Uganda vs New Zealand
2024-06-12 - international - T20 - male - 1415726 - West Indies vs New Zealand
2024-04-27 - international - T20 - male - 1424833 - Pakistan vs New Zealand
2024-04-25 - international - T20 - male - 1424832 - New Zealand vs Pakistan
2024-04-21 - international - T20 - male - 1424831 - Pakistan vs New Zealand
2024-04-20 - international - T20 - male - 1424830 - New Zealand vs Pakistan
2024-04-18 - international - T20 - male - 1424829 - New Zealand vs Pakistan
2024-03-08 - international - Test - male - 1388227 - New Zealand vs Australia
2024-02-29 - international - Test - male - 1388226 - Australia vs New Zealand
2024-02-25 - international - T20 - male - 1388225 - Australia vs New Zealand
2024-02-23 - international - T20 - male - 1388224 - Australia vs New Zealand
2024-02-21 - international - T20 - male - 1388223 - New Zealand vs Australia
2024-02-13 - international - Test - male - 1388222 - South Africa vs New Zealand
2024-02-04 - international - Test - male - 1388221 - New Zealand vs South Africa
2024-01-21 - international - T20 - male - 1388220 - Pakistan vs New Zealand
2024-01-19 - international - T20 - male - 1388219 - Pakistan vs New Zealand
2024-01-17 - international - T20 - male - 1388218 - New Zealand vs Pakistan
2024-01-14 - international - T20 - male - 1388217 - New Zealand vs Pakistan
2024-01-12 - international - T20 - male - 1388216 - New Zealand vs Pakistan
2023-12-31 - international - T20 - male - 1388215 - Bangladesh vs New Zealand
2023-12-29 - international - T20 - male - 1388214 - New Zealand vs Bangladesh
2023-12-27 - international - T20 - male - 1388213 - New Zealand vs Bangladesh
2023-12-23 - international - ODI - male - 1388212 - New Zealand vs Bangladesh
2023-12-20 - international - ODI - male - 1388211 - Bangladesh vs New Zealand
2023-12-17 - international - ODI - male - 1408102 - New Zealand vs Bangladesh
2023-12-06 - international - Test - male - 1395704 - Bangladesh vs New Zealand
2023-11-28 - international - Test - male - 1395703 - Bangladesh vs New Zealand
2023-11-15 - international - ODI - male - 1384437 - India vs New Zealand
2023-11-09 - international - ODI - male - 1384432 - Sri Lanka vs New Zealand
2023-11-04 - international - ODI - male - 1384426 - New Zealand vs Pakistan
2023-11-01 - international - ODI - male - 1384423 - South Africa vs New Zealand
2023-10-28 - international - ODI - male - 1384418 - Australia vs New Zealand
2023-10-22 - international - ODI - male - 1384412 - New Zealand vs India
2023-10-13 - international - ODI - male - 1384402 - Bangladesh vs New Zealand
2023-10-09 - international - ODI - male - 1384397 - New Zealand vs Netherlands
2023-10-05 - international - ODI - male - 1384392 - England vs New Zealand
2023-09-26 - international - ODI - male - 1395702 - Bangladesh vs New Zealand
2023-09-23 - international - ODI - male - 1395701 - New Zealand vs Bangladesh
2023-09-21 - international - ODI - male - 1395700 - New Zealand vs Bangladesh
2023-09-15 - international - ODI - male - 1336055 - England vs New Zealand
2023-09-13 - international - ODI - male - 1336054 - England vs New Zealand
2023-09-10 - international - ODI - male - 1336053 - England vs New Zealand
2023-09-08 - international - ODI - male - 1336052 - England vs New Zealand
2023-09-05 - international - T20 - male - 1336051 - England vs New Zealand
2023-09-03 - international - T20 - male - 1336050 - New Zealand vs England
2023-09-01 - international - T20 - male - 1336049 - England vs New Zealand
2023-08-30 - international - T20 - male - 1336048 - New Zealand vs England
2023-08-20 - international - T20 - male - 1377729 - New Zealand vs United Arab Emirates
2023-08-19 - international - T20 - male - 1377728 - New Zealand vs United Arab Emirates
2023-08-17 - international - T20 - male - 1377727 - New Zealand vs United Arab Emirates
2023-05-07 - international - ODI - male - 1339623 - New Zealand vs Pakistan
2023-05-05 - international - ODI - male - 1339622 - Pakistan vs New Zealand
2023-05-03 - international - ODI - male - 1339621 - Pakistan vs New Zealand
2023-04-29 - international - ODI - male - 1339620 - New Zealand vs Pakistan
2023-04-27 - international - ODI - male - 1339619 - New Zealand vs Pakistan
2023-04-24 - international - T20 - male - 1339618 - Pakistan vs New Zealand
2023-04-20 - international - T20 - male - 1339617 - New Zealand vs Pakistan
2023-04-17 - international - T20 - male - 1339616 - New Zealand vs Pakistan
2023-04-15 - international - T20 - male - 1339615 - Pakistan vs New Zealand
2023-04-14 - international - T20 - male - 1339614 - Pakistan vs New Zealand
2023-04-08 - international - T20 - male - 1322364 - Sri Lanka vs New Zealand
2023-04-05 - international - T20 - male - 1322363 - Sri Lanka vs New Zealand
2023-04-02 - international - T20 - male - 1322362 - Sri Lanka vs New Zealand
2023-03-31 - international - ODI - male - 1322361 - Sri Lanka vs New Zealand
2023-03-25 - international - ODI - male - 1322359 - New Zealand vs Sri Lanka
2023-03-17 - international - Test - male - 1322358 - New Zealand vs Sri Lanka
2023-03-09 - international - Test - male - 1322357 - Sri Lanka vs New Zealand
2023-02-24 - international - Test - male - 1322356 - England vs New Zealand
2023-02-16 - international - Test - male - 1322355 - England vs New Zealand
2023-02-01 - international - T20 - male - 1348651 - India vs New Zealand
2023-01-29 - international - T20 - male - 1348650 - New Zealand vs India
2023-01-27 - international - T20 - male - 1348649 - New Zealand vs India
2023-01-24 - international - ODI - male - 1348648 - India vs New Zealand
2023-01-21 - international - ODI - male - 1348647 - New Zealand vs India
2023-01-18 - international - ODI - male - 1348646 - India vs New Zealand
2023-01-13 - international - ODI - male - 1339613 - Pakistan vs New Zealand
2023-01-11 - international - ODI - male - 1339612 - New Zealand vs Pakistan
2023-01-09 - international - ODI - male - 1339611 - New Zealand vs Pakistan
2023-01-02 - international - Test - male - 1339610 - New Zealand vs Pakistan
2022-12-26 - international - Test - male - 1339609 - Pakistan vs New Zealand
2022-11-30 - international - ODI - male - 1322280 - India vs New Zealand
2022-11-27 - international - ODI - male - 1322279 - India vs New Zealand
2022-11-25 - international - ODI - male - 1322278 - India vs New Zealand
2022-11-22 - international - T20 - male - 1322277 - New Zealand vs India
2022-11-20 - international - T20 - male - 1322276 - India vs New Zealand
2022-11-09 - international - T20 - male - 1298177 - New Zealand vs Pakistan
2022-11-04 - international - T20 - male - 1298171 - New Zealand vs Ireland
2022-11-01 - international - T20 - male - 1298167 - England vs New Zealand
2022-10-29 - international - T20 - male - 1298161 - New Zealand vs Sri Lanka
2022-10-22 - international - T20 - male - 1298147 - New Zealand vs Australia
2022-10-14 - international - T20 - male - 1322340 - New Zealand vs Pakistan
2022-10-12 - international - T20 - male - 1322338 - New Zealand vs Bangladesh
2022-10-11 - international - T20 - male - 1322337 - Pakistan vs New Zealand
2022-10-09 - international - T20 - male - 1322336 - Bangladesh vs New Zealand
2022-10-08 - international - T20 - male - 1322335 - New Zealand vs Pakistan
2022-09-11 - international - ODI - male - 1317481 - Australia vs New Zealand
2022-09-08 - international - ODI - male - 1317480 - Australia vs New Zealand
2022-09-06 - international - ODI - male - 1317479 - New Zealand vs Australia
2022-08-21 - international - ODI - male - 1317913 - West Indies vs New Zealand
2022-08-19 - international - ODI - male - 1317912 - New Zealand vs West Indies
2022-08-17 - international - ODI - male - 1317911 - New Zealand vs West Indies
2022-08-14 - international - T20 - male - 1317910 - New Zealand vs West Indies
2022-08-12 - international - T20 - male - 1317909 - New Zealand vs West Indies
2022-08-10 - international - T20 - male - 1317908 - New Zealand vs West Indies
2022-08-05 - international - T20 - male - 1310902 - Netherlands vs New Zealand
2022-08-04 - international - T20 - male - 1310901 - New Zealand vs Netherlands
2022-07-31 - international - ODI - male - 1307479 - Scotland vs New Zealand
2022-07-29 - international - T20 - male - 1307478 - New Zealand vs Scotland
2022-07-27 - international - T20 - male - 1307477 - New Zealand vs Scotland
2022-07-22 - international - T20 - male - 1303314 - Ireland vs New Zealand
2022-07-20 - international - T20 - male - 1303313 - New Zealand vs Ireland
2022-07-18 - international - T20 - male - 1303312 - New Zealand vs Ireland
2022-07-15 - international - ODI - male - 1303311 - New Zealand vs Ireland
2022-07-12 - international - ODI - male - 1303310 - Ireland vs New Zealand
2022-07-10 - international - ODI - male - 1303309 - Ireland vs New Zealand
2022-06-23 - international - Test - male - 1276903 - New Zealand vs England
2022-06-10 - international - Test - male - 1276902 - New Zealand vs England
2022-06-02 - international - Test - male - 1276901 - New Zealand vs England
2022-04-04 - international - ODI - male - 1288989 - New Zealand vs Netherlands
2022-04-02 - international - ODI - male - 1288988 - New Zealand vs Netherlands
2022-03-29 - international - ODI - male - 1288987 - Netherlands vs New Zealand
2022-02-25 - international - Test - male - 1288982 - South Africa vs New Zealand
2022-02-17 - international - Test - male - 1288981 - South Africa vs New Zealand
2022-01-09 - international - Test - male - 1288980 - New Zealand vs Bangladesh
2022-01-01 - international - Test - male - 1288979 - New Zealand vs Bangladesh
2021-12-03 - international - Test - male - 1278675 - India vs New Zealand
2021-11-25 - international - Test - male - 1278674 - India vs New Zealand
2021-11-21 - international - T20 - male - 1278673 - India vs New Zealand
2021-11-19 - international - T20 - male - 1278672 - New Zealand vs India
2021-11-17 - international - T20 - male - 1278671 - New Zealand vs India
2021-11-14 - international - T20 - male - 1273756 - New Zealand vs Australia
2021-11-10 - international - T20 - male - 1273754 - England vs New Zealand
2021-11-05 - international - T20 - male - 1273747 - New Zealand vs Namibia
2021-11-03 - international - T20 - male - 1273743 - New Zealand vs Scotland
2021-10-31 - international - T20 - male - 1273739 - India vs New Zealand
2021-10-26 - international - T20 - male - 1273730 - New Zealand vs Pakistan
2021-09-10 - international - T20 - male - 1272097 - New Zealand vs Bangladesh
2021-09-08 - international - T20 - male - 1272096 - New Zealand vs Bangladesh
2021-09-05 - international - T20 - male - 1272095 - New Zealand vs Bangladesh
2021-09-03 - international - T20 - male - 1272094 - Bangladesh vs New Zealand
2021-09-01 - international - T20 - male - 1272093 - New Zealand vs Bangladesh
2021-06-18 - international - Test - male - 1249875 - India vs New Zealand
2021-06-10 - international - Test - male - 1249211 - England vs New Zealand
2021-06-02 - international - Test - male - 1249210 - New Zealand vs England
2021-04-01 - international - T20 - male - 1233981 - New Zealand vs Bangladesh
2021-03-30 - international - T20 - male - 1233980 - New Zealand vs Bangladesh
2021-03-28 - international - T20 - male - 1233979 - New Zealand vs Bangladesh
2021-03-26 - international - ODI - male - 1233978 - New Zealand vs Bangladesh
2021-03-23 - international - ODI - male - 1233977 - Bangladesh vs New Zealand
2021-03-20 - international - ODI - male - 1233976 - Bangladesh vs New Zealand
2021-03-07 - international - T20 - male - 1233975 - Australia vs New Zealand
2021-03-05 - international - T20 - male - 1233974 - Australia vs New Zealand
2021-03-03 - international - T20 - male - 1233973 - Australia vs New Zealand
2021-02-25 - international - T20 - male - 1233972 - New Zealand vs Australia
2021-02-22 - international - T20 - male - 1233971 - New Zealand vs Australia
2021-01-03 - international - Test - male - 1233963 - Pakistan vs New Zealand
2020-12-26 - international - Test - male - 1233962 - New Zealand vs Pakistan
2020-12-22 - international - T20 - male - 1233961 - New Zealand vs Pakistan
2020-12-20 - international - T20 - male - 1233960 - Pakistan vs New Zealand
2020-12-18 - international - T20 - male - 1233959 - Pakistan vs New Zealand
2020-12-11 - international - Test - male - 1233958 - New Zealand vs West Indies
2020-12-03 - international - Test - male - 1233957 - New Zealand vs West Indies
2020-11-30 - international - T20 - male - 1233956 - West Indies vs New Zealand
2020-11-29 - international - T20 - male - 1233955 - New Zealand vs West Indies
2020-11-27 - international - T20 - male - 1233954 - West Indies vs New Zealand
2020-03-13 - international - ODI - male - 1183537 - Australia vs New Zealand
2020-02-29 - international - Test - male - 1187686 - New Zealand vs India
2020-02-21 - international - Test - male - 1187685 - New Zealand vs India
2020-02-11 - international - ODI - male - 1187684 - New Zealand vs India
2020-02-08 - international - ODI - male - 1187683 - New Zealand vs India
2020-02-05 - international - ODI - male - 1187682 - New Zealand vs India
2020-02-02 - international - T20 - male - 1187681 - New Zealand vs India
2020-01-31 - international - T20 - male - 1187680 - New Zealand vs India
2020-01-29 - international - T20 - male - 1187679 - New Zealand vs India
2020-01-26 - international - T20 - male - 1187678 - New Zealand vs India
2020-01-24 - international - T20 - male - 1187677 - New Zealand vs India
2020-01-03 - international - Test - male - 1183534 - Australia vs New Zealand
2019-12-26 - international - Test - male - 1183533 - Australia vs New Zealand
2019-12-12 - international - Test - male - 1183532 - Australia vs New Zealand
2019-11-29 - international - Test - male - 1187672 - New Zealand vs England
2019-11-21 - international - Test - male - 1187671 - New Zealand vs England
2019-11-10 - international - T20 - male - 1187669 - New Zealand vs England
2019-11-08 - international - T20 - male - 1187668 - New Zealand vs England
2019-11-05 - international - T20 - male - 1187667 - New Zealand vs England
2019-11-03 - international - T20 - male - 1187666 - New Zealand vs England
2019-11-01 - international - T20 - male - 1187665 - New Zealand vs England
2019-09-06 - international - T20 - male - 1192877 - Sri Lanka vs New Zealand
2019-09-03 - international - T20 - male - 1192876 - Sri Lanka vs New Zealand
2019-09-01 - international - T20 - male - 1192875 - Sri Lanka vs New Zealand
2019-08-22 - international - Test - male - 1192874 - Sri Lanka vs New Zealand
2019-08-14 - international - Test - male - 1192873 - Sri Lanka vs New Zealand
2019-07-14 - international - ODI - male - 1144530 - England vs New Zealand
2019-07-09 - international - ODI - male - 1144528 - India vs New Zealand
2019-07-03 - international - ODI - male - 1144523 - England vs New Zealand
2019-06-29 - international - ODI - male - 1144519 - Australia vs New Zealand
2019-06-26 - international - ODI - male - 1144515 - New Zealand vs Pakistan
2019-06-22 - international - ODI - male - 1144511 - New Zealand vs West Indies
2019-06-19 - international - ODI - male - 1144507 - New Zealand vs South Africa
2019-06-05 - international - ODI - male - 1144491 - Bangladesh vs New Zealand
2019-06-01 - international - ODI - male - 1144485 - New Zealand vs Sri Lanka
2019-03-08 - international - Test - male - 1153848 - New Zealand vs Bangladesh
2019-02-28 - international - Test - male - 1153847 - New Zealand vs Bangladesh
2019-02-20 - international - ODI - male - 1153846 - New Zealand vs Bangladesh
2019-02-16 - international - ODI - male - 1153845 - New Zealand vs Bangladesh
2019-02-13 - international - ODI - male - 1153844 - New Zealand vs Bangladesh
2019-02-10 - international - T20 - male - 1153698 - New Zealand vs India
2019-02-08 - international - T20 - male - 1153697 - New Zealand vs India
2019-02-06 - international - T20 - male - 1153696 - New Zealand vs India
2019-02-03 - international - ODI - male - 1153695 - New Zealand vs India
2019-01-31 - international - ODI - male - 1153694 - New Zealand vs India
2019-01-28 - international - ODI - male - 1153693 - New Zealand vs India
2019-01-26 - international - ODI - male - 1153692 - New Zealand vs India
2019-01-23 - international - ODI - male - 1153691 - New Zealand vs India
2019-01-11 - international - T20 - male - 1153843 - New Zealand vs Sri Lanka
2019-01-08 - international - ODI - male - 1153842 - New Zealand vs Sri Lanka
2019-01-05 - international - ODI - male - 1153841 - New Zealand vs Sri Lanka
2019-01-03 - international - ODI - male - 1153840 - New Zealand vs Sri Lanka
2018-12-26 - international - Test - male - 1153839 - New Zealand vs Sri Lanka
2018-12-15 - international - Test - male - 1153838 - Sri Lanka vs New Zealand
2018-12-03 - international - Test - male - 1157383 - New Zealand vs Pakistan
2018-11-24 - international - Test - male - 1157382 - Pakistan vs New Zealand
2018-11-16 - international - Test - male - 1157381 - New Zealand vs Pakistan
2018-11-11 - international - ODI - male - 1157380 - Pakistan vs New Zealand
2018-11-09 - international - ODI - male - 1157379 - New Zealand vs Pakistan
2018-11-07 - international - ODI - male - 1157378 - New Zealand vs Pakistan
2018-11-04 - international - T20 - male - 1157377 - Pakistan vs New Zealand
2018-11-02 - international - T20 - male - 1157376 - New Zealand vs Pakistan
2018-10-31 - international - T20 - male - 1157375 - Pakistan vs New Zealand
2018-03-30 - international - Test - male - 1115781 - England vs New Zealand
2018-03-22 - international - Test - male - 1115780 - England vs New Zealand
2018-03-10 - international - ODI - male - 1115779 - New Zealand vs England
2018-03-07 - international - ODI - male - 1115778 - England vs New Zealand
2018-03-03 - international - ODI - male - 1115777 - England vs New Zealand
2018-02-28 - international - ODI - male - 1115776 - New Zealand vs England
2018-02-25 - international - ODI - male - 1115775 - England vs New Zealand
2018-02-21 - international - T20 - male - 1072322 - New Zealand vs Australia
2018-02-18 - international - T20 - male - 1072321 - England vs New Zealand
2018-02-16 - international - T20 - male - 1072320 - New Zealand vs Australia
2018-02-13 - international - T20 - male - 1072319 - New Zealand vs England
2018-02-03 - international - T20 - male - 1072316 - New Zealand vs Australia
2018-01-28 - international - T20 - male - 1115809 - Pakistan vs New Zealand
2018-01-25 - international - T20 - male - 1115808 - Pakistan vs New Zealand
2018-01-22 - international - T20 - male - 1115807 - Pakistan vs New Zealand
2018-01-19 - international - ODI - male - 1115806 - New Zealand vs Pakistan
2018-01-16 - international - ODI - male - 1115805 - Pakistan vs New Zealand
2018-01-13 - international - ODI - male - 1115804 - New Zealand vs Pakistan
2018-01-09 - international - ODI - male - 1115803 - Pakistan vs New Zealand
2018-01-06 - international - ODI - male - 1115802 - New Zealand vs Pakistan
2018-01-03 - international - T20 - male - 1115800 - New Zealand vs West Indies
2018-01-01 - international - T20 - male - 1115799 - New Zealand vs West Indies
2017-12-29 - international - T20 - male - 1115798 - New Zealand vs West Indies
2017-12-26 - international - ODI - male - 1115797 - New Zealand vs West Indies
2017-12-23 - international - ODI - male - 1115796 - New Zealand vs West Indies
2017-12-20 - international - ODI - male - 1115795 - West Indies vs New Zealand
2017-12-09 - international - Test - male - 1115794 - New Zealand vs West Indies
2017-12-01 - international - Test - male - 1115793 - West Indies vs New Zealand
2017-11-07 - international - T20 - male - 1120095 - India vs New Zealand
2017-11-04 - international - T20 - male - 1120094 - New Zealand vs India
2017-11-01 - international - T20 - male - 1120093 - India vs New Zealand
2017-10-29 - international - ODI - male - 1120092 - India vs New Zealand
2017-10-25 - international - ODI - male - 1120091 - New Zealand vs India
2017-10-22 - international - ODI - male - 1120090 - India vs New Zealand
2017-06-09 - international - ODI - male - 1022363 - Bangladesh vs New Zealand
2017-06-06 - international - ODI - male - 1022357 - England vs New Zealand
2017-06-02 - international - ODI - male - 1022349 - Australia vs New Zealand
2017-05-24 - international - ODI - male - 1033371 - Bangladesh vs New Zealand
2017-05-21 - international - ODI - male - 1033369 - Ireland vs New Zealand
2017-05-17 - international - ODI - male - 1033365 - Bangladesh vs New Zealand
2017-05-14 - international - ODI - male - 1033363 - Ireland vs New Zealand
2017-03-25 - international - Test - male - 1020045 - New Zealand vs South Africa
2017-03-16 - international - Test - male - 1020043 - New Zealand vs South Africa
2017-03-08 - international - Test - male - 1020041 - New Zealand vs South Africa
2017-03-04 - international - ODI - male - 1020039 - New Zealand vs South Africa
2017-03-01 - international - ODI - male - 1020037 - New Zealand vs South Africa
2017-02-25 - international - ODI - male - 1020035 - New Zealand vs South Africa
2017-02-22 - international - ODI - male - 1020033 - New Zealand vs South Africa
2017-02-19 - international - ODI - male - 1020031 - New Zealand vs South Africa
2017-02-17 - international - T20 - male - 1020029 - New Zealand vs South Africa
2017-02-05 - international - ODI - male - 1020017 - New Zealand vs Australia
2017-01-30 - international - ODI - male - 1020013 - New Zealand vs Australia
2017-01-20 - international - Test - male - 1019987 - New Zealand vs Bangladesh
2017-01-12 - international - Test - male - 1019985 - New Zealand vs Bangladesh
2017-01-08 - international - T20 - male - 1019983 - New Zealand vs Bangladesh
2017-01-06 - international - T20 - male - 1019981 - New Zealand vs Bangladesh
2017-01-03 - international - T20 - male - 1019979 - New Zealand vs Bangladesh
2016-12-31 - international - ODI - male - 1019977 - New Zealand vs Bangladesh
2016-12-29 - international - ODI - male - 1019975 - New Zealand vs Bangladesh
2016-12-26 - international - ODI - male - 1019973 - New Zealand vs Bangladesh
2016-12-09 - international - ODI - male - 1001375 - Australia vs New Zealand
2016-12-06 - international - ODI - male - 1001373 - Australia vs New Zealand
2016-12-04 - international - ODI - male - 1001371 - Australia vs New Zealand
2016-11-25 - international - Test - male - 1019995 - New Zealand vs Pakistan
2016-11-17 - international - Test - male - 1019993 - New Zealand vs Pakistan
2016-10-29 - international - ODI - male - 1030227 - India vs New Zealand
2016-10-26 - international - ODI - male - 1030225 - India vs New Zealand
2016-10-23 - international - ODI - male - 1030223 - India vs New Zealand
2016-10-20 - international - ODI - male - 1030221 - India vs New Zealand
2016-10-16 - international - ODI - male - 1030219 - India vs New Zealand
2016-10-08 - international - Test - male - 1030217 - India vs New Zealand
2016-09-30 - international - Test - male - 1030215 - India vs New Zealand
2016-09-22 - international - Test - male - 1030213 - India vs New Zealand
2016-08-27 - international - Test - male - 936129 - South Africa vs New Zealand
2016-08-19 - international - Test - male - 936127 - South Africa vs New Zealand
2016-08-06 - international - Test - male - 1024043 - Zimbabwe vs New Zealand
2016-07-28 - international - Test - male - 1024041 - Zimbabwe vs New Zealand
2016-03-30 - international - T20 - male - 951369 - England vs New Zealand
2016-03-26 - international - T20 - male - 951359 - Bangladesh vs New Zealand
2016-03-22 - international - T20 - male - 951349 - New Zealand vs Pakistan
2016-03-18 - international - T20 - male - 951337 - Australia vs New Zealand
2016-03-15 - international - T20 - male - 951329 - India vs New Zealand
2016-02-20 - international - Test - male - 914239 - New Zealand vs Australia
2016-02-12 - international - Test - male - 914237 - New Zealand vs Australia
2016-02-08 - international - ODI - male - 914235 - New Zealand vs Australia
2016-02-06 - international - ODI - male - 914233 - New Zealand vs Australia
2016-02-03 - international - ODI - male - 914231 - New Zealand vs Australia
2016-01-31 - international - ODI - male - 914265 - New Zealand vs Pakistan
2016-01-25 - international - ODI - male - 914227 - New Zealand vs Pakistan
2016-01-22 - international - T20 - male - 914225 - New Zealand vs Pakistan
2016-01-17 - international - T20 - male - 914223 - New Zealand vs Pakistan
2016-01-15 - international - T20 - male - 914221 - New Zealand vs Pakistan
2016-01-10 - international - T20 - male - 914219 - New Zealand vs Sri Lanka
2016-01-07 - international - T20 - male - 914217 - New Zealand vs Sri Lanka
2016-01-05 - international - ODI - male - 914215 - New Zealand vs Sri Lanka
2016-01-02 - international - ODI - male - 914213 - New Zealand vs Sri Lanka
2015-12-31 - international - ODI - male - 914211 - New Zealand vs Sri Lanka
2015-12-28 - international - ODI - male - 914209 - New Zealand vs Sri Lanka
2015-12-26 - international - ODI - male - 914207 - New Zealand vs Sri Lanka
2015-12-18 - international - Test - male - 914205 - New Zealand vs Sri Lanka
2015-12-10 - international - Test - male - 914203 - New Zealand vs Sri Lanka
2015-11-27 - international - Test - male - 892513 - Australia vs New Zealand
2015-11-13 - international - Test - male - 892511 - Australia vs New Zealand
2015-11-05 - international - Test - male - 892509 - Australia vs New Zealand
2015-08-26 - international - ODI - male - 848847 - South Africa vs New Zealand
2015-08-23 - international - ODI - male - 848845 - South Africa vs New Zealand
2015-08-19 - international - ODI - male - 848843 - South Africa vs New Zealand
2015-08-16 - international - T20 - male - 848841 - South Africa vs New Zealand
2015-08-14 - international - T20 - male - 848839 - South Africa vs New Zealand
2015-08-09 - international - T20 - male - 894293 - Zimbabwe vs New Zealand
2015-08-07 - international - ODI - male - 894291 - Zimbabwe vs New Zealand
2015-08-04 - international - ODI - male - 894289 - Zimbabwe vs New Zealand
2015-08-02 - international - ODI - male - 894287 - Zimbabwe vs New Zealand
2015-06-23 - international - T20 - male - 743953 - England vs New Zealand
2015-06-20 - international - ODI - male - 743951 - England vs New Zealand
2015-06-17 - international - ODI - male - 743949 - England vs New Zealand
2015-06-14 - international - ODI - male - 743947 - England vs New Zealand
2015-06-12 - international - ODI - male - 743945 - England vs New Zealand
2015-06-09 - international - ODI - male - 743943 - England vs New Zealand
2015-05-29 - international - Test - male - 743941 - England vs New Zealand
2015-05-21 - international - Test - male - 743939 - England vs New Zealand
2015-03-29 - international - ODI - male - 656495 - Australia vs New Zealand
2015-03-24 - international - ODI - male - 656491 - New Zealand vs South Africa
2015-03-21 - international - ODI - male - 656489 - New Zealand vs West Indies
2015-03-13 - international - ODI - male - 656471 - New Zealand vs Bangladesh
2015-02-28 - international - ODI - male - 656437 - New Zealand vs Australia
2015-02-20 - international - ODI - male - 656415 - New Zealand vs England
2015-02-17 - international - ODI - male - 656409 - New Zealand vs Scotland
2015-02-14 - international - ODI - male - 656399 - New Zealand vs Sri Lanka
2015-02-03 - international - ODI - male - 749797 - New Zealand vs Pakistan
2015-01-31 - international - ODI - male - 749795 - New Zealand vs Pakistan
2015-01-29 - international - ODI - male - 749793 - New Zealand vs Sri Lanka
2015-01-25 - international - ODI - male - 749791 - New Zealand vs Sri Lanka
2015-01-23 - international - ODI - male - 749789 - New Zealand vs Sri Lanka
2015-01-20 - international - ODI - male - 749787 - New Zealand vs Sri Lanka
2015-01-17 - international - ODI - male - 749785 - New Zealand vs Sri Lanka
2015-01-15 - international - ODI - male - 749783 - New Zealand vs Sri Lanka
2015-01-11 - international - ODI - male - 749781 - New Zealand vs Sri Lanka
2015-01-03 - international - Test - male - 749779 - New Zealand vs Sri Lanka
2014-12-26 - international - Test - male - 749777 - New Zealand vs Sri Lanka
2014-12-19 - international - ODI - male - 742627 - New Zealand vs Pakistan
2014-12-17 - international - ODI - male - 742625 - New Zealand vs Pakistan
2014-12-14 - international - ODI - male - 742623 - New Zealand vs Pakistan
2014-12-12 - international - ODI - male - 742621 - New Zealand vs Pakistan
2014-12-08 - international - ODI - male - 742619 - New Zealand vs Pakistan
2014-12-05 - international - T20 - male - 754039 - New Zealand vs Pakistan
2014-12-04 - international - T20 - male - 742617 - New Zealand vs Pakistan
2014-11-26 - international - Test - male - 742615 - New Zealand vs Pakistan
2014-11-17 - international - Test - male - 742613 - New Zealand vs Pakistan
2014-11-09 - international - Test - male - 742611 - New Zealand vs Pakistan
2014-10-27 - international - ODI - male - 749775 - New Zealand vs South Africa
2014-10-24 - international - ODI - male - 749773 - New Zealand vs South Africa
2014-10-21 - international - ODI - male - 749771 - New Zealand vs South Africa
2014-07-06 - international - T20 - male - 730285 - West Indies vs New Zealand
2014-07-05 - international - T20 - male - 730283 - West Indies vs New Zealand
2014-06-26 - international - Test - male - 730281 - West Indies vs New Zealand
2014-06-16 - international - Test - male - 730279 - West Indies vs New Zealand
2014-06-08 - international - Test - male - 730277 - West Indies vs New Zealand
2014-03-31 - international - T20 - male - 682955 - New Zealand vs Sri Lanka
2014-03-29 - international - T20 - male - 682945 - Netherlands vs New Zealand
2014-03-24 - international - T20 - male - 682931 - New Zealand vs South Africa
2014-03-22 - international - T20 - male - 682925 - England vs New Zealand
2014-02-14 - international - Test - male - 667653 - New Zealand vs India
2014-02-06 - international - Test - male - 667651 - New Zealand vs India
2014-01-31 - international - ODI - male - 667649 - New Zealand vs India
2014-01-28 - international - ODI - male - 667647 - New Zealand vs India
2014-01-25 - international - ODI - male - 667645 - New Zealand vs India
2014-01-22 - international - ODI - male - 667643 - New Zealand vs India
2014-01-19 - international - ODI - male - 667641 - New Zealand vs India
2014-01-15 - international - T20 - male - 661697 - New Zealand vs West Indies
2014-01-11 - international - T20 - male - 661695 - New Zealand vs West Indies
2014-01-08 - international - ODI - male - 661693 - New Zealand vs West Indies
2014-01-04 - international - ODI - male - 661691 - New Zealand vs West Indies
2014-01-01 - international - ODI - male - 661689 - New Zealand vs West Indies
2013-12-26 - international - ODI - male - 661685 - New Zealand vs West Indies
2013-12-19 - international - Test - male - 661683 - New Zealand vs West Indies
2013-12-11 - international - Test - male - 661681 - New Zealand vs West Indies
2013-12-03 - international - Test - male - 661679 - New Zealand vs West Indies
2013-11-21 - international - T20 - male - 668969 - Sri Lanka vs New Zealand
2013-11-16 - international - ODI - male - 668965 - Sri Lanka vs New Zealand
2013-11-12 - international - ODI - male - 668963 - Sri Lanka vs New Zealand
2013-11-10 - international - ODI - male - 668961 - Sri Lanka vs New Zealand
2013-11-06 - international - T20 - male - 668959 - Bangladesh vs New Zealand
2013-11-03 - international - ODI - male - 668957 - Bangladesh vs New Zealand
2013-10-31 - international - ODI - male - 668955 - Bangladesh vs New Zealand
2013-10-29 - international - ODI - male - 668953 - Bangladesh vs New Zealand
2013-10-21 - international - Test - male - 668951 - Bangladesh vs New Zealand
2013-10-09 - international - Test - male - 668949 - Bangladesh vs New Zealand
2013-06-27 - international - T20 - male - 566927 - England vs New Zealand
2013-06-25 - international - T20 - male - 566926 - England vs New Zealand
2013-06-16 - international - ODI - male - 578624 - England vs New Zealand
2013-06-12 - international - ODI - male - 578620 - Australia vs New Zealand
2013-06-09 - international - ODI - male - 578617 - New Zealand vs Sri Lanka
2013-06-05 - international - ODI - male - 566925 - England vs New Zealand
2013-06-02 - international - ODI - male - 566924 - England vs New Zealand
2013-05-31 - international - ODI - male - 566923 - England vs New Zealand
2013-05-24 - international - Test - male - 566922 - England vs New Zealand
2013-05-16 - international - Test - male - 566921 - England vs New Zealand
2013-03-22 - international - Test - male - 569245 - New Zealand vs England
2013-03-14 - international - Test - male - 569244 - New Zealand vs England
2013-03-06 - international - Test - male - 569243 - New Zealand vs England
2013-02-23 - international - ODI - male - 569242 - New Zealand vs England
2013-02-20 - international - ODI - male - 569241 - New Zealand vs England
2013-02-17 - international - ODI - male - 569240 - New Zealand vs England
2013-02-15 - international - T20 - male - 569239 - New Zealand vs England
2013-02-12 - international - T20 - male - 569238 - New Zealand vs England
2013-02-09 - international - T20 - male - 569237 - New Zealand vs England
2013-01-25 - international - ODI - male - 567360 - South Africa vs New Zealand
2013-01-22 - international - ODI - male - 567359 - South Africa vs New Zealand
2013-01-19 - international - ODI - male - 567358 - South Africa vs New Zealand
2013-01-11 - international - Test - male - 567357 - South Africa vs New Zealand
2013-01-02 - international - Test - male - 567356 - South Africa vs New Zealand
2012-12-26 - international - T20 - male - 567355 - South Africa vs New Zealand
2012-12-23 - international - T20 - male - 567354 - South Africa vs New Zealand
2012-12-21 - international - T20 - male - 567353 - South Africa vs New Zealand
2012-11-25 - international - Test - male - 582193 - Sri Lanka vs New Zealand
2012-11-17 - international - Test - male - 582192 - Sri Lanka vs New Zealand
2012-11-12 - international - ODI - male - 582191 - Sri Lanka vs New Zealand
2012-11-10 - international - ODI - male - 582190 - Sri Lanka vs New Zealand
2012-11-06 - international - ODI - male - 582189 - Sri Lanka vs New Zealand
2012-11-04 - international - ODI - male - 582188 - Sri Lanka vs New Zealand
2012-10-30 - international - T20 - male - 582186 - Sri Lanka vs New Zealand
2012-10-01 - international - T20 - male - 533292 - New Zealand vs West Indies
2012-09-29 - international - T20 - male - 533288 - England vs New Zealand
2012-09-27 - international - T20 - male - 533284 - Sri Lanka vs New Zealand
2012-09-23 - international - T20 - male - 533280 - New Zealand vs Pakistan
2012-09-21 - international - T20 - male - 533276 - Bangladesh vs New Zealand
2012-09-11 - international - T20 - male - 565820 - India vs New Zealand
2012-08-31 - international - Test - male - 565818 - India vs New Zealand
2012-08-23 - international - Test - male - 565817 - India vs New Zealand
2012-08-02 - international - Test - male - 560930 - West Indies vs New Zealand
2012-07-25 - international - Test - male - 560929 - West Indies vs New Zealand
2012-07-16 - international - ODI - male - 560927 - West Indies vs New Zealand
2012-07-14 - international - ODI - male - 560926 - West Indies vs New Zealand
2012-07-11 - international - ODI - male - 560925 - West Indies vs New Zealand
2012-07-07 - international - ODI - male - 560924 - West Indies vs New Zealand
2012-07-05 - international - ODI - male - 560923 - West Indies vs New Zealand
2012-07-01 - international - T20 - male - 560922 - New Zealand vs West Indies
2012-06-30 - international - T20 - male - 560921 - New Zealand vs West Indies
2012-03-23 - international - Test - male - 520605 - New Zealand vs South Africa
2012-03-15 - international - Test - male - 520604 - New Zealand vs South Africa
2012-03-07 - international - Test - male - 520603 - New Zealand vs South Africa
2012-03-03 - international - ODI - male - 520602 - New Zealand vs South Africa
2012-02-29 - international - ODI - male - 520601 - New Zealand vs South Africa
2012-02-25 - international - ODI - male - 520600 - New Zealand vs South Africa
2012-02-22 - international - T20 - male - 520599 - New Zealand vs South Africa
2012-02-19 - international - T20 - male - 520598 - New Zealand vs South Africa
2012-02-17 - international - T20 - male - 520597 - New Zealand vs South Africa
2012-02-14 - international - T20 - male - 520596 - New Zealand vs Zimbabwe
2012-02-11 - international - T20 - male - 520595 - New Zealand vs Zimbabwe
2012-02-09 - international - ODI - male - 520594 - New Zealand vs Zimbabwe
2012-02-06 - international - ODI - male - 520593 - New Zealand vs Zimbabwe
2012-02-03 - international - ODI - male - 520592 - New Zealand vs Zimbabwe
2012-01-26 - international - Test - male - 520591 - New Zealand vs Zimbabwe
2011-12-09 - international - Test - male - 518948 - Australia vs New Zealand
2011-12-01 - international - Test - male - 518947 - Australia vs New Zealand
2011-11-01 - international - Test - male - 527017 - Zimbabwe vs New Zealand
2011-10-25 - international - ODI - male - 527016 - Zimbabwe vs New Zealand
2011-10-22 - international - ODI - male - 527015 - Zimbabwe vs New Zealand
2011-10-20 - international - ODI - male - 527014 - Zimbabwe vs New Zealand
2011-10-17 - international - T20 - male - 527013 - Zimbabwe vs New Zealand
2011-10-15 - international - T20 - male - 527012 - Zimbabwe vs New Zealand
2011-03-29 - international - ODI - male - 433604 - Sri Lanka vs New Zealand
2011-03-25 - international - ODI - male - 433602 - New Zealand vs South Africa
2011-03-18 - international - ODI - male - 433594 - New Zealand vs Sri Lanka
2011-03-13 - international - ODI - male - 433587 - Canada vs New Zealand
2011-03-08 - international - ODI - male - 433581 - New Zealand vs Pakistan
2011-03-04 - international - ODI - male - 433575 - New Zealand vs Zimbabwe
2011-02-25 - international - ODI - male - 433565 - Australia vs New Zealand
2011-02-20 - international - ODI - male - 433559 - Kenya vs New Zealand
2011-02-05 - international - ODI - male - 473928 - New Zealand vs Pakistan
2011-02-03 - international - ODI - male - 473927 - New Zealand vs Pakistan
2011-02-01 - international - ODI - male - 473926 - New Zealand vs Pakistan
2011-01-29 - international - ODI - male - 473925 - New Zealand vs Pakistan
2011-01-26 - international - ODI - male - 473924 - New Zealand vs Pakistan
2011-01-22 - international - ODI - male - 473923 - New Zealand vs Pakistan
2011-01-15 - international - Test - male - 473922 - New Zealand vs Pakistan
2011-01-07 - international - Test - male - 473921 - New Zealand vs Pakistan
2010-12-30 - international - T20 - male - 473920 - New Zealand vs Pakistan
2010-12-28 - international - T20 - male - 473919 - New Zealand vs Pakistan
2010-12-26 - international - T20 - male - 473918 - New Zealand vs Pakistan
2010-12-10 - international - ODI - male - 467887 - India vs New Zealand
2010-12-07 - international - ODI - male - 467886 - India vs New Zealand
2010-12-04 - international - ODI - male - 467885 - India vs New Zealand
2010-12-01 - international - ODI - male - 467884 - India vs New Zealand
2010-11-28 - international - ODI - male - 467883 - India vs New Zealand
2010-11-20 - international - Test - male - 464533 - India vs New Zealand
2010-11-12 - international - Test - male - 464532 - India vs New Zealand
2010-11-04 - international - Test - male - 464531 - India vs New Zealand
2010-10-17 - international - ODI - male - 476600 - Bangladesh vs New Zealand
2010-10-14 - international - ODI - male - 476599 - Bangladesh vs New Zealand
2010-10-11 - international - ODI - male - 476598 - Bangladesh vs New Zealand
2010-10-05 - international - ODI - male - 476596 - Bangladesh vs New Zealand
2010-08-25 - international - ODI - male - 456665 - India vs New Zealand
2010-08-19 - international - ODI - male - 473315 - Sri Lanka vs New Zealand
2010-08-13 - international - ODI - male - 456664 - Sri Lanka vs New Zealand
2010-08-10 - international - ODI - male - 456662 - India vs New Zealand
2010-05-23 - international - T20 - male - 456992 - New Zealand vs Sri Lanka
2010-05-22 - international - T20 - male - 456991 - New Zealand vs Sri Lanka
2010-05-10 - international - T20 - male - 412698 - England vs New Zealand
2010-05-08 - international - T20 - male - 412693 - New Zealand vs Pakistan
2010-05-06 - international - T20 - male - 412690 - New Zealand vs South Africa
2010-05-04 - international - T20 - male - 412684 - New Zealand vs Zimbabwe
2010-04-30 - international - T20 - male - 412678 - New Zealand vs Sri Lanka
2010-03-27 - international - Test - male - 423790 - New Zealand vs Australia
2010-03-19 - international - Test - male - 423789 - New Zealand vs Australia
2010-03-13 - international - ODI - male - 423795 - New Zealand vs Australia
2010-03-11 - international - ODI - male - 423794 - New Zealand vs Australia
2010-03-09 - international - ODI - male - 423793 - New Zealand vs Australia
2010-03-06 - international - ODI - male - 423792 - New Zealand vs Australia
2010-03-03 - international - ODI - male - 423791 - New Zealand vs Australia
2010-02-28 - international - T20 - male - 423788 - New Zealand vs Australia
2010-02-26 - international - T20 - male - 423787 - New Zealand vs Australia
2010-02-15 - international - Test - male - 423786 - New Zealand vs Bangladesh
2010-02-11 - international - ODI - male - 423785 - New Zealand vs Bangladesh
2010-02-08 - international - ODI - male - 423784 - New Zealand vs Bangladesh
2010-02-05 - international - ODI - male - 423783 - New Zealand vs Bangladesh
2010-02-03 - international - T20 - male - 423782 - New Zealand vs Bangladesh
2009-12-11 - international - Test - male - 423780 - New Zealand vs Pakistan
2009-12-03 - international - Test - male - 423779 - New Zealand vs Pakistan
2009-11-24 - international - Test - male - 423778 - New Zealand vs Pakistan
2009-11-13 - international - T20 - male - 426724 - New Zealand vs Pakistan
2009-11-12 - international - T20 - male - 426723 - New Zealand vs Pakistan
2009-11-09 - international - ODI - male - 426722 - New Zealand vs Pakistan
2009-11-06 - international - ODI - male - 426721 - New Zealand vs Pakistan
2009-11-03 - international - ODI - male - 426720 - New Zealand vs Pakistan
2009-10-05 - international - ODI - male - 415287 - Australia vs New Zealand
2009-10-03 - international - ODI - male - 415286 - New Zealand vs Pakistan
2009-09-29 - international - ODI - male - 415282 - England vs New Zealand
2009-09-27 - international - ODI - male - 415279 - New Zealand vs Sri Lanka
2009-09-24 - international - ODI - male - 415275 - South Africa vs New Zealand
2009-09-11 - international - ODI - male - 403382 - India vs New Zealand
2009-09-08 - international - ODI - male - 403380 - Sri Lanka vs New Zealand
2009-09-04 - international - T20 - male - 403386 - Sri Lanka vs New Zealand
2009-09-02 - international - T20 - male - 403385 - Sri Lanka vs New Zealand
2009-08-26 - international - Test - male - 403379 - Sri Lanka vs New Zealand
2009-08-18 - international - Test - male - 403378 - Sri Lanka vs New Zealand
2009-06-16 - international - T20 - male - 356013 - New Zealand vs Sri Lanka
2009-06-13 - international - T20 - male - 356008 - New Zealand vs Pakistan
2009-06-11 - international - T20 - male - 356003 - Ireland vs New Zealand
2009-06-09 - international - T20 - male - 356000 - New Zealand vs South Africa
2009-06-06 - international - T20 - male - 355992 - New Zealand vs Scotland
2009-04-03 - international - Test - male - 366629 - New Zealand vs India
2009-03-26 - international - Test - male - 386496 - New Zealand vs India
2009-03-18 - international - Test - male - 366628 - New Zealand vs India
2009-03-14 - international - ODI - male - 366625 - New Zealand vs India
2009-03-11 - international - ODI - male - 366624 - New Zealand vs India
2009-03-08 - international - ODI - male - 366627 - New Zealand vs India
2009-03-06 - international - ODI - male - 366626 - New Zealand vs India
2009-03-03 - international - ODI - male - 366623 - New Zealand vs India
2009-02-27 - international - T20 - male - 366622 - New Zealand vs India
2009-02-25 - international - T20 - male - 386494 - New Zealand vs India
2009-02-15 - international - T20 - male - 351696 - Australia vs New Zealand
2009-02-13 - international - ODI - male - 351693 - Australia vs New Zealand
2009-02-10 - international - ODI - male - 351692 - Australia vs New Zealand
2009-02-08 - international - ODI - male - 351691 - Australia vs New Zealand
2009-02-06 - international - ODI - male - 351690 - Australia vs New Zealand
2009-02-01 - international - ODI - male - 351689 - Australia vs New Zealand
2009-01-07 - international - ODI - male - 366711 - New Zealand vs West Indies
2008-12-31 - international - ODI - male - 366709 - New Zealand vs West Indies
2008-12-28 - international - T20 - male - 366708 - New Zealand vs West Indies
2008-12-26 - international - T20 - male - 366707 - New Zealand vs West Indies
2008-11-28 - international - Test - male - 351680 - Australia vs New Zealand
2008-11-20 - international - Test - male - 351679 - Australia vs New Zealand
2008-10-25 - international - Test - male - 361759 - Bangladesh vs New Zealand
2008-06-28 - international - ODI - male - 296908 - England vs New Zealand
2008-06-25 - international - ODI - male - 296907 - England vs New Zealand
2008-06-21 - international - ODI - male - 296906 - England vs New Zealand
2008-06-18 - international - ODI - male - 296905 - England vs New Zealand
2008-06-15 - international - ODI - male - 296904 - England vs New Zealand
2008-06-13 - international - T20 - male - 296903 - England vs New Zealand
2008-06-05 - international - Test - male - 296902 - England vs New Zealand
2008-05-23 - international - Test - male - 296901 - England vs New Zealand
2008-05-15 - international - Test - male - 296900 - England vs New Zealand
2008-03-22 - international - Test - male - 300444 - New Zealand vs England
2008-03-13 - international - Test - male - 300443 - New Zealand vs England
2008-03-05 - international - Test - male - 300442 - New Zealand vs England
2008-02-23 - international - ODI - male - 300441 - New Zealand vs England
2008-02-20 - international - ODI - male - 300440 - New Zealand vs England
2008-02-15 - international - ODI - male - 300439 - New Zealand vs England
2008-02-12 - international - ODI - male - 300438 - New Zealand vs England
2008-02-09 - international - ODI - male - 300437 - New Zealand vs England
2008-02-07 - international - T20 - male - 300436 - New Zealand vs England
2008-02-05 - international - T20 - male - 300435 - New Zealand vs England
2008-01-12 - international - Test - male - 300430 - New Zealand vs Bangladesh
2008-01-04 - international - Test - male - 300429 - New Zealand vs Bangladesh
2007-12-31 - international - ODI - male - 300428 - New Zealand vs Bangladesh
2007-12-28 - international - ODI - male - 300427 - New Zealand vs Bangladesh
2007-12-26 - international - ODI - male - 300426 - New Zealand vs Bangladesh
2007-12-20 - international - ODI - male - 291347 - Australia vs New Zealand
2007-12-16 - international - ODI - male - 291346 - Australia vs New Zealand
2007-12-14 - international - ODI - male - 291345 - Australia vs New Zealand
2007-12-11 - international - T20 - male - 291343 - Australia vs New Zealand
2007-12-02 - international - ODI - male - 298798 - South Africa vs New Zealand
2007-11-30 - international - ODI - male - 298797 - South Africa vs New Zealand
2007-11-25 - international - ODI - male - 298796 - South Africa vs New Zealand
2007-11-23 - international - T20 - male - 298795 - South Africa vs New Zealand
2007-11-16 - international - Test - male - 298794 - New Zealand vs South Africa
2007-11-08 - international - Test - male - 298793 - South Africa vs New Zealand
2007-09-22 - international - T20 - male - 287877 - New Zealand vs Pakistan
2007-09-19 - international - T20 - male - 287872 - South Africa vs New Zealand
2007-09-18 - international - T20 - male - 287869 - England vs New Zealand
2007-09-16 - international - T20 - male - 287865 - India vs New Zealand
2007-09-15 - international - T20 - male - 287863 - New Zealand vs Sri Lanka
2007-09-12 - international - T20 - male - 287854 - Kenya vs New Zealand
2007-04-24 - international - ODI - male - 247505 - New Zealand vs Sri Lanka
2007-04-20 - international - ODI - male - 247503 - Australia vs New Zealand
2007-04-14 - international - ODI - male - 247497 - New Zealand vs South Africa
2007-04-12 - international - ODI - male - 247495 - New Zealand vs Sri Lanka
2007-04-09 - international - ODI - male - 247492 - Ireland vs New Zealand
2007-04-02 - international - ODI - male - 247487 - Bangladesh vs New Zealand
2007-03-29 - international - ODI - male - 247483 - West Indies vs New Zealand
2007-03-22 - international - ODI - male - 247475 - Canada vs New Zealand
2007-03-20 - international - ODI - male - 247471 - Kenya vs New Zealand
2007-03-16 - international - ODI - male - 247463 - England vs New Zealand
2007-02-20 - international - ODI - male - 251496 - New Zealand vs Australia
2007-02-18 - international - ODI - male - 251495 - New Zealand vs Australia
2007-02-16 - international - ODI - male - 251494 - New Zealand vs Australia
2007-02-06 - international - ODI - male - 249239 - England vs New Zealand
2007-02-04 - international - ODI - male - 249231 - Australia vs New Zealand
2007-01-30 - international - ODI - male - 249238 - England vs New Zealand
2007-01-28 - international - ODI - male - 249230 - Australia vs New Zealand
2007-01-23 - international - ODI - male - 249237 - England vs New Zealand
2007-01-21 - international - ODI - male - 249229 - Australia vs New Zealand
2007-01-16 - international - ODI - male - 249236 - England vs New Zealand
2007-01-14 - international - ODI - male - 249228 - Australia vs New Zealand
2007-01-06 - international - ODI - male - 251492 - New Zealand vs Sri Lanka
2007-01-02 - international - ODI - male - 251491 - New Zealand vs Sri Lanka
2006-12-28 - international - ODI - male - 251489 - New Zealand vs Sri Lanka
2006-12-26 - international - T20 - male - 251488 - New Zealand vs Sri Lanka
2006-12-22 - international - T20 - male - 251487 - New Zealand vs Sri Lanka
2006-12-15 - international - Test - male - 251486 - Sri Lanka vs New Zealand
2006-12-07 - international - Test - male - 251485 - Sri Lanka vs New Zealand
2006-11-01 - international - ODI - male - 249757 - Australia vs New Zealand
2006-10-25 - international - ODI - male - 249752 - New Zealand vs Pakistan
2006-10-20 - international - ODI - male - 249749 - New Zealand vs Sri Lanka
2006-10-16 - international - ODI - male - 249746 - New Zealand vs South Africa
2006-05-05 - international - Test - male - 238207 - New Zealand vs South Africa
2006-04-27 - international - Test - male - 238206 - New Zealand vs South Africa
2006-04-15 - international - Test - male - 238205 - South Africa vs New Zealand
2006-03-09 - international - Test - male - 238180 - New Zealand vs West Indies
2006-03-04 - international - ODI - male - 238179 - New Zealand vs West Indies
2006-03-01 - international - ODI - male - 238178 - New Zealand vs West Indies
2006-02-25 - international - ODI - male - 238177 - New Zealand vs West Indies
2006-02-22 - international - ODI - male - 238176 - New Zealand vs West Indies
2006-02-18 - international - ODI - male - 237568 - New Zealand vs West Indies
2006-02-16 - international - T20 - male - 237242 - New Zealand vs West Indies
2006-01-06 - international - ODI - male - 226392 - New Zealand vs Sri Lanka
2006-01-03 - international - ODI - male - 226391 - New Zealand vs Sri Lanka
2005-12-31 - international - ODI - male - 226390 - Sri Lanka vs New Zealand
2005-12-03 - international - ODI - male - 226364 - Australia vs New Zealand
2005-11-06 - international - ODI - male - 224227 - New Zealand vs South Africa
2005-11-04 - international - ODI - male - 224044 - South Africa vs New Zealand
2005-10-30 - international - ODI - male - 223542 - New Zealand vs South Africa
2005-10-28 - international - ODI - male - 223335 - South Africa vs New Zealand
2005-10-21 - international - T20 - male - 222678 - South Africa vs New Zealand
2005-09-06 - international - ODI - male - 218250 - India vs New Zealand
2005-08-31 - international - ODI - male - 217648 - New Zealand vs Zimbabwe
2005-08-15 - international - Test - male - 216055 - Zimbabwe vs New Zealand
2005-08-07 - international - Test - male - 215253 - New Zealand vs Zimbabwe
2005-04-11 - international - Test - male - 64134 - Sri Lanka vs New Zealand
2005-03-18 - international - Test - male - 64129 - Australia vs New Zealand
2005-03-10 - international - Test - male - 64128 - New Zealand vs Australia
2005-03-01 - international - ODI - male - 64935 - New Zealand vs Australia
2005-02-26 - international - ODI - male - 64933 - Australia vs New Zealand
2005-02-17 - international - T20 - male - 211048 - New Zealand vs Australia
2004-12-08 - international - ODI - male - 66386 - Australia vs New Zealand
2004-12-05 - international - ODI - male - 66385 - Australia vs New Zealand
2004-11-26 - international - Test - male - 64108 - Australia vs New Zealand
2004-11-18 - international - Test - male - 64107 - New Zealand vs Australia
2004-11-02 - international - ODI - male - 64907 - New Zealand vs Bangladesh
2004-10-26 - international - Test - male - 64104 - New Zealand vs Bangladesh
2004-09-16 - international - ODI - male - 66204 - New Zealand vs Australia
2004-09-10 - international - ODI - male - 66197 - New Zealand vs United States of America
2004-07-10 - international - ODI - male - 66311 - New Zealand vs West Indies
2004-06-29 - international - ODI - male - 66305 - England vs New Zealand
2004-03-26 - international - Test - male - 64076 - New Zealand vs South Africa
2004-03-18 - international - Test - male - 64075 - South Africa vs New Zealand
2004-02-25 - international - ODI - male - 64872 - South Africa vs New Zealand
2004-01-03 - international - ODI - male - 64857 - Pakistan vs New Zealand
2003-12-05 - international - ODI - male - 64855 - New Zealand vs Pakistan
2003-12-01 - international - ODI - male - 64853 - Pakistan vs New Zealand
2003-11-29 - international - ODI - male - 64850 - New Zealand vs Pakistan
2003-11-15 - international - ODI - male - 66372 - India vs New Zealand
2003-11-06 - international - ODI - male - 66369 - India vs New Zealand
2003-11-03 - international - ODI - male - 66368 - New Zealand vs Australia
2003-10-29 - international - ODI - male - 66366 - New Zealand vs Australia
2003-10-23 - international - ODI - male - 66364 - India vs New Zealand
2003-10-16 - international - Test - male - 64047 - New Zealand vs India
2003-05-23 - international - ODI - male - 66363 - Pakistan vs New Zealand
2003-05-19 - international - ODI - male - 66361 - New Zealand vs Sri Lanka
2003-05-11 - international - ODI - male - 66358 - Pakistan vs New Zealand
2003-03-14 - international - ODI - male - 65281 - New Zealand vs India
2003-03-11 - international - ODI - male - 65279 - Australia vs New Zealand
2003-03-08 - international - ODI - male - 65277 - Zimbabwe vs New Zealand
2003-03-03 - international - ODI - male - 65270 - Canada vs New Zealand
2003-02-26 - international - ODI - male - 65261 - Bangladesh vs New Zealand
2003-02-16 - international - ODI - male - 65248 - South Africa vs New Zealand
2003-02-13 - international - ODI - male - 65242 - New Zealand vs West Indies
2003-02-10 - international - ODI - male - 65237 - Sri Lanka vs New Zealand
2003-01-14 - international - ODI - male - 64819 - India vs New Zealand
2003-01-08 - international - ODI - male - 64817 - New Zealand vs India
2003-01-04 - international - ODI - male - 64816 - India vs New Zealand
2003-01-01 - international - ODI - male - 64815 - India vs New Zealand
2002-12-29 - international - ODI - male - 64814 - New Zealand vs India
