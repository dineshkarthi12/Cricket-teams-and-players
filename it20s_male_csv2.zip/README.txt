All Men's International T20 match data in CSV format
====================================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the YAML data provided on the site into a CSV format. That
initial version was heavily influenced by the format used by the baseball
project Retrosheet. I wasn't sure of the usefulness of my CSV format, but
nothing better was suggested so I persisted with it. Later Ashwin Raman
(https://twitter.com/AshwinRaman_) send me a detailed example of a format
he felt might work and, liking what I saw, I started to produce data in
a slightly modified version of that initial example.

This particular zip folder contains the CSV data for...
  All Men's International T20 matches
...for which we have data.

An "International T20" is a T20 match between countries that is not regarded
by the ICC as a "T20 International". At it's most basic it's a match that
doesn't involve 2 of the countries "granted" T20 International "status" by
the ICC.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the original? Ideally I'd like
to settle on a single CSV format so what should be kept from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_ashwin/
but the following is a brief summary of the details...

This format consists of 2 files per match, although you can get all of
the ball-by-ball data from just one of the files. The files for a match
are named <id>.csv (for the ball-by-ball data), and <id>_info.csv (for
the match info), where <id> is the Cricinfo id for the match. The
ball-by-ball file contains one row per delivery in the match, while the
match info file contains match information such as dates the match was
played, the outcome, and lists of the players involved in the match.

The match info file format
--------------------------

The info section contains the information on the actual match, such as
when and where it was played, any event it was part of, the type of
match etc. The fields included in the info section will each appear as
one or more rows in the data. Some of the fields are required, whereas
some are optional. If a field has multiple values, such as team, then
each value will appear on a row of it's own.

The ball-by-ball file format
----------------------------

The first row of each ball-by-ball CSV file contains the headers for the
file, with each subsequent row providing details on a single delivery.
The headers in the file are:

  * match_id
  * season
  * start_date
  * venue
  * innings
  * ball
  * batting_team
  * bowling_team
  * striker
  * non_striker
  * bowler
  * runs_off_bat
  * extras
  * wides
  * noballs
  * byes
  * legbyes
  * penalty
  * wicket_type
  * player_dismissed
  * other_wicket_type
  * other_player_dismissed

Most of the fields above should, hopefully, be self-explanatory, but some may
benefit from clarification...

"innings" contains the number of the innings within the match. If a match is
one that would normally have 2 innings, such as a T20 or ODI, then any innings
of more than 2 can be regarded as a super over.

"ball" is a combination of the over and delivery. For example, "0.3" represents
the 3rd ball of the 1st over.

"wides", "noballs", "byes", "legbyes", and "penalty" contain the total of each
particular type of extras, or are blank if not relevant to the delivery.

If a wicket occurred on a delivery then "wicket_type" will contain the method
of dismissal, while "player_dismissed" will indicate who was dismissed. There
is also the, admittedly remote, possibility that a second dismissal can be
recorded on the delivery (such as when a player retires on the same delivery
as another dismissal occurs). In this case "other_wicket_type" will record
the reason, while "other_player_dismissed" will show who was dismissed.

Matches included in this archive
--------------------------------

2024-05-26 - international - IT20 - male - 1434162 - Gibraltar vs Hungary
2018-12-07 - international - IT20 - male - 1166892 - Japan vs South Korea
2018-12-07 - international - IT20 - male - 1166891 - Philippines vs Indonesia
2018-12-06 - international - IT20 - male - 1166890 - Philippines vs Japan
2018-12-06 - international - IT20 - male - 1166889 - Indonesia vs South Korea
2018-12-05 - international - IT20 - male - 1166888 - Philippines vs South Korea
2018-12-05 - international - IT20 - male - 1166887 - Indonesia vs Japan
2018-12-03 - international - IT20 - male - 1166886 - Japan vs South Korea
2018-12-03 - international - IT20 - male - 1166885 - Philippines vs Indonesia
2018-12-02 - international - IT20 - male - 1166884 - Philippines vs Japan
2018-12-01 - international - IT20 - male - 1166882 - Philippines vs South Korea
2018-12-01 - international - IT20 - male - 1166881 - Japan vs Indonesia
2018-11-03 - international - IT20 - male - 1163067 - Namibia vs Botswana
2018-11-02 - international - IT20 - male - 1163066 - Namibia vs St Helena
2018-11-02 - international - IT20 - male - 1163064 - Lesotho vs Botswana
2018-11-01 - international - IT20 - male - 1163062 - Malawi vs Lesotho
2018-11-01 - international - IT20 - male - 1163061 - Swaziland vs Botswana
2018-11-01 - international - IT20 - male - 1163060 - Namibia vs Lesotho
2018-11-01 - international - IT20 - male - 1163059 - Malawi vs Mozambique
2018-10-30 - international - IT20 - male - 1163058 - Botswana vs Malawi
2018-10-30 - international - IT20 - male - 1163057 - Mozambique vs Lesotho
2018-10-30 - international - IT20 - male - 1163056 - Swaziland vs Malawi
2018-10-30 - international - IT20 - male - 1163055 - Botswana vs St Helena
2018-10-29 - international - IT20 - male - 1163054 - Namibia vs Mozambique
2018-10-29 - international - IT20 - male - 1163052 - St Helena vs Malawi
2018-10-29 - international - IT20 - male - 1163051 - Swaziland vs Lesotho
2018-10-28 - international - IT20 - male - 1163048 - Swaziland vs Namibia
2018-10-12 - international - IT20 - male - 1160965 - Singapore vs Nepal
2018-10-12 - international - IT20 - male - 1160964 - China vs Malaysia
2018-10-10 - international - IT20 - male - 1160962 - Thailand vs Myanmar
2018-10-10 - international - IT20 - male - 1160961 - Singapore vs Bhutan
2018-10-10 - international - IT20 - male - 1160960 - China vs Nepal
2018-10-09 - international - IT20 - male - 1160959 - Myanmar vs Malaysia
2018-10-09 - international - IT20 - male - 1160958 - Nepal vs Bhutan
2018-10-09 - international - IT20 - male - 1160957 - Thailand vs Singapore
2018-10-07 - international - IT20 - male - 1160956 - Nepal vs Thailand
2018-10-07 - international - IT20 - male - 1160954 - Singapore vs Malaysia
2018-10-06 - international - IT20 - male - 1160952 - China vs Singapore
2018-10-06 - international - IT20 - male - 1160951 - Malaysia vs Nepal
2018-10-04 - international - IT20 - male - 1160950 - Myanmar vs Singapore
2018-10-04 - international - IT20 - male - 1160949 - Malaysia vs Thailand
2018-10-04 - international - IT20 - male - 1160948 - China vs Bhutan
2018-10-03 - international - IT20 - male - 1160947 - Myanmar vs Nepal
2018-10-03 - international - IT20 - male - 1160946 - China vs Thailand
2018-09-26 - international - IT20 - male - 1157701 - Panama vs Canada
2018-09-26 - international - IT20 - male - 1157700 - Belize vs United States of America
2018-09-25 - international - IT20 - male - 1157699 - Canada vs United States of America
2018-09-25 - international - IT20 - male - 1157698 - Panama vs Belize
2018-09-23 - international - IT20 - male - 1157697 - Panama vs United States of America
2018-09-23 - international - IT20 - male - 1157696 - Belize vs Canada
2018-09-21 - international - IT20 - male - 1157693 - United States of America vs Belize
2018-09-21 - international - IT20 - male - 1157692 - Panama vs Canada
2018-09-20 - international - IT20 - male - 1157690 - Panama vs United States of America
2018-09-19 - international - IT20 - male - 1157691 - Belize vs Canada
2018-09-15 - international - IT20 - male - 1159091 - China vs Japan
2018-09-14 - international - IT20 - male - 1159089 - Japan vs South Korea
2018-09-13 - international - IT20 - male - 1159087 - China vs South Korea
2018-09-02 - international - IT20 - male - 1156678 - Norway vs Israel
2018-09-02 - international - IT20 - male - 1156663 - Jersey vs Finland
2018-09-02 - international - IT20 - male - 1155317 - Cyprus vs Portugal
2018-09-02 - international - IT20 - male - 1155316 - Denmark vs France
2018-09-02 - international - IT20 - male - 1155315 - Austria vs Germany
2018-09-01 - international - IT20 - male - 1156676 - Israel vs Czech Republic
2018-09-01 - international - IT20 - male - 1156675 - Guernsey vs Norway
2018-09-01 - international - IT20 - male - 1156660 - Finland vs Spain
2018-09-01 - international - IT20 - male - 1156659 - Belgium vs Italy
2018-09-01 - international - IT20 - male - 1155313 - Portugal vs Denmark
2018-08-31 - international - IT20 - male - 1157847 - Norway vs Sweden
2018-08-31 - international - IT20 - male - 1157845 - Israel vs Gibraltar
2018-08-31 - international - IT20 - male - 1157844 - Jersey vs Italy
2018-08-30 - international - IT20 - male - 1156672 - Sweden vs Israel
2018-08-30 - international - IT20 - male - 1156670 - Israel vs Guernsey
2018-08-30 - international - IT20 - male - 1156657 - Jersey vs Isle of Man
2018-08-30 - international - IT20 - male - 1156656 - Italy vs Finland
2018-08-30 - international - IT20 - male - 1156655 - Spain vs Jersey
2018-08-30 - international - IT20 - male - 1155310 - Germany vs France
2018-08-30 - international - IT20 - male - 1155308 - France vs Portugal
2018-08-29 - international - IT20 - male - 1156668 - Norway vs Sweden
2018-08-29 - international - IT20 - male - 1156665 - Gibraltar vs Guernsey
2018-08-29 - international - IT20 - male - 1156653 - Isle of Man vs Finland
2018-08-29 - international - IT20 - male - 1156651 - Isle of Man vs Belgium
2018-08-29 - international - IT20 - male - 1156650 - Italy vs Spain
2018-08-29 - international - IT20 - male - 1155306 - Germany vs Denmark
2018-08-29 - international - IT20 - male - 1155304 - Germany vs Cyprus
2018-08-29 - international - IT20 - male - 1155283 - Fiji vs Samoa
2018-08-29 - international - IT20 - male - 1155282 - Papua New Guinea vs Vanuatu
2018-08-28 - international - IT20 - male - 1155281 - Fiji vs Papua New Guinea
2018-08-28 - international - IT20 - male - 1155280 - Samoa vs Vanuatu
2018-08-28 - international - IT20 - male - 1155279 - Vanuatu vs Fiji
2018-08-26 - international - IT20 - male - 1155277 - Papua New Guinea vs Vanuatu
2018-08-26 - international - IT20 - male - 1155276 - Fiji vs Samoa
2018-08-25 - international - IT20 - male - 1155275 - Samoa vs Vanuatu
2018-08-25 - international - IT20 - male - 1155274 - Fiji vs Papua New Guinea
2018-08-25 - international - IT20 - male - 1155273 - Papua New Guinea vs Samoa
2018-08-25 - international - IT20 - male - 1155272 - Fiji vs Vanuatu
2018-07-14 - international - IT20 - male - 1151254 - Kenya vs Uganda
2018-07-14 - international - IT20 - male - 1151253 - Tanzania vs Rwanda
2018-07-13 - international - IT20 - male - 1151252 - Uganda vs Rwanda
2018-07-13 - international - IT20 - male - 1151251 - Kenya vs Tanzania
2018-07-11 - international - IT20 - male - 1151250 - Rwanda vs Kenya
2018-07-11 - international - IT20 - male - 1151249 - Uganda vs Tanzania
2018-07-10 - international - IT20 - male - 1151248 - Uganda vs Rwanda
2018-07-10 - international - IT20 - male - 1151247 - Tanzania vs Kenya
2018-07-08 - international - IT20 - male - 1151246 - Kenya vs Rwanda
2018-07-07 - international - IT20 - male - 1151244 - Tanzania vs Rwanda
2018-07-07 - international - IT20 - male - 1151243 - Uganda vs Kenya
2018-04-27 - international - IT20 - male - 1142224 - Qatar vs United Arab Emirates
2018-04-27 - international - IT20 - male - 1142223 - Kuwait vs Saudi Arabia
2018-04-26 - international - IT20 - male - 1142222 - Saudi Arabia vs Maldives
2018-04-26 - international - IT20 - male - 1142221 - Bahrain vs Qatar
2018-04-26 - international - IT20 - male - 1142220 - United Arab Emirates vs Kuwait
2018-04-24 - international - IT20 - male - 1142219 - Kuwait vs Bahrain
2018-04-24 - international - IT20 - male - 1142218 - Saudi Arabia vs Qatar
2018-04-24 - international - IT20 - male - 1142217 - United Arab Emirates vs Maldives
2018-04-23 - international - IT20 - male - 1142216 - United Arab Emirates vs Bahrain
2018-04-23 - international - IT20 - male - 1142215 - Kuwait vs Saudi Arabia
2018-04-23 - international - IT20 - male - 1142214 - Qatar vs Maldives
2018-04-21 - international - IT20 - male - 1143125 - Gambia vs Sierra Leone
2018-04-21 - international - IT20 - male - 1142213 - Saudi Arabia vs United Arab Emirates
2018-04-21 - international - IT20 - male - 1142212 - Maldives vs Bahrain
2018-04-21 - international - IT20 - male - 1142211 - Qatar vs Kuwait
2018-04-20 - international - IT20 - male - 1142210 - Qatar vs United Arab Emirates
2018-04-20 - international - IT20 - male - 1142209 - Bahrain vs Saudi Arabia
2018-04-20 - international - IT20 - male - 1142208 - Kuwait vs Maldives
2018-04-18 - international - IT20 - male - 1143122 - Nigeria vs Sierra Leone
2018-04-18 - international - IT20 - male - 1143121 - Ghana vs Gambia
2018-04-15 - international - IT20 - male - 1143118 - Ghana vs Sierra Leone
2018-04-14 - international - IT20 - male - 1143115 - Nigeria vs Sierra Leone
2017-01-17 - international - IT20 - male - 1074963 - Ireland vs Namibia
2017-01-15 - international - IT20 - male - 1074960 - United Arab Emirates vs Namibia
2016-11-03 - international - IT20 - male - 1063553 - Japan vs China
2016-09-29 - international - IT20 - male - 1059539 - Kenya vs Qatar
2016-09-28 - international - IT20 - male - 1058157 - Qatar vs Saudi Arabia
2016-09-28 - international - IT20 - male - 1058155 - Kenya vs Uganda
2016-09-27 - international - IT20 - male - 1058153 - Qatar vs Uganda
2016-09-27 - international - IT20 - male - 1058152 - Kenya vs Saudi Arabia
2016-08-17 - international - IT20 - male - 1046687 - Israel vs Spain
2016-08-17 - international - IT20 - male - 1046685 - Gibraltar vs Isle of Man
2016-08-17 - international - IT20 - male - 1046681 - Germany vs Isle of Man
2016-08-17 - international - IT20 - male - 1046679 - Gibraltar vs Israel
2016-02-21 - international - IT20 - male - 973777 - Malaysia vs Singapore
2015-07-23 - international - IT20 - male - 875547 - Namibia vs Oman
2015-07-21 - international - IT20 - male - 875543 - Namibia vs Netherlands
2015-07-19 - international - IT20 - male - 875539 - Hong Kong vs Namibia
2015-07-19 - international - IT20 - male - 875537 - Papua New Guinea vs United States of America
2015-07-19 - international - IT20 - male - 875535 - Ireland vs Jersey
2015-07-18 - international - IT20 - male - 875533 - Kenya vs Netherlands
2015-07-18 - international - IT20 - male - 875531 - Hong Kong vs United States of America
2015-07-18 - international - IT20 - male - 875529 - Namibia vs Papua New Guinea
2015-07-18 - international - IT20 - male - 875525 - Scotland vs Oman
2015-07-18 - international - IT20 - male - 875523 - Jersey vs Nepal
2015-07-17 - international - IT20 - male - 875517 - Canada vs Netherlands
2015-07-17 - international - IT20 - male - 875515 - Jersey vs Namibia
2015-07-16 - international - IT20 - male - 875511 - Scotland vs Canada
2015-07-15 - international - IT20 - male - 875509 - Kenya vs United Arab Emirates
2015-07-15 - international - IT20 - male - 875503 - Jersey vs United States of America
2015-07-14 - international - IT20 - male - 875499 - Kenya vs Scotland
2015-07-14 - international - IT20 - male - 875497 - Canada vs United Arab Emirates
2015-07-14 - international - IT20 - male - 875495 - Netherlands vs Oman
2015-07-12 - international - IT20 - male - 875479 - Papua New Guinea vs Jersey
2015-07-12 - international - IT20 - male - 875477 - Ireland vs United States of America
2015-07-11 - international - IT20 - male - 875475 - Namibia vs Nepal
2015-07-11 - international - IT20 - male - 875473 - Kenya vs Oman
2015-07-11 - international - IT20 - male - 875469 - Hong Kong vs Jersey
2015-07-10 - international - IT20 - male - 875465 - Nepal vs United States of America
2015-07-10 - international - IT20 - male - 875463 - Canada vs Kenya
2015-07-10 - international - IT20 - male - 875461 - Ireland vs Namibia
2015-05-18 - international - IT20 - male - 877507 - Namibia vs Hong Kong
2015-01-30 - international - IT20 - male - 811137 - Malaysia vs Singapore
2015-01-30 - international - IT20 - male - 811135 - Kuwait vs Oman
2015-01-29 - international - IT20 - male - 811129 - Saudi Arabia vs Singapore
2015-01-29 - international - IT20 - male - 811127 - Maldives vs Oman
2015-01-27 - international - IT20 - male - 811125 - Malaysia vs Saudi Arabia
2015-01-27 - international - IT20 - male - 811123 - Oman vs Singapore
2015-01-27 - international - IT20 - male - 811121 - Kuwait vs Maldives
2015-01-26 - international - IT20 - male - 811119 - Malaysia vs Oman
2015-01-26 - international - IT20 - male - 811117 - Kuwait vs Saudi Arabia
2015-01-25 - international - IT20 - male - 811111 - Malaysia vs Maldives
2014-10-03 - international - IT20 - male - 778041 - Bangladesh vs Hong Kong
2014-10-02 - international - IT20 - male - 778039 - Bangladesh vs Sri Lanka
2014-09-30 - international - IT20 - male - 778031 - South Korea vs Sri Lanka
2014-09-30 - international - IT20 - male - 778029 - Hong Kong vs Malaysia
2014-09-29 - international - IT20 - male - 778027 - South Korea vs China
2014-09-28 - international - IT20 - male - 778023 - Maldives vs Nepal
2014-09-28 - international - IT20 - male - 778021 - China vs Malaysia
2014-09-27 - international - IT20 - male - 778019 - Kuwait vs Nepal
2014-09-27 - international - IT20 - male - 778017 - South Korea vs Malaysia
2013-11-30 - international - IT20 - male - 660233 - United Arab Emirates vs Nepal
2013-11-29 - international - IT20 - male - 660231 - United Arab Emirates vs Ireland
2013-11-29 - international - IT20 - male - 660225 - Papua New Guinea vs Scotland
2013-11-28 - international - IT20 - male - 660221 - Italy vs Namibia
2013-11-28 - international - IT20 - male - 660219 - Hong Kong vs Papua New Guinea
2013-11-27 - international - IT20 - male - 660217 - United Arab Emirates vs Netherlands
2013-11-27 - international - IT20 - male - 660215 - Italy vs Scotland
2013-11-27 - international - IT20 - male - 660211 - Hong Kong vs Nepal
2013-11-26 - international - IT20 - male - 660207 - United States of America vs Denmark
2013-11-26 - international - IT20 - male - 660205 - Bermuda vs Uganda
2013-11-24 - international - IT20 - male - 660201 - Bermuda vs Papua New Guinea
2013-11-24 - international - IT20 - male - 660199 - United Arab Emirates vs United States of America
2013-11-24 - international - IT20 - male - 660197 - Hong Kong vs Ireland
2013-11-24 - international - IT20 - male - 660195 - Denmark vs Scotland
2013-11-24 - international - IT20 - male - 660191 - Canada vs Italy
2013-11-23 - international - IT20 - male - 660189 - Bermuda vs Nepal
2013-11-23 - international - IT20 - male - 660187 - United Arab Emirates vs Italy
2013-11-23 - international - IT20 - male - 660183 - Canada vs Namibia
2013-11-22 - international - IT20 - male - 660179 - Hong Kong vs United States of America
2013-11-22 - international - IT20 - male - 660177 - Ireland vs Uganda
2013-11-22 - international - IT20 - male - 660171 - United Arab Emirates vs Canada
2013-11-21 - international - IT20 - male - 660169 - Bermuda vs Kenya
2013-11-21 - international - IT20 - male - 660163 - Scotland vs Papua New Guinea
2013-11-20 - international - IT20 - male - 660159 - Netherlands vs Nepal
2013-11-20 - international - IT20 - male - 660157 - Hong Kong vs Namibia
2013-11-20 - international - IT20 - male - 660153 - Ireland vs United States of America
2013-11-19 - international - IT20 - male - 660151 - Nepal vs Papua New Guinea
2013-11-19 - international - IT20 - male - 660147 - Canada vs Uganda
2013-11-19 - international - IT20 - male - 660145 - United Arab Emirates vs Hong Kong
2013-11-19 - international - IT20 - male - 660143 - Denmark vs Netherlands
2013-11-19 - international - IT20 - male - 660141 - Italy vs Namibia
2013-11-18 - international - IT20 - male - 660139 - Nepal vs Scotland
2013-11-18 - international - IT20 - male - 660137 - Hong Kong vs Canada
2013-11-18 - international - IT20 - male - 660135 - Denmark vs Kenya
2013-11-18 - international - IT20 - male - 660133 - Italy vs Uganda
2013-11-17 - international - IT20 - male - 660127 - Ireland vs United Arab Emirates
2013-11-17 - international - IT20 - male - 660125 - Namibia vs United States of America
2013-11-16 - international - IT20 - male - 660121 - Kenya vs Nepal
2013-11-16 - international - IT20 - male - 660117 - United States of America vs Italy
2013-11-16 - international - IT20 - male - 660115 - Uganda vs Hong Kong
2013-11-16 - international - IT20 - male - 660111 - Denmark vs Bermuda
2013-11-16 - international - IT20 - male - 660109 - Namibia vs United Arab Emirates
2013-11-15 - international - IT20 - male - 660105 - Kenya vs Papua New Guinea
2013-11-15 - international - IT20 - male - 660103 - Italy vs Hong Kong
2013-11-15 - international - IT20 - male - 660099 - Bermuda vs Scotland
2013-11-15 - international - IT20 - male - 660097 - Denmark vs Nepal
2013-11-15 - international - IT20 - male - 660095 - Uganda vs United Arab Emirates
2013-11-15 - international - IT20 - male - 660093 - Ireland vs Namibia
2010-06-06 - international - IT20 - male - 460064 - Canada vs United States of America
2010-06-06 - international - IT20 - male - 460060 - Bermuda vs United States of America
2010-06-05 - international - IT20 - male - 460058 - Bermuda vs Bahamas
2010-06-05 - international - IT20 - male - 460056 - Cayman Islands vs Bermuda
2010-06-04 - international - IT20 - male - 460054 - Argentina vs United States of America

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
