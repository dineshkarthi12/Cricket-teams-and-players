This zip archive contains data files from Cricsheet in JSON format. This
archive contains 37 Argentina matches of all types.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/argentina_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-03-15 - international - T20 - male - 1525177 - Argentina vs Cayman Islands
2026-03-14 - international - T20 - male - 1525174 - Argentina vs Mexico
2026-03-12 - international - T20 - male - 1525173 - Suriname vs Argentina
2026-03-11 - international - T20 - male - 1525171 - Argentina vs Mexico
2026-03-09 - international - T20 - male - 1525168 - Argentina vs Suriname
2026-03-08 - international - T20 - male - 1525166 - Argentina vs Cayman Islands
2025-11-30 - international - T20 - male - 1511997 - Argentina vs Brazil
2025-11-30 - international - T20 - male - 1511996 - Argentina vs Brazil
2025-11-29 - international - T20 - male - 1511994 - Brazil vs Argentina
2025-11-28 - international - T20 - male - 1511993 - Brazil vs Argentina
2024-12-16 - international - T20 - male - 1462911 - Argentina vs Brazil
2024-12-15 - international - T20 - male - 1462905 - Cayman Islands vs Argentina
2024-12-14 - international - T20 - male - 1462903 - Argentina vs Mexico
2024-12-11 - international - T20 - male - 1462895 - Suriname vs Argentina
2024-12-10 - international - T20 - male - 1462891 - Panama vs Argentina
2024-12-08 - international - T20 - male - 1462885 - Bahamas vs Argentina
2024-12-07 - international - T20 - male - 1462881 - Argentina vs Belize
2024-12-02 - international - T20 - male - 1462926 - Bermuda vs Argentina
2024-10-13 - international - T20 - male - 1453909 - Mexico vs Argentina
2023-10-20 - international - T20 - male - 1403305 - Chile vs Argentina
2023-10-19 - international - T20 - male - 1403301 - Mexico vs Argentina
2023-03-04 - international - T20 - male - 1359802 - Argentina vs Cayman Islands
2023-03-02 - international - T20 - male - 1359798 - Argentina vs Bahamas
2023-02-26 - international - T20 - male - 1359793 - Bermuda vs Argentina
2023-02-25 - international - T20 - male - 1359794 - Panama vs Argentina
2023-02-22 - international - T20 - male - 1359787 - Bermuda vs Argentina
2023-02-21 - international - T20 - male - 1359786 - Argentina vs Bermuda
2021-11-13 - international - T20 - male - 1286685 - Argentina vs Canada
2021-11-11 - international - T20 - male - 1286681 - Argentina vs United States of America
2021-11-10 - international - T20 - male - 1286675 - Argentina vs Belize
2021-11-08 - international - T20 - male - 1286671 - Bahamas vs Argentina
2010-08-21 - international - ODM - male - 467095 - Argentina vs Cayman Islands
2010-08-20 - international - ODM - male - 467090 - Argentina vs United States of America
2010-08-18 - international - ODM - male - 467089 - Argentina vs Nepal
2010-08-17 - international - ODM - male - 467084 - Italy vs Argentina
2010-08-14 - international - ODM - male - 467080 - Argentina vs Tanzania
2010-06-04 - international - IT20 - male - 460054 - Argentina vs United States of America
