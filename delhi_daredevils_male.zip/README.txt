This zip archive contains data files from Cricsheet in YAML format. This
archive contains 161 Delhi Daredevils matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/delhi_daredevils_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2018-05-20 - club - IPL - male - 1136615 - Delhi Daredevils vs Mumbai Indians
2018-05-18 - club - IPL - male - 1136612 - Delhi Daredevils vs Chennai Super Kings
2018-05-12 - club - IPL - male - 1136605 - Delhi Daredevils vs Royal Challengers Bangalore
2018-05-10 - club - IPL - male - 1136602 - Delhi Daredevils vs Sunrisers Hyderabad
2018-05-05 - club - IPL - male - 1136596 - Sunrisers Hyderabad vs Delhi Daredevils
2018-05-02 - club - IPL - male - 1136592 - Delhi Daredevils vs Rajasthan Royals
2018-04-30 - club - IPL - male - 1136590 - Chennai Super Kings vs Delhi Daredevils
2018-04-27 - club - IPL - male - 1136586 - Delhi Daredevils vs Kolkata Knight Riders
2018-04-23 - club - IPL - male - 1136582 - Delhi Daredevils vs Kings XI Punjab
2018-04-21 - club - IPL - male - 1136579 - Royal Challengers Bangalore vs Delhi Daredevils
2018-04-16 - club - IPL - male - 1136573 - Kolkata Knight Riders vs Delhi Daredevils
2018-04-14 - club - IPL - male - 1136569 - Mumbai Indians vs Delhi Daredevils
2018-04-11 - club - IPL - male - 1136566 - Rajasthan Royals vs Delhi Daredevils
2018-04-08 - club - IPL - male - 1136562 - Kings XI Punjab vs Delhi Daredevils
2017-05-14 - club - IPL - male - 1082646 - Delhi Daredevils vs Royal Challengers Bangalore
2017-05-12 - club - IPL - male - 1082642 - Delhi Daredevils vs Rising Pune Supergiant
2017-05-10 - club - IPL - male - 1082640 - Gujarat Lions vs Delhi Daredevils
2017-05-06 - club - IPL - male - 1082635 - Delhi Daredevils vs Mumbai Indians
2017-05-04 - club - IPL - male - 1082632 - Delhi Daredevils vs Gujarat Lions
2017-05-02 - club - IPL - male - 1082630 - Delhi Daredevils vs Sunrisers Hyderabad
2017-04-30 - club - IPL - male - 1082626 - Kings XI Punjab vs Delhi Daredevils
2017-04-28 - club - IPL - male - 1082622 - Kolkata Knight Riders vs Delhi Daredevils
2017-04-22 - club - IPL - male - 1082614 - Mumbai Indians vs Delhi Daredevils
2017-04-19 - club - IPL - male - 1082611 - Sunrisers Hyderabad vs Delhi Daredevils
2017-04-17 - club - IPL - male - 1082608 - Delhi Daredevils vs Kolkata Knight Riders
2017-04-15 - club - IPL - male - 1082605 - Delhi Daredevils vs Kings XI Punjab
2017-04-11 - club - IPL - male - 1082599 - Rising Pune Supergiant vs Delhi Daredevils
2017-04-08 - club - IPL - male - 1082595 - Royal Challengers Bangalore vs Delhi Daredevils
2016-05-22 - club - IPL - male - 981011 - Delhi Daredevils vs Royal Challengers Bangalore
2016-05-20 - club - IPL - male - 981003 - Delhi Daredevils vs Sunrisers Hyderabad
2016-05-17 - club - IPL - male - 980997 - Rising Pune Supergiants vs Delhi Daredevils
2016-05-15 - club - IPL - male - 980993 - Mumbai Indians vs Delhi Daredevils
2016-05-12 - club - IPL - male - 980983 - Sunrisers Hyderabad vs Delhi Daredevils
2016-05-07 - club - IPL - male - 980971 - Kings XI Punjab vs Delhi Daredevils
2016-05-05 - club - IPL - male - 980965 - Delhi Daredevils vs Rising Pune Supergiants
2016-05-03 - club - IPL - male - 980961 - Gujarat Lions vs Delhi Daredevils
2016-04-30 - club - IPL - male - 980951 - Delhi Daredevils vs Kolkata Knight Riders
2016-04-27 - club - IPL - male - 980945 - Delhi Daredevils vs Gujarat Lions
2016-04-23 - club - IPL - male - 980933 - Delhi Daredevils vs Mumbai Indians
2016-04-17 - club - IPL - male - 980921 - Royal Challengers Bangalore vs Delhi Daredevils
2016-04-15 - club - IPL - male - 980913 - Delhi Daredevils vs Kings XI Punjab
2016-04-10 - club - IPL - male - 980903 - Kolkata Knight Riders vs Delhi Daredevils
2015-05-17 - club - IPL - male - 829813 - Royal Challengers Bangalore vs Delhi Daredevils
2015-05-12 - club - IPL - male - 829801 - Delhi Daredevils vs Chennai Super Kings
2015-05-09 - club - IPL - male - 829793 - Delhi Daredevils vs Sunrisers Hyderabad
2015-05-07 - club - IPL - male - 829761 - Kolkata Knight Riders vs Delhi Daredevils
2015-05-05 - club - IPL - male - 829783 - Mumbai Indians vs Delhi Daredevils
2015-05-03 - club - IPL - male - 829777 - Rajasthan Royals vs Delhi Daredevils
2015-05-01 - club - IPL - male - 829767 - Delhi Daredevils vs Kings XI Punjab
2015-04-26 - club - IPL - male - 829757 - Delhi Daredevils vs Royal Challengers Bangalore
2015-04-23 - club - IPL - male - 829747 - Delhi Daredevils vs Mumbai Indians
2015-04-20 - club - IPL - male - 829739 - Delhi Daredevils vs Kolkata Knight Riders
2015-04-18 - club - IPL - male - 829731 - Sunrisers Hyderabad vs Delhi Daredevils
2015-04-15 - club - IPL - male - 829725 - Kings XI Punjab vs Delhi Daredevils
2015-04-12 - club - IPL - male - 829715 - Delhi Daredevils vs Rajasthan Royals
2015-04-09 - club - IPL - male - 829707 - Chennai Super Kings vs Delhi Daredevils
2014-05-25 - club - IPL - male - 734039 - Kings XI Punjab vs Delhi Daredevils
2014-05-23 - club - IPL - male - 734031 - Mumbai Indians vs Delhi Daredevils
2014-05-19 - club - IPL - male - 734019 - Delhi Daredevils vs Kings XI Punjab
2014-05-15 - club - IPL - male - 734011 - Rajasthan Royals vs Delhi Daredevils
2014-05-13 - club - IPL - male - 734005 - Royal Challengers Bangalore vs Delhi Daredevils
2014-05-10 - club - IPL - male - 733993 - Delhi Daredevils vs Sunrisers Hyderabad
2014-05-07 - club - IPL - male - 733985 - Delhi Daredevils vs Kolkata Knight Riders
2014-05-05 - club - IPL - male - 733981 - Delhi Daredevils vs Chennai Super Kings
2014-05-03 - club - IPL - male - 733975 - Delhi Daredevils vs Rajasthan Royals
2014-04-27 - club - IPL - male - 729309 - Delhi Daredevils vs Mumbai Indians
2014-04-25 - club - IPL - male - 729301 - Sunrisers Hyderabad vs Delhi Daredevils
2014-04-21 - club - IPL - male - 729293 - Chennai Super Kings vs Delhi Daredevils
2014-04-19 - club - IPL - male - 729289 - Kolkata Knight Riders vs Delhi Daredevils
2014-04-17 - club - IPL - male - 729281 - Delhi Daredevils vs Royal Challengers Bangalore
2013-05-19 - club - IPL - male - 598067 - Pune Warriors vs Delhi Daredevils
2013-05-16 - club - IPL - male - 598028 - Kings XI Punjab vs Delhi Daredevils
2013-05-14 - club - IPL - male - 598062 - Chennai Super Kings vs Delhi Daredevils
2013-05-10 - club - IPL - male - 598054 - Delhi Daredevils vs Royal Challengers Bangalore
2013-05-07 - club - IPL - male - 598049 - Rajasthan Royals vs Delhi Daredevils
2013-05-04 - club - IPL - male - 598044 - Sunrisers Hyderabad vs Delhi Daredevils
2013-05-01 - club - IPL - male - 598040 - Delhi Daredevils vs Kolkata Knight Riders
2013-04-28 - club - IPL - male - 598035 - Delhi Daredevils vs Pune Warriors
2013-04-23 - club - IPL - male - 598059 - Delhi Daredevils vs Kings XI Punjab
2013-04-21 - club - IPL - male - 598024 - Delhi Daredevils vs Mumbai Indians
2013-04-18 - club - IPL - male - 598020 - Delhi Daredevils vs Chennai Super Kings
2013-04-16 - club - IPL - male - 598017 - Royal Challengers Bangalore vs Delhi Daredevils
2013-04-12 - club - IPL - male - 598010 - Delhi Daredevils vs Sunrisers Hyderabad
2013-04-09 - club - IPL - male - 598006 - Mumbai Indians vs Delhi Daredevils
2013-04-06 - club - IPL - male - 598001 - Delhi Daredevils vs Rajasthan Royals
2013-04-03 - club - IPL - male - 597998 - Kolkata Knight Riders vs Delhi Daredevils
2012-05-25 - club - IPL - male - 548380 - Delhi Daredevils vs Chennai Super Kings
2012-05-22 - club - IPL - male - 548378 - Delhi Daredevils vs Kolkata Knight Riders
2012-05-19 - club - IPL - male - 548374 - Kings XI Punjab vs Delhi Daredevils
2012-05-17 - club - IPL - male - 548372 - Delhi Daredevils vs Royal Challengers Bangalore
2012-05-15 - club - IPL - male - 548369 - Delhi Daredevils vs Kings XI Punjab
2012-05-12 - club - IPL - male - 548364 - Chennai Super Kings vs Delhi Daredevils
2012-05-10 - club - IPL - male - 548329 - Deccan Chargers vs Delhi Daredevils
2012-05-07 - club - IPL - male - 548357 - Delhi Daredevils vs Kolkata Knight Riders
2012-05-01 - club - IPL - male - 548349 - Rajasthan Royals vs Delhi Daredevils
2012-04-29 - club - IPL - male - 548345 - Delhi Daredevils vs Rajasthan Royals
2012-04-27 - club - IPL - male - 548342 - Delhi Daredevils vs Mumbai Indians
2012-04-24 - club - IPL - male - 548337 - Pune Warriors vs Delhi Daredevils
2012-04-21 - club - IPL - male - 548333 - Delhi Daredevils vs Pune Warriors
2012-04-19 - club - IPL - male - 548321 - Delhi Daredevils vs Deccan Chargers
2012-04-16 - club - IPL - male - 548325 - Mumbai Indians vs Delhi Daredevils
2012-04-10 - club - IPL - male - 548316 - Delhi Daredevils vs Chennai Super Kings
2012-04-07 - club - IPL - male - 548310 - Royal Challengers Bangalore vs Delhi Daredevils
2012-04-05 - club - IPL - male - 548307 - Kolkata Knight Riders vs Delhi Daredevils
2011-05-21 - club - IPL - male - 501265 - Delhi Daredevils vs Pune Warriors
2011-05-15 - club - IPL - male - 501257 - Kings XI Punjab vs Delhi Daredevils
2011-05-12 - club - IPL - male - 501253 - Chennai Super Kings vs Delhi Daredevils
2011-05-07 - club - IPL - male - 501246 - Mumbai Indians vs Delhi Daredevils
2011-05-05 - club - IPL - male - 501243 - Deccan Chargers vs Delhi Daredevils
2011-05-02 - club - IPL - male - 501238 - Delhi Daredevils vs Kochi Tuskers Kerala
2011-04-30 - club - IPL - male - 501233 - Kochi Tuskers Kerala vs Delhi Daredevils
2011-04-28 - club - IPL - male - 501230 - Delhi Daredevils vs Kolkata Knight Riders
2011-04-26 - club - IPL - male - 501227 - Delhi Daredevils vs Royal Challengers Bangalore
2011-04-23 - club - IPL - male - 501223 - Delhi Daredevils vs Kings XI Punjab
2011-04-19 - club - IPL - male - 501216 - Delhi Daredevils vs Deccan Chargers
2011-04-17 - club - IPL - male - 501213 - Pune Warriors vs Delhi Daredevils
2011-04-12 - club - IPL - male - 501204 - Rajasthan Royals vs Delhi Daredevils
2011-04-10 - club - IPL - male - 501201 - Delhi Daredevils vs Mumbai Indians
2010-04-18 - club - IPL - male - 419160 - Delhi Daredevils vs Deccan Chargers
2010-04-15 - club - IPL - male - 419155 - Chennai Super Kings vs Delhi Daredevils
2010-04-13 - club - IPL - male - 419152 - Mumbai Indians vs Delhi Daredevils
2010-04-11 - club - IPL - male - 419149 - Delhi Daredevils vs Kings XI Punjab
2010-04-07 - club - IPL - male - 419144 - Kolkata Knight Riders vs Delhi Daredevils
2010-04-04 - club - IPL - male - 419140 - Delhi Daredevils vs Royal Challengers Bangalore
2010-03-31 - club - IPL - male - 419134 - Delhi Daredevils vs Rajasthan Royals
2010-03-29 - club - IPL - male - 419131 - Delhi Daredevils vs Kolkata Knight Riders
2010-03-25 - club - IPL - male - 419128 - Royal Challengers Bangalore vs Delhi Daredevils
2010-03-21 - club - IPL - male - 419120 - Deccan Chargers vs Delhi Daredevils
2010-03-19 - club - IPL - male - 419116 - Delhi Daredevils vs Chennai Super Kings
2010-03-17 - club - IPL - male - 419114 - Delhi Daredevils vs Mumbai Indians
2010-03-15 - club - IPL - male - 419111 - Rajasthan Royals vs Delhi Daredevils
2010-03-13 - club - IPL - male - 419108 - Kings XI Punjab vs Delhi Daredevils
2009-05-22 - club - IPL - male - 392237 - Delhi Daredevils vs Deccan Chargers
2009-05-21 - club - IPL - male - 392235 - Delhi Daredevils vs Mumbai Indians
2009-05-19 - club - IPL - male - 392232 - Royal Challengers Bangalore vs Delhi Daredevils
2009-05-17 - club - IPL - male - 392230 - Delhi Daredevils vs Rajasthan Royals
2009-05-15 - club - IPL - male - 392226 - Delhi Daredevils vs Kings XI Punjab
2009-05-13 - club - IPL - male - 392223 - Deccan Chargers vs Delhi Daredevils
2009-05-10 - club - IPL - male - 392219 - Delhi Daredevils vs Kolkata Knight Riders
2009-05-08 - club - IPL - male - 392215 - Delhi Daredevils vs Mumbai Indians
2009-05-05 - club - IPL - male - 392211 - Delhi Daredevils vs Kolkata Knight Riders
2009-05-02 - club - IPL - male - 392206 - Chennai Super Kings vs Delhi Daredevils
2009-04-30 - club - IPL - male - 392201 - Deccan Chargers vs Delhi Daredevils
2009-04-28 - club - IPL - male - 392198 - Delhi Daredevils vs Rajasthan Royals
2009-04-26 - club - IPL - male - 392194 - Royal Challengers Bangalore vs Delhi Daredevils
2009-04-23 - club - IPL - male - 392189 - Chennai Super Kings vs Delhi Daredevils
2009-04-19 - club - IPL - male - 392183 - Delhi Daredevils vs Kings XI Punjab
2008-05-30 - club - IPL - male - 336038 - Delhi Daredevils vs Rajasthan Royals
2008-05-24 - club - IPL - male - 336032 - Delhi Daredevils vs Mumbai Indians
2008-05-19 - club - IPL - male - 336026 - Royal Challengers Bangalore vs Delhi Daredevils
2008-05-17 - club - IPL - male - 336022 - Delhi Daredevils vs Kings XI Punjab
2008-05-15 - club - IPL - male - 336020 - Delhi Daredevils vs Deccan Chargers
2008-05-13 - club - IPL - male - 336017 - Kolkata Knight Riders vs Delhi Daredevils
2008-05-11 - club - IPL - male - 336015 - Rajasthan Royals vs Delhi Daredevils
2008-05-08 - club - IPL - male - 336009 - Delhi Daredevils vs Chennai Super Kings
2008-05-04 - club - IPL - male - 336004 - Mumbai Indians vs Delhi Daredevils
2008-05-02 - club - IPL - male - 336001 - Chennai Super Kings vs Delhi Daredevils
2008-04-30 - club - IPL - male - 335998 - Delhi Daredevils vs Royal Challengers Bangalore
2008-04-27 - club - IPL - male - 335995 - Kings XI Punjab vs Delhi Daredevils
2008-04-22 - club - IPL - male - 335988 - Deccan Chargers vs Delhi Daredevils
2008-04-19 - club - IPL - male - 335984 - Delhi Daredevils vs Rajasthan Royals
