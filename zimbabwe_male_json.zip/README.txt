This zip archive contains data files from Cricsheet in JSON format. This
archive contains 515 Zimbabwe matches of all types. A further 54 matches have
been withheld due to either featuring the Afghanistan men's team or being
played in the Afghanistan Premier League, due to the Cricsheet policy to no
longer feature matches involving Afghanistan men or played in Afghanistan
Premier League (see https://cricsheet.org/withheld-matches for more
information).


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/zimbabwe_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-09-15 - international - ODI - male - 1530203 - Australia vs Zimbabwe
2026-09-06 - international - T20 - male - 1549530 - South Africa vs Zimbabwe
2026-09-03 - international - T20 - male - 1549528 - Namibia vs Zimbabwe
2026-09-01 - international - T20 - male - 1549527 - South Africa vs Zimbabwe
2026-08-31 - international - T20 - male - 1549526 - Zimbabwe vs Namibia
2026-08-29 - international - T20 - male - 1549525 - Zimbabwe vs South Africa
2026-07-26 - international - T20 - male - 1530062 - India vs Zimbabwe
2026-07-25 - international - T20 - male - 1530061 - India vs Zimbabwe
2026-07-23 - international - T20 - male - 1530060 - Zimbabwe vs India
2026-07-19 - international - T20 - male - 1538303 - Zimbabwe vs Bangladesh
2026-07-17 - international - T20 - male - 1538302 - Bangladesh vs Zimbabwe
2026-07-15 - international - T20 - male - 1538301 - Zimbabwe vs Bangladesh
2026-07-11 - international - ODI - male - 1538300 - Zimbabwe vs Bangladesh
2026-07-09 - international - ODI - male - 1538299 - Zimbabwe vs Bangladesh
2026-07-06 - international - ODI - male - 1538298 - Zimbabwe vs Bangladesh
2026-06-28 - international - Test - male - 1538297 - Bangladesh vs Zimbabwe
2026-03-01 - international - T20 - male - 1512769 - Zimbabwe vs South Africa
2026-02-26 - international - T20 - male - 1512766 - India vs Zimbabwe
2026-02-23 - international - T20 - male - 1512762 - West Indies vs Zimbabwe
2026-02-19 - international - T20 - male - 1512756 - Sri Lanka vs Zimbabwe
2026-02-13 - international - T20 - male - 1512737 - Zimbabwe vs Australia
2026-02-09 - international - T20 - male - 1512726 - Oman vs Zimbabwe
2025-11-25 - international - T20 - male - 1502052 - Zimbabwe vs Sri Lanka
2025-11-23 - international - T20 - male - 1502051 - Pakistan vs Zimbabwe
2025-11-20 - international - T20 - male - 1502049 - Zimbabwe vs Sri Lanka
2025-11-18 - international - T20 - male - 1502048 - Zimbabwe vs Pakistan
2025-10-04 - international - T20 - male - 1502762 - Namibia vs Zimbabwe
2025-10-02 - international - T20 - male - 1502757 - Kenya vs Zimbabwe
2025-09-30 - international - T20 - male - 1502751 - Zimbabwe vs Tanzania
2025-09-28 - international - T20 - male - 1502749 - Zimbabwe vs Botswana
2025-09-26 - international - T20 - male - 1502745 - Uganda vs Zimbabwe
2025-09-18 - international - T20 - male - 1502166 - Namibia vs Zimbabwe
2025-09-16 - international - T20 - male - 1502165 - Namibia vs Zimbabwe
2025-09-15 - international - T20 - male - 1502164 - Zimbabwe vs Namibia
2025-09-07 - international - T20 - male - 1492825 - Zimbabwe vs Sri Lanka
2025-09-06 - international - T20 - male - 1492824 - Sri Lanka vs Zimbabwe
2025-09-03 - international - T20 - male - 1492823 - Zimbabwe vs Sri Lanka
2025-08-31 - international - ODI - male - 1492822 - Zimbabwe vs Sri Lanka
2025-08-29 - international - ODI - male - 1492821 - Sri Lanka vs Zimbabwe
2025-08-07 - international - Test - male - 1478873 - Zimbabwe vs New Zealand
2025-07-30 - international - Test - male - 1478872 - Zimbabwe vs New Zealand
2025-07-24 - international - T20 - male - 1478870 - New Zealand vs Zimbabwe
2025-07-20 - international - T20 - male - 1478868 - Zimbabwe vs South Africa
2025-07-18 - international - T20 - male - 1478867 - Zimbabwe vs New Zealand
2025-07-14 - international - T20 - male - 1478865 - Zimbabwe vs South Africa
2025-07-06 - international - Test - male - 1478864 - South Africa vs Zimbabwe
2025-06-28 - international - Test - male - 1478863 - South Africa vs Zimbabwe
2025-05-22 - international - Test - male - 1392691 - England vs Zimbabwe
2025-04-28 - international - Test - male - 1476410 - Zimbabwe vs Bangladesh
2025-04-20 - international - Test - male - 1476409 - Bangladesh vs Zimbabwe
2025-02-25 - international - T20 - male - 1467706 - Zimbabwe vs Ireland
2025-02-23 - international - T20 - male - 1467705 - Ireland vs Zimbabwe
2025-02-22 - international - T20 - male - 1467704 - Zimbabwe vs Ireland
2025-02-18 - international - ODI - male - 1467703 - Ireland vs Zimbabwe
2025-02-16 - international - ODI - male - 1467702 - Zimbabwe vs Ireland
2025-02-14 - international - ODI - male - 1467701 - Zimbabwe vs Ireland
2025-02-06 - international - Test - male - 1467700 - Ireland vs Zimbabwe
2024-12-05 - international - T20 - male - 1444654 - Pakistan vs Zimbabwe
2024-12-03 - international - T20 - male - 1444653 - Zimbabwe vs Pakistan
2024-12-01 - international - T20 - male - 1444652 - Pakistan vs Zimbabwe
2024-11-28 - international - ODI - male - 1444651 - Pakistan vs Zimbabwe
2024-11-26 - international - ODI - male - 1444650 - Zimbabwe vs Pakistan
2024-11-24 - international - ODI - male - 1444649 - Zimbabwe vs Pakistan
2024-10-24 - international - T20 - male - 1453925 - Zimbabwe vs Kenya
2024-10-23 - international - T20 - male - 1453932 - Zimbabwe vs Gambia
2024-10-22 - international - T20 - male - 1453935 - Zimbabwe vs Rwanda
2024-10-20 - international - T20 - male - 1453927 - Mozambique vs Zimbabwe
2024-10-19 - international - T20 - male - 1453922 - Zimbabwe vs Seychelles
2024-07-25 - international - Test - male - 1431085 - Zimbabwe vs Ireland
2024-07-14 - international - T20 - male - 1420227 - India vs Zimbabwe
2024-07-13 - international - T20 - male - 1420226 - Zimbabwe vs India
2024-07-10 - international - T20 - male - 1420225 - India vs Zimbabwe
2024-07-07 - international - T20 - male - 1420224 - India vs Zimbabwe
2024-07-06 - international - T20 - male - 1420223 - Zimbabwe vs India
2024-05-12 - international - T20 - male - 1425130 - Bangladesh vs Zimbabwe
2024-05-10 - international - T20 - male - 1425129 - Bangladesh vs Zimbabwe
2024-05-07 - international - T20 - male - 1425128 - Bangladesh vs Zimbabwe
2024-05-05 - international - T20 - male - 1425127 - Zimbabwe vs Bangladesh
2024-05-03 - international - T20 - male - 1425126 - Zimbabwe vs Bangladesh
2024-03-23 - international - T20 - male - 1424767 - Namibia vs Zimbabwe
2024-03-21 - international - T20 - male - 1424765 - Zimbabwe vs Kenya
2024-03-20 - international - T20 - male - 1424762 - Nigeria vs Zimbabwe
2024-03-18 - international - T20 - male - 1424756 - Tanzania vs Zimbabwe
2024-03-17 - international - T20 - male - 1424752 - Zimbabwe vs Namibia
2024-01-18 - international - T20 - male - 1412544 - Zimbabwe vs Sri Lanka
2024-01-16 - international - T20 - male - 1412543 - Sri Lanka vs Zimbabwe
2024-01-14 - international - T20 - male - 1412542 - Zimbabwe vs Sri Lanka
2024-01-11 - international - ODI - male - 1412541 - Zimbabwe vs Sri Lanka
2024-01-08 - international - ODI - male - 1412540 - Zimbabwe vs Sri Lanka
2024-01-06 - international - ODI - male - 1412539 - Sri Lanka vs Zimbabwe
2023-12-17 - international - ODI - male - 1408108 - Zimbabwe vs Ireland
2023-12-15 - international - ODI - male - 1408107 - Zimbabwe vs Ireland
2023-12-13 - international - ODI - male - 1408106 - Zimbabwe vs Ireland
2023-12-10 - international - T20 - male - 1408105 - Zimbabwe vs Ireland
2023-12-09 - international - T20 - male - 1408104 - Zimbabwe vs Ireland
2023-12-07 - international - T20 - male - 1408103 - Ireland vs Zimbabwe
2023-11-30 - international - T20 - male - 1407107 - Zimbabwe vs Kenya
2023-11-29 - international - T20 - male - 1407104 - Nigeria vs Zimbabwe
2023-11-27 - international - T20 - male - 1407101 - Zimbabwe vs Rwanda
2023-11-26 - international - T20 - male - 1407099 - Zimbabwe vs Uganda
2023-11-23 - international - T20 - male - 1407093 - Tanzania vs Zimbabwe
2023-11-22 - international - T20 - male - 1407091 - Zimbabwe vs Namibia
2023-10-30 - international - T20 - male - 1404394 - Namibia vs Zimbabwe
2023-10-29 - international - T20 - male - 1404393 - Zimbabwe vs Namibia
2023-10-27 - international - T20 - male - 1404392 - Namibia vs Zimbabwe
2023-10-25 - international - T20 - male - 1404391 - Namibia vs Zimbabwe
2023-10-24 - international - T20 - male - 1404390 - Zimbabwe vs Namibia
2023-07-04 - international - ODI - male - 1377773 - Scotland vs Zimbabwe
2023-07-02 - international - ODI - male - 1377770 - Zimbabwe vs Sri Lanka
2023-06-29 - international - ODI - male - 1377766 - Zimbabwe vs Oman
2023-06-26 - international - ODI - male - 1377762 - Zimbabwe vs United States of America
2023-06-24 - international - ODI - male - 1377758 - Zimbabwe vs West Indies
2023-06-20 - international - ODI - male - 1377750 - Netherlands vs Zimbabwe
2023-06-18 - international - ODI - male - 1377746 - Nepal vs Zimbabwe
2023-03-25 - international - ODI - male - 1362381 - Netherlands vs Zimbabwe
2023-03-23 - international - ODI - male - 1362380 - Zimbabwe vs Netherlands
2023-03-21 - international - ODI - male - 1362379 - Zimbabwe vs Netherlands
2023-02-12 - international - Test - male - 1350682 - Zimbabwe vs West Indies
2023-02-04 - international - Test - male - 1350681 - West Indies vs Zimbabwe
2023-01-23 - international - ODI - male - 1348328 - Zimbabwe vs Ireland
2023-01-21 - international - ODI - male - 1348327 - Ireland vs Zimbabwe
2023-01-18 - international - ODI - male - 1348326 - Ireland vs Zimbabwe
2023-01-15 - international - T20 - male - 1348325 - Ireland vs Zimbabwe
2023-01-14 - international - T20 - male - 1348324 - Zimbabwe vs Ireland
2023-01-12 - international - T20 - male - 1348323 - Ireland vs Zimbabwe
2022-11-06 - international - T20 - male - 1298176 - India vs Zimbabwe
2022-11-02 - international - T20 - male - 1298168 - Zimbabwe vs Netherlands
2022-10-30 - international - T20 - male - 1298162 - Bangladesh vs Zimbabwe
2022-10-27 - international - T20 - male - 1298158 - Zimbabwe vs Pakistan
2022-10-24 - international - T20 - male - 1298152 - Zimbabwe vs South Africa
2022-10-21 - international - T20 - male - 1298146 - Scotland vs Zimbabwe
2022-10-19 - international - T20 - male - 1298142 - West Indies vs Zimbabwe
2022-10-17 - international - T20 - male - 1298138 - Zimbabwe vs Ireland
2022-09-03 - international - ODI - male - 1317478 - Australia vs Zimbabwe
2022-08-31 - international - ODI - male - 1317477 - Zimbabwe vs Australia
2022-08-28 - international - ODI - male - 1317476 - Zimbabwe vs Australia
2022-08-22 - international - ODI - male - 1325551 - India vs Zimbabwe
2022-08-20 - international - ODI - male - 1325550 - Zimbabwe vs India
2022-08-18 - international - ODI - male - 1325549 - Zimbabwe vs India
2022-08-10 - international - ODI - male - 1323294 - Bangladesh vs Zimbabwe
2022-08-07 - international - ODI - male - 1323293 - Bangladesh vs Zimbabwe
2022-08-05 - international - ODI - male - 1323292 - Bangladesh vs Zimbabwe
2022-08-02 - international - T20 - male - 1323297 - Zimbabwe vs Bangladesh
2022-07-31 - international - T20 - male - 1323296 - Zimbabwe vs Bangladesh
2022-07-30 - international - T20 - male - 1323295 - Zimbabwe vs Bangladesh
2022-07-17 - international - T20 - male - 1321484 - Zimbabwe vs Netherlands
2022-07-15 - international - T20 - male - 1321479 - Zimbabwe vs Papua New Guinea
2022-07-14 - international - T20 - male - 1321475 - Zimbabwe vs United States of America
2022-07-12 - international - T20 - male - 1321469 - Zimbabwe vs Jersey
2022-07-11 - international - T20 - male - 1321465 - Zimbabwe vs Singapore
2022-05-24 - international - T20 - male - 1310942 - Namibia vs Zimbabwe
2022-05-22 - international - T20 - male - 1310941 - Zimbabwe vs Namibia
2022-05-21 - international - T20 - male - 1310940 - Namibia vs Zimbabwe
2022-05-19 - international - T20 - male - 1310939 - Zimbabwe vs Namibia
2022-05-17 - international - T20 - male - 1310938 - Zimbabwe vs Namibia
2022-01-21 - international - ODI - male - 1294971 - Sri Lanka vs Zimbabwe
2022-01-18 - international - ODI - male - 1294970 - Zimbabwe vs Sri Lanka
2022-01-16 - international - ODI - male - 1294969 - Zimbabwe vs Sri Lanka
2021-09-19 - international - T20 - male - 1273273 - Scotland vs Zimbabwe
2021-09-17 - international - T20 - male - 1273272 - Zimbabwe vs Scotland
2021-09-15 - international - T20 - male - 1273271 - Scotland vs Zimbabwe
2021-09-13 - international - ODI - male - 1272381 - Zimbabwe vs Ireland
2021-09-10 - international - ODI - male - 1272380 - Ireland vs Zimbabwe
2021-09-08 - international - ODI - male - 1272379 - Zimbabwe vs Ireland
2021-09-04 - international - T20 - male - 1272377 - Zimbabwe vs Ireland
2021-09-02 - international - T20 - male - 1272376 - Ireland vs Zimbabwe
2021-09-01 - international - T20 - male - 1272375 - Ireland vs Zimbabwe
2021-08-29 - international - T20 - male - 1272374 - Zimbabwe vs Ireland
2021-08-27 - international - T20 - male - 1272373 - Zimbabwe vs Ireland
2021-07-25 - international - T20 - male - 1267682 - Zimbabwe vs Bangladesh
2021-07-23 - international - T20 - male - 1267681 - Zimbabwe vs Bangladesh
2021-07-22 - international - T20 - male - 1267680 - Zimbabwe vs Bangladesh
2021-07-20 - international - ODI - male - 1267679 - Zimbabwe vs Bangladesh
2021-07-18 - international - ODI - male - 1267678 - Zimbabwe vs Bangladesh
2021-07-16 - international - ODI - male - 1267677 - Bangladesh vs Zimbabwe
2021-07-07 - international - Test - male - 1267676 - Bangladesh vs Zimbabwe
2021-05-07 - international - Test - male - 1257187 - Pakistan vs Zimbabwe
2021-04-29 - international - Test - male - 1257186 - Zimbabwe vs Pakistan
2021-04-25 - international - T20 - male - 1257185 - Pakistan vs Zimbabwe
2021-04-23 - international - T20 - male - 1257184 - Zimbabwe vs Pakistan
2021-04-21 - international - T20 - male - 1257183 - Pakistan vs Zimbabwe
2020-11-10 - international - T20 - male - 1233466 - Zimbabwe vs Pakistan
2020-11-08 - international - T20 - male - 1233465 - Zimbabwe vs Pakistan
2020-11-07 - international - T20 - male - 1233464 - Zimbabwe vs Pakistan
2020-11-03 - international - ODI - male - 1233463 - Zimbabwe vs Pakistan
2020-11-01 - international - ODI - male - 1233462 - Zimbabwe vs Pakistan
2020-10-30 - international - ODI - male - 1233461 - Pakistan vs Zimbabwe
2020-03-11 - international - T20 - male - 1214671 - Bangladesh vs Zimbabwe
2020-03-09 - international - T20 - male - 1214670 - Bangladesh vs Zimbabwe
2020-03-06 - international - ODI - male - 1214669 - Bangladesh vs Zimbabwe
2020-03-03 - international - ODI - male - 1214668 - Bangladesh vs Zimbabwe
2020-03-01 - international - ODI - male - 1214667 - Bangladesh vs Zimbabwe
2020-02-22 - international - Test - male - 1214666 - Bangladesh vs Zimbabwe
2020-01-27 - international - Test - male - 1212542 - Zimbabwe vs Sri Lanka
2020-01-19 - international - Test - male - 1212541 - Zimbabwe vs Sri Lanka
2019-10-03 - international - T20 - male - 1201685 - Singapore vs Zimbabwe
2019-10-01 - international - T20 - male - 1201683 - Nepal vs Zimbabwe
2019-09-29 - international - T20 - male - 1201682 - Singapore vs Zimbabwe
2019-09-27 - international - T20 - male - 1201680 - Nepal vs Zimbabwe
2019-09-18 - international - T20 - male - 1197143 - Bangladesh vs Zimbabwe
2019-09-13 - international - T20 - male - 1197140 - Bangladesh vs Zimbabwe
2019-07-14 - international - T20 - male - 1168522 - Ireland vs Zimbabwe
2019-07-12 - international - T20 - male - 1168521 - Ireland vs Zimbabwe
2019-07-07 - international - ODI - male - 1168519 - Ireland vs Zimbabwe
2019-07-04 - international - ODI - male - 1168518 - Ireland vs Zimbabwe
2019-07-01 - international - ODI - male - 1168517 - Ireland vs Zimbabwe
2019-06-25 - international - T20 - male - 1188380 - Netherlands vs Zimbabwe
2019-06-23 - international - T20 - male - 1188379 - Netherlands vs Zimbabwe
2019-06-21 - international - ODI - male - 1188378 - Netherlands vs Zimbabwe
2019-06-19 - international - ODI - male - 1188377 - Netherlands vs Zimbabwe
2019-04-16 - international - ODI - male - 1179275 - Zimbabwe vs United Arab Emirates
2019-04-12 - international - ODI - male - 1179273 - Zimbabwe vs United Arab Emirates
2019-04-10 - international - ODI - male - 1179272 - Zimbabwe vs United Arab Emirates
2018-11-11 - international - Test - male - 1153640 - Bangladesh vs Zimbabwe
2018-11-03 - international - Test - male - 1153639 - Zimbabwe vs Bangladesh
2018-10-26 - international - ODI - male - 1153637 - Zimbabwe vs Bangladesh
2018-10-24 - international - ODI - male - 1153636 - Zimbabwe vs Bangladesh
2018-10-21 - international - ODI - male - 1153635 - Bangladesh vs Zimbabwe
2018-10-12 - international - T20 - male - 1144150 - Zimbabwe vs South Africa
2018-10-09 - international - T20 - male - 1144149 - South Africa vs Zimbabwe
2018-10-06 - international - ODI - male - 1144148 - Zimbabwe vs South Africa
2018-10-03 - international - ODI - male - 1144147 - South Africa vs Zimbabwe
2018-09-30 - international - ODI - male - 1144146 - Zimbabwe vs South Africa
2018-07-22 - international - ODI - male - 1142924 - Pakistan vs Zimbabwe
2018-07-20 - international - ODI - male - 1142923 - Pakistan vs Zimbabwe
2018-07-18 - international - ODI - male - 1142922 - Zimbabwe vs Pakistan
2018-07-16 - international - ODI - male - 1142921 - Zimbabwe vs Pakistan
2018-07-13 - international - ODI - male - 1142920 - Pakistan vs Zimbabwe
2018-07-06 - international - T20 - male - 1142918 - Zimbabwe vs Australia
2018-07-04 - international - T20 - male - 1142916 - Zimbabwe vs Pakistan
2018-07-03 - international - T20 - male - 1142915 - Australia vs Zimbabwe
2018-07-01 - international - T20 - male - 1142913 - Pakistan vs Zimbabwe
2018-03-22 - international - ODI - male - 1133029 - United Arab Emirates vs Zimbabwe
2018-03-19 - international - ODI - male - 1133026 - Zimbabwe vs West Indies
2018-03-16 - international - ODI - male - 1133022 - Zimbabwe vs Ireland
2018-03-12 - international - ODI - male - 1133017 - Zimbabwe vs Scotland
2018-03-10 - international - ODI - male - 1133012 - Zimbabwe vs Hong Kong
2018-03-04 - international - ODM - male - 1133000 - Zimbabwe vs Nepal
2018-01-23 - international - ODI - male - 1130741 - Bangladesh vs Zimbabwe
2018-01-21 - international - ODI - male - 1130740 - Zimbabwe vs Sri Lanka
2018-01-17 - international - ODI - male - 1130738 - Zimbabwe vs Sri Lanka
2018-01-15 - international - ODI - male - 1130737 - Zimbabwe vs Bangladesh
2017-12-26 - international - Test - male - 1122310 - South Africa vs Zimbabwe
2017-10-29 - international - Test - male - 1122887 - Zimbabwe vs West Indies
2017-10-21 - international - Test - male - 1122886 - West Indies vs Zimbabwe
2017-07-14 - international - Test - male - 1104483 - Zimbabwe vs Sri Lanka
2017-07-10 - international - ODI - male - 1104482 - Sri Lanka vs Zimbabwe
2017-07-08 - international - ODI - male - 1104481 - Sri Lanka vs Zimbabwe
2017-07-06 - international - ODI - male - 1104480 - Sri Lanka vs Zimbabwe
2017-07-02 - international - ODI - male - 1104479 - Sri Lanka vs Zimbabwe
2017-06-30 - international - ODI - male - 1104478 - Sri Lanka vs Zimbabwe
2017-06-17 - international - ODI - male - 1089420 - Scotland vs Zimbabwe
2017-06-15 - international - ODI - male - 1089419 - Scotland vs Zimbabwe
2016-11-27 - international - ODI - male - 1059716 - Zimbabwe vs Sri Lanka
2016-11-25 - international - ODI - male - 1059715 - Zimbabwe vs West Indies
2016-11-21 - international - ODI - male - 1059713 - Zimbabwe vs Sri Lanka
2016-11-19 - international - ODI - male - 1059712 - Zimbabwe vs West Indies
2016-11-14 - international - ODI - male - 1059710 - Zimbabwe vs Sri Lanka
2016-11-06 - international - Test - male - 1059703 - Zimbabwe vs Sri Lanka
2016-10-29 - international - Test - male - 1059702 - Zimbabwe vs Sri Lanka
2016-08-06 - international - Test - male - 1024043 - Zimbabwe vs New Zealand
2016-07-28 - international - Test - male - 1024041 - Zimbabwe vs New Zealand
2016-06-22 - international - T20 - male - 1007659 - Zimbabwe vs India
2016-06-20 - international - T20 - male - 1007657 - Zimbabwe vs India
2016-06-18 - international - T20 - male - 1007655 - Zimbabwe vs India
2016-06-15 - international - ODI - male - 1007653 - Zimbabwe vs India
2016-06-13 - international - ODI - male - 1007651 - Zimbabwe vs India
2016-06-11 - international - ODI - male - 1007649 - Zimbabwe vs India
2016-03-10 - international - T20 - male - 951313 - Scotland vs Zimbabwe
2016-03-08 - international - T20 - male - 951305 - Hong Kong vs Zimbabwe
2016-01-22 - international - T20 - male - 958421 - Bangladesh vs Zimbabwe
2016-01-20 - international - T20 - male - 958419 - Bangladesh vs Zimbabwe
2016-01-17 - international - T20 - male - 958417 - Bangladesh vs Zimbabwe
2016-01-15 - international - T20 - male - 958415 - Bangladesh vs Zimbabwe
2015-11-15 - international - T20 - male - 931398 - Bangladesh vs Zimbabwe
2015-11-13 - international - T20 - male - 931396 - Bangladesh vs Zimbabwe
2015-11-11 - international - ODI - male - 931394 - Bangladesh vs Zimbabwe
2015-11-09 - international - ODI - male - 931392 - Bangladesh vs Zimbabwe
2015-11-07 - international - ODI - male - 931390 - Bangladesh vs Zimbabwe
2015-10-13 - international - ODI - male - 919617 - Zimbabwe vs Ireland
2015-10-11 - international - ODI - male - 919615 - Zimbabwe vs Ireland
2015-10-09 - international - ODI - male - 919613 - Zimbabwe vs Ireland
2015-10-05 - international - ODI - male - 919611 - Zimbabwe vs Pakistan
2015-10-03 - international - ODI - male - 919609 - Zimbabwe vs Pakistan
2015-10-01 - international - ODI - male - 919607 - Zimbabwe vs Pakistan
2015-09-29 - international - T20 - male - 919605 - Zimbabwe vs Pakistan
2015-09-27 - international - T20 - male - 919603 - Zimbabwe vs Pakistan
2015-08-09 - international - T20 - male - 894293 - Zimbabwe vs New Zealand
2015-08-07 - international - ODI - male - 894291 - Zimbabwe vs New Zealand
2015-08-04 - international - ODI - male - 894289 - Zimbabwe vs New Zealand
2015-08-02 - international - ODI - male - 894287 - Zimbabwe vs New Zealand
2015-07-19 - international - T20 - male - 885971 - Zimbabwe vs India
2015-07-17 - international - T20 - male - 885969 - Zimbabwe vs India
2015-07-14 - international - ODI - male - 885967 - Zimbabwe vs India
2015-07-12 - international - ODI - male - 885965 - Zimbabwe vs India
2015-07-10 - international - ODI - male - 885959 - Zimbabwe vs India
2015-05-31 - international - ODI - male - 868731 - Pakistan vs Zimbabwe
2015-05-29 - international - ODI - male - 868729 - Pakistan vs Zimbabwe
2015-05-26 - international - ODI - male - 868727 - Pakistan vs Zimbabwe
2015-05-24 - international - T20 - male - 868725 - Pakistan vs Zimbabwe
2015-05-22 - international - T20 - male - 868723 - Pakistan vs Zimbabwe
2015-03-14 - international - ODI - male - 656475 - India vs Zimbabwe
2015-03-07 - international - ODI - male - 656457 - Ireland vs Zimbabwe
2015-03-01 - international - ODI - male - 656443 - Pakistan vs Zimbabwe
2015-02-24 - international - ODI - male - 656427 - West Indies vs Zimbabwe
2015-02-19 - international - ODI - male - 656413 - United Arab Emirates vs Zimbabwe
2015-02-15 - international - ODI - male - 656403 - South Africa vs Zimbabwe
2014-12-01 - international - ODI - male - 760795 - Bangladesh vs Zimbabwe
2014-11-28 - international - ODI - male - 760793 - Bangladesh vs Zimbabwe
2014-11-26 - international - ODI - male - 760791 - Bangladesh vs Zimbabwe
2014-11-23 - international - ODI - male - 760789 - Bangladesh vs Zimbabwe
2014-11-21 - international - ODI - male - 760787 - Bangladesh vs Zimbabwe
2014-11-12 - international - Test - male - 760785 - Bangladesh vs Zimbabwe
2014-11-03 - international - Test - male - 760783 - Bangladesh vs Zimbabwe
2014-10-25 - international - Test - male - 760781 - Bangladesh vs Zimbabwe
2014-09-04 - international - ODI - male - 736453 - Zimbabwe vs South Africa
2014-08-31 - international - ODI - male - 736449 - Zimbabwe vs Australia
2014-08-29 - international - ODI - male - 736447 - Zimbabwe vs South Africa
2014-08-25 - international - ODI - male - 736443 - Zimbabwe vs Australia
2014-08-21 - international - ODI - male - 736441 - Zimbabwe vs South Africa
2014-08-19 - international - ODI - male - 736439 - Zimbabwe vs South Africa
2014-08-17 - international - ODI - male - 736437 - Zimbabwe vs South Africa
2014-08-09 - international - Test - male - 736435 - Zimbabwe vs South Africa
2014-03-21 - international - T20 - male - 682917 - United Arab Emirates vs Zimbabwe
2014-03-19 - international - T20 - male - 682909 - Netherlands vs Zimbabwe
2014-03-17 - international - T20 - male - 682901 - Ireland vs Zimbabwe
2013-09-10 - international - Test - male - 659557 - Zimbabwe vs Pakistan
2013-09-03 - international - Test - male - 659555 - Zimbabwe vs Pakistan
2013-08-31 - international - ODI - male - 659553 - Zimbabwe vs Pakistan
2013-08-29 - international - ODI - male - 659551 - Zimbabwe vs Pakistan
2013-08-27 - international - ODI - male - 659549 - Zimbabwe vs Pakistan
2013-08-24 - international - T20 - male - 659547 - Zimbabwe vs Pakistan
2013-08-23 - international - T20 - male - 659545 - Zimbabwe vs Pakistan
2013-08-03 - international - ODI - male - 643677 - Zimbabwe vs India
2013-08-01 - international - ODI - male - 643675 - Zimbabwe vs India
2013-07-28 - international - ODI - male - 643669 - Zimbabwe vs India
2013-07-26 - international - ODI - male - 643667 - Zimbabwe vs India
2013-07-24 - international - ODI - male - 643665 - Zimbabwe vs India
2013-05-12 - international - T20 - male - 623572 - Zimbabwe vs Bangladesh
2013-05-11 - international - T20 - male - 623571 - Zimbabwe vs Bangladesh
2013-05-08 - international - ODI - male - 623575 - Zimbabwe vs Bangladesh
2013-05-05 - international - ODI - male - 623574 - Zimbabwe vs Bangladesh
2013-05-03 - international - ODI - male - 623573 - Zimbabwe vs Bangladesh
2013-04-25 - international - Test - male - 623577 - Zimbabwe vs Bangladesh
2013-04-17 - international - Test - male - 623576 - Zimbabwe vs Bangladesh
2013-03-20 - international - Test - male - 593989 - West Indies vs Zimbabwe
2013-03-12 - international - Test - male - 593988 - West Indies vs Zimbabwe
2013-03-03 - international - T20 - male - 593987 - West Indies vs Zimbabwe
2013-03-02 - international - T20 - male - 593986 - West Indies vs Zimbabwe
2013-02-26 - international - ODI - male - 593985 - West Indies vs Zimbabwe
2013-02-22 - international - ODI - male - 593983 - West Indies vs Zimbabwe
2012-09-20 - international - T20 - male - 533275 - South Africa vs Zimbabwe
2012-09-18 - international - T20 - male - 533272 - Sri Lanka vs Zimbabwe
2012-02-14 - international - T20 - male - 520596 - New Zealand vs Zimbabwe
2012-02-11 - international - T20 - male - 520595 - New Zealand vs Zimbabwe
2012-02-09 - international - ODI - male - 520594 - New Zealand vs Zimbabwe
2012-02-06 - international - ODI - male - 520593 - New Zealand vs Zimbabwe
2012-02-03 - international - ODI - male - 520592 - New Zealand vs Zimbabwe
2012-01-26 - international - Test - male - 520591 - New Zealand vs Zimbabwe
2011-11-01 - international - Test - male - 527017 - Zimbabwe vs New Zealand
2011-10-25 - international - ODI - male - 527016 - Zimbabwe vs New Zealand
2011-10-22 - international - ODI - male - 527015 - Zimbabwe vs New Zealand
2011-10-20 - international - ODI - male - 527014 - Zimbabwe vs New Zealand
2011-10-17 - international - T20 - male - 527013 - Zimbabwe vs New Zealand
2011-10-15 - international - T20 - male - 527012 - Zimbabwe vs New Zealand
2011-09-18 - international - T20 - male - 523736 - Zimbabwe vs Pakistan
2011-09-16 - international - T20 - male - 523735 - Zimbabwe vs Pakistan
2011-09-14 - international - ODI - male - 523734 - Zimbabwe vs Pakistan
2011-09-11 - international - ODI - male - 523733 - Zimbabwe vs Pakistan
2011-09-08 - international - ODI - male - 523732 - Zimbabwe vs Pakistan
2011-09-01 - international - Test - male - 523731 - Zimbabwe vs Pakistan
2011-08-21 - international - ODI - male - 522250 - Zimbabwe vs Bangladesh
2011-08-19 - international - ODI - male - 522249 - Zimbabwe vs Bangladesh
2011-08-16 - international - ODI - male - 522248 - Zimbabwe vs Bangladesh
2011-08-14 - international - ODI - male - 522247 - Zimbabwe vs Bangladesh
2011-08-12 - international - ODI - male - 522246 - Zimbabwe vs Bangladesh
2011-08-04 - international - Test - male - 522245 - Zimbabwe vs Bangladesh
2011-03-20 - international - ODI - male - 433598 - Kenya vs Zimbabwe
2011-03-14 - international - ODI - male - 433589 - Pakistan vs Zimbabwe
2011-03-10 - international - ODI - male - 433583 - Sri Lanka vs Zimbabwe
2011-03-04 - international - ODI - male - 433575 - New Zealand vs Zimbabwe
2011-02-28 - international - ODI - male - 433570 - Canada vs Zimbabwe
2011-02-21 - international - ODI - male - 433561 - Australia vs Zimbabwe
2010-12-12 - international - ODI - male - 486526 - Bangladesh vs Zimbabwe
2010-12-06 - international - ODI - male - 486523 - Bangladesh vs Zimbabwe
2010-12-03 - international - ODI - male - 486522 - Bangladesh vs Zimbabwe
2010-12-01 - international - ODI - male - 486520 - Bangladesh vs Zimbabwe
2010-10-22 - international - ODI - male - 463145 - South Africa vs Zimbabwe
2010-10-17 - international - ODI - male - 463144 - South Africa vs Zimbabwe
2010-10-15 - international - ODI - male - 463143 - South Africa vs Zimbabwe
2010-10-10 - international - T20 - male - 463142 - South Africa vs Zimbabwe
2010-10-08 - international - T20 - male - 463141 - South Africa vs Zimbabwe
2010-06-13 - international - T20 - male - 452154 - Zimbabwe vs India
2010-06-12 - international - T20 - male - 452153 - Zimbabwe vs India
2010-06-09 - international - ODI - male - 452152 - Zimbabwe vs Sri Lanka
2010-06-07 - international - ODI - male - 452151 - Zimbabwe vs Sri Lanka
2010-06-03 - international - ODI - male - 452149 - Zimbabwe vs India
2010-06-01 - international - ODI - male - 452148 - Zimbabwe vs Sri Lanka
2010-05-28 - international - ODI - male - 452146 - Zimbabwe vs India
2010-05-04 - international - T20 - male - 412684 - New Zealand vs Zimbabwe
2010-05-03 - international - T20 - male - 412686 - Sri Lanka vs Zimbabwe
2010-03-14 - international - ODI - male - 439144 - West Indies vs Zimbabwe
2010-03-12 - international - ODI - male - 439143 - West Indies vs Zimbabwe
2010-03-10 - international - ODI - male - 439142 - West Indies vs Zimbabwe
2010-03-06 - international - ODI - male - 439141 - West Indies vs Zimbabwe
2010-03-04 - international - ODI - male - 439140 - West Indies vs Zimbabwe
2010-02-28 - international - T20 - male - 439139 - West Indies vs Zimbabwe
2009-11-10 - international - ODI - male - 430509 - South Africa vs Zimbabwe
2009-11-08 - international - ODI - male - 430508 - South Africa vs Zimbabwe
2009-11-05 - international - ODI - male - 422630 - Bangladesh vs Zimbabwe
2009-11-03 - international - ODI - male - 422629 - Bangladesh vs Zimbabwe
2009-10-31 - international - ODI - male - 422628 - Bangladesh vs Zimbabwe
2009-10-29 - international - ODI - male - 422627 - Bangladesh vs Zimbabwe
2009-10-27 - international - ODI - male - 422626 - Bangladesh vs Zimbabwe
2009-08-18 - international - ODI - male - 410341 - Zimbabwe vs Bangladesh
2009-08-16 - international - ODI - male - 410340 - Zimbabwe vs Bangladesh
2009-08-14 - international - ODI - male - 410339 - Zimbabwe vs Bangladesh
2009-08-11 - international - ODI - male - 410338 - Zimbabwe vs Bangladesh
2009-08-09 - international - ODI - male - 410337 - Zimbabwe vs Bangladesh
2009-01-31 - international - ODI - male - 385025 - Kenya vs Zimbabwe
2009-01-23 - international - ODI - male - 378759 - Bangladesh vs Zimbabwe
2009-01-10 - international - ODI - male - 378753 - Bangladesh vs Zimbabwe
2008-11-30 - international - ODI - male - 375462 - Zimbabwe vs Sri Lanka
2008-11-24 - international - ODI - male - 375460 - Zimbabwe vs Sri Lanka
2008-11-22 - international - ODI - male - 375457 - Zimbabwe vs Sri Lanka
2008-11-20 - international - ODI - male - 375456 - Zimbabwe vs Sri Lanka
2008-10-17 - international - ODI - male - 325581 - Ireland vs Zimbabwe
2008-02-02 - international - ODI - male - 325804 - Pakistan vs Zimbabwe
2008-01-30 - international - ODI - male - 325803 - Pakistan vs Zimbabwe
2008-01-27 - international - ODI - male - 325802 - Pakistan vs Zimbabwe
2008-01-24 - international - ODI - male - 325801 - Pakistan vs Zimbabwe
2008-01-21 - international - ODI - male - 325800 - Pakistan vs Zimbabwe
2007-12-07 - international - ODI - male - 317581 - Zimbabwe vs West Indies
2007-12-02 - international - ODI - male - 317579 - Zimbabwe vs West Indies
2007-11-30 - international - ODI - male - 317578 - Zimbabwe vs West Indies
2007-09-13 - international - T20 - male - 287858 - England vs Zimbabwe
2007-09-12 - international - T20 - male - 287856 - Australia vs Zimbabwe
2007-08-26 - international - ODI - male - 300488 - Zimbabwe vs South Africa
2007-08-25 - international - ODI - male - 300487 - Zimbabwe vs South Africa
2007-08-22 - international - ODI - male - 300486 - Zimbabwe vs South Africa
2007-03-21 - international - ODI - male - 247473 - Pakistan vs Zimbabwe
2007-03-19 - international - ODI - male - 247469 - West Indies vs Zimbabwe
2007-03-15 - international - ODI - male - 247461 - Ireland vs Zimbabwe
2006-12-09 - international - ODI - male - 264071 - Bangladesh vs Zimbabwe
2006-12-08 - international - ODI - male - 264070 - Bangladesh vs Zimbabwe
2006-12-05 - international - ODI - male - 264069 - Bangladesh vs Zimbabwe
2006-12-03 - international - ODI - male - 264068 - Bangladesh vs Zimbabwe
2006-10-13 - international - ODI - male - 249743 - Bangladesh vs Zimbabwe
2006-10-10 - international - ODI - male - 249741 - Sri Lanka vs Zimbabwe
2006-10-08 - international - ODI - male - 249740 - West Indies vs Zimbabwe
2006-09-20 - international - ODI - male - 257470 - South Africa vs Zimbabwe
2006-09-18 - international - ODI - male - 259793 - South Africa vs Zimbabwe
2006-09-15 - international - ODI - male - 255961 - South Africa vs Zimbabwe
2006-08-06 - international - ODI - male - 249207 - Zimbabwe vs Bangladesh
2006-05-14 - international - ODI - male - 239913 - West Indies vs Zimbabwe
2006-05-13 - international - ODI - male - 239912 - West Indies vs Zimbabwe
2006-05-10 - international - ODI - male - 239911 - West Indies vs Zimbabwe
2006-04-30 - international - ODI - male - 239908 - West Indies vs Zimbabwe
2006-04-29 - international - ODI - male - 239907 - West Indies vs Zimbabwe
2005-09-13 - international - Test - male - 219062 - Zimbabwe vs India
2005-09-04 - international - ODI - male - 217979 - Zimbabwe vs India
2005-08-31 - international - ODI - male - 217648 - New Zealand vs Zimbabwe
2005-08-29 - international - ODI - male - 217481 - India vs Zimbabwe
2005-08-15 - international - Test - male - 216055 - Zimbabwe vs New Zealand
2005-08-07 - international - Test - male - 215253 - New Zealand vs Zimbabwe
2005-03-11 - international - Test - male - 64124 - Zimbabwe vs South Africa
2005-03-04 - international - Test - male - 64123 - Zimbabwe vs South Africa
2005-03-02 - international - ODI - male - 64936 - Zimbabwe vs South Africa
2005-02-27 - international - ODI - male - 64934 - South Africa vs Zimbabwe
2005-02-25 - international - ODI - male - 64932 - South Africa vs Zimbabwe
2005-01-31 - international - ODI - male - 64923 - Zimbabwe vs Bangladesh
2005-01-24 - international - ODI - male - 64919 - Zimbabwe vs Bangladesh
2004-12-05 - international - ODI - male - 64913 - England vs Zimbabwe
2004-12-01 - international - ODI - male - 64911 - England vs Zimbabwe
2004-11-28 - international - ODI - male - 64910 - Zimbabwe vs England
2004-10-09 - international - ODI - male - 66381 - Zimbabwe vs Sri Lanka
2004-10-03 - international - ODI - male - 66379 - Zimbabwe vs Pakistan
2004-09-30 - international - ODI - male - 66378 - Pakistan vs Zimbabwe
2004-09-14 - international - ODI - male - 66201 - Zimbabwe vs Sri Lanka
2004-09-10 - international - ODI - male - 66196 - England vs Zimbabwe
2004-05-29 - international - ODI - male - 64901 - Zimbabwe vs Australia
2004-05-27 - international - ODI - male - 64900 - Australia vs Zimbabwe
2004-05-25 - international - ODI - male - 64899 - Zimbabwe vs Australia
2004-04-27 - international - ODI - male - 64891 - Sri Lanka vs Zimbabwe
2004-04-20 - international - ODI - male - 64887 - Zimbabwe vs Sri Lanka
2004-03-14 - international - ODI - male - 64881 - Bangladesh vs Zimbabwe
2004-01-29 - international - ODI - male - 65652 - Australia vs Zimbabwe
2004-01-20 - international - ODI - male - 65648 - India vs Zimbabwe
2004-01-16 - international - ODI - male - 65646 - Australia vs Zimbabwe
2004-01-14 - international - ODI - male - 65645 - Zimbabwe vs India
2004-01-11 - international - ODI - male - 65644 - Australia vs Zimbabwe
2003-11-30 - international - ODI - male - 64852 - Zimbabwe vs West Indies
2003-11-29 - international - ODI - male - 64851 - West Indies vs Zimbabwe
2003-11-26 - international - ODI - male - 64849 - Zimbabwe vs West Indies
2003-11-23 - international - ODI - male - 64848 - West Indies vs Zimbabwe
2003-11-12 - international - Test - male - 64055 - West Indies vs Zimbabwe
2003-10-17 - international - Test - male - 64049 - Zimbabwe vs Australia
2003-10-09 - international - Test - male - 64048 - Australia vs Zimbabwe
2003-07-10 - international - ODI - male - 66301 - Zimbabwe vs South Africa
2003-07-06 - international - ODI - male - 66299 - Zimbabwe vs England
2003-07-01 - international - ODI - male - 66296 - England vs Zimbabwe
2003-06-29 - international - ODI - male - 66295 - South Africa vs Zimbabwe
2003-06-26 - international - ODI - male - 66293 - England vs Zimbabwe
2003-04-10 - international - ODI - male - 65809 - Zimbabwe vs Pakistan
2003-04-07 - international - ODI - male - 65807 - Sri Lanka vs Zimbabwe
2003-04-05 - international - ODI - male - 65805 - Kenya vs Zimbabwe
2003-04-03 - international - ODI - male - 65803 - Pakistan vs Zimbabwe
2003-03-15 - international - ODI - male - 65282 - Sri Lanka vs Zimbabwe
2003-03-12 - international - ODI - male - 65280 - Zimbabwe vs Kenya
2003-03-08 - international - ODI - male - 65277 - Zimbabwe vs New Zealand
2003-03-04 - international - ODI - male - 65273 - Pakistan vs Zimbabwe
2003-02-28 - international - ODI - male - 65265 - Zimbabwe vs Netherlands
2003-02-24 - international - ODI - male - 65259 - Zimbabwe vs Australia
2003-02-19 - international - ODI - male - 65250 - India vs Zimbabwe
2003-02-10 - international - ODI - male - 65236 - Zimbabwe vs Namibia
