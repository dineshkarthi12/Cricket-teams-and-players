This zip archive contains data files from Cricsheet in YAML format. This
archive contains 48 Tamil Nadu matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/tamil_nadu_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-25 - club - SMA - male - 1383541 - Tamil Nadu vs Madhya Pradesh
2023-10-23 - club - SMA - male - 1383522 - Delhi vs Tamil Nadu
2023-10-19 - club - SMA - male - 1383487 - Tripura vs Tamil Nadu
2021-11-22 - club - SMA - male - 1280302 - Karnataka vs Tamil Nadu
2021-11-20 - club - SMA - male - 1280300 - Hyderabad (India) vs Tamil Nadu
2021-11-18 - club - SMA - male - 1280296 - Kerala vs Tamil Nadu
2021-11-09 - club - SMA - male - 1280276 - Punjab vs Tamil Nadu
2021-11-08 - club - SMA - male - 1280255 - Tamil Nadu vs Goa
2021-11-06 - club - SMA - male - 1280237 - Puducherry vs Tamil Nadu
2021-11-04 - club - SMA - male - 1280198 - Tamil Nadu vs Maharashtra
2021-01-31 - club - SMA - male - 1244407 - Baroda vs Tamil Nadu
2021-01-29 - club - SMA - male - 1244405 - Rajasthan vs Tamil Nadu
2021-01-26 - club - SMA - male - 1244402 - Himachal vs Tamil Nadu
2021-01-18 - club - SMA - male - 1244387 - Bengal vs Tamil Nadu
2021-01-16 - club - SMA - male - 1244366 - Hyderabad (India) vs Tamil Nadu
2021-01-14 - club - SMA - male - 1244348 - Odisha vs Tamil Nadu
2021-01-12 - club - SMA - male - 1244330 - Assam vs Tamil Nadu
2021-01-10 - club - SMA - male - 1244310 - Tamil Nadu vs Jharkhand
2019-12-01 - club - SMA - male - 1205862 - Karnataka vs Tamil Nadu
2019-11-27 - club - SMA - male - 1205858 - Jharkhand vs Tamil Nadu
2019-11-25 - club - SMA - male - 1205855 - Punjab vs Tamil Nadu
2019-11-22 - club - SMA - male - 1205847 - Mumbai vs Tamil Nadu
2019-11-21 - club - SMA - male - 1205842 - Tamil Nadu vs Karnataka
2019-11-17 - club - SMA - male - 1205833 - Tamil Nadu vs Vidarbha
2019-11-15 - club - SMA - male - 1205815 - Tripura vs Tamil Nadu
2019-11-14 - club - SMA - male - 1205797 - Manipur vs Tamil Nadu
2019-11-11 - club - SMA - male - 1205753 - Tamil Nadu vs Uttar Pradesh
2019-11-09 - club - SMA - male - 1205735 - Tamil Nadu vs Rajasthan
2019-11-08 - club - SMA - male - 1205716 - Tamil Nadu vs Kerala
2019-03-02 - club - SMA - male - 1157197 - Tamil Nadu vs Meghalaya
2019-02-28 - club - SMA - male - 1157180 - Vidarbha vs Tamil Nadu
2019-02-27 - club - SMA - male - 1157164 - Tamil Nadu vs Himachal
2019-02-25 - club - SMA - male - 1157145 - Tamil Nadu vs Gujarat
2019-02-24 - club - SMA - male - 1157130 - Bihar vs Tamil Nadu
2019-02-21 - club - SMA - male - 1157095 - Rajasthan vs Tamil Nadu
2018-01-25 - club - SMA - male - 1133420 - Tamil Nadu vs Baroda
2018-01-24 - club - SMA - male - 1133416 - Tamil Nadu vs Bengal
2018-01-23 - club - SMA - male - 1133411 - Uttar Pradesh vs Tamil Nadu
2018-01-21 - club - SMA - male - 1133403 - Tamil Nadu vs Delhi
2018-01-14 - club - SMA - male - 1130712 - Tamil Nadu vs Hyderabad (India)
2018-01-12 - club - SMA - male - 1130702 - Karnataka vs Tamil Nadu
2018-01-11 - club - SMA - male - 1130692 - Tamil Nadu vs Goa
2018-01-09 - club - SMA - male - 1130676 - Tamil Nadu vs Kerala
2018-01-08 - club - SMA - male - 1130671 - Andhra vs Tamil Nadu
2016-01-10 - club - SMA - male - 902229 - Hyderabad (India) vs Tamil Nadu
2016-01-07 - club - SMA - male - 902185 - Gujarat vs Tamil Nadu
2016-01-03 - club - SMA - male - 902115 - Tamil Nadu vs Bengal
2016-01-02 - club - SMA - male - 902091 - Haryana vs Tamil Nadu
