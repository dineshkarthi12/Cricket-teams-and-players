This zip archive contains data files from Cricsheet in JSON format. This
archive contains 56 Mumbai matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/mumbai_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2024-12-15 - club - SMA - male - 1446107 - Madhya Pradesh vs Mumbai
2024-12-13 - club - SMA - male - 1446105 - Baroda vs Mumbai
2024-12-11 - club - SMA - male - 1446104 - Vidarbha vs Mumbai
2023-10-21 - club - SMA - male - 1383488 - Mumbai vs Jammu & Kashmir
2023-10-17 - club - SMA - male - 1383452 - Meghalaya vs Mumbai
2023-10-16 - club - SMA - male - 1383434 - Haryana vs Mumbai
2022-11-05 - club - SMA - male - 1333055 - Himachal Pradesh vs Mumbai
2022-11-03 - club - SMA - male - 1333054 - Vidarbha vs Mumbai
2022-11-01 - club - SMA - male - 1333052 - Saurashtra vs Mumbai
2022-10-20 - club - SMA - male - 1333016 - Mumbai vs Railways
2022-10-14 - club - SMA - male - 1332962 - Mumbai vs Assam
2022-10-12 - club - SMA - male - 1332943 - Madhya Pradesh vs Mumbai
2021-11-09 - club - SMA - male - 1280277 - Mumbai vs Baroda
2021-11-08 - club - SMA - male - 1280260 - Chhattisgarh vs Mumbai
2021-11-06 - club - SMA - male - 1280240 - Mumbai vs Bengal
2021-11-04 - club - SMA - male - 1280202 - Karnataka vs Mumbai
2021-01-19 - club - SMA - male - 1244396 - Andhra vs Mumbai
2021-01-17 - club - SMA - male - 1244375 - Mumbai vs Puducherry
2021-01-15 - club - SMA - male - 1244357 - Mumbai vs Haryana
2021-01-11 - club - SMA - male - 1244319 - Delhi vs Mumbai
2019-11-27 - club - SMA - male - 1205859 - Mumbai vs Punjab
2019-11-25 - club - SMA - male - 1205854 - Karnataka vs Mumbai
2019-11-24 - club - SMA - male - 1205851 - Jharkhand vs Mumbai
2019-11-22 - club - SMA - male - 1205847 - Mumbai vs Tamil Nadu
2019-11-17 - club - SMA - male - 1205828 - Mumbai vs Assam
2019-11-15 - club - SMA - male - 1205818 - Mumbai vs Meghalaya
2019-11-14 - club - SMA - male - 1205792 - Bengal vs Mumbai
2019-11-12 - club - SMA - male - 1205783 - Mumbai vs Puducherry
2019-11-11 - club - SMA - male - 1205764 - Madhya Pradesh vs Mumbai
2019-11-09 - club - SMA - male - 1205747 - Haryana vs Mumbai
2019-11-08 - club - SMA - male - 1205721 - Mizoram vs Mumbai
2019-03-12 - club - SMA - male - 1175042 - Mumbai vs Uttar Pradesh
2019-03-11 - club - SMA - male - 1175038 - Vidarbha vs Mumbai
2019-03-09 - club - SMA - male - 1175030 - Delhi vs Mumbai
2019-03-08 - club - SMA - male - 1175028 - Mumbai vs Karnataka
2019-02-27 - club - SMA - male - 1157167 - Railways vs Mumbai
2019-02-25 - club - SMA - male - 1157149 - Goa vs Mumbai
2019-02-24 - club - SMA - male - 1157131 - Madhya Pradesh vs Mumbai
2019-02-22 - club - SMA - male - 1157115 - Mumbai vs Punjab
2019-02-21 - club - SMA - male - 1157099 - Mumbai vs Sikkim
2018-01-25 - club - SMA - male - 1133418 - Mumbai vs Karnataka
2018-01-24 - club - SMA - male - 1133413 - Rajasthan vs Mumbai
2018-01-22 - club - SMA - male - 1133406 - Mumbai vs Punjab
2018-01-21 - club - SMA - male - 1133402 - Mumbai vs Jharkhand
2018-01-11 - club - SMA - male - 1130690 - Maharashtra vs Mumbai
2018-01-10 - club - SMA - male - 1130687 - Mumbai vs Saurashtra
2018-01-08 - club - SMA - male - 1130673 - Gujarat vs Mumbai
2018-01-07 - club - SMA - male - 1130661 - Baroda vs Mumbai
2016-01-18 - club - SMA - male - 955065 - Mumbai vs Baroda
2016-01-16 - club - SMA - male - 955057 - Vidarbha vs Mumbai
2016-01-15 - club - SMA - male - 955049 - Kerala vs Mumbai
2016-01-08 - club - SMA - male - 902181 - Maharashtra vs Mumbai
2016-01-07 - club - SMA - male - 902203 - Mumbai vs Uttar Pradesh
2016-01-04 - club - SMA - male - 902155 - Services vs Mumbai
2016-01-03 - club - SMA - male - 902131 - Karnataka vs Mumbai
2016-01-02 - club - SMA - male - 902105 - Odisha vs Mumbai
