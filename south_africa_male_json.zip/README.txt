This zip archive contains data files from Cricsheet in JSON format. This
archive contains 815 South Africa matches of all types. A further 10 matches
have been withheld due to either featuring the Afghanistan men's team or being
played in the Afghanistan Premier League, due to the Cricsheet policy to no
longer feature matches involving Afghanistan men or played in Afghanistan
Premier League (see https://cricsheet.org/withheld-matches for more
information).


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/south_africa_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-09-13 - international - ODI - male - 1549533 - Namibia vs South Africa
2026-09-11 - international - ODI - male - 1549532 - South Africa vs Namibia
2026-09-09 - international - ODI - male - 1549531 - South Africa vs Namibia
2026-09-06 - international - T20 - male - 1549530 - South Africa vs Zimbabwe
2026-09-04 - international - T20 - male - 1549529 - South Africa vs Namibia
2026-09-01 - international - T20 - male - 1549527 - South Africa vs Zimbabwe
2026-08-29 - international - T20 - male - 1549525 - Zimbabwe vs South Africa
2026-08-28 - international - T20 - male - 1549524 - Namibia vs South Africa
2026-03-25 - international - T20 - male - 1491739 - South Africa vs New Zealand
2026-03-22 - international - T20 - male - 1491738 - South Africa vs New Zealand
2026-03-20 - international - T20 - male - 1491737 - South Africa vs New Zealand
2026-03-17 - international - T20 - male - 1491736 - New Zealand vs South Africa
2026-03-15 - international - T20 - male - 1491735 - New Zealand vs South Africa
2026-03-04 - international - T20 - male - 1512771 - South Africa vs New Zealand
2026-03-01 - international - T20 - male - 1512769 - Zimbabwe vs South Africa
2026-02-26 - international - T20 - male - 1512765 - West Indies vs South Africa
2026-02-22 - international - T20 - male - 1512761 - South Africa vs India
2026-02-18 - international - T20 - male - 1512752 - United Arab Emirates vs South Africa
2026-02-14 - international - T20 - male - 1512742 - New Zealand vs South Africa
2026-02-09 - international - T20 - male - 1512727 - South Africa vs Canada
2026-01-31 - international - T20 - male - 1477611 - West Indies vs South Africa
2026-01-29 - international - T20 - male - 1477610 - West Indies vs South Africa
2026-01-27 - international - T20 - male - 1477609 - West Indies vs South Africa
2025-12-19 - international - T20 - male - 1479580 - India vs South Africa
2025-12-14 - international - T20 - male - 1479578 - South Africa vs India
2025-12-11 - international - T20 - male - 1479577 - South Africa vs India
2025-12-09 - international - T20 - male - 1479576 - India vs South Africa
2025-12-06 - international - ODI - male - 1479575 - South Africa vs India
2025-12-03 - international - ODI - male - 1479574 - India vs South Africa
2025-11-30 - international - ODI - male - 1479573 - India vs South Africa
2025-11-22 - international - Test - male - 1479572 - South Africa vs India
2025-11-14 - international - Test - male - 1479571 - South Africa vs India
2025-11-08 - international - ODI - male - 1501900 - South Africa vs Pakistan
2025-11-06 - international - ODI - male - 1501899 - Pakistan vs South Africa
2025-11-04 - international - ODI - male - 1501898 - South Africa vs Pakistan
2025-11-01 - international - T20 - male - 1501897 - South Africa vs Pakistan
2025-10-31 - international - T20 - male - 1501896 - South Africa vs Pakistan
2025-10-28 - international - T20 - male - 1501895 - South Africa vs Pakistan
2025-10-20 - international - Test - male - 1501894 - Pakistan vs South Africa
2025-10-12 - international - Test - male - 1501893 - Pakistan vs South Africa
2025-10-11 - international - T20 - male - 1487824 - South Africa vs Namibia
2025-09-12 - international - T20 - male - 1448358 - England vs South Africa
2025-09-10 - international - T20 - male - 1448357 - South Africa vs England
2025-09-07 - international - ODI - male - 1448356 - England vs South Africa
2025-09-04 - international - ODI - male - 1448355 - South Africa vs England
2025-09-02 - international - ODI - male - 1448354 - England vs South Africa
2025-08-24 - international - ODI - male - 1478903 - Australia vs South Africa
2025-08-22 - international - ODI - male - 1478902 - South Africa vs Australia
2025-08-19 - international - ODI - male - 1478901 - South Africa vs Australia
2025-08-16 - international - T20 - male - 1478900 - South Africa vs Australia
2025-08-12 - international - T20 - male - 1478899 - South Africa vs Australia
2025-08-10 - international - T20 - male - 1478898 - Australia vs South Africa
2025-07-26 - international - T20 - male - 1478871 - New Zealand vs South Africa
2025-07-22 - international - T20 - male - 1478869 - South Africa vs New Zealand
2025-07-20 - international - T20 - male - 1478868 - Zimbabwe vs South Africa
2025-07-16 - international - T20 - male - 1478866 - New Zealand vs South Africa
2025-07-14 - international - T20 - male - 1478865 - Zimbabwe vs South Africa
2025-07-06 - international - Test - male - 1478864 - South Africa vs Zimbabwe
2025-06-28 - international - Test - male - 1478863 - South Africa vs Zimbabwe
2025-06-11 - international - Test - male - 1449769 - Australia vs South Africa
2025-03-05 - international - ODI - male - 1466427 - New Zealand vs South Africa
2025-03-01 - international - ODI - male - 1466424 - England vs South Africa
2025-02-12 - international - ODI - male - 1442222 - South Africa vs Pakistan
2025-02-10 - international - ODI - male - 1442221 - South Africa vs New Zealand
2025-01-03 - international - Test - male - 1432218 - South Africa vs Pakistan
2024-12-26 - international - Test - male - 1432217 - Pakistan vs South Africa
2024-12-22 - international - ODI - male - 1432216 - Pakistan vs South Africa
2024-12-19 - international - ODI - male - 1432215 - Pakistan vs South Africa
2024-12-17 - international - ODI - male - 1432214 - South Africa vs Pakistan
2024-12-13 - international - T20 - male - 1432212 - Pakistan vs South Africa
2024-12-10 - international - T20 - male - 1432211 - South Africa vs Pakistan
2024-12-05 - international - Test - male - 1432210 - South Africa vs Sri Lanka
2024-11-27 - international - Test - male - 1432209 - South Africa vs Sri Lanka
2024-11-15 - international - T20 - male - 1449304 - India vs South Africa
2024-11-13 - international - T20 - male - 1449303 - India vs South Africa
2024-11-10 - international - T20 - male - 1449302 - India vs South Africa
2024-11-08 - international - T20 - male - 1449301 - India vs South Africa
2024-10-29 - international - Test - male - 1453294 - South Africa vs Bangladesh
2024-10-21 - international - Test - male - 1453293 - Bangladesh vs South Africa
2024-10-07 - international - ODI - male - 1431090 - Ireland vs South Africa
2024-10-04 - international - ODI - male - 1431089 - South Africa vs Ireland
2024-10-02 - international - ODI - male - 1431088 - South Africa vs Ireland
2024-09-29 - international - T20 - male - 1431087 - Ireland vs South Africa
2024-09-27 - international - T20 - male - 1431086 - Ireland vs South Africa
2024-08-27 - international - T20 - male - 1433369 - South Africa vs West Indies
2024-08-25 - international - T20 - male - 1433368 - West Indies vs South Africa
2024-08-23 - international - T20 - male - 1433367 - South Africa vs West Indies
2024-08-15 - international - Test - male - 1433366 - South Africa vs West Indies
2024-08-07 - international - Test - male - 1433365 - South Africa vs West Indies
2024-06-29 - international - T20 - male - 1415755 - India vs South Africa
2024-06-23 - international - T20 - male - 1415750 - West Indies vs South Africa
2024-06-21 - international - T20 - male - 1415745 - South Africa vs England
2024-06-19 - international - T20 - male - 1415741 - South Africa vs United States of America
2024-06-14 - international - T20 - male - 1415731 - South Africa vs Nepal
2024-06-10 - international - T20 - male - 1415721 - South Africa vs Bangladesh
2024-06-08 - international - T20 - male - 1415716 - Netherlands vs South Africa
2024-06-03 - international - T20 - male - 1415704 - Sri Lanka vs South Africa
2024-05-26 - international - T20 - male - 1433364 - South Africa vs West Indies
2024-05-25 - international - T20 - male - 1433363 - West Indies vs South Africa
2024-05-23 - international - T20 - male - 1433362 - West Indies vs South Africa
2024-03-17 - international - T20 - male - 1424754 - South Africa vs Ghana
2024-02-13 - international - Test - male - 1388222 - South Africa vs New Zealand
2024-02-04 - international - Test - male - 1388221 - New Zealand vs South Africa
2024-01-03 - international - Test - male - 1387604 - South Africa vs India
2023-12-26 - international - Test - male - 1387603 - India vs South Africa
2023-12-21 - international - ODI - male - 1387602 - India vs South Africa
2023-12-19 - international - ODI - male - 1387601 - India vs South Africa
2023-12-17 - international - ODI - male - 1387600 - South Africa vs India
2023-12-14 - international - T20 - male - 1387599 - India vs South Africa
2023-12-12 - international - T20 - male - 1387598 - India vs South Africa
2023-11-16 - international - ODI - male - 1384438 - South Africa vs Australia
2023-11-05 - international - ODI - male - 1384428 - India vs South Africa
2023-11-01 - international - ODI - male - 1384423 - South Africa vs New Zealand
2023-10-27 - international - ODI - male - 1384417 - Pakistan vs South Africa
2023-10-24 - international - ODI - male - 1384414 - South Africa vs Bangladesh
2023-10-21 - international - ODI - male - 1384411 - South Africa vs England
2023-10-17 - international - ODI - male - 1384406 - Netherlands vs South Africa
2023-10-12 - international - ODI - male - 1384401 - South Africa vs Australia
2023-10-07 - international - ODI - male - 1384395 - South Africa vs Sri Lanka
2023-09-17 - international - ODI - male - 1373575 - South Africa vs Australia
2023-09-15 - international - ODI - male - 1373574 - South Africa vs Australia
2023-09-12 - international - ODI - male - 1373573 - South Africa vs Australia
2023-09-09 - international - ODI - male - 1373572 - Australia vs South Africa
2023-09-07 - international - ODI - male - 1373571 - South Africa vs Australia
2023-09-03 - international - T20 - male - 1373570 - South Africa vs Australia
2023-09-01 - international - T20 - male - 1373569 - South Africa vs Australia
2023-08-30 - international - T20 - male - 1373568 - Australia vs South Africa
2023-04-02 - international - ODI - male - 1339608 - South Africa vs Netherlands
2023-03-31 - international - ODI - male - 1339607 - Netherlands vs South Africa
2023-03-28 - international - T20 - male - 1339606 - West Indies vs South Africa
2023-03-26 - international - T20 - male - 1339605 - West Indies vs South Africa
2023-03-25 - international - T20 - male - 1339604 - South Africa vs West Indies
2023-03-21 - international - ODI - male - 1339603 - West Indies vs South Africa
2023-03-18 - international - ODI - male - 1339602 - West Indies vs South Africa
2023-03-08 - international - Test - male - 1339600 - South Africa vs West Indies
2023-02-28 - international - Test - male - 1339599 - South Africa vs West Indies
2023-02-01 - international - ODI - male - 1339597 - England vs South Africa
2023-01-29 - international - ODI - male - 1339596 - England vs South Africa
2023-01-27 - international - ODI - male - 1339595 - South Africa vs England
2023-01-04 - international - Test - male - 1317494 - Australia vs South Africa
2022-12-26 - international - Test - male - 1317493 - South Africa vs Australia
2022-12-17 - international - Test - male - 1317492 - South Africa vs Australia
2022-11-06 - international - T20 - male - 1298174 - Netherlands vs South Africa
2022-11-03 - international - T20 - male - 1298170 - Pakistan vs South Africa
2022-10-30 - international - T20 - male - 1298164 - India vs South Africa
2022-10-27 - international - T20 - male - 1298156 - South Africa vs Bangladesh
2022-10-24 - international - T20 - male - 1298152 - Zimbabwe vs South Africa
2022-10-11 - international - ODI - male - 1327511 - South Africa vs India
2022-10-09 - international - ODI - male - 1327510 - South Africa vs India
2022-10-06 - international - ODI - male - 1327509 - South Africa vs India
2022-10-04 - international - T20 - male - 1327508 - South Africa vs India
2022-10-02 - international - T20 - male - 1327507 - India vs South Africa
2022-09-28 - international - T20 - male - 1327506 - South Africa vs India
2022-09-08 - international - Test - male - 1276918 - South Africa vs England
2022-08-25 - international - Test - male - 1276917 - South Africa vs England
2022-08-17 - international - Test - male - 1276916 - England vs South Africa
2022-08-05 - international - T20 - male - 1303316 - South Africa vs Ireland
2022-08-03 - international - T20 - male - 1303315 - South Africa vs Ireland
2022-07-31 - international - T20 - male - 1276915 - South Africa vs England
2022-07-28 - international - T20 - male - 1276914 - South Africa vs England
2022-07-27 - international - T20 - male - 1276913 - England vs South Africa
2022-07-24 - international - ODI - male - 1276912 - South Africa vs England
2022-07-22 - international - ODI - male - 1276911 - England vs South Africa
2022-07-19 - international - ODI - male - 1276910 - South Africa vs England
2022-06-19 - international - T20 - male - 1278691 - India vs South Africa
2022-06-17 - international - T20 - male - 1278690 - India vs South Africa
2022-06-14 - international - T20 - male - 1278689 - India vs South Africa
2022-06-12 - international - T20 - male - 1278688 - India vs South Africa
2022-06-09 - international - T20 - male - 1278687 - India vs South Africa
2022-04-08 - international - Test - male - 1277101 - South Africa vs Bangladesh
2022-03-31 - international - Test - male - 1277100 - South Africa vs Bangladesh
2022-03-23 - international - ODI - male - 1277099 - South Africa vs Bangladesh
2022-03-20 - international - ODI - male - 1277098 - Bangladesh vs South Africa
2022-03-18 - international - ODI - male - 1277097 - Bangladesh vs South Africa
2022-02-25 - international - Test - male - 1288982 - South Africa vs New Zealand
2022-02-17 - international - Test - male - 1288981 - South Africa vs New Zealand
2022-01-23 - international - ODI - male - 1277084 - South Africa vs India
2022-01-21 - international - ODI - male - 1277083 - India vs South Africa
2022-01-19 - international - ODI - male - 1277082 - South Africa vs India
2022-01-11 - international - Test - male - 1277081 - India vs South Africa
2022-01-03 - international - Test - male - 1277080 - India vs South Africa
2021-12-26 - international - Test - male - 1277079 - India vs South Africa
2021-11-26 - international - ODI - male - 1277073 - South Africa vs Netherlands
2021-11-06 - international - T20 - male - 1273750 - South Africa vs England
2021-11-02 - international - T20 - male - 1273741 - Bangladesh vs South Africa
2021-10-30 - international - T20 - male - 1273736 - Sri Lanka vs South Africa
2021-10-26 - international - T20 - male - 1273729 - West Indies vs South Africa
2021-10-23 - international - T20 - male - 1273724 - South Africa vs Australia
2021-09-14 - international - T20 - male - 1271632 - Sri Lanka vs South Africa
2021-09-12 - international - T20 - male - 1271631 - Sri Lanka vs South Africa
2021-09-10 - international - T20 - male - 1271630 - South Africa vs Sri Lanka
2021-09-07 - international - ODI - male - 1271629 - Sri Lanka vs South Africa
2021-09-04 - international - ODI - male - 1271628 - South Africa vs Sri Lanka
2021-09-02 - international - ODI - male - 1271627 - Sri Lanka vs South Africa
2021-07-24 - international - T20 - male - 1251955 - South Africa vs Ireland
2021-07-22 - international - T20 - male - 1251954 - South Africa vs Ireland
2021-07-19 - international - T20 - male - 1251953 - South Africa vs Ireland
2021-07-16 - international - ODI - male - 1251952 - South Africa vs Ireland
2021-07-13 - international - ODI - male - 1251951 - Ireland vs South Africa
2021-07-11 - international - ODI - male - 1251950 - Ireland vs South Africa
2021-07-03 - international - T20 - male - 1263155 - South Africa vs West Indies
2021-07-01 - international - T20 - male - 1263154 - West Indies vs South Africa
2021-06-29 - international - T20 - male - 1263153 - South Africa vs West Indies
2021-06-27 - international - T20 - male - 1263152 - South Africa vs West Indies
2021-06-26 - international - T20 - male - 1263151 - South Africa vs West Indies
2021-06-18 - international - Test - male - 1263150 - South Africa vs West Indies
2021-06-10 - international - Test - male - 1263149 - West Indies vs South Africa
2021-04-16 - international - T20 - male - 1251578 - South Africa vs Pakistan
2021-04-14 - international - T20 - male - 1251577 - South Africa vs Pakistan
2021-04-12 - international - T20 - male - 1251576 - Pakistan vs South Africa
2021-04-10 - international - T20 - male - 1251575 - South Africa vs Pakistan
2021-04-07 - international - ODI - male - 1251574 - Pakistan vs South Africa
2021-04-04 - international - ODI - male - 1251573 - South Africa vs Pakistan
2021-04-02 - international - ODI - male - 1251572 - South Africa vs Pakistan
2021-02-14 - international - T20 - male - 1243021 - South Africa vs Pakistan
2021-02-13 - international - T20 - male - 1243020 - Pakistan vs South Africa
2021-02-11 - international - T20 - male - 1243019 - Pakistan vs South Africa
2021-02-04 - international - Test - male - 1243018 - Pakistan vs South Africa
2021-01-26 - international - Test - male - 1243017 - South Africa vs Pakistan
2021-01-03 - international - Test - male - 1237357 - Sri Lanka vs South Africa
2020-12-26 - international - Test - male - 1237356 - Sri Lanka vs South Africa
2020-12-01 - international - T20 - male - 1237124 - South Africa vs England
2020-11-29 - international - T20 - male - 1237123 - South Africa vs England
2020-11-27 - international - T20 - male - 1237122 - South Africa vs England
2020-03-07 - international - ODI - male - 1185321 - South Africa vs Australia
2020-03-04 - international - ODI - male - 1185320 - South Africa vs Australia
2020-02-29 - international - ODI - male - 1185319 - South Africa vs Australia
2020-02-26 - international - T20 - male - 1185318 - South Africa vs Australia
2020-02-23 - international - T20 - male - 1185317 - South Africa vs Australia
2020-02-21 - international - T20 - male - 1185316 - South Africa vs Australia
2020-02-16 - international - T20 - male - 1185315 - South Africa vs England
2020-02-14 - international - T20 - male - 1185314 - South Africa vs England
2020-02-12 - international - T20 - male - 1185313 - South Africa vs England
2020-02-09 - international - ODI - male - 1185312 - South Africa vs England
2020-02-07 - international - ODI - male - 1185311 - South Africa vs England
2020-02-04 - international - ODI - male - 1185310 - South Africa vs England
2020-01-24 - international - Test - male - 1185307 - South Africa vs England
2020-01-16 - international - Test - male - 1185306 - South Africa vs England
2020-01-03 - international - Test - male - 1185305 - South Africa vs England
2019-12-26 - international - Test - male - 1185304 - South Africa vs England
2019-10-19 - international - Test - male - 1187009 - India vs South Africa
2019-10-10 - international - Test - male - 1187008 - India vs South Africa
2019-10-02 - international - Test - male - 1187007 - India vs South Africa
2019-09-22 - international - T20 - male - 1187006 - India vs South Africa
2019-09-18 - international - T20 - male - 1187005 - India vs South Africa
2019-07-06 - international - ODI - male - 1144527 - Australia vs South Africa
2019-06-28 - international - ODI - male - 1144517 - South Africa vs Sri Lanka
2019-06-23 - international - ODI - male - 1144512 - Pakistan vs South Africa
2019-06-19 - international - ODI - male - 1144507 - New Zealand vs South Africa
2019-06-10 - international - ODI - male - 1144497 - South Africa vs West Indies
2019-06-05 - international - ODI - male - 1144490 - India vs South Africa
2019-06-02 - international - ODI - male - 1144487 - Bangladesh vs South Africa
2019-05-30 - international - ODI - male - 1144483 - England vs South Africa
2019-03-24 - international - T20 - male - 1144174 - South Africa vs Sri Lanka
2019-03-22 - international - T20 - male - 1144173 - South Africa vs Sri Lanka
2019-03-19 - international - T20 - male - 1144172 - South Africa vs Sri Lanka
2019-03-16 - international - ODI - male - 1144171 - South Africa vs Sri Lanka
2019-03-13 - international - ODI - male - 1144170 - South Africa vs Sri Lanka
2019-03-10 - international - ODI - male - 1144169 - South Africa vs Sri Lanka
2019-03-06 - international - ODI - male - 1144168 - South Africa vs Sri Lanka
2019-03-03 - international - ODI - male - 1144167 - South Africa vs Sri Lanka
2019-02-21 - international - Test - male - 1144165 - South Africa vs Sri Lanka
2019-02-13 - international - Test - male - 1144164 - South Africa vs Sri Lanka
2019-02-06 - international - T20 - male - 1144163 - South Africa vs Pakistan
2019-02-03 - international - T20 - male - 1144162 - South Africa vs Pakistan
2019-02-01 - international - T20 - male - 1144161 - South Africa vs Pakistan
2019-01-30 - international - ODI - male - 1144160 - South Africa vs Pakistan
2019-01-27 - international - ODI - male - 1144159 - South Africa vs Pakistan
2019-01-25 - international - ODI - male - 1144158 - South Africa vs Pakistan
2019-01-22 - international - ODI - male - 1144157 - South Africa vs Pakistan
2019-01-19 - international - ODI - male - 1144156 - South Africa vs Pakistan
2019-01-11 - international - Test - male - 1144155 - South Africa vs Pakistan
2019-01-03 - international - Test - male - 1144154 - South Africa vs Pakistan
2018-12-26 - international - Test - male - 1144153 - South Africa vs Pakistan
2018-11-17 - international - T20 - male - 1144989 - South Africa vs Australia
2018-11-11 - international - ODI - male - 1144988 - South Africa vs Australia
2018-11-09 - international - ODI - male - 1144987 - Australia vs South Africa
2018-11-04 - international - ODI - male - 1144986 - Australia vs South Africa
2018-10-12 - international - T20 - male - 1144150 - Zimbabwe vs South Africa
2018-10-09 - international - T20 - male - 1144149 - South Africa vs Zimbabwe
2018-10-06 - international - ODI - male - 1144148 - Zimbabwe vs South Africa
2018-10-03 - international - ODI - male - 1144147 - South Africa vs Zimbabwe
2018-09-30 - international - ODI - male - 1144146 - Zimbabwe vs South Africa
2018-08-14 - international - T20 - male - 1142589 - South Africa vs Sri Lanka
2018-08-12 - international - ODI - male - 1142588 - Sri Lanka vs South Africa
2018-08-08 - international - ODI - male - 1142587 - Sri Lanka vs South Africa
2018-08-05 - international - ODI - male - 1142586 - South Africa vs Sri Lanka
2018-08-01 - international - ODI - male - 1142585 - Sri Lanka vs South Africa
2018-07-29 - international - ODI - male - 1142584 - Sri Lanka vs South Africa
2018-07-20 - international - Test - male - 1142582 - Sri Lanka vs South Africa
2018-07-12 - international - Test - male - 1142581 - Sri Lanka vs South Africa
2018-03-30 - international - Test - male - 1075985 - South Africa vs Australia
2018-03-22 - international - Test - male - 1075984 - South Africa vs Australia
2018-03-09 - international - Test - male - 1075983 - Australia vs South Africa
2018-03-01 - international - Test - male - 1075982 - Australia vs South Africa
2018-02-24 - international - T20 - male - 1122287 - India vs South Africa
2018-02-21 - international - T20 - male - 1122286 - India vs South Africa
2018-02-18 - international - T20 - male - 1122285 - India vs South Africa
2018-02-16 - international - ODI - male - 1122284 - South Africa vs India
2018-02-13 - international - ODI - male - 1122283 - India vs South Africa
2018-02-10 - international - ODI - male - 1122282 - India vs South Africa
2018-02-07 - international - ODI - male - 1122281 - India vs South Africa
2018-02-04 - international - ODI - male - 1122280 - South Africa vs India
2018-02-01 - international - ODI - male - 1122279 - South Africa vs India
2018-01-24 - international - Test - male - 1122278 - India vs South Africa
2018-01-13 - international - Test - male - 1122277 - South Africa vs India
2018-01-05 - international - Test - male - 1122276 - South Africa vs India
2017-12-26 - international - Test - male - 1122310 - South Africa vs Zimbabwe
2017-10-29 - international - T20 - male - 1075508 - South Africa vs Bangladesh
2017-10-26 - international - T20 - male - 1075507 - South Africa vs Bangladesh
2017-10-22 - international - ODI - male - 1075506 - South Africa vs Bangladesh
2017-10-18 - international - ODI - male - 1075505 - South Africa vs Bangladesh
2017-10-15 - international - ODI - male - 1075504 - Bangladesh vs South Africa
2017-10-06 - international - Test - male - 1075503 - South Africa vs Bangladesh
2017-09-28 - international - Test - male - 1075502 - South Africa vs Bangladesh
2017-08-04 - international - Test - male - 1031443 - England vs South Africa
2017-07-27 - international - Test - male - 1031441 - England vs South Africa
2017-07-14 - international - Test - male - 1031439 - South Africa vs England
2017-07-06 - international - Test - male - 1031437 - England vs South Africa
2017-06-25 - international - T20 - male - 1031435 - England vs South Africa
2017-06-23 - international - T20 - male - 1031433 - England vs South Africa
2017-06-21 - international - T20 - male - 1031431 - England vs South Africa
2017-06-11 - international - ODI - male - 1022367 - India vs South Africa
2017-06-07 - international - ODI - male - 1022359 - Pakistan vs South Africa
2017-06-03 - international - ODI - male - 1022351 - South Africa vs Sri Lanka
2017-05-29 - international - ODI - male - 1031429 - England vs South Africa
2017-05-27 - international - ODI - male - 1031427 - England vs South Africa
2017-05-24 - international - ODI - male - 1031425 - England vs South Africa
2017-03-25 - international - Test - male - 1020045 - New Zealand vs South Africa
2017-03-16 - international - Test - male - 1020043 - New Zealand vs South Africa
2017-03-08 - international - Test - male - 1020041 - New Zealand vs South Africa
2017-03-04 - international - ODI - male - 1020039 - New Zealand vs South Africa
2017-03-01 - international - ODI - male - 1020037 - New Zealand vs South Africa
2017-02-25 - international - ODI - male - 1020035 - New Zealand vs South Africa
2017-02-22 - international - ODI - male - 1020033 - New Zealand vs South Africa
2017-02-19 - international - ODI - male - 1020031 - New Zealand vs South Africa
2017-02-17 - international - T20 - male - 1020029 - New Zealand vs South Africa
2017-02-10 - international - ODI - male - 936167 - South Africa vs Sri Lanka
2017-02-07 - international - ODI - male - 936165 - South Africa vs Sri Lanka
2017-02-04 - international - ODI - male - 936163 - South Africa vs Sri Lanka
2017-02-01 - international - ODI - male - 936161 - South Africa vs Sri Lanka
2017-01-28 - international - ODI - male - 936159 - South Africa vs Sri Lanka
2017-01-25 - international - T20 - male - 936157 - South Africa vs Sri Lanka
2017-01-22 - international - T20 - male - 936155 - South Africa vs Sri Lanka
2017-01-20 - international - T20 - male - 936153 - South Africa vs Sri Lanka
2017-01-12 - international - Test - male - 936151 - South Africa vs Sri Lanka
2017-01-02 - international - Test - male - 936149 - South Africa vs Sri Lanka
2016-12-26 - international - Test - male - 936147 - South Africa vs Sri Lanka
2016-11-24 - international - Test - male - 1000855 - Australia vs South Africa
2016-11-12 - international - Test - male - 1000853 - Australia vs South Africa
2016-11-03 - international - Test - male - 1000851 - Australia vs South Africa
2016-10-12 - international - ODI - male - 936143 - South Africa vs Australia
2016-10-09 - international - ODI - male - 936141 - South Africa vs Australia
2016-10-05 - international - ODI - male - 936139 - South Africa vs Australia
2016-10-02 - international - ODI - male - 936137 - South Africa vs Australia
2016-09-30 - international - ODI - male - 936135 - South Africa vs Australia
2016-09-25 - international - ODI - male - 936131 - South Africa vs Ireland
2016-08-27 - international - Test - male - 936129 - South Africa vs New Zealand
2016-08-19 - international - Test - male - 936127 - South Africa vs New Zealand
2016-06-24 - international - ODI - male - 932865 - West Indies vs South Africa
2016-06-19 - international - ODI - male - 932861 - Australia vs South Africa
2016-06-15 - international - ODI - male - 932859 - West Indies vs South Africa
2016-06-11 - international - ODI - male - 932855 - Australia vs South Africa
2016-06-07 - international - ODI - male - 932853 - Australia vs South Africa
2016-06-03 - international - ODI - male - 932849 - West Indies vs South Africa
2016-03-28 - international - T20 - male - 951367 - South Africa vs Sri Lanka
2016-03-25 - international - T20 - male - 951357 - South Africa vs West Indies
2016-03-18 - international - T20 - male - 951339 - England vs South Africa
2016-03-09 - international - T20 - male - 884351 - South Africa vs Australia
2016-03-06 - international - T20 - male - 884349 - South Africa vs Australia
2016-03-04 - international - T20 - male - 884347 - South Africa vs Australia
2016-02-21 - international - T20 - male - 800481 - South Africa vs England
2016-02-19 - international - T20 - male - 800479 - South Africa vs England
2016-02-14 - international - ODI - male - 800477 - South Africa vs England
2016-02-12 - international - ODI - male - 800475 - South Africa vs England
2016-02-09 - international - ODI - male - 800473 - South Africa vs England
2016-02-06 - international - ODI - male - 800471 - South Africa vs England
2016-02-03 - international - ODI - male - 800469 - South Africa vs England
2016-01-22 - international - Test - male - 800467 - South Africa vs England
2016-01-14 - international - Test - male - 800465 - South Africa vs England
2016-01-02 - international - Test - male - 800463 - South Africa vs England
2015-12-26 - international - Test - male - 800461 - South Africa vs England
2015-12-03 - international - Test - male - 903609 - India vs South Africa
2015-11-25 - international - Test - male - 903607 - India vs South Africa
2015-11-14 - international - Test - male - 903605 - India vs South Africa
2015-11-05 - international - Test - male - 903603 - India vs South Africa
2015-10-25 - international - ODI - male - 903601 - India vs South Africa
2015-10-22 - international - ODI - male - 903599 - India vs South Africa
2015-10-18 - international - ODI - male - 903597 - India vs South Africa
2015-10-14 - international - ODI - male - 903595 - India vs South Africa
2015-10-11 - international - ODI - male - 903593 - India vs South Africa
2015-10-05 - international - T20 - male - 903589 - India vs South Africa
2015-10-02 - international - T20 - male - 903587 - India vs South Africa
2015-08-26 - international - ODI - male - 848847 - South Africa vs New Zealand
2015-08-23 - international - ODI - male - 848845 - South Africa vs New Zealand
2015-08-19 - international - ODI - male - 848843 - South Africa vs New Zealand
2015-08-16 - international - T20 - male - 848841 - South Africa vs New Zealand
2015-08-14 - international - T20 - male - 848839 - South Africa vs New Zealand
2015-07-30 - international - Test - male - 817215 - Bangladesh vs South Africa
2015-07-21 - international - Test - male - 817213 - Bangladesh vs South Africa
2015-07-15 - international - ODI - male - 817211 - Bangladesh vs South Africa
2015-07-12 - international - ODI - male - 817209 - Bangladesh vs South Africa
2015-07-10 - international - ODI - male - 817207 - Bangladesh vs South Africa
2015-07-07 - international - T20 - male - 817205 - Bangladesh vs South Africa
2015-07-05 - international - T20 - male - 817203 - Bangladesh vs South Africa
2015-03-24 - international - ODI - male - 656491 - New Zealand vs South Africa
2015-03-18 - international - ODI - male - 656483 - South Africa vs Sri Lanka
2015-03-12 - international - ODI - male - 656469 - South Africa vs United Arab Emirates
2015-03-07 - international - ODI - male - 656455 - Pakistan vs South Africa
2015-03-03 - international - ODI - male - 656445 - Ireland vs South Africa
2015-02-27 - international - ODI - male - 656435 - South Africa vs West Indies
2015-02-22 - international - ODI - male - 656423 - India vs South Africa
2015-02-15 - international - ODI - male - 656403 - South Africa vs Zimbabwe
2015-01-28 - international - ODI - male - 722347 - South Africa vs West Indies
2015-01-25 - international - ODI - male - 722345 - South Africa vs West Indies
2015-01-21 - international - ODI - male - 722343 - South Africa vs West Indies
2015-01-18 - international - ODI - male - 722341 - South Africa vs West Indies
2015-01-16 - international - ODI - male - 722339 - South Africa vs West Indies
2015-01-14 - international - T20 - male - 736063 - South Africa vs West Indies
2015-01-11 - international - T20 - male - 722337 - South Africa vs West Indies
2015-01-09 - international - T20 - male - 722335 - South Africa vs West Indies
2015-01-02 - international - Test - male - 722333 - South Africa vs West Indies
2014-12-26 - international - Test - male - 722331 - South Africa vs West Indies
2014-12-17 - international - Test - male - 722329 - South Africa vs West Indies
2014-11-23 - international - ODI - male - 754731 - Australia vs South Africa
2014-11-21 - international - ODI - male - 754729 - Australia vs South Africa
2014-11-19 - international - ODI - male - 754727 - Australia vs South Africa
2014-11-16 - international - ODI - male - 754725 - Australia vs South Africa
2014-11-14 - international - ODI - male - 754723 - Australia vs South Africa
2014-11-09 - international - T20 - male - 754721 - Australia vs South Africa
2014-11-07 - international - T20 - male - 754719 - Australia vs South Africa
2014-11-05 - international - T20 - male - 754717 - Australia vs South Africa
2014-10-27 - international - ODI - male - 749775 - New Zealand vs South Africa
2014-10-24 - international - ODI - male - 749773 - New Zealand vs South Africa
2014-10-21 - international - ODI - male - 749771 - New Zealand vs South Africa
2014-09-06 - international - ODI - male - 736455 - Australia vs South Africa
2014-09-04 - international - ODI - male - 736453 - Zimbabwe vs South Africa
2014-09-02 - international - ODI - male - 736451 - Australia vs South Africa
2014-08-29 - international - ODI - male - 736447 - Zimbabwe vs South Africa
2014-08-27 - international - ODI - male - 736445 - Australia vs South Africa
2014-08-21 - international - ODI - male - 736441 - Zimbabwe vs South Africa
2014-08-19 - international - ODI - male - 736439 - Zimbabwe vs South Africa
2014-08-17 - international - ODI - male - 736437 - Zimbabwe vs South Africa
2014-08-09 - international - Test - male - 736435 - Zimbabwe vs South Africa
2014-07-24 - international - Test - male - 730091 - Sri Lanka vs South Africa
2014-07-16 - international - Test - male - 730089 - Sri Lanka vs South Africa
2014-07-12 - international - ODI - male - 730087 - Sri Lanka vs South Africa
2014-07-09 - international - ODI - male - 730085 - Sri Lanka vs South Africa
2014-07-06 - international - ODI - male - 730083 - Sri Lanka vs South Africa
2014-04-04 - international - T20 - male - 682963 - India vs South Africa
2014-03-29 - international - T20 - male - 682947 - England vs South Africa
2014-03-27 - international - T20 - male - 682937 - Netherlands vs South Africa
2014-03-24 - international - T20 - male - 682931 - New Zealand vs South Africa
2014-03-22 - international - T20 - male - 682923 - South Africa vs Sri Lanka
2014-03-14 - international - T20 - male - 648683 - South Africa vs Australia
2014-03-12 - international - T20 - male - 648681 - South Africa vs Australia
2014-03-01 - international - Test - male - 648677 - South Africa vs Australia
2014-02-20 - international - Test - male - 648675 - South Africa vs Australia
2014-02-12 - international - Test - male - 648673 - South Africa vs Australia
2013-12-26 - international - Test - male - 648667 - South Africa vs India
2013-12-18 - international - Test - male - 648665 - South Africa vs India
2013-12-11 - international - ODI - male - 648655 - South Africa vs India
2013-12-08 - international - ODI - male - 648653 - South Africa vs India
2013-12-05 - international - ODI - male - 648651 - South Africa vs India
2013-11-30 - international - ODI - male - 685735 - South Africa vs Pakistan
2013-11-27 - international - ODI - male - 685733 - South Africa vs Pakistan
2013-11-24 - international - ODI - male - 685731 - South Africa vs Pakistan
2013-11-22 - international - T20 - male - 685729 - South Africa vs Pakistan
2013-11-20 - international - T20 - male - 685727 - South Africa vs Pakistan
2013-11-15 - international - T20 - male - 649103 - Pakistan vs South Africa
2013-11-13 - international - T20 - male - 649101 - Pakistan vs South Africa
2013-11-11 - international - ODI - male - 649099 - Pakistan vs South Africa
2013-11-08 - international - ODI - male - 649097 - Pakistan vs South Africa
2013-11-06 - international - ODI - male - 649095 - Pakistan vs South Africa
2013-11-01 - international - ODI - male - 649093 - Pakistan vs South Africa
2013-10-30 - international - ODI - male - 649091 - Pakistan vs South Africa
2013-10-23 - international - Test - male - 649089 - Pakistan vs South Africa
2013-10-14 - international - Test - male - 649087 - Pakistan vs South Africa
2013-08-06 - international - T20 - male - 635660 - Sri Lanka vs South Africa
2013-08-04 - international - T20 - male - 635659 - Sri Lanka vs South Africa
2013-08-02 - international - T20 - male - 635658 - Sri Lanka vs South Africa
2013-07-31 - international - ODI - male - 635657 - Sri Lanka vs South Africa
2013-07-28 - international - ODI - male - 635656 - Sri Lanka vs South Africa
2013-07-26 - international - ODI - male - 635655 - Sri Lanka vs South Africa
2013-07-23 - international - ODI - male - 635654 - Sri Lanka vs South Africa
2013-07-20 - international - ODI - male - 635653 - Sri Lanka vs South Africa
2013-06-19 - international - ODI - male - 566946 - England vs South Africa
2013-06-14 - international - ODI - male - 578622 - South Africa vs West Indies
2013-06-10 - international - ODI - male - 578618 - Pakistan vs South Africa
2013-06-06 - international - ODI - male - 578614 - India vs South Africa
2013-03-24 - international - ODI - male - 567372 - South Africa vs Pakistan
2013-03-21 - international - ODI - male - 567371 - South Africa vs Pakistan
2013-03-17 - international - ODI - male - 567370 - South Africa vs Pakistan
2013-03-15 - international - ODI - male - 567369 - South Africa vs Pakistan
2013-03-10 - international - ODI - male - 567368 - South Africa vs Pakistan
2013-03-03 - international - T20 - male - 567367 - South Africa vs Pakistan
2013-02-22 - international - Test - male - 567365 - South Africa vs Pakistan
2013-02-14 - international - Test - male - 567364 - South Africa vs Pakistan
2013-02-01 - international - Test - male - 567363 - South Africa vs Pakistan
2013-01-25 - international - ODI - male - 567360 - South Africa vs New Zealand
2013-01-22 - international - ODI - male - 567359 - South Africa vs New Zealand
2013-01-19 - international - ODI - male - 567358 - South Africa vs New Zealand
2013-01-11 - international - Test - male - 567357 - South Africa vs New Zealand
2013-01-02 - international - Test - male - 567356 - South Africa vs New Zealand
2012-12-26 - international - T20 - male - 567355 - South Africa vs New Zealand
2012-12-23 - international - T20 - male - 567354 - South Africa vs New Zealand
2012-12-21 - international - T20 - male - 567353 - South Africa vs New Zealand
2012-11-30 - international - Test - male - 573009 - Australia vs South Africa
2012-11-22 - international - Test - male - 573008 - Australia vs South Africa
2012-11-09 - international - Test - male - 573007 - Australia vs South Africa
2012-10-02 - international - T20 - male - 533295 - India vs South Africa
2012-09-30 - international - T20 - male - 533290 - Australia vs South Africa
2012-09-28 - international - T20 - male - 533286 - Pakistan vs South Africa
2012-09-22 - international - T20 - male - 533278 - Sri Lanka vs South Africa
2012-09-20 - international - T20 - male - 533275 - South Africa vs Zimbabwe
2012-09-12 - international - T20 - male - 534235 - England vs South Africa
2012-09-10 - international - T20 - male - 534234 - England vs South Africa
2012-09-08 - international - T20 - male - 534233 - England vs South Africa
2012-09-05 - international - ODI - male - 534232 - England vs South Africa
2012-09-02 - international - ODI - male - 534231 - England vs South Africa
2012-08-31 - international - ODI - male - 534230 - England vs South Africa
2012-08-28 - international - ODI - male - 534229 - England vs South Africa
2012-08-24 - international - ODI - male - 534228 - England vs South Africa
2012-08-16 - international - Test - male - 534227 - England vs South Africa
2012-08-02 - international - Test - male - 534226 - England vs South Africa
2012-07-19 - international - Test - male - 534225 - England vs South Africa
2012-03-30 - international - T20 - male - 556252 - South Africa vs India
2012-03-23 - international - Test - male - 520605 - New Zealand vs South Africa
2012-03-15 - international - Test - male - 520604 - New Zealand vs South Africa
2012-03-07 - international - Test - male - 520603 - New Zealand vs South Africa
2012-03-03 - international - ODI - male - 520602 - New Zealand vs South Africa
2012-02-29 - international - ODI - male - 520601 - New Zealand vs South Africa
2012-02-25 - international - ODI - male - 520600 - New Zealand vs South Africa
2012-02-22 - international - T20 - male - 520599 - New Zealand vs South Africa
2012-02-19 - international - T20 - male - 520598 - New Zealand vs South Africa
2012-02-17 - international - T20 - male - 520597 - New Zealand vs South Africa
2012-01-22 - international - ODI - male - 514039 - South Africa vs Sri Lanka
2012-01-20 - international - ODI - male - 514038 - South Africa vs Sri Lanka
2012-01-17 - international - ODI - male - 514037 - South Africa vs Sri Lanka
2012-01-14 - international - ODI - male - 514036 - South Africa vs Sri Lanka
2012-01-11 - international - ODI - male - 514035 - South Africa vs Sri Lanka
2012-01-03 - international - Test - male - 514034 - South Africa vs Sri Lanka
2011-12-26 - international - Test - male - 514033 - South Africa vs Sri Lanka
2011-12-15 - international - Test - male - 514032 - South Africa vs Sri Lanka
2011-11-17 - international - Test - male - 514030 - South Africa vs Australia
2011-11-09 - international - Test - male - 514029 - South Africa vs Australia
2011-10-28 - international - ODI - male - 514027 - South Africa vs Australia
2011-10-23 - international - ODI - male - 514026 - South Africa vs Australia
2011-10-19 - international - ODI - male - 514025 - South Africa vs Australia
2011-10-16 - international - T20 - male - 514024 - South Africa vs Australia
2011-10-13 - international - T20 - male - 514023 - South Africa vs Australia
2011-03-25 - international - ODI - male - 433602 - New Zealand vs South Africa
2011-03-19 - international - ODI - male - 433597 - Bangladesh vs South Africa
2011-03-15 - international - ODI - male - 433591 - Ireland vs South Africa
2011-03-12 - international - ODI - male - 433586 - India vs South Africa
2011-03-06 - international - ODI - male - 433579 - England vs South Africa
2011-03-03 - international - ODI - male - 433573 - Netherlands vs South Africa
2011-02-24 - international - ODI - male - 433564 - South Africa vs West Indies
2011-01-23 - international - ODI - male - 463154 - South Africa vs India
2011-01-21 - international - ODI - male - 463153 - South Africa vs India
2011-01-18 - international - ODI - male - 463152 - South Africa vs India
2011-01-15 - international - ODI - male - 463151 - South Africa vs India
2011-01-12 - international - ODI - male - 463150 - South Africa vs India
2011-01-09 - international - T20 - male - 463149 - South Africa vs India
2011-01-02 - international - Test - male - 463148 - South Africa vs India
2010-12-26 - international - Test - male - 463147 - South Africa vs India
2010-12-16 - international - Test - male - 463146 - South Africa vs India
2010-11-20 - international - Test - male - 461572 - Pakistan vs South Africa
2010-11-12 - international - Test - male - 461571 - Pakistan vs South Africa
2010-11-08 - international - ODI - male - 461570 - Pakistan vs South Africa
2010-11-05 - international - ODI - male - 461569 - Pakistan vs South Africa
2010-11-02 - international - ODI - male - 461568 - Pakistan vs South Africa
2010-10-31 - international - ODI - male - 461567 - Pakistan vs South Africa
2010-10-29 - international - ODI - male - 461566 - Pakistan vs South Africa
2010-10-27 - international - T20 - male - 461565 - Pakistan vs South Africa
2010-10-26 - international - T20 - male - 478279 - Pakistan vs South Africa
2010-10-22 - international - ODI - male - 463145 - South Africa vs Zimbabwe
2010-10-17 - international - ODI - male - 463144 - South Africa vs Zimbabwe
2010-10-15 - international - ODI - male - 463143 - South Africa vs Zimbabwe
2010-10-10 - international - T20 - male - 463142 - South Africa vs Zimbabwe
2010-10-08 - international - T20 - male - 463141 - South Africa vs Zimbabwe
2010-06-26 - international - Test - male - 439154 - West Indies vs South Africa
2010-06-18 - international - Test - male - 439153 - West Indies vs South Africa
2010-06-10 - international - Test - male - 439152 - West Indies vs South Africa
2010-06-03 - international - ODI - male - 439151 - West Indies vs South Africa
2010-05-30 - international - ODI - male - 439150 - West Indies vs South Africa
2010-05-28 - international - ODI - male - 439149 - West Indies vs South Africa
2010-05-24 - international - ODI - male - 439148 - West Indies vs South Africa
2010-05-22 - international - ODI - male - 439147 - West Indies vs South Africa
2010-05-20 - international - T20 - male - 447539 - West Indies vs South Africa
2010-05-19 - international - T20 - male - 439146 - West Indies vs South Africa
2010-05-10 - international - T20 - male - 412697 - Pakistan vs South Africa
2010-05-08 - international - T20 - male - 412694 - England vs South Africa
2010-05-06 - international - T20 - male - 412690 - New Zealand vs South Africa
2010-05-02 - international - T20 - male - 412682 - India vs South Africa
2010-02-27 - international - ODI - male - 441829 - India vs South Africa
2010-02-24 - international - ODI - male - 441828 - India vs South Africa
2010-02-21 - international - ODI - male - 441827 - India vs South Africa
2010-02-14 - international - Test - male - 441826 - India vs South Africa
2010-02-06 - international - Test - male - 441825 - India vs South Africa
2010-01-14 - international - Test - male - 387573 - South Africa vs England
2010-01-03 - international - Test - male - 387572 - South Africa vs England
2009-12-26 - international - Test - male - 387571 - South Africa vs England
2009-12-16 - international - Test - male - 387570 - South Africa vs England
2009-11-29 - international - ODI - male - 387568 - South Africa vs England
2009-11-27 - international - ODI - male - 387567 - South Africa vs England
2009-11-22 - international - ODI - male - 387566 - South Africa vs England
2009-11-15 - international - T20 - male - 387564 - South Africa vs England
2009-11-13 - international - T20 - male - 387563 - South Africa vs England
2009-11-10 - international - ODI - male - 430509 - South Africa vs Zimbabwe
2009-11-08 - international - ODI - male - 430508 - South Africa vs Zimbabwe
2009-09-27 - international - ODI - male - 415280 - South Africa vs England
2009-09-24 - international - ODI - male - 415275 - South Africa vs New Zealand
2009-09-22 - international - ODI - male - 415273 - South Africa vs Sri Lanka
2009-06-18 - international - T20 - male - 356015 - Pakistan vs South Africa
2009-06-16 - international - T20 - male - 356014 - India vs South Africa
2009-06-13 - international - T20 - male - 356007 - South Africa vs West Indies
2009-06-11 - international - T20 - male - 356004 - England vs South Africa
2009-06-09 - international - T20 - male - 356000 - New Zealand vs South Africa
2009-06-07 - international - T20 - male - 355995 - Scotland vs South Africa
2009-04-17 - international - ODI - male - 350481 - South Africa vs Australia
2009-04-13 - international - ODI - male - 350480 - South Africa vs Australia
2009-04-09 - international - ODI - male - 350479 - South Africa vs Australia
2009-04-05 - international - ODI - male - 350478 - South Africa vs Australia
2009-04-03 - international - ODI - male - 350477 - South Africa vs Australia
2009-03-29 - international - T20 - male - 350476 - South Africa vs Australia
2009-03-27 - international - T20 - male - 350475 - South Africa vs Australia
2009-03-19 - international - Test - male - 350474 - South Africa vs Australia
2009-03-06 - international - Test - male - 350473 - South Africa vs Australia
2009-02-26 - international - Test - male - 350472 - South Africa vs Australia
2009-01-30 - international - ODI - male - 351688 - Australia vs South Africa
2009-01-26 - international - ODI - male - 351687 - Australia vs South Africa
2009-01-23 - international - ODI - male - 351686 - Australia vs South Africa
2009-01-18 - international - ODI - male - 351685 - Australia vs South Africa
2009-01-16 - international - ODI - male - 351684 - Australia vs South Africa
2009-01-13 - international - T20 - male - 351695 - Australia vs South Africa
2009-01-11 - international - T20 - male - 351694 - Australia vs South Africa
2009-01-03 - international - Test - male - 351683 - Australia vs South Africa
2008-12-26 - international - Test - male - 351682 - Australia vs South Africa
2008-12-17 - international - Test - male - 351681 - Australia vs South Africa
2008-11-26 - international - Test - male - 350346 - South Africa vs Bangladesh
2008-11-19 - international - Test - male - 350345 - South Africa vs Bangladesh
2008-11-07 - international - ODI - male - 350348 - South Africa vs Bangladesh
2008-11-05 - international - T20 - male - 350347 - South Africa vs Bangladesh
2008-10-31 - international - ODI - male - 360800 - South Africa vs Kenya
2008-09-03 - international - ODI - male - 296918 - England vs South Africa
2008-08-31 - international - ODI - male - 296917 - England vs South Africa
2008-08-29 - international - ODI - male - 296916 - England vs South Africa
2008-08-26 - international - ODI - male - 296915 - England vs South Africa
2008-08-22 - international - ODI - male - 296914 - England vs South Africa
2008-08-07 - international - Test - male - 296912 - England vs South Africa
2008-07-30 - international - Test - male - 296911 - England vs South Africa
2008-07-18 - international - Test - male - 296910 - England vs South Africa
2008-07-10 - international - Test - male - 296909 - England vs South Africa
2008-04-11 - international - Test - male - 332913 - India vs South Africa
2008-04-03 - international - Test - male - 332912 - India vs South Africa
2008-03-26 - international - Test - male - 332911 - India vs South Africa
2008-03-14 - international - ODI - male - 323951 - Bangladesh vs South Africa
2008-03-12 - international - ODI - male - 323950 - Bangladesh vs South Africa
2008-03-09 - international - ODI - male - 323949 - Bangladesh vs South Africa
2008-02-29 - international - Test - male - 323948 - Bangladesh vs South Africa
2008-02-22 - international - Test - male - 323947 - Bangladesh vs South Africa
2008-02-03 - international - ODI - male - 298809 - South Africa vs West Indies
2008-02-01 - international - ODI - male - 298808 - South Africa vs West Indies
2008-01-27 - international - ODI - male - 298807 - South Africa vs West Indies
2008-01-25 - international - ODI - male - 298806 - South Africa vs West Indies
2008-01-20 - international - ODI - male - 298805 - South Africa vs West Indies
2008-01-18 - international - T20 - male - 298804 - South Africa vs West Indies
2008-01-10 - international - Test - male - 298803 - South Africa vs West Indies
2008-01-02 - international - Test - male - 298802 - South Africa vs West Indies
2007-12-26 - international - Test - male - 298801 - West Indies vs South Africa
2007-12-16 - international - T20 - male - 319112 - South Africa vs West Indies
2007-12-02 - international - ODI - male - 298798 - South Africa vs New Zealand
2007-11-30 - international - ODI - male - 298797 - South Africa vs New Zealand
2007-11-25 - international - ODI - male - 298796 - South Africa vs New Zealand
2007-11-23 - international - T20 - male - 298795 - South Africa vs New Zealand
2007-11-16 - international - Test - male - 298794 - New Zealand vs South Africa
2007-11-08 - international - Test - male - 298793 - South Africa vs New Zealand
2007-10-29 - international - ODI - male - 299010 - Pakistan vs South Africa
2007-10-26 - international - ODI - male - 299009 - Pakistan vs South Africa
2007-10-23 - international - ODI - male - 299008 - Pakistan vs South Africa
2007-10-20 - international - ODI - male - 299007 - Pakistan vs South Africa
2007-10-18 - international - ODI - male - 299006 - Pakistan vs South Africa
2007-10-08 - international - Test - male - 299005 - South Africa vs Pakistan
2007-10-01 - international - Test - male - 299004 - South Africa vs Pakistan
2007-09-20 - international - T20 - male - 287876 - South Africa vs India
2007-09-19 - international - T20 - male - 287872 - South Africa vs New Zealand
2007-09-16 - international - T20 - male - 287867 - South Africa vs England
2007-09-15 - international - T20 - male - 287864 - South Africa vs Bangladesh
2007-09-11 - international - T20 - male - 287853 - South Africa vs West Indies
2007-08-26 - international - ODI - male - 300488 - Zimbabwe vs South Africa
2007-08-25 - international - ODI - male - 300487 - Zimbabwe vs South Africa
2007-08-22 - international - ODI - male - 300486 - Zimbabwe vs South Africa
2007-07-01 - international - ODI - male - 293078 - India vs South Africa
2007-06-29 - international - ODI - male - 293077 - India vs South Africa
2007-06-26 - international - ODI - male - 293076 - India vs South Africa
2007-06-24 - international - ODI - male - 293072 - Ireland vs South Africa
2007-04-25 - international - ODI - male - 247506 - Australia vs South Africa
2007-04-17 - international - ODI - male - 247500 - England vs South Africa
2007-04-14 - international - ODI - male - 247497 - New Zealand vs South Africa
2007-04-10 - international - ODI - male - 247493 - West Indies vs South Africa
2007-04-07 - international - ODI - male - 247490 - Bangladesh vs South Africa
2007-04-03 - international - ODI - male - 247488 - Ireland vs South Africa
2007-03-28 - international - ODI - male - 247482 - South Africa vs Sri Lanka
2007-03-24 - international - ODI - male - 247478 - Australia vs South Africa
2007-03-20 - international - ODI - male - 247470 - Scotland vs South Africa
2007-03-16 - international - ODI - male - 247462 - Netherlands vs South Africa
2007-02-14 - international - ODI - male - 250672 - South Africa vs Pakistan
2007-02-11 - international - ODI - male - 250671 - South Africa vs Pakistan
2007-02-09 - international - ODI - male - 250670 - South Africa vs Pakistan
2007-02-07 - international - ODI - male - 250669 - South Africa vs Pakistan
2007-02-04 - international - ODI - male - 250668 - South Africa vs Pakistan
2007-01-26 - international - Test - male - 250667 - Pakistan vs South Africa
2007-01-19 - international - Test - male - 250666 - South Africa vs Pakistan
2007-01-02 - international - Test - male - 249217 - India vs South Africa
2006-12-26 - international - Test - male - 249216 - South Africa vs India
2006-12-15 - international - Test - male - 249215 - India vs South Africa
2006-12-03 - international - ODI - male - 249214 - South Africa vs India
2006-12-01 - international - T20 - male - 255954 - South Africa vs India
2006-11-29 - international - ODI - male - 249213 - South Africa vs India
2006-11-26 - international - ODI - male - 249212 - South Africa vs India
2006-11-22 - international - ODI - male - 249211 - South Africa vs India
2006-11-02 - international - ODI - male - 249758 - South Africa vs West Indies
2006-10-27 - international - ODI - male - 249754 - Pakistan vs South Africa
2006-10-24 - international - ODI - male - 249751 - South Africa vs Sri Lanka
2006-10-16 - international - ODI - male - 249746 - New Zealand vs South Africa
2006-09-20 - international - ODI - male - 257470 - South Africa vs Zimbabwe
2006-09-18 - international - ODI - male - 259793 - South Africa vs Zimbabwe
2006-09-15 - international - ODI - male - 255961 - South Africa vs Zimbabwe
2006-08-04 - international - Test - male - 249194 - South Africa vs Sri Lanka
2006-07-27 - international - Test - male - 249193 - South Africa vs Sri Lanka
2006-05-05 - international - Test - male - 238207 - New Zealand vs South Africa
2006-04-27 - international - Test - male - 238206 - New Zealand vs South Africa
2006-04-15 - international - Test - male - 238205 - South Africa vs New Zealand
2006-03-31 - international - Test - male - 238203 - South Africa vs Australia
2006-03-24 - international - Test - male - 238202 - Australia vs South Africa
2006-03-16 - international - Test - male - 238201 - South Africa vs Australia
2006-03-12 - international - ODI - male - 238200 - South Africa vs Australia
2006-03-10 - international - ODI - male - 238199 - South Africa vs Australia
2006-03-05 - international - ODI - male - 238198 - South Africa vs Australia
2006-03-03 - international - ODI - male - 238197 - South Africa vs Australia
2006-02-26 - international - ODI - male - 238196 - South Africa vs Australia
2006-02-24 - international - T20 - male - 238195 - South Africa vs Australia
2006-02-07 - international - ODI - male - 226386 - South Africa vs Sri Lanka
2006-02-05 - international - ODI - male - 226378 - Australia vs South Africa
2006-02-03 - international - ODI - male - 226377 - Australia vs South Africa
2006-01-31 - international - ODI - male - 226385 - South Africa vs Sri Lanka
2006-01-24 - international - ODI - male - 226384 - South Africa vs Sri Lanka
2006-01-20 - international - ODI - male - 226376 - Australia vs South Africa
2006-01-17 - international - ODI - male - 226383 - South Africa vs Sri Lanka
2006-01-15 - international - ODI - male - 226375 - Australia vs South Africa
2006-01-09 - international - T20 - male - 226374 - Australia vs South Africa
2006-01-02 - international - Test - male - 226373 - South Africa vs Australia
2005-12-26 - international - Test - male - 226372 - Australia vs South Africa
2005-11-28 - international - ODI - male - 226359 - South Africa vs India
2005-11-16 - international - ODI - male - 225959 - India vs South Africa
2005-11-06 - international - ODI - male - 224227 - New Zealand vs South Africa
2005-11-04 - international - ODI - male - 224044 - South Africa vs New Zealand
2005-10-30 - international - ODI - male - 223542 - New Zealand vs South Africa
2005-10-28 - international - ODI - male - 223335 - South Africa vs New Zealand
2005-10-21 - international - T20 - male - 222678 - South Africa vs New Zealand
2005-05-15 - international - ODI - male - 209339 - West Indies vs South Africa
2005-05-08 - international - ODI - male - 208835 - West Indies vs South Africa
2005-04-29 - international - Test - male - 208321 - South Africa vs West Indies
2005-04-21 - international - Test - male - 207334 - West Indies vs South Africa
2005-03-11 - international - Test - male - 64124 - Zimbabwe vs South Africa
2005-03-04 - international - Test - male - 64123 - Zimbabwe vs South Africa
2005-03-02 - international - ODI - male - 64936 - Zimbabwe vs South Africa
2005-02-27 - international - ODI - male - 64934 - South Africa vs Zimbabwe
2005-02-25 - international - ODI - male - 64932 - South Africa vs Zimbabwe
2005-02-13 - international - ODI - male - 64929 - England vs South Africa
2005-02-11 - international - ODI - male - 64928 - South Africa vs England
2005-02-09 - international - ODI - male - 64927 - South Africa vs England
2005-02-06 - international - ODI - male - 64926 - South Africa vs England
2005-02-04 - international - ODI - male - 64925 - England vs South Africa
2005-02-02 - international - ODI - male - 64924 - England vs South Africa
2005-01-30 - international - ODI - male - 64922 - South Africa vs England
2005-01-02 - international - Test - male - 64118 - South Africa vs England
2004-11-28 - international - Test - male - 64110 - South Africa vs India
2004-11-20 - international - Test - male - 64109 - South Africa vs India
2004-09-18 - international - ODI - male - 66206 - South Africa vs West Indies
2004-08-31 - international - ODI - male - 64906 - Sri Lanka vs South Africa
2004-08-28 - international - ODI - male - 64905 - South Africa vs Sri Lanka
2004-03-26 - international - Test - male - 64076 - New Zealand vs South Africa
2004-03-18 - international - Test - male - 64075 - South Africa vs New Zealand
2004-02-25 - international - ODI - male - 64872 - South Africa vs New Zealand
2004-02-01 - international - ODI - male - 64865 - South Africa vs West Indies
2004-01-30 - international - ODI - male - 64864 - West Indies vs South Africa
2004-01-25 - international - ODI - male - 64862 - South Africa vs West Indies
2003-12-12 - international - Test - male - 64063 - South Africa vs West Indies
2003-10-24 - international - Test - male - 64051 - South Africa vs Pakistan
2003-10-17 - international - Test - male - 64050 - South Africa vs Pakistan
2003-10-12 - international - ODI - male - 64842 - Pakistan vs South Africa
2003-10-10 - international - ODI - male - 64841 - Pakistan vs South Africa
2003-10-07 - international - ODI - male - 64840 - Pakistan vs South Africa
2003-10-05 - international - ODI - male - 64839 - Pakistan vs South Africa
2003-10-03 - international - ODI - male - 64838 - Pakistan vs South Africa
2003-09-04 - international - Test - male - 64042 - South Africa vs England
2003-08-21 - international - Test - male - 64041 - South Africa vs England
2003-08-14 - international - Test - male - 64040 - England vs South Africa
2003-07-24 - international - Test - male - 64038 - South Africa vs England
2003-07-12 - international - ODI - male - 66302 - South Africa vs England
2003-07-10 - international - ODI - male - 66301 - Zimbabwe vs South Africa
2003-07-03 - international - ODI - male - 66297 - England vs South Africa
2003-06-29 - international - ODI - male - 66295 - South Africa vs Zimbabwe
2003-06-28 - international - ODI - male - 66294 - South Africa vs England
2003-04-21 - international - ODI - male - 66356 - India vs South Africa
2003-03-03 - international - ODI - male - 65272 - Sri Lanka vs South Africa
2003-02-27 - international - ODI - male - 65264 - South Africa vs Canada
2003-02-22 - international - ODI - male - 65254 - Bangladesh vs South Africa
2003-02-16 - international - ODI - male - 65248 - South Africa vs New Zealand
2003-02-12 - international - ODI - male - 65240 - Kenya vs South Africa
2003-02-09 - international - ODI - male - 65235 - West Indies vs South Africa
2003-01-02 - international - Test - male - 64023 - South Africa vs Pakistan
2002-12-26 - international - Test - male - 64022 - South Africa vs Pakistan
