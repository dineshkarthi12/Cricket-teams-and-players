All International League T20 match data in CSV format
=====================================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the IPL data from YAML into this CSV format. This then expanded
to include international T20s, for both women and men, before, finally,
expanding again to cover all matches we provide.

This particular zip folder contains the CSV data for...
  All International League T20 matches
...for which we have data, and is loosely based on the format that Retrosheet
uses for baseball, with some suitable hacks built in.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the newer "Ashwin" format?
Ideally I'd like to settle on a single CSV format so what should be kept
from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_original/
but the following is a brief summary of the details...

Each file has a 'version', multiple 'info' lines, and multiple 'ball' lines.
'version' is just 1.8.0 for now, and will change as I make changes.
The 'info' entries should be fairly self-explanatory but feel free to ask on
Mastodon (@cricsheet@deeden.co.uk) if you're unsure. If you look carefully
you may see some slight hints as to some data we'll be including in the full
data files in the future.

Each 'ball' line has the following fields:

  * The word 'ball' to identify it as such
  * Innings number, starting from 1
  * Over and ball
  * Batting team name
  * Batsman
  * Non-striker
  * Bowler
  * Runs-off-bat
  * Extras
  * Wides
  * No-balls
  * Byes
  * Leg-byes
  * Penalty
  * Kind of wicket, if any
  * Dismissed played, if there was a wicket

Matches included in this archive
--------------------------------

2026-01-04 - club - ILT - male - 1501351 - Desert Vipers vs MI Emirates
2026-01-02 - club - ILT - male - 1501350 - Abu Dhabi Knight Riders vs MI Emirates
2026-01-01 - club - ILT - male - 1501349 - Abu Dhabi Knight Riders vs Dubai Capitals
2025-12-30 - club - ILT - male - 1501348 - Desert Vipers vs MI Emirates
2025-12-28 - club - ILT - male - 1501347 - Abu Dhabi Knight Riders vs Gulf Giants
2025-12-27 - club - ILT - male - 1501346 - Dubai Capitals vs MI Emirates
2025-12-26 - club - ILT - male - 1501345 - Sharjah Warriorz vs Desert Vipers
2025-12-24 - club - ILT - male - 1501344 - Sharjah Warriorz vs Dubai Capitals
2025-12-23 - club - ILT - male - 1501343 - Gulf Giants vs MI Emirates
2025-12-22 - club - ILT - male - 1501342 - Abu Dhabi Knight Riders vs Sharjah Warriorz
2025-12-21 - club - ILT - male - 1501341 - Desert Vipers vs MI Emirates
2025-12-21 - club - ILT - male - 1501340 - Gulf Giants vs Dubai Capitals
2025-12-20 - club - ILT - male - 1501339 - Sharjah Warriorz vs Desert Vipers
2025-12-20 - club - ILT - male - 1501338 - MI Emirates vs Abu Dhabi Knight Riders
2025-12-19 - club - ILT - male - 1501337 - Dubai Capitals vs Sharjah Warriorz
2025-12-18 - club - ILT - male - 1501336 - Gulf Giants vs Abu Dhabi Knight Riders
2025-12-17 - club - ILT - male - 1501335 - MI Emirates vs Dubai Capitals
2025-12-16 - club - ILT - male - 1501334 - Abu Dhabi Knight Riders vs Desert Vipers
2025-12-15 - club - ILT - male - 1501333 - Sharjah Warriorz vs Gulf Giants
2025-12-14 - club - ILT - male - 1501332 - Dubai Capitals vs Desert Vipers
2025-12-14 - club - ILT - male - 1501331 - Sharjah Warriorz vs MI Emirates
2025-12-13 - club - ILT - male - 1501330 - Dubai Capitals vs Abu Dhabi Knight Riders
2025-12-12 - club - ILT - male - 1501329 - Gulf Giants vs Desert Vipers
2025-12-11 - club - ILT - male - 1501328 - Abu Dhabi Knight Riders vs MI Emirates
2025-12-10 - club - ILT - male - 1501327 - Sharjah Warriorz vs Gulf Giants
2025-12-09 - club - ILT - male - 1501326 - Desert Vipers vs MI Emirates
2025-12-08 - club - ILT - male - 1501325 - Gulf Giants vs Desert Vipers
2025-12-07 - club - ILT - male - 1501324 - Dubai Capitals vs Abu Dhabi Knight Riders
2025-12-07 - club - ILT - male - 1501323 - MI Emirates vs Sharjah Warriorz
2025-12-06 - club - ILT - male - 1501322 - Dubai Capitals vs Gulf Giants
2025-12-05 - club - ILT - male - 1501321 - Abu Dhabi Knight Riders vs Desert Vipers
2025-12-04 - club - ILT - male - 1501320 - MI Emirates vs Gulf Giants
2025-12-03 - club - ILT - male - 1501319 - Abu Dhabi Knight Riders vs Sharjah Warriorz
2025-12-02 - club - ILT - male - 1501318 - Dubai Capitals vs Desert Vipers
2025-02-09 - club - ILT - male - 1462206 - Desert Vipers vs Dubai Capitals
2025-02-07 - club - ILT - male - 1462205 - Sharjah Warriorz vs Desert Vipers
2025-02-06 - club - ILT - male - 1462204 - MI Emirates vs Sharjah Warriorz
2025-02-05 - club - ILT - male - 1462203 - Desert Vipers vs Dubai Capitals
2025-02-03 - club - ILT - male - 1462202 - Desert Vipers vs Dubai Capitals
2025-02-02 - club - ILT - male - 1462201 - Dubai Capitals vs Abu Dhabi Knight Riders
2025-02-02 - club - ILT - male - 1462200 - MI Emirates vs Sharjah Warriorz
2025-02-01 - club - ILT - male - 1462199 - Abu Dhabi Knight Riders vs Gulf Giants
2025-01-31 - club - ILT - male - 1462198 - Gulf Giants vs MI Emirates
2025-01-30 - club - ILT - male - 1462197 - Abu Dhabi Knight Riders vs Sharjah Warriorz
2025-01-29 - club - ILT - male - 1462196 - Gulf Giants vs Desert Vipers
2025-01-28 - club - ILT - male - 1462195 - Dubai Capitals vs Sharjah Warriorz
2025-01-27 - club - ILT - male - 1462194 - MI Emirates vs Desert Vipers
2025-01-26 - club - ILT - male - 1462193 - Sharjah Warriorz vs Gulf Giants
2025-01-26 - club - ILT - male - 1462192 - Abu Dhabi Knight Riders vs Dubai Capitals
2025-01-25 - club - ILT - male - 1462191 - MI Emirates vs Gulf Giants
2025-01-25 - club - ILT - male - 1462190 - Sharjah Warriorz vs Desert Vipers
2025-01-24 - club - ILT - male - 1462189 - Abu Dhabi Knight Riders vs MI Emirates
2025-01-23 - club - ILT - male - 1462188 - Gulf Giants vs Dubai Capitals
2025-01-22 - club - ILT - male - 1462187 - Sharjah Warriorz vs Desert Vipers
2025-01-21 - club - ILT - male - 1462186 - MI Emirates vs Abu Dhabi Knight Riders
2025-01-20 - club - ILT - male - 1462185 - Desert Vipers vs Dubai Capitals
2025-01-19 - club - ILT - male - 1462184 - Abu Dhabi Knight Riders vs Gulf Giants
2025-01-19 - club - ILT - male - 1462183 - Sharjah Warriorz vs MI Emirates
2025-01-18 - club - ILT - male - 1462182 - Dubai Capitals vs Gulf Giants
2025-01-18 - club - ILT - male - 1462181 - Desert Vipers vs Abu Dhabi Knight Riders
2025-01-17 - club - ILT - male - 1462180 - Dubai Capitals vs Sharjah Warriorz
2025-01-16 - club - ILT - male - 1462179 - MI Emirates vs Desert Vipers
2025-01-15 - club - ILT - male - 1462178 - Abu Dhabi Knight Riders vs Sharjah Warriorz
2025-01-14 - club - ILT - male - 1462177 - Gulf Giants vs Desert Vipers
2025-01-13 - club - ILT - male - 1462176 - MI Emirates vs Dubai Capitals
2025-01-12 - club - ILT - male - 1462175 - Gulf Giants vs Sharjah Warriorz
2025-01-12 - club - ILT - male - 1462174 - Abu Dhabi Knight Riders vs Desert Vipers
2025-01-11 - club - ILT - male - 1462173 - Dubai Capitals vs MI Emirates
2024-02-17 - club - ILT - male - 1406922 - MI Emirates vs Dubai Capitals
2024-02-15 - club - ILT - male - 1406921 - Gulf Giants vs Dubai Capitals
2024-02-14 - club - ILT - male - 1406919 - MI Emirates vs Gulf Giants
2024-02-13 - club - ILT - male - 1406920 - Dubai Capitals vs Abu Dhabi Knight Riders
2024-02-11 - club - ILT - male - 1406918 - Sharjah Warriors vs Desert Vipers
2024-02-10 - club - ILT - male - 1406917 - Dubai Capitals vs MI Emirates
2024-02-10 - club - ILT - male - 1406916 - Gulf Giants vs Abu Dhabi Knight Riders
2024-02-09 - club - ILT - male - 1406915 - Desert Vipers vs Dubai Capitals
2024-02-08 - club - ILT - male - 1406914 - Gulf Giants vs MI Emirates
2024-02-07 - club - ILT - male - 1406913 - Abu Dhabi Knight Riders vs Sharjah Warriors
2024-02-06 - club - ILT - male - 1406912 - Gulf Giants vs Dubai Capitals
2024-02-05 - club - ILT - male - 1406911 - Sharjah Warriors vs Abu Dhabi Knight Riders
2024-02-04 - club - ILT - male - 1406910 - Gulf Giants vs Sharjah Warriors
2024-02-04 - club - ILT - male - 1406909 - MI Emirates vs Desert Vipers
2024-02-03 - club - ILT - male - 1406908 - Abu Dhabi Knight Riders vs Dubai Capitals
2024-02-03 - club - ILT - male - 1406907 - Gulf Giants vs Desert Vipers
2024-02-02 - club - ILT - male - 1406906 - Sharjah Warriors vs MI Emirates
2024-02-01 - club - ILT - male - 1406905 - Desert Vipers vs Dubai Capitals
2024-01-31 - club - ILT - male - 1406904 - Gulf Giants vs Abu Dhabi Knight Riders
2024-01-30 - club - ILT - male - 1406903 - MI Emirates vs Desert Vipers
2024-01-29 - club - ILT - male - 1406902 - Dubai Capitals vs Sharjah Warriors
2024-01-28 - club - ILT - male - 1406901 - Sharjah Warriors vs Desert Vipers
2024-01-28 - club - ILT - male - 1406900 - Abu Dhabi Knight Riders vs MI Emirates
2024-01-27 - club - ILT - male - 1406899 - Dubai Capitals vs Gulf Giants
2024-01-27 - club - ILT - male - 1406898 - Desert Vipers vs Abu Dhabi Knight Riders
2024-01-26 - club - ILT - male - 1406897 - MI Emirates vs Sharjah Warriors
2024-01-25 - club - ILT - male - 1406896 - Abu Dhabi Knight Riders vs Dubai Capitals
2024-01-24 - club - ILT - male - 1406895 - Gulf Giants vs Desert Vipers
2024-01-23 - club - ILT - male - 1406894 - Abu Dhabi Knight Riders vs MI Emirates
2024-01-22 - club - ILT - male - 1406893 - Dubai Capitals vs Sharjah Warriors
2024-01-21 - club - ILT - male - 1406892 - MI Emirates vs Gulf Giants
2024-01-21 - club - ILT - male - 1406891 - Desert Vipers vs Abu Dhabi Knight Riders
2024-01-20 - club - ILT - male - 1406890 - MI Emirates vs Dubai Capitals
2024-01-19 - club - ILT - male - 1406889 - Gulf Giants vs Sharjah Warriors
2023-02-12 - club - ILT - male - 1346949 - Desert Vipers vs Gulf Giants
2023-02-10 - club - ILT - male - 1346948 - MI Emirates vs Gulf Giants
2023-02-09 - club - ILT - male - 1346947 - Dubai Capitals vs MI Emirates
2023-02-08 - club - ILT - male - 1346946 - Desert Vipers vs Gulf Giants
2023-02-06 - club - ILT - male - 1346945 - Sharjah Warriors vs Gulf Giants
2023-02-05 - club - ILT - male - 1346944 - MI Emirates vs Dubai Capitals
2023-02-04 - club - ILT - male - 1346943 - Sharjah Warriors vs Abu Dhabi Knight Riders
2023-02-04 - club - ILT - male - 1346942 - Gulf Giants vs Desert Vipers
2023-02-03 - club - ILT - male - 1346941 - MI Emirates vs Abu Dhabi Knight Riders
2023-02-02 - club - ILT - male - 1346940 - Desert Vipers vs Dubai Capitals
2023-02-01 - club - ILT - male - 1346939 - MI Emirates vs Gulf Giants
2023-01-31 - club - ILT - male - 1346938 - Desert Vipers vs Sharjah Warriors
2023-01-30 - club - ILT - male - 1346937 - Abu Dhabi Knight Riders vs Dubai Capitals
2023-01-29 - club - ILT - male - 1346936 - MI Emirates vs Desert Vipers
2023-01-28 - club - ILT - male - 1346935 - Desert Vipers vs Dubai Capitals
2023-01-28 - club - ILT - male - 1346934 - Abu Dhabi Knight Riders vs Sharjah Warriors
2023-01-26 - club - ILT - male - 1346932 - Dubai Capitals vs Sharjah Warriors
2023-01-24 - club - ILT - male - 1346930 - MI Emirates vs Desert Vipers
2023-01-23 - club - ILT - male - 1346929 - Sharjah Warriors vs Gulf Giants
2023-01-22 - club - ILT - male - 1346928 - Dubai Capitals vs MI Emirates
2023-01-22 - club - ILT - male - 1346927 - Desert Vipers vs Gulf Giants
2023-01-21 - club - ILT - male - 1346926 - Abu Dhabi Knight Riders vs MI Emirates
2023-01-21 - club - ILT - male - 1346925 - Dubai Capitals vs Sharjah Warriors
2023-01-20 - club - ILT - male - 1346924 - Desert Vipers vs Abu Dhabi Knight Riders
2023-01-19 - club - ILT - male - 1346923 - Gulf Giants vs Dubai Capitals
2023-01-18 - club - ILT - male - 1346922 - Abu Dhabi Knight Riders vs Desert Vipers
2023-01-17 - club - ILT - male - 1346921 - Sharjah Warriors vs MI Emirates
2023-01-16 - club - ILT - male - 1346920 - Dubai Capitals vs Gulf Giants
2023-01-15 - club - ILT - male - 1346919 - Sharjah Warriors vs Desert Vipers
2023-01-15 - club - ILT - male - 1346918 - Abu Dhabi Knight Riders vs Gulf Giants
2023-01-14 - club - ILT - male - 1346917 - MI Emirates vs Sharjah Warriors
2023-01-13 - club - ILT - male - 1346916 - Dubai Capitals vs Abu Dhabi Knight Riders

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
