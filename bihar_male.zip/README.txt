This zip archive contains data files from Cricsheet in YAML format. This
archive contains 24 Bihar matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/bihar_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2022-10-22 - club - SMA - male - 1333040 - Bihar vs Gujarat
2022-10-18 - club - SMA - male - 1333006 - Bihar vs Andhra
2022-10-12 - club - SMA - male - 1332952 - Nagaland vs Bihar
2021-11-09 - club - SMA - male - 1280283 - Bihar vs Gujarat
2021-11-08 - club - SMA - male - 1280266 - Bihar vs Madhya Pradesh
2021-11-06 - club - SMA - male - 1280246 - Bihar vs Assam
2021-11-05 - club - SMA - male - 1280228 - Bihar vs Kerala
2021-11-04 - club - SMA - male - 1280208 - Bihar vs Railways
2021-01-19 - club - SMA - male - 1244399 - Mizoram vs Bihar
2021-01-17 - club - SMA - male - 1244378 - Manipur vs Bihar
2021-01-15 - club - SMA - male - 1244359 - Meghalaya vs Bihar
2021-01-13 - club - SMA - male - 1244342 - Sikkim vs Bihar
2021-01-11 - club - SMA - male - 1244323 - Bihar vs Arunachal Pradesh
2019-11-17 - club - SMA - male - 1205822 - Bihar vs Uttarakhand
2019-11-15 - club - SMA - male - 1205814 - Bihar vs Karnataka
2019-11-14 - club - SMA - male - 1205796 - Bihar vs Baroda
2019-11-11 - club - SMA - male - 1205751 - Services vs Bihar
2019-11-09 - club - SMA - male - 1205733 - Goa vs Bihar
2019-11-08 - club - SMA - male - 1205715 - Bihar vs Andhra
2019-02-28 - club - SMA - male - 1157179 - Meghalaya vs Bihar
2019-02-27 - club - SMA - male - 1157162 - Gujarat vs Bihar
2019-02-25 - club - SMA - male - 1157146 - Bihar vs Himachal
2019-02-24 - club - SMA - male - 1157130 - Bihar vs Tamil Nadu
2019-02-22 - club - SMA - male - 1157113 - Bihar vs Vidarbha
