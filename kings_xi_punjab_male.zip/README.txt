This zip archive contains data files from Cricsheet in YAML format. This
archive contains 190 Kings XI Punjab matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/kings_xi_punjab_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2020-11-01 - club - IPL - male - 1216506 - Kings XI Punjab vs Chennai Super Kings
2020-10-30 - club - IPL - male - 1216537 - Kings XI Punjab vs Rajasthan Royals
2020-10-26 - club - IPL - male - 1216520 - Kolkata Knight Riders vs Kings XI Punjab
2020-10-24 - club - IPL - male - 1216498 - Kings XI Punjab vs Sunrisers Hyderabad
2020-10-20 - club - IPL - male - 1216546 - Delhi Capitals vs Kings XI Punjab
2020-10-18 - club - IPL - male - 1216517 - Mumbai Indians vs Kings XI Punjab
2020-10-15 - club - IPL - male - 1216531 - Royal Challengers Bangalore vs Kings XI Punjab
2020-10-10 - club - IPL - male - 1216523 - Kolkata Knight Riders vs Kings XI Punjab
2020-10-08 - club - IPL - male - 1216542 - Sunrisers Hyderabad vs Kings XI Punjab
2020-10-04 - club - IPL - male - 1216513 - Kings XI Punjab vs Chennai Super Kings
2020-10-01 - club - IPL - male - 1216503 - Mumbai Indians vs Kings XI Punjab
2020-09-27 - club - IPL - male - 1216527 - Kings XI Punjab vs Rajasthan Royals
2020-09-24 - club - IPL - male - 1216510 - Kings XI Punjab vs Royal Challengers Bangalore
2020-09-20 - club - IPL - male - 1216493 - Delhi Capitals vs Kings XI Punjab
2019-05-05 - club - IPL - male - 1178430 - Kings XI Punjab vs Chennai Super Kings
2019-05-03 - club - IPL - male - 1178427 - Kings XI Punjab vs Kolkata Knight Riders
2019-04-29 - club - IPL - male - 1178423 - Sunrisers Hyderabad vs Kings XI Punjab
2019-04-24 - club - IPL - male - 1178417 - Royal Challengers Bangalore vs Kings XI Punjab
2019-04-20 - club - IPL - male - 1178412 - Delhi Capitals vs Kings XI Punjab
2019-04-16 - club - IPL - male - 1178407 - Kings XI Punjab vs Rajasthan Royals
2019-04-13 - club - IPL - male - 1178403 - Kings XI Punjab vs Royal Challengers Bangalore
2019-04-10 - club - IPL - male - 1178399 - Mumbai Indians vs Kings XI Punjab
2019-04-08 - club - IPL - male - 1178397 - Kings XI Punjab vs Sunrisers Hyderabad
2019-04-06 - club - IPL - male - 1178393 - Chennai Super Kings vs Kings XI Punjab
2019-04-01 - club - IPL - male - 1175368 - Kings XI Punjab vs Delhi Capitals
2019-03-30 - club - IPL - male - 1175364 - Kings XI Punjab vs Mumbai Indians
2019-03-27 - club - IPL - male - 1175361 - Kolkata Knight Riders vs Kings XI Punjab
2019-03-25 - club - IPL - male - 1175359 - Rajasthan Royals vs Kings XI Punjab
2018-05-20 - club - IPL - male - 1136616 - Chennai Super Kings vs Kings XI Punjab
2018-05-16 - club - IPL - male - 1136610 - Mumbai Indians vs Kings XI Punjab
2018-05-14 - club - IPL - male - 1136608 - Kings XI Punjab vs Royal Challengers Bangalore
2018-05-12 - club - IPL - male - 1136604 - Kings XI Punjab vs Kolkata Knight Riders
2018-05-08 - club - IPL - male - 1136600 - Rajasthan Royals vs Kings XI Punjab
2018-05-06 - club - IPL - male - 1136598 - Kings XI Punjab vs Rajasthan Royals
2018-05-04 - club - IPL - male - 1136594 - Kings XI Punjab vs Mumbai Indians
2018-04-26 - club - IPL - male - 1136585 - Sunrisers Hyderabad vs Kings XI Punjab
2018-04-23 - club - IPL - male - 1136582 - Delhi Daredevils vs Kings XI Punjab
2018-04-21 - club - IPL - male - 1136578 - Kolkata Knight Riders vs Kings XI Punjab
2018-04-19 - club - IPL - male - 1136576 - Kings XI Punjab vs Sunrisers Hyderabad
2018-04-15 - club - IPL - male - 1136572 - Kings XI Punjab vs Chennai Super Kings
2018-04-13 - club - IPL - male - 1136568 - Royal Challengers Bangalore vs Kings XI Punjab
2018-04-08 - club - IPL - male - 1136562 - Kings XI Punjab vs Delhi Daredevils
2017-05-14 - club - IPL - male - 1082645 - Rising Pune Supergiant vs Kings XI Punjab
2017-05-11 - club - IPL - male - 1082641 - Mumbai Indians vs Kings XI Punjab
2017-05-09 - club - IPL - male - 1082639 - Kings XI Punjab vs Kolkata Knight Riders
2017-05-07 - club - IPL - male - 1082637 - Kings XI Punjab vs Gujarat Lions
2017-05-05 - club - IPL - male - 1082633 - Royal Challengers Bangalore vs Kings XI Punjab
2017-04-30 - club - IPL - male - 1082626 - Kings XI Punjab vs Delhi Daredevils
2017-04-28 - club - IPL - male - 1082623 - Kings XI Punjab vs Sunrisers Hyderabad
2017-04-23 - club - IPL - male - 1082616 - Gujarat Lions vs Kings XI Punjab
2017-04-20 - club - IPL - male - 1082612 - Kings XI Punjab vs Mumbai Indians
2017-04-17 - club - IPL - male - 1082609 - Sunrisers Hyderabad vs Kings XI Punjab
2017-04-15 - club - IPL - male - 1082605 - Delhi Daredevils vs Kings XI Punjab
2017-04-13 - club - IPL - male - 1082601 - Kolkata Knight Riders vs Kings XI Punjab
2017-04-10 - club - IPL - male - 1082598 - Kings XI Punjab vs Royal Challengers Bangalore
2017-04-08 - club - IPL - male - 1082594 - Kings XI Punjab vs Rising Pune Supergiant
2016-05-21 - club - IPL - male - 981005 - Rising Pune Supergiants vs Kings XI Punjab
2016-05-18 - club - IPL - male - 980999 - Royal Challengers Bangalore vs Kings XI Punjab
2016-05-15 - club - IPL - male - 980991 - Kings XI Punjab vs Sunrisers Hyderabad
2016-05-13 - club - IPL - male - 980985 - Mumbai Indians vs Kings XI Punjab
2016-05-09 - club - IPL - male - 980977 - Kings XI Punjab vs Royal Challengers Bangalore
2016-05-07 - club - IPL - male - 980971 - Kings XI Punjab vs Delhi Daredevils
2016-05-04 - club - IPL - male - 980963 - Kolkata Knight Riders vs Kings XI Punjab
2016-05-01 - club - IPL - male - 980955 - Gujarat Lions vs Kings XI Punjab
2016-04-25 - club - IPL - male - 980941 - Kings XI Punjab vs Mumbai Indians
2016-04-23 - club - IPL - male - 980935 - Sunrisers Hyderabad vs Kings XI Punjab
2016-04-19 - club - IPL - male - 980925 - Kings XI Punjab vs Kolkata Knight Riders
2016-04-17 - club - IPL - male - 980919 - Kings XI Punjab vs Rising Pune Supergiants
2016-04-15 - club - IPL - male - 980913 - Delhi Daredevils vs Kings XI Punjab
2016-04-11 - club - IPL - male - 980905 - Kings XI Punjab vs Gujarat Lions
2015-05-16 - club - IPL - male - 829809 - Kings XI Punjab vs Chennai Super Kings
2015-05-13 - club - IPL - male - 829803 - Kings XI Punjab vs Royal Challengers Bangalore
2015-05-11 - club - IPL - male - 829799 - Sunrisers Hyderabad vs Kings XI Punjab
2015-05-09 - club - IPL - male - 829791 - Kolkata Knight Riders vs Kings XI Punjab
2015-05-06 - club - IPL - male - 829785 - Royal Challengers Bangalore vs Kings XI Punjab
2015-05-03 - club - IPL - male - 829775 - Kings XI Punjab vs Mumbai Indians
2015-05-01 - club - IPL - male - 829767 - Delhi Daredevils vs Kings XI Punjab
2015-04-27 - club - IPL - male - 829759 - Kings XI Punjab vs Sunrisers Hyderabad
2015-04-25 - club - IPL - male - 829753 - Chennai Super Kings vs Kings XI Punjab
2015-04-21 - club - IPL - male - 829741 - Rajasthan Royals vs Kings XI Punjab
2015-04-18 - club - IPL - male - 829733 - Kings XI Punjab vs Kolkata Knight Riders
2015-04-15 - club - IPL - male - 829725 - Kings XI Punjab vs Delhi Daredevils
2015-04-12 - club - IPL - male - 829717 - Mumbai Indians vs Kings XI Punjab
2015-04-10 - club - IPL - male - 829709 - Kings XI Punjab vs Rajasthan Royals
2014-06-01 - club - IPL - male - 734049 - Kolkata Knight Riders vs Kings XI Punjab
2014-05-30 - club - IPL - male - 734047 - Chennai Super Kings vs Kings XI Punjab
2014-05-27 - club - IPL - male - 734043 - Kings XI Punjab vs Kolkata Knight Riders
2014-05-25 - club - IPL - male - 734039 - Kings XI Punjab vs Delhi Daredevils
2014-05-23 - club - IPL - male - 734033 - Kings XI Punjab vs Rajasthan Royals
2014-05-21 - club - IPL - male - 734025 - Kings XI Punjab vs Mumbai Indians
2014-05-19 - club - IPL - male - 734019 - Delhi Daredevils vs Kings XI Punjab
2014-05-14 - club - IPL - male - 734007 - Sunrisers Hyderabad vs Kings XI Punjab
2014-05-11 - club - IPL - male - 733997 - Kings XI Punjab vs Kolkata Knight Riders
2014-05-09 - club - IPL - male - 733991 - Royal Challengers Bangalore vs Kings XI Punjab
2014-05-07 - club - IPL - male - 733987 - Kings XI Punjab vs Chennai Super Kings
2014-05-03 - club - IPL - male - 733973 - Mumbai Indians vs Kings XI Punjab
2014-04-28 - club - IPL - male - 729313 - Kings XI Punjab vs Royal Challengers Bangalore
2014-04-26 - club - IPL - male - 729307 - Kolkata Knight Riders vs Kings XI Punjab
2014-04-22 - club - IPL - male - 729295 - Kings XI Punjab vs Sunrisers Hyderabad
2014-04-20 - club - IPL - male - 729291 - Rajasthan Royals vs Kings XI Punjab
2014-04-18 - club - IPL - male - 729283 - Chennai Super Kings vs Kings XI Punjab
2013-05-18 - club - IPL - male - 598066 - Kings XI Punjab vs Mumbai Indians
2013-05-16 - club - IPL - male - 598028 - Kings XI Punjab vs Delhi Daredevils
2013-05-14 - club - IPL - male - 598045 - Royal Challengers Bangalore vs Kings XI Punjab
2013-05-11 - club - IPL - male - 598056 - Kings XI Punjab vs Sunrisers Hyderabad
2013-05-09 - club - IPL - male - 598052 - Kings XI Punjab vs Rajasthan Royals
2013-05-06 - club - IPL - male - 598064 - Kings XI Punjab vs Royal Challengers Bangalore
2013-05-02 - club - IPL - male - 598041 - Chennai Super Kings vs Kings XI Punjab
2013-04-29 - club - IPL - male - 598037 - Mumbai Indians vs Kings XI Punjab
2013-04-26 - club - IPL - male - 598031 - Kolkata Knight Riders vs Kings XI Punjab
2013-04-23 - club - IPL - male - 598059 - Delhi Daredevils vs Kings XI Punjab
2013-04-21 - club - IPL - male - 598025 - Kings XI Punjab vs Pune Warriors
2013-04-19 - club - IPL - male - 598021 - Sunrisers Hyderabad vs Kings XI Punjab
2013-04-16 - club - IPL - male - 598016 - Kings XI Punjab vs Kolkata Knight Riders
2013-04-14 - club - IPL - male - 598014 - Rajasthan Royals vs Kings XI Punjab
2013-04-10 - club - IPL - male - 598007 - Kings XI Punjab vs Chennai Super Kings
2013-04-07 - club - IPL - male - 598003 - Pune Warriors vs Kings XI Punjab
2012-05-19 - club - IPL - male - 548374 - Kings XI Punjab vs Delhi Daredevils
2012-05-17 - club - IPL - male - 548371 - Kings XI Punjab vs Chennai Super Kings
2012-05-15 - club - IPL - male - 548369 - Delhi Daredevils vs Kings XI Punjab
2012-05-13 - club - IPL - male - 548366 - Kings XI Punjab vs Deccan Chargers
2012-05-08 - club - IPL - male - 548359 - Deccan Chargers vs Kings XI Punjab
2012-05-05 - club - IPL - male - 548354 - Kings XI Punjab vs Rajasthan Royals
2012-05-02 - club - IPL - male - 548350 - Royal Challengers Bangalore vs Kings XI Punjab
2012-04-28 - club - IPL - male - 548343 - Chennai Super Kings vs Kings XI Punjab
2012-04-25 - club - IPL - male - 548339 - Kings XI Punjab vs Mumbai Indians
2012-04-22 - club - IPL - male - 548334 - Mumbai Indians vs Kings XI Punjab
2012-04-20 - club - IPL - male - 548331 - Kings XI Punjab vs Royal Challengers Bangalore
2012-04-18 - club - IPL - male - 548328 - Kings XI Punjab vs Kolkata Knight Riders
2012-04-15 - club - IPL - male - 548323 - Kolkata Knight Riders vs Kings XI Punjab
2012-04-12 - club - IPL - male - 548319 - Kings XI Punjab vs Pune Warriors
2012-04-08 - club - IPL - male - 548313 - Pune Warriors vs Kings XI Punjab
2012-04-06 - club - IPL - male - 548309 - Rajasthan Royals vs Kings XI Punjab
2011-05-21 - club - IPL - male - 501264 - Kings XI Punjab vs Deccan Chargers
2011-05-17 - club - IPL - male - 501260 - Kings XI Punjab vs Royal Challengers Bangalore
2011-05-15 - club - IPL - male - 501257 - Kings XI Punjab vs Delhi Daredevils
2011-05-13 - club - IPL - male - 501254 - Kochi Tuskers Kerala vs Kings XI Punjab
2011-05-10 - club - IPL - male - 501251 - Kings XI Punjab vs Mumbai Indians
2011-05-08 - club - IPL - male - 501248 - Kings XI Punjab vs Pune Warriors
2011-05-06 - club - IPL - male - 501244 - Royal Challengers Bangalore vs Kings XI Punjab
2011-05-02 - club - IPL - male - 501237 - Mumbai Indians vs Kings XI Punjab
2011-04-30 - club - IPL - male - 501234 - Kolkata Knight Riders vs Kings XI Punjab
2011-04-23 - club - IPL - male - 501223 - Delhi Daredevils vs Kings XI Punjab
2011-04-21 - club - IPL - male - 501220 - Kings XI Punjab vs Rajasthan Royals
2011-04-16 - club - IPL - male - 501212 - Deccan Chargers vs Kings XI Punjab
2011-04-13 - club - IPL - male - 501206 - Kings XI Punjab vs Chennai Super Kings
2011-04-10 - club - IPL - male - 501202 - Pune Warriors vs Kings XI Punjab
2010-04-18 - club - IPL - male - 419159 - Kings XI Punjab vs Chennai Super Kings
2010-04-16 - club - IPL - male - 419156 - Kings XI Punjab vs Deccan Chargers
2010-04-11 - club - IPL - male - 419149 - Delhi Daredevils vs Kings XI Punjab
2010-04-09 - club - IPL - male - 419146 - Kings XI Punjab vs Mumbai Indians
2010-04-07 - club - IPL - male - 419143 - Rajasthan Royals vs Kings XI Punjab
2010-04-04 - club - IPL - male - 419139 - Kolkata Knight Riders vs Kings XI Punjab
2010-04-02 - club - IPL - male - 419136 - Kings XI Punjab vs Royal Challengers Bangalore
2010-03-30 - club - IPL - male - 419132 - Mumbai Indians vs Kings XI Punjab
2010-03-27 - club - IPL - male - 419127 - Kings XI Punjab vs Kolkata Knight Riders
2010-03-24 - club - IPL - male - 419124 - Kings XI Punjab vs Rajasthan Royals
2010-03-21 - club - IPL - male - 419121 - Chennai Super Kings vs Kings XI Punjab
2010-03-19 - club - IPL - male - 419117 - Deccan Chargers vs Kings XI Punjab
2010-03-16 - club - IPL - male - 419112 - Royal Challengers Bangalore vs Kings XI Punjab
2010-03-13 - club - IPL - male - 419108 - Kings XI Punjab vs Delhi Daredevils
2009-05-20 - club - IPL - male - 392234 - Chennai Super Kings vs Kings XI Punjab
2009-05-17 - club - IPL - male - 392229 - Deccan Chargers vs Kings XI Punjab
2009-05-15 - club - IPL - male - 392226 - Delhi Daredevils vs Kings XI Punjab
2009-05-12 - club - IPL - male - 392222 - Kings XI Punjab vs Mumbai Indians
2009-05-09 - club - IPL - male - 392216 - Deccan Chargers vs Kings XI Punjab
2009-05-07 - club - IPL - male - 392214 - Chennai Super Kings vs Kings XI Punjab
2009-05-05 - club - IPL - male - 392210 - Kings XI Punjab vs Rajasthan Royals
2009-05-03 - club - IPL - male - 392207 - Kings XI Punjab vs Kolkata Knight Riders
2009-05-01 - club - IPL - male - 392204 - Royal Challengers Bangalore vs Kings XI Punjab
2009-04-29 - club - IPL - male - 392200 - Kings XI Punjab vs Mumbai Indians
2009-04-26 - club - IPL - male - 392195 - Kings XI Punjab vs Rajasthan Royals
2009-04-24 - club - IPL - male - 392191 - Royal Challengers Bangalore vs Kings XI Punjab
2009-04-21 - club - IPL - male - 392186 - Kings XI Punjab vs Kolkata Knight Riders
2009-04-19 - club - IPL - male - 392183 - Delhi Daredevils vs Kings XI Punjab
2008-05-31 - club - IPL - male - 336039 - Chennai Super Kings vs Kings XI Punjab
2008-05-28 - club - IPL - male - 336019 - Kings XI Punjab vs Rajasthan Royals
2008-05-25 - club - IPL - male - 336035 - Kolkata Knight Riders vs Kings XI Punjab
2008-05-23 - club - IPL - male - 336031 - Kings XI Punjab vs Deccan Chargers
2008-05-21 - club - IPL - male - 336028 - Mumbai Indians vs Kings XI Punjab
2008-05-17 - club - IPL - male - 336022 - Delhi Daredevils vs Kings XI Punjab
2008-05-12 - club - IPL - male - 336016 - Kings XI Punjab vs Royal Challengers Bangalore
2008-05-10 - club - IPL - male - 336013 - Chennai Super Kings vs Kings XI Punjab
2008-05-05 - club - IPL - male - 336006 - Royal Challengers Bangalore vs Kings XI Punjab
2008-05-03 - club - IPL - male - 336003 - Kings XI Punjab vs Kolkata Knight Riders
2008-05-01 - club - IPL - male - 335999 - Deccan Chargers vs Kings XI Punjab
2008-04-27 - club - IPL - male - 335995 - Kings XI Punjab vs Delhi Daredevils
2008-04-25 - club - IPL - male - 335991 - Kings XI Punjab vs Mumbai Indians
2008-04-21 - club - IPL - male - 335987 - Rajasthan Royals vs Kings XI Punjab
2008-04-19 - club - IPL - male - 335983 - Kings XI Punjab vs Chennai Super Kings
