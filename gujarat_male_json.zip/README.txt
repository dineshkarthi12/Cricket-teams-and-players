This zip archive contains data files from Cricsheet in JSON format. This
archive contains 44 Gujarat matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/gujarat_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-31 - club - SMA - male - 1383560 - Gujarat vs Uttar Pradesh
2023-10-25 - club - SMA - male - 1383534 - Railways vs Gujarat
2023-10-19 - club - SMA - male - 1383480 - Gujarat vs Goa
2023-10-17 - club - SMA - male - 1383461 - Saurashtra vs Gujarat
2022-10-22 - club - SMA - male - 1333040 - Bihar vs Gujarat
2022-10-20 - club - SMA - male - 1333022 - Andhra vs Gujarat
2022-10-16 - club - SMA - male - 1332986 - Gujarat vs Saurashtra
2022-10-14 - club - SMA - male - 1332968 - Baroda vs Gujarat
2021-11-18 - club - SMA - male - 1280299 - Hyderabad (India) vs Gujarat
2021-11-09 - club - SMA - male - 1280283 - Bihar vs Gujarat
2021-11-06 - club - SMA - male - 1280247 - Gujarat vs Madhya Pradesh
2021-11-05 - club - SMA - male - 1280227 - Gujarat vs Assam
2021-11-04 - club - SMA - male - 1280209 - Kerala vs Gujarat
2021-01-18 - club - SMA - male - 1244388 - Baroda vs Gujarat
2021-01-16 - club - SMA - male - 1244371 - Chhattisgarh vs Gujarat
2021-01-14 - club - SMA - male - 1244351 - Himachal vs Gujarat
2021-01-12 - club - SMA - male - 1244332 - Gujarat vs Uttarakhand
2021-01-10 - club - SMA - male - 1244312 - Gujarat vs Maharashtra
2019-11-18 - club - SMA - male - 1205741 - Jammu & Kashmir vs Gujarat
2019-11-15 - club - SMA - male - 1205813 - Odisha vs Gujarat
2019-11-14 - club - SMA - male - 1205795 - Sikkim vs Gujarat
2019-11-11 - club - SMA - male - 1205759 - Saurashtra vs Gujarat
2019-03-12 - club - SMA - male - 1175043 - Gujarat vs Bengal
2019-03-11 - club - SMA - male - 1175037 - Railways vs Gujarat
2019-03-10 - club - SMA - male - 1175036 - Gujarat vs Maharashtra
2019-03-08 - club - SMA - male - 1175025 - Jharkhand vs Gujarat
2019-03-02 - club - SMA - male - 1157196 - Gujarat vs Vidarbha
2019-02-27 - club - SMA - male - 1157162 - Gujarat vs Bihar
2019-02-25 - club - SMA - male - 1157145 - Tamil Nadu vs Gujarat
2019-02-24 - club - SMA - male - 1157128 - Gujarat vs Himachal
2019-02-21 - club - SMA - male - 1157094 - Gujarat vs Meghalaya
2018-01-13 - club - SMA - male - 1130705 - Saurashtra vs Gujarat
2018-01-10 - club - SMA - male - 1130683 - Baroda vs Gujarat
2018-01-08 - club - SMA - male - 1130673 - Gujarat vs Mumbai
2018-01-07 - club - SMA - male - 1130662 - Gujarat vs Maharashtra
2016-01-18 - club - SMA - male - 955063 - Jharkhand vs Gujarat
2016-01-16 - club - SMA - male - 955059 - Gujarat vs Uttar Pradesh
2016-01-15 - club - SMA - male - 955047 - Delhi vs Gujarat
2016-01-10 - club - SMA - male - 902225 - Haryana vs Gujarat
2016-01-07 - club - SMA - male - 902185 - Gujarat vs Tamil Nadu
2016-01-06 - club - SMA - male - 902161 - Bengal vs Gujarat
2016-01-04 - club - SMA - male - 902137 - Hyderabad (India) vs Gujarat
2016-01-03 - club - SMA - male - 902111 - Gujarat vs Vidarbha
2016-01-02 - club - SMA - male - 902087 - Gujarat vs Himachal
