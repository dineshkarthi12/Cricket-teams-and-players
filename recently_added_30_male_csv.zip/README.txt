All recently added Men's match data in CSV format
=================================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the IPL data from YAML into this CSV format. This then expanded
to include international T20s, for both women and men, before, finally,
expanding again to cover all matches we provide.

This particular zip folder contains the CSV data for...
  All recently added Men's matches
...for which we have data, and is loosely based on the format that Retrosheet
uses for baseball, with some suitable hacks built in.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the newer "Ashwin" format?
Ideally I'd like to settle on a single CSV format so what should be kept
from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_original/
but the following is a brief summary of the details...

Each file has a 'version', multiple 'info' lines, and multiple 'ball' lines.
'version' is just 1.8.0 for now, and will change as I make changes.
The 'info' entries should be fairly self-explanatory but feel free to ask on
Mastodon (@cricsheet@deeden.co.uk) if you're unsure. If you look carefully
you may see some slight hints as to some data we'll be including in the full
data files in the future.

Each 'ball' line has the following fields:

  * The word 'ball' to identify it as such
  * Innings number, starting from 1
  * Over and ball
  * Batting team name
  * Batsman
  * Non-striker
  * Bowler
  * Runs-off-bat
  * Extras
  * Wides
  * No-balls
  * Byes
  * Leg-byes
  * Penalty
  * Kind of wicket, if any
  * Dismissed played, if there was a wicket

Matches included in this archive
--------------------------------

2026-09-17 - international - T20 - male - 1552923 - Kenya vs Botswana
2026-09-17 - international - T20 - male - 1552922 - Uganda vs Rwanda
2026-09-17 - international - T20 - male - 1552897 - United Arab Emirates vs Malaysia
2026-09-17 - international - T20 - male - 1496586 - Sri Lanka vs England
2026-09-17 - club - ETPL - male - 1547901 - Rotterdam Dockers vs Dublin Guardians
2026-09-17 - club - ETPL - male - 1547900 - Belfast Wolves vs Edinburgh Castle Rockers
2026-09-16 - international - T20 - male - 1552921 - Sierra Leone vs Rwanda
2026-09-16 - international - T20 - male - 1552920 - Botswana vs Uganda
2026-09-16 - international - T20 - male - 1552896 - Malaysia vs United Arab Emirates
2026-09-16 - club - MCT - male - 1535542 - Sinhalese Sports Club vs Tamil Union Cricket and Athletic Club
2026-09-16 - club - ETPL - male - 1547899 - Glasgow Cosmic vs Amsterdam Flames
2026-09-16 - club - CPL - male - 1534214 - Barbados Tridents vs Jamaica Kingsmen
2026-09-15 - international - T20 - male - 1552919 - Kenya vs Rwanda
2026-09-15 - international - T20 - male - 1552918 - Sierra Leone vs Uganda
2026-09-15 - international - T20 - male - 1496585 - England vs Sri Lanka
2026-09-15 - international - ODI - male - 1530203 - Australia vs Zimbabwe
2026-09-15 - club - ETPL - male - 1547898 - Rotterdam Dockers vs Edinburgh Castle Rockers
2026-09-15 - club - ETPL - male - 1547897 - Amsterdam Flames vs Dublin Guardians
2026-09-15 - club - CCH - male - 1513447 - Lancashire vs Kent
2026-09-15 - club - CCH - male - 1513386 - Essex vs Warwickshire
2026-09-14 - international - T20 - male - 1552895 - Malaysia vs United Arab Emirates
2026-09-13 - international - T20 - male - 1552917 - Rwanda vs Botswana
2026-09-13 - international - T20 - male - 1552916 - Sierra Leone vs Kenya
2026-09-13 - international - ODI - male - 1549533 - Namibia vs South Africa
2026-09-13 - club - MCT - male - 1535541 - Sinhalese Sports Club vs Nondescripts Cricket Club
2026-09-13 - club - MCT - male - 1535540 - Tamil Union Cricket and Athletic Club vs Colombo Cricket Club
2026-09-13 - club - ETPL - male - 1547896 - Belfast Wolves vs Glasgow Cosmic
2026-09-13 - club - ETPL - male - 1547895 - Edinburgh Castle Rockers vs Amsterdam Flames
2026-09-13 - club - CPL - male - 1534213 - Guyana Amazon Warriors vs Barbados Tridents
2026-09-12 - international - T20 - male - 1552915 - Botswana vs Sierra Leone
2026-09-12 - international - T20 - male - 1552914 - Uganda vs Kenya
2026-09-12 - international - ODI - male - 1549969 - Nepal vs United Arab Emirates
2026-09-12 - club - ETPL - male - 1547894 - Dublin Guardians vs Glasgow Cosmic
2026-09-12 - club - ETPL - male - 1547893 - Belfast Wolves vs Rotterdam Dockers
2026-09-12 - club - CPL - male - 1534212 - Jamaica Kingsmen vs Barbados Tridents
2026-09-11 - international - T20 - male - 1552913 - Botswana vs Kenya
2026-09-11 - international - T20 - male - 1552912 - Uganda vs Rwanda
2026-09-11 - international - ODI - male - 1549532 - South Africa vs Namibia
2026-09-11 - club - MCL - male - 1547446 - Moors Sports Club vs Sinhalese Sports Club
2026-09-11 - club - ETPL - male - 1547892 - Edinburgh Castle Rockers vs Dublin Guardians
2026-09-11 - club - CPL - male - 1534211 - Trinbago Knight Riders vs Guyana Amazon Warriors
2026-09-10 - international - T20 - male - 1552911 - Rwanda vs Sierra Leone
2026-09-10 - international - T20 - male - 1552910 - Botswana vs Uganda
2026-09-10 - international - ODI - male - 1549966 - Nepal vs Oman
2026-09-10 - club - ETPL - male - 1547891 - Amsterdam Flames vs Belfast Wolves
2026-09-10 - club - ETPL - male - 1547890 - Rotterdam Dockers vs Glasgow Cosmic
2026-09-10 - club - CPL - male - 1534210 - St Kitts and Nevis Patriots vs Barbados Tridents
2026-09-09 - international - Test - male - 1496584 - Pakistan vs England
2026-09-09 - international - T20 - male - 1552909 - Rwanda vs Kenya
2026-09-09 - international - T20 - male - 1552908 - Uganda vs Sierra Leone
2026-09-09 - international - ODI - male - 1549531 - South Africa vs Namibia
2026-09-09 - club - MCT - male - 1535539 - Colombo Cricket Club vs Ace Capital Cricket Club
2026-09-09 - club - MCT - male - 1535538 - Moors Sports Club vs Nondescripts Cricket Club
2026-09-09 - club - MCT - male - 1535537 - Sinhalese Sports Club vs Police Sports Club
2026-09-09 - club - MCT - male - 1535536 - Tamil Union Cricket and Athletic Club vs Panadura Sports Club
2026-09-09 - club - ETPL - male - 1547889 - Belfast Wolves vs Dublin Guardians
2026-09-09 - club - CPL - male - 1534209 - St Lucia Kings vs Guyana Amazon Warriors
2026-09-08 - international - T20 - male - 1552907 - Kenya vs Sierra Leone
2026-09-08 - international - T20 - male - 1552906 - Rwanda vs Botswana
2026-09-08 - international - ODI - male - 1549965 - United Arab Emirates vs Oman
2026-09-08 - club - CPL - male - 1534208 - Antigua and Barbuda Falcons vs Guyana Amazon Warriors
2026-09-08 - club - CCH - male - 1513443 - Gloucestershire vs Lancashire
2026-09-08 - club - CCH - male - 1513442 - Durham vs Middlesex
2026-09-08 - club - CCH - male - 1513441 - Worcestershire vs Northamptonshire
2026-09-08 - club - CCH - male - 1513440 - Derbyshire vs Kent
2026-09-08 - club - CCH - male - 1513385 - Somerset vs Leicestershire
2026-09-08 - club - CCH - male - 1513384 - Sussex vs Surrey
2026-09-08 - club - CCH - male - 1513383 - Glamorgan vs Warwickshire
2026-09-08 - club - CCH - male - 1513382 - Yorkshire vs Essex
2026-09-08 - club - CCH - male - 1513381 - Nottinghamshire vs Hampshire
2026-09-07 - club - MCL - male - 1547445 - Moors Sports Club vs Colts Cricket Club
2026-09-07 - club - MCL - male - 1547444 - Sinhalese Sports Club vs Colombo Cricket Club
2026-09-06 - international - T20 - male - 1549530 - South Africa vs Zimbabwe
2026-09-06 - club - ETPL - male - 1547888 - Rotterdam Dockers vs Amsterdam Flames
2026-09-06 - club - ETPL - male - 1547887 - Glasgow Cosmic vs Edinburgh Castle Rockers
2026-09-06 - club - CPL - male - 1534207 - St Lucia Kings vs Barbados Tridents
2026-09-06 - club - CPL - male - 1534206 - St Kitts and Nevis Patriots vs Guyana Amazon Warriors
2026-09-05 - club - MCT - male - 1535511 - Nondescripts Cricket Club vs Colts Cricket Club
2026-09-05 - club - MCT - male - 1535510 - Moors Sports Club vs Burgher Recreation Club
2026-09-05 - club - MCT - male - 1535509 - Ace Capital Cricket Club vs Sinhalese Sports Club
2026-09-05 - club - MCT - male - 1535508 - Nugegoda Sports Welfare Club vs Police Sports Club
2026-09-05 - club - MCT - male - 1535507 - Panadura Sports Club vs Badureliya Sports Club
2026-09-05 - club - MCT - male - 1535506 - Kurunegala Youth Cricket Club vs Colombo Cricket Club
2026-09-05 - club - ETPL - male - 1547886 - Amsterdam Flames vs Dublin Guardians
2026-09-05 - club - ETPL - male - 1547885 - Edinburgh Castle Rockers vs Rotterdam Dockers
2026-09-05 - club - CPL - male - 1534205 - Trinbago Knight Riders vs Barbados Tridents
2026-09-04 - international - T20 - male - 1549529 - South Africa vs Namibia
2026-09-04 - club - ETPL - male - 1547884 - Belfast Wolves vs Glasgow Cosmic
2026-09-04 - club - CPL - male - 1534204 - Jamaica Kingsmen vs Guyana Amazon Warriors
2026-09-03 - international - T20 - male - 1549528 - Namibia vs Zimbabwe
2026-09-03 - club - MCL - male - 1547443 - Badureliya Sports Club vs Burgher Recreation Club
2026-09-03 - club - MCL - male - 1547442 - Bloomfield Cricket and Athletic Club vs Sinhalese Sports Club
2026-09-03 - club - MCL - male - 1547441 - Colts Cricket Club vs Police Sports Club
2026-09-03 - club - MCL - male - 1547440 - Nugegoda Sports Welfare Club vs Ace Capital Cricket Club
2026-09-03 - club - MCL - male - 1547439 - Panadura Sports Club vs Kurunegala Youth Cricket Club
2026-09-03 - club - MCL - male - 1547438 - Colombo Cricket Club vs Tamil Union Cricket and Athletic Club
2026-09-03 - club - ETPL - male - 1547883 - Glasgow Cosmic vs Amsterdam Flames
2026-09-03 - club - CPL - male - 1534203 - St Kitts and Nevis Patriots vs St Lucia Kings
2026-09-02 - club - ETPL - male - 1547882 - Edinburgh Castle Rockers vs Belfast Wolves
2026-09-02 - club - ETPL - male - 1547881 - Dublin Guardians vs Rotterdam Dockers
2026-09-02 - club - CPL - male - 1534202 - Antigua and Barbuda Falcons vs Trinbago Knight Riders
2026-09-02 - club - CCH - male - 1513439 - Middlesex vs Lancashire
2026-09-02 - club - CCH - male - 1513438 - Durham vs Northamptonshire
2026-09-02 - club - CCH - male - 1513437 - Kent vs Worcestershire
2026-09-02 - club - CCH - male - 1513436 - Gloucestershire vs Derbyshire
2026-09-02 - club - CCH - male - 1513380 - Warwickshire vs Hampshire
2026-09-02 - club - CCH - male - 1513379 - Glamorgan vs Somerset
2026-09-02 - club - CCH - male - 1513378 - Nottinghamshire vs Leicestershire
2026-09-02 - club - CCH - male - 1513377 - Yorkshire vs Surrey
2026-09-02 - club - CCH - male - 1513376 - Sussex vs Essex
2026-09-01 - international - T20 - male - 1549527 - South Africa vs Zimbabwe
2026-09-01 - club - MCT - male - 1535505 - Colts Cricket Club vs Bloomfield Cricket and Athletic Club
2026-09-01 - club - MCT - male - 1535504 - Burgher Recreation Club vs Tamil Union Cricket and Athletic Club
2026-09-01 - club - MCT - male - 1535503 - Ace Capital Cricket Club vs Nondescripts Cricket Club
2026-09-01 - club - MCT - male - 1535502 - Nugegoda Sports Welfare Club vs Moors Sports Club
2026-09-01 - club - MCT - male - 1535501 - Colombo Cricket Club vs Police Sports Club
2026-09-01 - club - MCT - male - 1535500 - Panadura Sports Club vs Sinhalese Sports Club
2026-09-01 - club - ETPL - male - 1547880 - Glasgow Cosmic vs Rotterdam Dockers
2026-09-01 - club - CPL - male - 1534201 - Barbados Tridents vs St Kitts and Nevis Patriots
2026-08-31 - international - T20 - male - 1549526 - Zimbabwe vs Namibia
2026-08-31 - club - MCL - male - 1547432 - Panadura Sports Club vs Colombo Cricket Club
2026-08-31 - club - CPL - male - 1534200 - Guyana Amazon Warriors vs Trinbago Knight Riders
2026-08-30 - club - MCL - male - 1547437 - Burgher Recreation Club vs Colts Cricket Club
2026-08-30 - club - MCL - male - 1547436 - Nondescripts Cricket Club vs Badureliya Sports Club
2026-08-30 - club - MCL - male - 1547435 - Police Sports Club vs Bloomfield Cricket and Athletic Club
2026-08-30 - club - MCL - male - 1547434 - Nugegoda Sports Welfare Club vs Tamil Union Cricket and Athletic Club
2026-08-30 - club - MCL - male - 1547433 - Ace Capital Cricket Club vs Moors Sports Club
2026-08-30 - club - ETPL - male - 1547879 - Dublin Guardians vs Edinburgh Castle Rockers
2026-08-30 - club - ETPL - male - 1547878 - Amsterdam Flames vs Belfast Wolves
2026-08-29 - international - T20 - male - 1549525 - Zimbabwe vs South Africa
2026-08-29 - club - ETPL - male - 1547877 - Belfast Wolves vs Rotterdam Dockers
2026-08-29 - club - ETPL - male - 1547876 - Glasgow Cosmic vs Dublin Guardians
2026-08-29 - club - CPL - male - 1534198 - Trinbago Knight Riders vs Jamaica Kingsmen
2026-08-28 - international - T20 - male - 1549524 - Namibia vs South Africa
2026-08-28 - club - MCT - male - 1535499 - Bloomfield Cricket and Athletic Club vs Ace Capital Cricket Club
2026-08-28 - club - MCT - male - 1535498 - Tamil Union Cricket and Athletic Club vs Nugegoda Sports Welfare Club
2026-08-28 - club - MCT - male - 1535497 - Colts Cricket Club vs Badureliya Sports Club
2026-08-28 - club - MCT - male - 1535496 - Kurunegala Youth Cricket Club vs Burgher Recreation Club
2026-08-28 - club - MCT - male - 1535495 - Nondescripts Cricket Club vs Sinhalese Sports Club
2026-08-28 - club - MCT - male - 1535494 - Police Sports Club vs Moors Sports Club
2026-08-28 - club - CPL - male - 1534197 - Barbados Tridents vs Trinbago Knight Riders
2026-08-27 - international - Test - male - 1496583 - England vs Pakistan
2026-08-27 - club - ETPL - male - 1547874 - Glasgow Cosmic vs Edinburgh Castle Rockers
2026-08-27 - club - ETPL - male - 1547873 - Belfast Wolves vs Dublin Guardians
2026-08-27 - club - CPL - male - 1534196 - Jamaica Kingsmen vs St Kitts and Nevis Patriots
2026-08-27 - club - CCH - male - 1513435 - Gloucestershire vs Durham
2026-08-27 - club - CCH - male - 1513434 - Lancashire vs Worcestershire
2026-08-27 - club - CCH - male - 1513433 - Kent vs Northamptonshire
2026-08-27 - club - CCH - male - 1513432 - Derbyshire vs Middlesex
2026-08-27 - club - CCH - male - 1513375 - Somerset vs Sussex
2026-08-27 - club - CCH - male - 1513374 - Hampshire vs Glamorgan
2026-08-27 - club - CCH - male - 1513373 - Yorkshire vs Leicestershire
2026-08-27 - club - CCH - male - 1513372 - Surrey vs Essex
2026-08-27 - club - CCH - male - 1513371 - Nottinghamshire vs Warwickshire
2026-08-26 - club - MCL - male - 1547431 - Burgher Recreation Club vs Sinhalese Sports Club
2026-08-26 - club - MCL - male - 1547430 - Bloomfield Cricket and Athletic Club vs Colts Cricket Club
2026-08-26 - club - MCL - male - 1547429 - Nondescripts Cricket Club vs Police Sports Club
2026-08-26 - club - MCL - male - 1547428 - Panadura Sports Club vs Tamil Union Cricket and Athletic Club
2026-08-26 - club - MCL - male - 1547427 - Moors Sports Club vs Colombo Cricket Club
2026-08-26 - club - ETPL - male - 1547872 - Amsterdam Flames vs Rotterdam Dockers
2026-08-26 - club - CPL - male - 1534195 - St Lucia Kings vs Trinbago Knight Riders
2026-08-25 - club - MCL - male - 1547426 - Nugegoda Sports Welfare Club vs Kurunegala Youth Cricket Club
2026-08-25 - club - CPL - male - 1534194 - Antigua and Barbuda Falcons vs Barbados Tridents
2026-08-24 - club - MCT - male - 1535535 - Ace Capital Cricket Club vs Badureliya Sports Club
2026-08-24 - club - MCT - male - 1535534 - Nugegoda Sports Welfare Club vs Kurunegala Youth Cricket Club
2026-08-24 - club - MCT - male - 1535533 - Bloomfield Cricket and Athletic Club vs Sinhalese Sports Club
2026-08-24 - club - MCT - male - 1535532 - Police Sports Club vs Tamil Union Cricket and Athletic Club
2026-08-24 - club - MCT - male - 1535531 - Colombo Cricket Club vs Moors Sports Club
2026-08-24 - club - MCT - male - 1535530 - Panadura Sports Club vs Nondescripts Cricket Club
2026-08-23 - international - Test - male - 1544002 - India vs Sri Lanka
2026-08-23 - club - CPL - male - 1534193 - Antigua and Barbuda Falcons vs Guyana Amazon Warriors
2026-08-22 - international - Test - male - 1527274 - Bangladesh vs Australia
2026-08-22 - club - MCL - male - 1547425 - Sinhalese Sports Club vs Nondescripts Cricket Club
2026-08-22 - club - MCL - male - 1547424 - Burgher Recreation Club vs Bloomfield Cricket and Athletic Club
2026-08-22 - club - MCL - male - 1547423 - Badureliya Sports Club vs Police Sports Club
2026-08-22 - club - MCL - male - 1547422 - Moors Sports Club vs Kurunegala Youth Cricket Club
2026-08-22 - club - CPL - male - 1534192 - Trinbago Knight Riders vs Antigua and Barbuda Falcons
2026-08-21 - international - T20 - male - 1545683 - Portugal vs Spain
2026-08-21 - international - T20 - male - 1545682 - Israel vs Isle of Man
2026-08-21 - international - T20 - male - 1545681 - Bulgaria vs Czech Republic
2026-08-21 - international - T20 - male - 1545680 - Germany vs Finland
2026-08-21 - club - MCL - male - 1547421 - Nugegoda Sports Welfare Club vs Panadura Sports Club
2026-08-21 - club - MCL - male - 1547420 - Colombo Cricket Club vs Ace Capital Cricket Club
2026-08-21 - club - CPL - male - 1534191 - Jamaica Kingsmen vs St Lucia Kings
2026-08-20 - international - T20 - male - 1545679 - Israel vs Greece
2026-08-20 - international - T20 - male - 1545677 - Portugal vs Czech Republic
2026-08-20 - international - T20 - male - 1545676 - Bulgaria vs Luxembourg
2026-08-20 - club - MCT - male - 1535529 - Sinhalese Sports Club vs Badureliya Sports Club
2026-08-20 - club - MCT - male - 1535528 - Police Sports Club vs Kurunegala Youth Cricket Club
2026-08-20 - club - MCT - male - 1535527 - Moors Sports Club vs Tamil Union Cricket and Athletic Club
2026-08-20 - club - MCT - male - 1535526 - Nondescripts Cricket Club vs Bloomfield Cricket and Athletic Club
2026-08-20 - club - MCT - male - 1535525 - Panadura Sports Club vs Colts Cricket Club
2026-08-20 - club - MCT - male - 1535524 - Burgher Recreation Club vs Colombo Cricket Club
2026-08-20 - club - CPL - male - 1534190 - St Kitts and Nevis Patriots vs Antigua and Barbuda Falcons
2026-08-20 - club - CCH - male - 1513431 - Gloucestershire vs Worcestershire
2026-08-20 - club - CCH - male - 1513430 - Northamptonshire vs Lancashire
2026-08-20 - club - CCH - male - 1513429 - Durham vs Derbyshire
2026-08-20 - club - CCH - male - 1513428 - Kent vs Middlesex
2026-08-20 - club - CCH - male - 1513370 - Yorkshire vs Hampshire
2026-08-20 - club - CCH - male - 1513369 - Somerset vs Essex
2026-08-20 - club - CCH - male - 1513368 - Leicestershire vs Glamorgan
2026-08-20 - club - CCH - male - 1513367 - Sussex vs Warwickshire
2026-08-20 - club - CCH - male - 1513366 - Nottinghamshire vs Surrey
2026-08-19 - international - Test - male - 1496582 - Pakistan vs England
2026-08-19 - club - CPL - male - 1534189 - St Lucia Kings vs Guyana Amazon Warriors
2026-08-18 - international - T20 - male - 1545675 - Bulgaria vs Spain
2026-08-18 - international - T20 - male - 1545674 - Czech Republic vs Israel
2026-08-18 - international - T20 - male - 1545673 - Finland vs Luxembourg
2026-08-18 - international - T20 - male - 1545672 - Greece vs Germany
2026-08-18 - international - ODM - male - 1546354 - Uganda vs Bahrain
2026-08-18 - international - ODM - male - 1546353 - Tanzania vs Italy
2026-08-18 - club - MCL - male - 1547419 - Colts Cricket Club vs Nondescripts Cricket Club
2026-08-18 - club - MCL - male - 1547418 - Badureliya Sports Club vs Sinhalese Sports Club
2026-08-18 - club - MCL - male - 1547417 - Burgher Recreation Club vs Police Sports Club
2026-08-18 - club - MCL - male - 1547416 - Tamil Union Cricket and Athletic Club vs Moors Sports Club
2026-08-18 - club - MCL - male - 1547415 - Kurunegala Youth Cricket Club vs Ace Capital Cricket Club
2026-08-18 - club - MCL - male - 1547414 - Colombo Cricket Club vs Nugegoda Sports Welfare Club
2026-08-18 - club - CPL - male - 1534188 - Jamaica Kingsmen vs St Kitts and Nevis Patriots
2026-08-15 - international - Test - male - 1544001 - India vs Sri Lanka

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
