This zip archive contains data files from Cricsheet in YAML format. This
archive contains 54 Karnataka matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/karnataka_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-25 - club - SMA - male - 1383539 - Uttar Pradesh vs Karnataka
2023-10-21 - club - SMA - male - 1383503 - Karnataka vs Delhi
2023-10-19 - club - SMA - male - 1383485 - Madhya Pradesh vs Karnataka
2022-11-01 - club - SMA - male - 1333049 - Punjab vs Karnataka
2021-11-22 - club - SMA - male - 1280302 - Karnataka vs Tamil Nadu
2021-11-20 - club - SMA - male - 1280301 - Karnataka vs Vidarbha
2021-11-18 - club - SMA - male - 1280297 - Karnataka vs Bengal
2021-11-16 - club - SMA - male - 1280294 - Saurashtra vs Karnataka
2021-11-09 - club - SMA - male - 1280279 - Karnataka vs Bengal
2021-11-08 - club - SMA - male - 1280259 - Baroda vs Karnataka
2021-11-06 - club - SMA - male - 1280239 - Karnataka vs Services
2021-11-05 - club - SMA - male - 1280220 - Chhattisgarh vs Karnataka
2021-11-04 - club - SMA - male - 1280202 - Karnataka vs Mumbai
2021-01-26 - club - SMA - male - 1244401 - Karnataka vs Punjab
2021-01-16 - club - SMA - male - 1244364 - Railways vs Karnataka
2021-01-14 - club - SMA - male - 1244346 - Karnataka vs Tripura
2021-01-12 - club - SMA - male - 1244325 - Karnataka vs Punjab
2021-01-10 - club - SMA - male - 1244306 - Karnataka vs Jammu & Kashmir
2019-12-01 - club - SMA - male - 1205862 - Karnataka vs Tamil Nadu
2019-11-29 - club - SMA - male - 1205861 - Haryana vs Karnataka
2019-11-25 - club - SMA - male - 1205854 - Karnataka vs Mumbai
2019-11-24 - club - SMA - male - 1205850 - Punjab vs Karnataka
2019-11-22 - club - SMA - male - 1205846 - Karnataka vs Jharkhand
2019-11-21 - club - SMA - male - 1205842 - Tamil Nadu vs Karnataka
2019-11-17 - club - SMA - male - 1205823 - Karnataka vs Goa
2019-11-15 - club - SMA - male - 1205814 - Bihar vs Karnataka
2019-11-12 - club - SMA - male - 1205769 - Karnataka vs Services
2019-11-09 - club - SMA - male - 1205732 - Baroda vs Karnataka
2019-11-08 - club - SMA - male - 1205714 - Uttarakhand vs Karnataka
2019-03-14 - club - SMA - male - 1175045 - Maharashtra vs Karnataka
2019-03-12 - club - SMA - male - 1175044 - Vidarbha vs Karnataka
2019-03-10 - club - SMA - male - 1175033 - Delhi vs Karnataka
2019-03-09 - club - SMA - male - 1175032 - Karnataka vs Uttar Pradesh
2019-03-08 - club - SMA - male - 1175028 - Mumbai vs Karnataka
2019-03-02 - club - SMA - male - 1157204 - Karnataka vs Haryana
2019-02-28 - club - SMA - male - 1157187 - Karnataka vs Odisha
2019-02-27 - club - SMA - male - 1157169 - Chhattisgarh vs Karnataka
2019-02-25 - club - SMA - male - 1157154 - Karnataka vs Mizoram
2019-02-24 - club - SMA - male - 1157137 - Karnataka vs Arunachal Pradesh
2019-02-22 - club - SMA - male - 1157120 - Bengal vs Karnataka
2018-01-25 - club - SMA - male - 1133418 - Mumbai vs Karnataka
2018-01-24 - club - SMA - male - 1133414 - Karnataka vs Jharkhand
2018-01-23 - club - SMA - male - 1133409 - Rajasthan vs Karnataka
2018-01-21 - club - SMA - male - 1133401 - Karnataka vs Punjab
2018-01-14 - club - SMA - male - 1130716 - Karnataka vs Kerala
2018-01-12 - club - SMA - male - 1130702 - Karnataka vs Tamil Nadu
2018-01-11 - club - SMA - male - 1130689 - Karnataka vs Hyderabad (India)
2018-01-09 - club - SMA - male - 1130680 - Karnataka vs Andhra
2018-01-08 - club - SMA - male - 1130665 - Karnataka vs Goa
2016-01-08 - club - SMA - male - 902177 - Odisha vs Karnataka
2016-01-07 - club - SMA - male - 902205 - Maharashtra vs Karnataka
2016-01-04 - club - SMA - male - 902153 - Karnataka vs Uttar Pradesh
2016-01-03 - club - SMA - male - 902131 - Karnataka vs Mumbai
2016-01-02 - club - SMA - male - 902107 - Karnataka vs Services
