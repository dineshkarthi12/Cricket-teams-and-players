This zip archive contains data files from Cricsheet in YAML format. This
archive contains 16 Rising Pune Supergiant matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/rising_pune_supergiant_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2017-05-21 - club - IPL - male - 1082650 - Mumbai Indians vs Rising Pune Supergiant
2017-05-16 - club - IPL - male - 1082647 - Mumbai Indians vs Rising Pune Supergiant
2017-05-14 - club - IPL - male - 1082645 - Rising Pune Supergiant vs Kings XI Punjab
2017-05-12 - club - IPL - male - 1082642 - Delhi Daredevils vs Rising Pune Supergiant
2017-05-06 - club - IPL - male - 1082634 - Sunrisers Hyderabad vs Rising Pune Supergiant
2017-05-03 - club - IPL - male - 1082631 - Kolkata Knight Riders vs Rising Pune Supergiant
2017-05-01 - club - IPL - male - 1082629 - Rising Pune Supergiant vs Gujarat Lions
2017-04-29 - club - IPL - male - 1082624 - Rising Pune Supergiant vs Royal Challengers Bangalore
2017-04-26 - club - IPL - male - 1082620 - Rising Pune Supergiant vs Kolkata Knight Riders
2017-04-24 - club - IPL - male - 1082618 - Mumbai Indians vs Rising Pune Supergiant
2017-04-22 - club - IPL - male - 1082615 - Rising Pune Supergiant vs Sunrisers Hyderabad
2017-04-16 - club - IPL - male - 1082607 - Royal Challengers Bangalore vs Rising Pune Supergiant
2017-04-14 - club - IPL - male - 1082603 - Gujarat Lions vs Rising Pune Supergiant
2017-04-11 - club - IPL - male - 1082599 - Rising Pune Supergiant vs Delhi Daredevils
2017-04-08 - club - IPL - male - 1082594 - Kings XI Punjab vs Rising Pune Supergiant
2017-04-06 - club - IPL - male - 1082592 - Rising Pune Supergiant vs Mumbai Indians
