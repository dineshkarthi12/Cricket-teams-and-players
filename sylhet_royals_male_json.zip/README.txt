This zip archive contains data files from Cricsheet in JSON format. This
archive contains 15 Sylhet Royals matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/sylhet_royals_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2013-02-18 - club - BPL - male - 605286 - Sylhet Royals vs Chittagong Kings
2013-02-15 - club - BPL - male - 599907 - Dhaka Gladiators vs Sylhet Royals
2013-02-13 - club - BPL - male - 599904 - Barisal Burners vs Sylhet Royals
2013-02-12 - club - BPL - male - 599901 - Sylhet Royals vs Khulna Royal Bengals
2013-02-07 - club - BPL - male - 599894 - Rangpur Riders vs Sylhet Royals
2013-01-31 - club - BPL - male - 599883 - Rangpur Riders vs Sylhet Royals
2013-01-25 - club - BPL - male - 599877 - Dhaka Gladiators vs Sylhet Royals
2013-01-23 - club - BPL - male - 599874 - Khulna Royal Bengals vs Sylhet Royals
2013-01-20 - club - BPL - male - 599870 - Duronto Rajshahi vs Sylhet Royals
2013-01-18 - club - BPL - male - 599866 - Sylhet Royals vs Barisal Burners
2012-02-25 - club - BPL - male - 551070 - Sylhet Royals vs Chittagong Kings
2012-02-24 - club - BPL - male - 551068 - Duronto Rajshahi vs Sylhet Royals
2012-02-19 - club - BPL - male - 551062 - Sylhet Royals vs Barisal Burners
2012-02-18 - club - BPL - male - 551059 - Khulna Royal Bengals vs Sylhet Royals
2012-02-14 - club - BPL - male - 551053 - Duronto Rajshahi vs Sylhet Royals
