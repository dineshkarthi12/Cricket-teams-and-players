This zip archive contains data files from Cricsheet in YAML format. This
archive contains 72 Lucknow Super Giants matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/lucknow_super_giants_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-05-23 - club - IPL - male - 1529311 - Lucknow Super Giants vs Punjab Kings
2026-05-19 - club - IPL - male - 1529307 - Lucknow Super Giants vs Rajasthan Royals
2026-05-15 - club - IPL - male - 1529302 - Chennai Super Kings vs Lucknow Super Giants
2026-05-10 - club - IPL - male - 1529296 - Lucknow Super Giants vs Chennai Super Kings
2026-05-07 - club - IPL - male - 1529293 - Lucknow Super Giants vs Royal Challengers Bengaluru
2026-05-04 - club - IPL - male - 1529290 - Lucknow Super Giants vs Mumbai Indians
2026-04-26 - club - IPL - male - 1529281 - Kolkata Knight Riders vs Lucknow Super Giants
2026-04-22 - club - IPL - male - 1529275 - Rajasthan Royals vs Lucknow Super Giants
2026-04-19 - club - IPL - male - 1529272 - Punjab Kings vs Lucknow Super Giants
2026-04-15 - club - IPL - male - 1529266 - Lucknow Super Giants vs Royal Challengers Bengaluru
2026-04-12 - club - IPL - male - 1527692 - Lucknow Super Giants vs Gujarat Titans
2026-04-09 - club - IPL - male - 1527688 - Kolkata Knight Riders vs Lucknow Super Giants
2026-04-05 - club - IPL - male - 1527683 - Sunrisers Hyderabad vs Lucknow Super Giants
2026-04-01 - club - IPL - male - 1527678 - Lucknow Super Giants vs Delhi Capitals
2025-05-27 - club - IPL - male - 1473507 - Lucknow Super Giants vs Royal Challengers Bengaluru
2025-05-22 - club - IPL - male - 1473502 - Lucknow Super Giants vs Gujarat Titans
2025-05-19 - club - IPL - male - 1473499 - Lucknow Super Giants vs Sunrisers Hyderabad
2025-05-04 - club - IPL - male - 1473491 - Punjab Kings vs Lucknow Super Giants
2025-04-27 - club - IPL - male - 1473482 - Mumbai Indians vs Lucknow Super Giants
2025-04-22 - club - IPL - male - 1473477 - Lucknow Super Giants vs Delhi Capitals
2025-04-19 - club - IPL - male - 1473473 - Lucknow Super Giants vs Rajasthan Royals
2025-04-14 - club - IPL - male - 1473467 - Lucknow Super Giants vs Chennai Super Kings
2025-04-12 - club - IPL - male - 1473463 - Gujarat Titans vs Lucknow Super Giants
2025-04-08 - club - IPL - male - 1473456 - Lucknow Super Giants vs Kolkata Knight Riders
2025-04-04 - club - IPL - male - 1473453 - Lucknow Super Giants vs Mumbai Indians
2025-04-01 - club - IPL - male - 1473450 - Lucknow Super Giants vs Punjab Kings
2025-03-27 - club - IPL - male - 1473444 - Sunrisers Hyderabad vs Lucknow Super Giants
2025-03-24 - club - IPL - male - 1473441 - Lucknow Super Giants vs Delhi Capitals
2024-05-17 - club - IPL - male - 1426305 - Lucknow Super Giants vs Mumbai Indians
2024-05-14 - club - IPL - male - 1426302 - Delhi Capitals vs Lucknow Super Giants
2024-05-08 - club - IPL - male - 1426295 - Lucknow Super Giants vs Sunrisers Hyderabad
2024-05-05 - club - IPL - male - 1426292 - Kolkata Knight Riders vs Lucknow Super Giants
2024-04-30 - club - IPL - male - 1426286 - Mumbai Indians vs Lucknow Super Giants
2024-04-27 - club - IPL - male - 1426282 - Lucknow Super Giants vs Rajasthan Royals
2024-04-23 - club - IPL - male - 1426277 - Chennai Super Kings vs Lucknow Super Giants
2024-04-19 - club - IPL - male - 1426272 - Chennai Super Kings vs Lucknow Super Giants
2024-04-14 - club - IPL - male - 1426266 - Lucknow Super Giants vs Kolkata Knight Riders
2024-04-12 - club - IPL - male - 1426264 - Lucknow Super Giants vs Delhi Capitals
2024-04-07 - club - IPL - male - 1422139 - Lucknow Super Giants vs Gujarat Titans
2024-04-02 - club - IPL - male - 1422133 - Lucknow Super Giants vs Royal Challengers Bengaluru
2024-03-30 - club - IPL - male - 1422129 - Lucknow Super Giants vs Punjab Kings
2024-03-24 - club - IPL - male - 1422122 - Rajasthan Royals vs Lucknow Super Giants
2023-05-24 - club - IPL - male - 1370351 - Mumbai Indians vs Lucknow Super Giants
2023-05-20 - club - IPL - male - 1359542 - Lucknow Super Giants vs Kolkata Knight Riders
2023-05-16 - club - IPL - male - 1359537 - Lucknow Super Giants vs Mumbai Indians
2023-05-13 - club - IPL - male - 1359532 - Sunrisers Hyderabad vs Lucknow Super Giants
2023-05-07 - club - IPL - male - 1359525 - Gujarat Titans vs Lucknow Super Giants
2023-05-03 - club - IPL - male - 1359519 - Lucknow Super Giants vs Chennai Super Kings
2023-05-01 - club - IPL - male - 1359517 - Royal Challengers Bangalore vs Lucknow Super Giants
2023-04-28 - club - IPL - male - 1359512 - Lucknow Super Giants vs Punjab Kings
2023-04-22 - club - IPL - male - 1359504 - Gujarat Titans vs Lucknow Super Giants
2023-04-19 - club - IPL - male - 1359500 - Lucknow Super Giants vs Rajasthan Royals
2023-04-15 - club - IPL - male - 1359495 - Lucknow Super Giants vs Punjab Kings
2023-04-10 - club - IPL - male - 1359489 - Royal Challengers Bangalore vs Lucknow Super Giants
2023-04-07 - club - IPL - male - 1359484 - Sunrisers Hyderabad vs Lucknow Super Giants
2023-04-03 - club - IPL - male - 1359480 - Chennai Super Kings vs Lucknow Super Giants
2023-04-01 - club - IPL - male - 1359477 - Lucknow Super Giants vs Delhi Capitals
2022-05-25 - club - IPL - male - 1312198 - Royal Challengers Bangalore vs Lucknow Super Giants
2022-05-18 - club - IPL - male - 1304112 - Lucknow Super Giants vs Kolkata Knight Riders
2022-05-15 - club - IPL - male - 1304109 - Rajasthan Royals vs Lucknow Super Giants
2022-05-10 - club - IPL - male - 1304103 - Gujarat Titans vs Lucknow Super Giants
2022-05-07 - club - IPL - male - 1304099 - Lucknow Super Giants vs Kolkata Knight Riders
2022-05-01 - club - IPL - male - 1304091 - Lucknow Super Giants vs Delhi Capitals
2022-04-29 - club - IPL - male - 1304088 - Lucknow Super Giants vs Punjab Kings
2022-04-24 - club - IPL - male - 1304083 - Lucknow Super Giants vs Mumbai Indians
2022-04-19 - club - IPL - male - 1304077 - Royal Challengers Bangalore vs Lucknow Super Giants
2022-04-16 - club - IPL - male - 1304072 - Lucknow Super Giants vs Mumbai Indians
2022-04-10 - club - IPL - male - 1304066 - Rajasthan Royals vs Lucknow Super Giants
2022-04-07 - club - IPL - male - 1304061 - Delhi Capitals vs Lucknow Super Giants
2022-04-04 - club - IPL - male - 1304058 - Lucknow Super Giants vs Sunrisers Hyderabad
2022-03-31 - club - IPL - male - 1304053 - Chennai Super Kings vs Lucknow Super Giants
2022-03-28 - club - IPL - male - 1304050 - Lucknow Super Giants vs Gujarat Titans
