This zip archive contains data files from Cricsheet in YAML format. This
archive contains 240 Royal Challengers Bangalore matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/royal_challengers_bangalore_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-05-21 - club - IPL - male - 1359544 - Royal Challengers Bangalore vs Gujarat Titans
2023-05-18 - club - IPL - male - 1359539 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2023-05-14 - club - IPL - male - 1359534 - Royal Challengers Bangalore vs Rajasthan Royals
2023-05-09 - club - IPL - male - 1359528 - Royal Challengers Bangalore vs Mumbai Indians
2023-05-06 - club - IPL - male - 1359524 - Royal Challengers Bangalore vs Delhi Capitals
2023-05-01 - club - IPL - male - 1359517 - Royal Challengers Bangalore vs Lucknow Super Giants
2023-04-26 - club - IPL - male - 1359510 - Kolkata Knight Riders vs Royal Challengers Bangalore
2023-04-23 - club - IPL - male - 1359506 - Royal Challengers Bangalore vs Rajasthan Royals
2023-04-20 - club - IPL - male - 1359501 - Royal Challengers Bangalore vs Punjab Kings
2023-04-17 - club - IPL - male - 1359498 - Chennai Super Kings vs Royal Challengers Bangalore
2023-04-15 - club - IPL - male - 1359494 - Royal Challengers Bangalore vs Delhi Capitals
2023-04-10 - club - IPL - male - 1359489 - Royal Challengers Bangalore vs Lucknow Super Giants
2023-04-06 - club - IPL - male - 1359483 - Kolkata Knight Riders vs Royal Challengers Bangalore
2023-04-02 - club - IPL - male - 1359479 - Mumbai Indians vs Royal Challengers Bangalore
2022-05-27 - club - IPL - male - 1312199 - Royal Challengers Bangalore vs Rajasthan Royals
2022-05-25 - club - IPL - male - 1312198 - Royal Challengers Bangalore vs Lucknow Super Giants
2022-05-19 - club - IPL - male - 1304113 - Gujarat Titans vs Royal Challengers Bangalore
2022-05-13 - club - IPL - male - 1304106 - Punjab Kings vs Royal Challengers Bangalore
2022-05-08 - club - IPL - male - 1304100 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2022-05-04 - club - IPL - male - 1304095 - Royal Challengers Bangalore vs Chennai Super Kings
2022-04-30 - club - IPL - male - 1304089 - Royal Challengers Bangalore vs Gujarat Titans
2022-04-26 - club - IPL - male - 1304085 - Rajasthan Royals vs Royal Challengers Bangalore
2022-04-23 - club - IPL - male - 1304082 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2022-04-19 - club - IPL - male - 1304077 - Royal Challengers Bangalore vs Lucknow Super Giants
2022-04-16 - club - IPL - male - 1304073 - Royal Challengers Bangalore vs Delhi Capitals
2022-04-12 - club - IPL - male - 1304068 - Chennai Super Kings vs Royal Challengers Bangalore
2022-04-09 - club - IPL - male - 1304064 - Mumbai Indians vs Royal Challengers Bangalore
2022-04-05 - club - IPL - male - 1304059 - Rajasthan Royals vs Royal Challengers Bangalore
2022-03-30 - club - IPL - male - 1304052 - Kolkata Knight Riders vs Royal Challengers Bangalore
2022-03-27 - club - IPL - male - 1304049 - Royal Challengers Bangalore vs Punjab Kings
2021-10-11 - club - IPL - male - 1254115 - Royal Challengers Bangalore vs Kolkata Knight Riders
2021-10-08 - club - IPL - male - 1254101 - Delhi Capitals vs Royal Challengers Bangalore
2021-10-06 - club - IPL - male - 1254095 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2021-10-03 - club - IPL - male - 1254090 - Royal Challengers Bangalore vs Punjab Kings
2021-09-29 - club - IPL - male - 1254103 - Rajasthan Royals vs Royal Challengers Bangalore
2021-09-26 - club - IPL - male - 1254108 - Royal Challengers Bangalore vs Mumbai Indians
2021-09-24 - club - IPL - male - 1254113 - Royal Challengers Bangalore vs Chennai Super Kings
2021-09-20 - club - IPL - male - 1254087 - Royal Challengers Bangalore vs Kolkata Knight Riders
2021-04-30 - club - IPL - male - 1254083 - Punjab Kings vs Royal Challengers Bangalore
2021-04-27 - club - IPL - male - 1254079 - Royal Challengers Bangalore vs Delhi Capitals
2021-04-25 - club - IPL - male - 1254076 - Chennai Super Kings vs Royal Challengers Bangalore
2021-04-22 - club - IPL - male - 1254073 - Rajasthan Royals vs Royal Challengers Bangalore
2021-04-18 - club - IPL - male - 1254067 - Royal Challengers Bangalore vs Kolkata Knight Riders
2021-04-14 - club - IPL - male - 1254063 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2021-04-09 - club - IPL - male - 1254058 - Mumbai Indians vs Royal Challengers Bangalore
2020-11-06 - club - IPL - male - 1237178 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2020-11-02 - club - IPL - male - 1216505 - Royal Challengers Bangalore vs Delhi Capitals
2020-10-31 - club - IPL - male - 1216502 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2020-10-28 - club - IPL - male - 1216499 - Royal Challengers Bangalore vs Mumbai Indians
2020-10-25 - club - IPL - male - 1216544 - Royal Challengers Bangalore vs Chennai Super Kings
2020-10-21 - club - IPL - male - 1216494 - Kolkata Knight Riders vs Royal Challengers Bangalore
2020-10-17 - club - IPL - male - 1216522 - Rajasthan Royals vs Royal Challengers Bangalore
2020-10-15 - club - IPL - male - 1216531 - Royal Challengers Bangalore vs Kings XI Punjab
2020-10-12 - club - IPL - male - 1216540 - Royal Challengers Bangalore vs Kolkata Knight Riders
2020-10-10 - club - IPL - male - 1216525 - Royal Challengers Bangalore vs Chennai Super Kings
2020-10-05 - club - IPL - male - 1216519 - Delhi Capitals vs Royal Challengers Bangalore
2020-10-03 - club - IPL - male - 1216514 - Rajasthan Royals vs Royal Challengers Bangalore
2020-09-28 - club - IPL - male - 1216547 - Royal Challengers Bangalore vs Mumbai Indians
2020-09-24 - club - IPL - male - 1216510 - Kings XI Punjab vs Royal Challengers Bangalore
2020-09-21 - club - IPL - male - 1216534 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2019-05-04 - club - IPL - male - 1178429 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2019-04-30 - club - IPL - male - 1178424 - Royal Challengers Bangalore vs Rajasthan Royals
2019-04-28 - club - IPL - male - 1178421 - Delhi Capitals vs Royal Challengers Bangalore
2019-04-24 - club - IPL - male - 1178417 - Royal Challengers Bangalore vs Kings XI Punjab
2019-04-21 - club - IPL - male - 1178414 - Royal Challengers Bangalore vs Chennai Super Kings
2019-04-19 - club - IPL - male - 1178410 - Kolkata Knight Riders vs Royal Challengers Bangalore
2019-04-15 - club - IPL - male - 1178406 - Mumbai Indians vs Royal Challengers Bangalore
2019-04-13 - club - IPL - male - 1178403 - Kings XI Punjab vs Royal Challengers Bangalore
2019-04-07 - club - IPL - male - 1178395 - Royal Challengers Bangalore vs Delhi Capitals
2019-04-05 - club - IPL - male - 1175372 - Royal Challengers Bangalore vs Kolkata Knight Riders
2019-04-02 - club - IPL - male - 1175369 - Rajasthan Royals vs Royal Challengers Bangalore
2019-03-31 - club - IPL - male - 1175366 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2019-03-28 - club - IPL - male - 1175362 - Royal Challengers Bangalore vs Mumbai Indians
2019-03-23 - club - IPL - male - 1175356 - Chennai Super Kings vs Royal Challengers Bangalore
2018-05-19 - club - IPL - male - 1136613 - Rajasthan Royals vs Royal Challengers Bangalore
2018-05-17 - club - IPL - male - 1136611 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2018-05-14 - club - IPL - male - 1136608 - Kings XI Punjab vs Royal Challengers Bangalore
2018-05-12 - club - IPL - male - 1136605 - Delhi Daredevils vs Royal Challengers Bangalore
2018-05-07 - club - IPL - male - 1136599 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2018-05-05 - club - IPL - male - 1136595 - Chennai Super Kings vs Royal Challengers Bangalore
2018-05-01 - club - IPL - male - 1136591 - Royal Challengers Bangalore vs Mumbai Indians
2018-04-29 - club - IPL - male - 1136589 - Royal Challengers Bangalore vs Kolkata Knight Riders
2018-04-25 - club - IPL - male - 1136584 - Royal Challengers Bangalore vs Chennai Super Kings
2018-04-21 - club - IPL - male - 1136579 - Royal Challengers Bangalore vs Delhi Daredevils
2018-04-17 - club - IPL - male - 1136574 - Mumbai Indians vs Royal Challengers Bangalore
2018-04-15 - club - IPL - male - 1136571 - Royal Challengers Bangalore vs Rajasthan Royals
2018-04-13 - club - IPL - male - 1136568 - Royal Challengers Bangalore vs Kings XI Punjab
2018-04-08 - club - IPL - male - 1136563 - Kolkata Knight Riders vs Royal Challengers Bangalore
2017-05-14 - club - IPL - male - 1082646 - Delhi Daredevils vs Royal Challengers Bangalore
2017-05-07 - club - IPL - male - 1082636 - Royal Challengers Bangalore vs Kolkata Knight Riders
2017-05-05 - club - IPL - male - 1082633 - Royal Challengers Bangalore vs Kings XI Punjab
2017-05-01 - club - IPL - male - 1082628 - Mumbai Indians vs Royal Challengers Bangalore
2017-04-29 - club - IPL - male - 1082624 - Rising Pune Supergiant vs Royal Challengers Bangalore
2017-04-27 - club - IPL - male - 1082621 - Royal Challengers Bangalore vs Gujarat Lions
2017-04-23 - club - IPL - male - 1082617 - Kolkata Knight Riders vs Royal Challengers Bangalore
2017-04-18 - club - IPL - male - 1082610 - Gujarat Lions vs Royal Challengers Bangalore
2017-04-16 - club - IPL - male - 1082607 - Royal Challengers Bangalore vs Rising Pune Supergiant
2017-04-14 - club - IPL - male - 1082602 - Royal Challengers Bangalore vs Mumbai Indians
2017-04-10 - club - IPL - male - 1082598 - Kings XI Punjab vs Royal Challengers Bangalore
2017-04-08 - club - IPL - male - 1082595 - Royal Challengers Bangalore vs Delhi Daredevils
2017-04-05 - club - IPL - male - 1082591 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2016-05-29 - club - IPL - male - 981019 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2016-05-24 - club - IPL - male - 981013 - Gujarat Lions vs Royal Challengers Bangalore
2016-05-22 - club - IPL - male - 981011 - Delhi Daredevils vs Royal Challengers Bangalore
2016-05-18 - club - IPL - male - 980999 - Royal Challengers Bangalore vs Kings XI Punjab
2016-05-16 - club - IPL - male - 980995 - Kolkata Knight Riders vs Royal Challengers Bangalore
2016-05-14 - club - IPL - male - 980987 - Royal Challengers Bangalore vs Gujarat Lions
2016-05-11 - club - IPL - male - 980981 - Royal Challengers Bangalore vs Mumbai Indians
2016-05-09 - club - IPL - male - 980977 - Kings XI Punjab vs Royal Challengers Bangalore
2016-05-07 - club - IPL - male - 980969 - Royal Challengers Bangalore vs Rising Pune Supergiants
2016-05-02 - club - IPL - male - 980959 - Royal Challengers Bangalore vs Kolkata Knight Riders
2016-04-30 - club - IPL - male - 980953 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2016-04-24 - club - IPL - male - 980937 - Gujarat Lions vs Royal Challengers Bangalore
2016-04-22 - club - IPL - male - 980931 - Rising Pune Supergiants vs Royal Challengers Bangalore
2016-04-20 - club - IPL - male - 980927 - Mumbai Indians vs Royal Challengers Bangalore
2016-04-17 - club - IPL - male - 980921 - Royal Challengers Bangalore vs Delhi Daredevils
2016-04-12 - club - IPL - male - 980907 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2015-05-22 - club - IPL - male - 829821 - Chennai Super Kings vs Royal Challengers Bangalore
2015-05-20 - club - IPL - male - 829819 - Royal Challengers Bangalore vs Rajasthan Royals
2015-05-17 - club - IPL - male - 829813 - Royal Challengers Bangalore vs Delhi Daredevils
2015-05-15 - club - IPL - male - 829807 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2015-05-13 - club - IPL - male - 829803 - Kings XI Punjab vs Royal Challengers Bangalore
2015-05-10 - club - IPL - male - 829795 - Mumbai Indians vs Royal Challengers Bangalore
2015-05-06 - club - IPL - male - 829785 - Royal Challengers Bangalore vs Kings XI Punjab
2015-05-04 - club - IPL - male - 829779 - Chennai Super Kings vs Royal Challengers Bangalore
2015-05-02 - club - IPL - male - 829771 - Royal Challengers Bangalore vs Kolkata Knight Riders
2015-04-29 - club - IPL - male - 829763 - Royal Challengers Bangalore vs Rajasthan Royals
2015-04-26 - club - IPL - male - 829757 - Delhi Daredevils vs Royal Challengers Bangalore
2015-04-24 - club - IPL - male - 829749 - Rajasthan Royals vs Royal Challengers Bangalore
2015-04-22 - club - IPL - male - 829745 - Royal Challengers Bangalore vs Chennai Super Kings
2015-04-19 - club - IPL - male - 829737 - Royal Challengers Bangalore vs Mumbai Indians
2015-04-13 - club - IPL - male - 829719 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2015-04-11 - club - IPL - male - 829713 - Kolkata Knight Riders vs Royal Challengers Bangalore
2014-05-24 - club - IPL - male - 734035 - Royal Challengers Bangalore vs Chennai Super Kings
2014-05-22 - club - IPL - male - 734027 - Kolkata Knight Riders vs Royal Challengers Bangalore
2014-05-20 - club - IPL - male - 734021 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2014-05-18 - club - IPL - male - 734013 - Chennai Super Kings vs Royal Challengers Bangalore
2014-05-13 - club - IPL - male - 734005 - Royal Challengers Bangalore vs Delhi Daredevils
2014-05-11 - club - IPL - male - 733999 - Royal Challengers Bangalore vs Rajasthan Royals
2014-05-09 - club - IPL - male - 733991 - Royal Challengers Bangalore vs Kings XI Punjab
2014-05-06 - club - IPL - male - 733983 - Mumbai Indians vs Royal Challengers Bangalore
2014-05-04 - club - IPL - male - 733977 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2014-04-28 - club - IPL - male - 729313 - Kings XI Punjab vs Royal Challengers Bangalore
2014-04-26 - club - IPL - male - 729305 - Rajasthan Royals vs Royal Challengers Bangalore
2014-04-24 - club - IPL - male - 729299 - Royal Challengers Bangalore vs Kolkata Knight Riders
2014-04-19 - club - IPL - male - 729287 - Royal Challengers Bangalore vs Mumbai Indians
2014-04-17 - club - IPL - male - 729281 - Delhi Daredevils vs Royal Challengers Bangalore
2013-05-18 - club - IPL - male - 598068 - Royal Challengers Bangalore vs Chennai Super Kings
2013-05-14 - club - IPL - male - 598045 - Royal Challengers Bangalore vs Kings XI Punjab
2013-05-12 - club - IPL - male - 598057 - Kolkata Knight Riders vs Royal Challengers Bangalore
2013-05-10 - club - IPL - male - 598054 - Delhi Daredevils vs Royal Challengers Bangalore
2013-05-06 - club - IPL - male - 598064 - Kings XI Punjab vs Royal Challengers Bangalore
2013-05-02 - club - IPL - male - 598042 - Pune Warriors vs Royal Challengers Bangalore
2013-04-29 - club - IPL - male - 598036 - Rajasthan Royals vs Royal Challengers Bangalore
2013-04-27 - club - IPL - male - 598033 - Mumbai Indians vs Royal Challengers Bangalore
2013-04-23 - club - IPL - male - 598027 - Royal Challengers Bangalore vs Pune Warriors
2013-04-20 - club - IPL - male - 598023 - Royal Challengers Bangalore vs Rajasthan Royals
2013-04-16 - club - IPL - male - 598017 - Royal Challengers Bangalore vs Delhi Daredevils
2013-04-13 - club - IPL - male - 598012 - Chennai Super Kings vs Royal Challengers Bangalore
2013-04-11 - club - IPL - male - 598008 - Royal Challengers Bangalore vs Kolkata Knight Riders
2013-04-09 - club - IPL - male - 598048 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2013-04-07 - club - IPL - male - 598004 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2013-04-04 - club - IPL - male - 597999 - Royal Challengers Bangalore vs Mumbai Indians
2012-05-20 - club - IPL - male - 548376 - Deccan Chargers vs Royal Challengers Bangalore
2012-05-17 - club - IPL - male - 548372 - Delhi Daredevils vs Royal Challengers Bangalore
2012-05-14 - club - IPL - male - 548367 - Royal Challengers Bangalore vs Mumbai Indians
2012-05-11 - club - IPL - male - 548362 - Pune Warriors vs Royal Challengers Bangalore
2012-05-09 - club - IPL - male - 548360 - Mumbai Indians vs Royal Challengers Bangalore
2012-05-06 - club - IPL - male - 548356 - Royal Challengers Bangalore vs Deccan Chargers
2012-05-02 - club - IPL - male - 548350 - Royal Challengers Bangalore vs Kings XI Punjab
2012-04-28 - club - IPL - male - 548344 - Kolkata Knight Riders vs Royal Challengers Bangalore
2012-04-23 - club - IPL - male - 548336 - Rajasthan Royals vs Royal Challengers Bangalore
2012-04-20 - club - IPL - male - 548331 - Kings XI Punjab vs Royal Challengers Bangalore
2012-04-17 - club - IPL - male - 548327 - Royal Challengers Bangalore vs Pune Warriors
2012-04-15 - club - IPL - male - 548324 - Royal Challengers Bangalore vs Rajasthan Royals
2012-04-12 - club - IPL - male - 548318 - Chennai Super Kings vs Royal Challengers Bangalore
2012-04-10 - club - IPL - male - 548315 - Royal Challengers Bangalore vs Kolkata Knight Riders
2012-04-07 - club - IPL - male - 548310 - Royal Challengers Bangalore vs Delhi Daredevils
2011-05-28 - club - IPL - male - 501271 - Chennai Super Kings vs Royal Challengers Bangalore
2011-05-27 - club - IPL - male - 501270 - Royal Challengers Bangalore vs Mumbai Indians
2011-05-24 - club - IPL - male - 501268 - Royal Challengers Bangalore vs Chennai Super Kings
2011-05-22 - club - IPL - male - 501266 - Royal Challengers Bangalore vs Chennai Super Kings
2011-05-17 - club - IPL - male - 501260 - Kings XI Punjab vs Royal Challengers Bangalore
2011-05-14 - club - IPL - male - 501255 - Royal Challengers Bangalore vs Kolkata Knight Riders
2011-05-11 - club - IPL - male - 501252 - Rajasthan Royals vs Royal Challengers Bangalore
2011-05-08 - club - IPL - male - 501247 - Royal Challengers Bangalore vs Kochi Tuskers Kerala
2011-05-06 - club - IPL - male - 501244 - Royal Challengers Bangalore vs Kings XI Punjab
2011-04-29 - club - IPL - male - 501232 - Royal Challengers Bangalore vs Pune Warriors
2011-04-26 - club - IPL - male - 501227 - Delhi Daredevils vs Royal Challengers Bangalore
2011-04-22 - club - IPL - male - 501222 - Kolkata Knight Riders vs Royal Challengers Bangalore
2011-04-16 - club - IPL - male - 501211 - Chennai Super Kings vs Royal Challengers Bangalore
2011-04-14 - club - IPL - male - 501208 - Deccan Chargers vs Royal Challengers Bangalore
2011-04-12 - club - IPL - male - 501205 - Royal Challengers Bangalore vs Mumbai Indians
2011-04-09 - club - IPL - male - 501200 - Kochi Tuskers Kerala vs Royal Challengers Bangalore
2010-04-24 - club - IPL - male - 419164 - Royal Challengers Bangalore vs Deccan Chargers
2010-04-21 - club - IPL - male - 419162 - Royal Challengers Bangalore vs Mumbai Indians
2010-04-17 - club - IPL - male - 419157 - Royal Challengers Bangalore vs Mumbai Indians
2010-04-14 - club - IPL - male - 419154 - Rajasthan Royals vs Royal Challengers Bangalore
2010-04-12 - club - IPL - male - 419151 - Deccan Chargers vs Royal Challengers Bangalore
2010-04-10 - club - IPL - male - 419148 - Royal Challengers Bangalore vs Kolkata Knight Riders
2010-04-08 - club - IPL - male - 419145 - Royal Challengers Bangalore vs Deccan Chargers
2010-04-04 - club - IPL - male - 419140 - Delhi Daredevils vs Royal Challengers Bangalore
2010-04-02 - club - IPL - male - 419136 - Kings XI Punjab vs Royal Challengers Bangalore
2010-03-31 - club - IPL - male - 419133 - Chennai Super Kings vs Royal Challengers Bangalore
2010-03-25 - club - IPL - male - 419128 - Royal Challengers Bangalore vs Delhi Daredevils
2010-03-23 - club - IPL - male - 419123 - Royal Challengers Bangalore vs Chennai Super Kings
2010-03-20 - club - IPL - male - 419119 - Mumbai Indians vs Royal Challengers Bangalore
2010-03-18 - club - IPL - male - 419115 - Royal Challengers Bangalore vs Rajasthan Royals
2010-03-16 - club - IPL - male - 419112 - Royal Challengers Bangalore vs Kings XI Punjab
2010-03-14 - club - IPL - male - 419109 - Kolkata Knight Riders vs Royal Challengers Bangalore
2009-05-24 - club - IPL - male - 392239 - Royal Challengers Bangalore vs Deccan Chargers
2009-05-23 - club - IPL - male - 392238 - Royal Challengers Bangalore vs Chennai Super Kings
2009-05-21 - club - IPL - male - 392236 - Royal Challengers Bangalore vs Deccan Chargers
2009-05-19 - club - IPL - male - 392232 - Royal Challengers Bangalore vs Delhi Daredevils
2009-05-14 - club - IPL - male - 392224 - Royal Challengers Bangalore vs Chennai Super Kings
2009-05-12 - club - IPL - male - 392221 - Royal Challengers Bangalore vs Kolkata Knight Riders
2009-05-10 - club - IPL - male - 392218 - Royal Challengers Bangalore vs Mumbai Indians
2009-05-07 - club - IPL - male - 392213 - Royal Challengers Bangalore vs Rajasthan Royals
2009-05-03 - club - IPL - male - 392208 - Royal Challengers Bangalore vs Mumbai Indians
2009-05-01 - club - IPL - male - 392204 - Royal Challengers Bangalore vs Kings XI Punjab
2009-04-29 - club - IPL - male - 392199 - Royal Challengers Bangalore vs Kolkata Knight Riders
2009-04-26 - club - IPL - male - 392194 - Royal Challengers Bangalore vs Delhi Daredevils
2009-04-24 - club - IPL - male - 392191 - Royal Challengers Bangalore vs Kings XI Punjab
2009-04-22 - club - IPL - male - 392188 - Royal Challengers Bangalore vs Deccan Chargers
2009-04-20 - club - IPL - male - 392185 - Royal Challengers Bangalore vs Chennai Super Kings
2009-04-18 - club - IPL - male - 392182 - Royal Challengers Bangalore vs Rajasthan Royals
2008-05-28 - club - IPL - male - 336012 - Royal Challengers Bangalore vs Mumbai Indians
2008-05-25 - club - IPL - male - 336002 - Deccan Chargers vs Royal Challengers Bangalore
2008-05-21 - club - IPL - male - 336029 - Chennai Super Kings vs Royal Challengers Bangalore
2008-05-19 - club - IPL - male - 336026 - Royal Challengers Bangalore vs Delhi Daredevils
2008-05-17 - club - IPL - male - 336023 - Rajasthan Royals vs Royal Challengers Bangalore
2008-05-12 - club - IPL - male - 336016 - Kings XI Punjab vs Royal Challengers Bangalore
2008-05-08 - club - IPL - male - 336010 - Kolkata Knight Riders vs Royal Challengers Bangalore
2008-05-05 - club - IPL - male - 336006 - Royal Challengers Bangalore vs Kings XI Punjab
2008-05-03 - club - IPL - male - 336034 - Royal Challengers Bangalore vs Deccan Chargers
2008-04-30 - club - IPL - male - 335998 - Delhi Daredevils vs Royal Challengers Bangalore
2008-04-28 - club - IPL - male - 335996 - Royal Challengers Bangalore vs Chennai Super Kings
2008-04-26 - club - IPL - male - 335992 - Royal Challengers Bangalore vs Rajasthan Royals
2008-04-20 - club - IPL - male - 335985 - Mumbai Indians vs Royal Challengers Bangalore
2008-04-18 - club - IPL - male - 335982 - Royal Challengers Bangalore vs Kolkata Knight Riders
