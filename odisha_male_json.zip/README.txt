This zip archive contains data files from Cricsheet in JSON format. This
archive contains 27 Odisha matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/odisha_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2021-11-09 - club - SMA - male - 1280274 - Odisha vs Puducherry
2021-11-06 - club - SMA - male - 1280238 - Maharashtra vs Odisha
2021-11-04 - club - SMA - male - 1280200 - Goa vs Odisha
2021-01-18 - club - SMA - male - 1244385 - Assam vs Odisha
2021-01-16 - club - SMA - male - 1244368 - Jharkhand vs Odisha
2021-01-14 - club - SMA - male - 1244348 - Odisha vs Tamil Nadu
2021-01-10 - club - SMA - male - 1244309 - Odisha vs Bengal
2019-11-17 - club - SMA - male - 1205839 - Odisha vs Nagaland
2019-11-15 - club - SMA - male - 1205813 - Odisha vs Gujarat
2019-11-12 - club - SMA - male - 1205784 - Jammu & Kashmir vs Odisha
2019-11-11 - club - SMA - male - 1205767 - Sikkim vs Odisha
2019-03-02 - club - SMA - male - 1157205 - Odisha vs Bengal
2019-02-28 - club - SMA - male - 1157187 - Karnataka vs Odisha
2019-02-27 - club - SMA - male - 1157168 - Assam vs Odisha
2019-02-25 - club - SMA - male - 1157153 - Arunachal Pradesh vs Odisha
2019-02-24 - club - SMA - male - 1157136 - Mizoram vs Odisha
2019-02-22 - club - SMA - male - 1157119 - Haryana vs Odisha
2019-02-21 - club - SMA - male - 1157101 - Odisha vs Chhattisgarh
2018-01-16 - club - SMA - male - 1130684 - Odisha vs Jharkhand
2018-01-12 - club - SMA - male - 1130723 - Odisha vs Tripura
2018-01-10 - club - SMA - male - 1130714 - Odisha vs Assam
2018-01-08 - club - SMA - male - 1130672 - Odisha vs Bengal
2016-01-08 - club - SMA - male - 902177 - Odisha vs Karnataka
2016-01-07 - club - SMA - male - 902201 - Odisha vs Services
2016-01-04 - club - SMA - male - 902157 - Odisha vs Maharashtra
2016-01-03 - club - SMA - male - 902129 - Uttar Pradesh vs Odisha
2016-01-02 - club - SMA - male - 902105 - Odisha vs Mumbai
