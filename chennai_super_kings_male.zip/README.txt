This zip archive contains data files from Cricsheet in YAML format. This
archive contains 266 Chennai Super Kings matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/chennai_super_kings_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-05-21 - club - IPL - male - 1529309 - Gujarat Titans vs Chennai Super Kings
2026-05-18 - club - IPL - male - 1529306 - Chennai Super Kings vs Sunrisers Hyderabad
2026-05-15 - club - IPL - male - 1529302 - Chennai Super Kings vs Lucknow Super Giants
2026-05-10 - club - IPL - male - 1529296 - Lucknow Super Giants vs Chennai Super Kings
2026-05-05 - club - IPL - male - 1529291 - Delhi Capitals vs Chennai Super Kings
2026-05-02 - club - IPL - male - 1529287 - Mumbai Indians vs Chennai Super Kings
2026-04-26 - club - IPL - male - 1529280 - Chennai Super Kings vs Gujarat Titans
2026-04-23 - club - IPL - male - 1529276 - Chennai Super Kings vs Mumbai Indians
2026-04-18 - club - IPL - male - 1529270 - Sunrisers Hyderabad vs Chennai Super Kings
2026-04-14 - club - IPL - male - 1529265 - Chennai Super Kings vs Kolkata Knight Riders
2026-04-11 - club - IPL - male - 1527691 - Chennai Super Kings vs Delhi Capitals
2026-04-05 - club - IPL - male - 1527684 - Royal Challengers Bengaluru vs Chennai Super Kings
2026-04-03 - club - IPL - male - 1527680 - Chennai Super Kings vs Punjab Kings
2026-03-30 - club - IPL - male - 1527676 - Chennai Super Kings vs Rajasthan Royals
2025-05-25 - club - IPL - male - 1473504 - Chennai Super Kings vs Gujarat Titans
2025-05-20 - club - IPL - male - 1473500 - Chennai Super Kings vs Rajasthan Royals
2025-05-07 - club - IPL - male - 1473494 - Kolkata Knight Riders vs Chennai Super Kings
2025-05-03 - club - IPL - male - 1473489 - Royal Challengers Bengaluru vs Chennai Super Kings
2025-04-30 - club - IPL - male - 1473486 - Chennai Super Kings vs Punjab Kings
2025-04-25 - club - IPL - male - 1473480 - Chennai Super Kings vs Sunrisers Hyderabad
2025-04-20 - club - IPL - male - 1473475 - Chennai Super Kings vs Mumbai Indians
2025-04-14 - club - IPL - male - 1473467 - Lucknow Super Giants vs Chennai Super Kings
2025-04-11 - club - IPL - male - 1473462 - Chennai Super Kings vs Kolkata Knight Riders
2025-04-08 - club - IPL - male - 1473459 - Punjab Kings vs Chennai Super Kings
2025-04-05 - club - IPL - male - 1473454 - Delhi Capitals vs Chennai Super Kings
2025-03-30 - club - IPL - male - 1473448 - Rajasthan Royals vs Chennai Super Kings
2025-03-28 - club - IPL - male - 1473445 - Royal Challengers Bengaluru vs Chennai Super Kings
2025-03-23 - club - IPL - male - 1473440 - Mumbai Indians vs Chennai Super Kings
2024-05-18 - club - IPL - male - 1426306 - Royal Challengers Bengaluru vs Chennai Super Kings
2024-05-12 - club - IPL - male - 1426299 - Rajasthan Royals vs Chennai Super Kings
2024-05-10 - club - IPL - male - 1426297 - Gujarat Titans vs Chennai Super Kings
2024-05-05 - club - IPL - male - 1426291 - Chennai Super Kings vs Punjab Kings
2024-05-01 - club - IPL - male - 1426287 - Chennai Super Kings vs Punjab Kings
2024-04-28 - club - IPL - male - 1426284 - Chennai Super Kings vs Sunrisers Hyderabad
2024-04-23 - club - IPL - male - 1426277 - Chennai Super Kings vs Lucknow Super Giants
2024-04-19 - club - IPL - male - 1426272 - Chennai Super Kings vs Lucknow Super Giants
2024-04-14 - club - IPL - male - 1426267 - Chennai Super Kings vs Mumbai Indians
2024-04-08 - club - IPL - male - 1426260 - Kolkata Knight Riders vs Chennai Super Kings
2024-04-05 - club - IPL - male - 1422136 - Chennai Super Kings vs Sunrisers Hyderabad
2024-03-31 - club - IPL - male - 1422131 - Delhi Capitals vs Chennai Super Kings
2024-03-26 - club - IPL - male - 1422125 - Chennai Super Kings vs Gujarat Titans
2024-03-22 - club - IPL - male - 1422119 - Royal Challengers Bengaluru vs Chennai Super Kings
2023-05-29 - club - IPL - male - 1370353 - Gujarat Titans vs Chennai Super Kings
2023-05-23 - club - IPL - male - 1370350 - Chennai Super Kings vs Gujarat Titans
2023-05-20 - club - IPL - male - 1359541 - Chennai Super Kings vs Delhi Capitals
2023-05-14 - club - IPL - male - 1359535 - Chennai Super Kings vs Kolkata Knight Riders
2023-05-10 - club - IPL - male - 1359529 - Chennai Super Kings vs Delhi Capitals
2023-05-06 - club - IPL - male - 1359523 - Mumbai Indians vs Chennai Super Kings
2023-05-03 - club - IPL - male - 1359519 - Lucknow Super Giants vs Chennai Super Kings
2023-04-30 - club - IPL - male - 1359515 - Chennai Super Kings vs Punjab Kings
2023-04-27 - club - IPL - male - 1359511 - Rajasthan Royals vs Chennai Super Kings
2023-04-23 - club - IPL - male - 1359507 - Chennai Super Kings vs Kolkata Knight Riders
2023-04-21 - club - IPL - male - 1359503 - Sunrisers Hyderabad vs Chennai Super Kings
2023-04-17 - club - IPL - male - 1359498 - Chennai Super Kings vs Royal Challengers Bangalore
2023-04-12 - club - IPL - male - 1359491 - Rajasthan Royals vs Chennai Super Kings
2023-04-08 - club - IPL - male - 1359486 - Mumbai Indians vs Chennai Super Kings
2023-04-03 - club - IPL - male - 1359480 - Chennai Super Kings vs Lucknow Super Giants
2023-03-31 - club - IPL - male - 1359475 - Chennai Super Kings vs Gujarat Titans
2022-05-20 - club - IPL - male - 1304114 - Chennai Super Kings vs Rajasthan Royals
2022-05-15 - club - IPL - male - 1304108 - Chennai Super Kings vs Gujarat Titans
2022-05-12 - club - IPL - male - 1304105 - Chennai Super Kings vs Mumbai Indians
2022-05-08 - club - IPL - male - 1304101 - Chennai Super Kings vs Delhi Capitals
2022-05-04 - club - IPL - male - 1304095 - Royal Challengers Bangalore vs Chennai Super Kings
2022-05-01 - club - IPL - male - 1304092 - Chennai Super Kings vs Sunrisers Hyderabad
2022-04-25 - club - IPL - male - 1304084 - Punjab Kings vs Chennai Super Kings
2022-04-21 - club - IPL - male - 1304079 - Mumbai Indians vs Chennai Super Kings
2022-04-17 - club - IPL - male - 1304075 - Chennai Super Kings vs Gujarat Titans
2022-04-12 - club - IPL - male - 1304068 - Chennai Super Kings vs Royal Challengers Bangalore
2022-04-09 - club - IPL - male - 1304063 - Chennai Super Kings vs Sunrisers Hyderabad
2022-04-03 - club - IPL - male - 1304057 - Punjab Kings vs Chennai Super Kings
2022-03-31 - club - IPL - male - 1304053 - Chennai Super Kings vs Lucknow Super Giants
2022-03-26 - club - IPL - male - 1304047 - Chennai Super Kings vs Kolkata Knight Riders
2021-10-15 - club - IPL - male - 1254117 - Chennai Super Kings vs Kolkata Knight Riders
2021-10-10 - club - IPL - male - 1254114 - Delhi Capitals vs Chennai Super Kings
2021-10-07 - club - IPL - male - 1254094 - Chennai Super Kings vs Punjab Kings
2021-10-04 - club - IPL - male - 1254110 - Chennai Super Kings vs Delhi Capitals
2021-10-02 - club - IPL - male - 1254089 - Chennai Super Kings vs Rajasthan Royals
2021-09-30 - club - IPL - male - 1254091 - Sunrisers Hyderabad vs Chennai Super Kings
2021-09-26 - club - IPL - male - 1254098 - Kolkata Knight Riders vs Chennai Super Kings
2021-09-24 - club - IPL - male - 1254113 - Royal Challengers Bangalore vs Chennai Super Kings
2021-09-19 - club - IPL - male - 1254104 - Chennai Super Kings vs Mumbai Indians
2021-05-01 - club - IPL - male - 1254084 - Chennai Super Kings vs Mumbai Indians
2021-04-28 - club - IPL - male - 1254080 - Sunrisers Hyderabad vs Chennai Super Kings
2021-04-25 - club - IPL - male - 1254076 - Chennai Super Kings vs Royal Challengers Bangalore
2021-04-21 - club - IPL - male - 1254072 - Chennai Super Kings vs Kolkata Knight Riders
2021-04-19 - club - IPL - male - 1254069 - Chennai Super Kings vs Rajasthan Royals
2021-04-16 - club - IPL - male - 1254065 - Punjab Kings vs Chennai Super Kings
2021-04-10 - club - IPL - male - 1254059 - Chennai Super Kings vs Delhi Capitals
2020-11-01 - club - IPL - male - 1216506 - Kings XI Punjab vs Chennai Super Kings
2020-10-29 - club - IPL - male - 1216536 - Kolkata Knight Riders vs Chennai Super Kings
2020-10-25 - club - IPL - male - 1216544 - Royal Challengers Bangalore vs Chennai Super Kings
2020-10-23 - club - IPL - male - 1216521 - Chennai Super Kings vs Mumbai Indians
2020-10-19 - club - IPL - male - 1216533 - Chennai Super Kings vs Rajasthan Royals
2020-10-17 - club - IPL - male - 1216509 - Chennai Super Kings vs Delhi Capitals
2020-10-13 - club - IPL - male - 1216528 - Chennai Super Kings vs Sunrisers Hyderabad
2020-10-10 - club - IPL - male - 1216525 - Royal Challengers Bangalore vs Chennai Super Kings
2020-10-07 - club - IPL - male - 1216501 - Kolkata Knight Riders vs Chennai Super Kings
2020-10-04 - club - IPL - male - 1216513 - Kings XI Punjab vs Chennai Super Kings
2020-10-02 - club - IPL - male - 1216516 - Sunrisers Hyderabad vs Chennai Super Kings
2020-09-25 - club - IPL - male - 1216539 - Delhi Capitals vs Chennai Super Kings
2020-09-22 - club - IPL - male - 1216496 - Rajasthan Royals vs Chennai Super Kings
2020-09-19 - club - IPL - male - 1216492 - Mumbai Indians vs Chennai Super Kings
2019-05-12 - club - IPL - male - 1181768 - Mumbai Indians vs Chennai Super Kings
2019-05-10 - club - IPL - male - 1181767 - Chennai Super Kings vs Delhi Capitals
2019-05-07 - club - IPL - male - 1181764 - Mumbai Indians vs Chennai Super Kings
2019-05-05 - club - IPL - male - 1178430 - Kings XI Punjab vs Chennai Super Kings
2019-05-01 - club - IPL - male - 1178425 - Chennai Super Kings vs Delhi Capitals
2019-04-26 - club - IPL - male - 1178419 - Chennai Super Kings vs Mumbai Indians
2019-04-23 - club - IPL - male - 1178416 - Chennai Super Kings vs Sunrisers Hyderabad
2019-04-21 - club - IPL - male - 1178414 - Royal Challengers Bangalore vs Chennai Super Kings
2019-04-17 - club - IPL - male - 1178408 - Sunrisers Hyderabad vs Chennai Super Kings
2019-04-14 - club - IPL - male - 1178404 - Kolkata Knight Riders vs Chennai Super Kings
2019-04-11 - club - IPL - male - 1178400 - Rajasthan Royals vs Chennai Super Kings
2019-04-09 - club - IPL - male - 1178398 - Chennai Super Kings vs Kolkata Knight Riders
2019-04-06 - club - IPL - male - 1178393 - Chennai Super Kings vs Kings XI Punjab
2019-04-03 - club - IPL - male - 1175370 - Mumbai Indians vs Chennai Super Kings
2019-03-31 - club - IPL - male - 1175367 - Chennai Super Kings vs Rajasthan Royals
2019-03-26 - club - IPL - male - 1175360 - Delhi Capitals vs Chennai Super Kings
2019-03-23 - club - IPL - male - 1175356 - Chennai Super Kings vs Royal Challengers Bangalore
2018-05-27 - club - IPL - male - 1136620 - Chennai Super Kings vs Sunrisers Hyderabad
2018-05-22 - club - IPL - male - 1136617 - Sunrisers Hyderabad vs Chennai Super Kings
2018-05-20 - club - IPL - male - 1136616 - Chennai Super Kings vs Kings XI Punjab
2018-05-18 - club - IPL - male - 1136612 - Delhi Daredevils vs Chennai Super Kings
2018-05-13 - club - IPL - male - 1136606 - Chennai Super Kings vs Sunrisers Hyderabad
2018-05-11 - club - IPL - male - 1136603 - Rajasthan Royals vs Chennai Super Kings
2018-05-05 - club - IPL - male - 1136595 - Chennai Super Kings vs Royal Challengers Bangalore
2018-05-03 - club - IPL - male - 1136593 - Kolkata Knight Riders vs Chennai Super Kings
2018-04-30 - club - IPL - male - 1136590 - Chennai Super Kings vs Delhi Daredevils
2018-04-28 - club - IPL - male - 1136587 - Chennai Super Kings vs Mumbai Indians
2018-04-25 - club - IPL - male - 1136584 - Royal Challengers Bangalore vs Chennai Super Kings
2018-04-22 - club - IPL - male - 1136580 - Sunrisers Hyderabad vs Chennai Super Kings
2018-04-20 - club - IPL - male - 1136577 - Chennai Super Kings vs Rajasthan Royals
2018-04-15 - club - IPL - male - 1136572 - Kings XI Punjab vs Chennai Super Kings
2018-04-10 - club - IPL - male - 1136565 - Chennai Super Kings vs Kolkata Knight Riders
2018-04-07 - club - IPL - male - 1136561 - Mumbai Indians vs Chennai Super Kings
2015-05-24 - club - IPL - male - 829823 - Mumbai Indians vs Chennai Super Kings
2015-05-22 - club - IPL - male - 829821 - Chennai Super Kings vs Royal Challengers Bangalore
2015-05-19 - club - IPL - male - 829817 - Chennai Super Kings vs Mumbai Indians
2015-05-16 - club - IPL - male - 829809 - Kings XI Punjab vs Chennai Super Kings
2015-05-12 - club - IPL - male - 829801 - Delhi Daredevils vs Chennai Super Kings
2015-05-10 - club - IPL - male - 829797 - Chennai Super Kings vs Rajasthan Royals
2015-05-08 - club - IPL - male - 829789 - Chennai Super Kings vs Mumbai Indians
2015-05-04 - club - IPL - male - 829779 - Chennai Super Kings vs Royal Challengers Bangalore
2015-05-02 - club - IPL - male - 829773 - Sunrisers Hyderabad vs Chennai Super Kings
2015-04-30 - club - IPL - male - 829723 - Kolkata Knight Riders vs Chennai Super Kings
2015-04-28 - club - IPL - male - 829765 - Chennai Super Kings vs Kolkata Knight Riders
2015-04-25 - club - IPL - male - 829753 - Chennai Super Kings vs Kings XI Punjab
2015-04-22 - club - IPL - male - 829745 - Royal Challengers Bangalore vs Chennai Super Kings
2015-04-19 - club - IPL - male - 829735 - Rajasthan Royals vs Chennai Super Kings
2015-04-17 - club - IPL - male - 829729 - Mumbai Indians vs Chennai Super Kings
2015-04-11 - club - IPL - male - 829711 - Chennai Super Kings vs Sunrisers Hyderabad
2015-04-09 - club - IPL - male - 829707 - Chennai Super Kings vs Delhi Daredevils
2014-05-30 - club - IPL - male - 734047 - Chennai Super Kings vs Kings XI Punjab
2014-05-28 - club - IPL - male - 734045 - Chennai Super Kings vs Mumbai Indians
2014-05-24 - club - IPL - male - 734035 - Royal Challengers Bangalore vs Chennai Super Kings
2014-05-22 - club - IPL - male - 734029 - Chennai Super Kings vs Sunrisers Hyderabad
2014-05-20 - club - IPL - male - 734023 - Kolkata Knight Riders vs Chennai Super Kings
2014-05-18 - club - IPL - male - 734013 - Chennai Super Kings vs Royal Challengers Bangalore
2014-05-13 - club - IPL - male - 734003 - Chennai Super Kings vs Rajasthan Royals
2014-05-10 - club - IPL - male - 733995 - Mumbai Indians vs Chennai Super Kings
2014-05-07 - club - IPL - male - 733987 - Kings XI Punjab vs Chennai Super Kings
2014-05-05 - club - IPL - male - 733981 - Delhi Daredevils vs Chennai Super Kings
2014-05-02 - club - IPL - male - 733971 - Chennai Super Kings vs Kolkata Knight Riders
2014-04-27 - club - IPL - male - 729311 - Sunrisers Hyderabad vs Chennai Super Kings
2014-04-25 - club - IPL - male - 729303 - Chennai Super Kings vs Mumbai Indians
2014-04-23 - club - IPL - male - 729297 - Rajasthan Royals vs Chennai Super Kings
2014-04-21 - club - IPL - male - 729293 - Chennai Super Kings vs Delhi Daredevils
2014-04-18 - club - IPL - male - 729283 - Chennai Super Kings vs Kings XI Punjab
2013-05-26 - club - IPL - male - 598073 - Chennai Super Kings vs Mumbai Indians
2013-05-21 - club - IPL - male - 598070 - Chennai Super Kings vs Mumbai Indians
2013-05-18 - club - IPL - male - 598068 - Royal Challengers Bangalore vs Chennai Super Kings
2013-05-14 - club - IPL - male - 598062 - Chennai Super Kings vs Delhi Daredevils
2013-05-12 - club - IPL - male - 598058 - Rajasthan Royals vs Chennai Super Kings
2013-05-08 - club - IPL - male - 598051 - Sunrisers Hyderabad vs Chennai Super Kings
2013-05-05 - club - IPL - male - 598046 - Mumbai Indians vs Chennai Super Kings
2013-05-02 - club - IPL - male - 598041 - Chennai Super Kings vs Kings XI Punjab
2013-04-30 - club - IPL - male - 598038 - Pune Warriors vs Chennai Super Kings
2013-04-28 - club - IPL - male - 598034 - Chennai Super Kings vs Kolkata Knight Riders
2013-04-25 - club - IPL - male - 598030 - Chennai Super Kings vs Sunrisers Hyderabad
2013-04-22 - club - IPL - male - 598026 - Chennai Super Kings vs Rajasthan Royals
2013-04-20 - club - IPL - male - 598022 - Kolkata Knight Riders vs Chennai Super Kings
2013-04-18 - club - IPL - male - 598020 - Delhi Daredevils vs Chennai Super Kings
2013-04-15 - club - IPL - male - 598015 - Chennai Super Kings vs Pune Warriors
2013-04-13 - club - IPL - male - 598012 - Chennai Super Kings vs Royal Challengers Bangalore
2013-04-10 - club - IPL - male - 598007 - Kings XI Punjab vs Chennai Super Kings
2013-04-06 - club - IPL - male - 598002 - Chennai Super Kings vs Mumbai Indians
2012-05-27 - club - IPL - male - 548381 - Kolkata Knight Riders vs Chennai Super Kings
2012-05-25 - club - IPL - male - 548380 - Delhi Daredevils vs Chennai Super Kings
2012-05-23 - club - IPL - male - 548379 - Chennai Super Kings vs Mumbai Indians
2012-05-17 - club - IPL - male - 548371 - Kings XI Punjab vs Chennai Super Kings
2012-05-14 - club - IPL - male - 548368 - Kolkata Knight Riders vs Chennai Super Kings
2012-05-12 - club - IPL - male - 548364 - Chennai Super Kings vs Delhi Daredevils
2012-05-10 - club - IPL - male - 548361 - Rajasthan Royals vs Chennai Super Kings
2012-05-06 - club - IPL - male - 548355 - Mumbai Indians vs Chennai Super Kings
2012-05-04 - club - IPL - male - 548352 - Chennai Super Kings vs Deccan Chargers
2012-04-30 - club - IPL - male - 548347 - Chennai Super Kings vs Kolkata Knight Riders
2012-04-28 - club - IPL - male - 548343 - Chennai Super Kings vs Kings XI Punjab
2012-04-21 - club - IPL - male - 548332 - Chennai Super Kings vs Rajasthan Royals
2012-04-19 - club - IPL - male - 548330 - Chennai Super Kings vs Pune Warriors
2012-04-14 - club - IPL - male - 548322 - Pune Warriors vs Chennai Super Kings
2012-04-12 - club - IPL - male - 548318 - Chennai Super Kings vs Royal Challengers Bangalore
2012-04-10 - club - IPL - male - 548316 - Delhi Daredevils vs Chennai Super Kings
2012-04-07 - club - IPL - male - 548311 - Deccan Chargers vs Chennai Super Kings
2012-04-04 - club - IPL - male - 548306 - Chennai Super Kings vs Mumbai Indians
2011-05-28 - club - IPL - male - 501271 - Chennai Super Kings vs Royal Challengers Bangalore
2011-05-24 - club - IPL - male - 501268 - Royal Challengers Bangalore vs Chennai Super Kings
2011-05-22 - club - IPL - male - 501266 - Royal Challengers Bangalore vs Chennai Super Kings
2011-05-18 - club - IPL - male - 501261 - Chennai Super Kings vs Kochi Tuskers Kerala
2011-05-12 - club - IPL - male - 501253 - Chennai Super Kings vs Delhi Daredevils
2011-05-09 - club - IPL - male - 501249 - Rajasthan Royals vs Chennai Super Kings
2011-05-07 - club - IPL - male - 501245 - Kolkata Knight Riders vs Chennai Super Kings
2011-05-04 - club - IPL - male - 501240 - Chennai Super Kings vs Rajasthan Royals
2011-05-01 - club - IPL - male - 501236 - Chennai Super Kings vs Deccan Chargers
2011-04-27 - club - IPL - male - 501228 - Pune Warriors vs Chennai Super Kings
2011-04-25 - club - IPL - male - 501226 - Chennai Super Kings vs Pune Warriors
2011-04-22 - club - IPL - male - 501221 - Mumbai Indians vs Chennai Super Kings
2011-04-18 - club - IPL - male - 501215 - Kochi Tuskers Kerala vs Chennai Super Kings
2011-04-16 - club - IPL - male - 501211 - Chennai Super Kings vs Royal Challengers Bangalore
2011-04-13 - club - IPL - male - 501206 - Kings XI Punjab vs Chennai Super Kings
2011-04-08 - club - IPL - male - 501198 - Chennai Super Kings vs Kolkata Knight Riders
2010-04-25 - club - IPL - male - 419165 - Chennai Super Kings vs Mumbai Indians
2010-04-22 - club - IPL - male - 419163 - Chennai Super Kings vs Deccan Chargers
2010-04-18 - club - IPL - male - 419159 - Kings XI Punjab vs Chennai Super Kings
2010-04-15 - club - IPL - male - 419155 - Chennai Super Kings vs Delhi Daredevils
2010-04-13 - club - IPL - male - 419153 - Chennai Super Kings vs Kolkata Knight Riders
2010-04-10 - club - IPL - male - 419147 - Deccan Chargers vs Chennai Super Kings
2010-04-06 - club - IPL - male - 419142 - Chennai Super Kings vs Mumbai Indians
2010-04-03 - club - IPL - male - 419137 - Chennai Super Kings vs Rajasthan Royals
2010-03-31 - club - IPL - male - 419133 - Chennai Super Kings vs Royal Challengers Bangalore
2010-03-28 - club - IPL - male - 419129 - Rajasthan Royals vs Chennai Super Kings
2010-03-25 - club - IPL - male - 419125 - Chennai Super Kings vs Mumbai Indians
2010-03-23 - club - IPL - male - 419123 - Royal Challengers Bangalore vs Chennai Super Kings
2010-03-21 - club - IPL - male - 419121 - Chennai Super Kings vs Kings XI Punjab
2010-03-19 - club - IPL - male - 419116 - Delhi Daredevils vs Chennai Super Kings
2010-03-16 - club - IPL - male - 419113 - Kolkata Knight Riders vs Chennai Super Kings
2010-03-14 - club - IPL - male - 419110 - Chennai Super Kings vs Deccan Chargers
2009-05-23 - club - IPL - male - 392238 - Royal Challengers Bangalore vs Chennai Super Kings
2009-05-20 - club - IPL - male - 392234 - Chennai Super Kings vs Kings XI Punjab
2009-05-18 - club - IPL - male - 392231 - Chennai Super Kings vs Kolkata Knight Riders
2009-05-16 - club - IPL - male - 392227 - Chennai Super Kings vs Mumbai Indians
2009-05-14 - club - IPL - male - 392224 - Royal Challengers Bangalore vs Chennai Super Kings
2009-05-09 - club - IPL - male - 392217 - Chennai Super Kings vs Rajasthan Royals
2009-05-07 - club - IPL - male - 392214 - Chennai Super Kings vs Kings XI Punjab
2009-05-04 - club - IPL - male - 392209 - Chennai Super Kings vs Deccan Chargers
2009-05-02 - club - IPL - male - 392206 - Chennai Super Kings vs Delhi Daredevils
2009-04-30 - club - IPL - male - 392202 - Chennai Super Kings vs Rajasthan Royals
2009-04-27 - club - IPL - male - 392196 - Chennai Super Kings vs Deccan Chargers
2009-04-23 - club - IPL - male - 392189 - Chennai Super Kings vs Delhi Daredevils
2009-04-20 - club - IPL - male - 392185 - Royal Challengers Bangalore vs Chennai Super Kings
2009-04-18 - club - IPL - male - 392181 - Chennai Super Kings vs Mumbai Indians
2008-06-01 - club - IPL - male - 336040 - Chennai Super Kings vs Rajasthan Royals
2008-05-31 - club - IPL - male - 336039 - Chennai Super Kings vs Kings XI Punjab
2008-05-27 - club - IPL - male - 336037 - Deccan Chargers vs Chennai Super Kings
2008-05-24 - club - IPL - male - 336033 - Chennai Super Kings vs Rajasthan Royals
2008-05-21 - club - IPL - male - 336029 - Chennai Super Kings vs Royal Challengers Bangalore
2008-05-18 - club - IPL - male - 336025 - Kolkata Knight Riders vs Chennai Super Kings
2008-05-14 - club - IPL - male - 336018 - Mumbai Indians vs Chennai Super Kings
2008-05-10 - club - IPL - male - 336013 - Chennai Super Kings vs Kings XI Punjab
2008-05-08 - club - IPL - male - 336009 - Delhi Daredevils vs Chennai Super Kings
2008-05-06 - club - IPL - male - 336007 - Chennai Super Kings vs Deccan Chargers
2008-05-04 - club - IPL - male - 336005 - Rajasthan Royals vs Chennai Super Kings
2008-05-02 - club - IPL - male - 336001 - Chennai Super Kings vs Delhi Daredevils
2008-04-28 - club - IPL - male - 335996 - Royal Challengers Bangalore vs Chennai Super Kings
2008-04-26 - club - IPL - male - 335993 - Chennai Super Kings vs Kolkata Knight Riders
2008-04-23 - club - IPL - male - 335989 - Chennai Super Kings vs Mumbai Indians
2008-04-19 - club - IPL - male - 335983 - Kings XI Punjab vs Chennai Super Kings
