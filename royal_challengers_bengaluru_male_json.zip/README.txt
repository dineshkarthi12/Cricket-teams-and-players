This zip archive contains data files from Cricsheet in JSON format. This
archive contains 46 Royal Challengers Bengaluru matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/royal_challengers_bengaluru_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-05-31 - club - IPL - male - 1535465 - Gujarat Titans vs Royal Challengers Bengaluru
2026-05-26 - club - IPL - male - 1535462 - Royal Challengers Bengaluru vs Gujarat Titans
2026-05-22 - club - IPL - male - 1529310 - Sunrisers Hyderabad vs Royal Challengers Bengaluru
2026-05-17 - club - IPL - male - 1529304 - Royal Challengers Bengaluru vs Punjab Kings
2026-05-13 - club - IPL - male - 1529300 - Kolkata Knight Riders vs Royal Challengers Bengaluru
2026-05-10 - club - IPL - male - 1529297 - Mumbai Indians vs Royal Challengers Bengaluru
2026-05-07 - club - IPL - male - 1529293 - Lucknow Super Giants vs Royal Challengers Bengaluru
2026-04-30 - club - IPL - male - 1529285 - Royal Challengers Bengaluru vs Gujarat Titans
2026-04-27 - club - IPL - male - 1529282 - Delhi Capitals vs Royal Challengers Bengaluru
2026-04-24 - club - IPL - male - 1529277 - Gujarat Titans vs Royal Challengers Bengaluru
2026-04-18 - club - IPL - male - 1529269 - Royal Challengers Bengaluru vs Delhi Capitals
2026-04-15 - club - IPL - male - 1529266 - Lucknow Super Giants vs Royal Challengers Bengaluru
2026-04-12 - club - IPL - male - 1527693 - Royal Challengers Bengaluru vs Mumbai Indians
2026-04-10 - club - IPL - male - 1527689 - Royal Challengers Bengaluru vs Rajasthan Royals
2026-04-05 - club - IPL - male - 1527684 - Royal Challengers Bengaluru vs Chennai Super Kings
2026-03-28 - club - IPL - male - 1527674 - Sunrisers Hyderabad vs Royal Challengers Bengaluru
2025-06-03 - club - IPL - male - 1473511 - Royal Challengers Bengaluru vs Punjab Kings
2025-05-29 - club - IPL - male - 1473508 - Punjab Kings vs Royal Challengers Bengaluru
2025-05-27 - club - IPL - male - 1473507 - Lucknow Super Giants vs Royal Challengers Bengaluru
2025-05-23 - club - IPL - male - 1473503 - Sunrisers Hyderabad vs Royal Challengers Bengaluru
2025-05-03 - club - IPL - male - 1473489 - Royal Challengers Bengaluru vs Chennai Super Kings
2025-04-27 - club - IPL - male - 1473483 - Delhi Capitals vs Royal Challengers Bengaluru
2025-04-24 - club - IPL - male - 1473479 - Royal Challengers Bengaluru vs Rajasthan Royals
2025-04-20 - club - IPL - male - 1473474 - Punjab Kings vs Royal Challengers Bengaluru
2025-04-18 - club - IPL - male - 1473471 - Royal Challengers Bengaluru vs Punjab Kings
2025-04-13 - club - IPL - male - 1473465 - Rajasthan Royals vs Royal Challengers Bengaluru
2025-04-10 - club - IPL - male - 1473461 - Royal Challengers Bengaluru vs Delhi Capitals
2025-04-07 - club - IPL - male - 1473458 - Royal Challengers Bengaluru vs Mumbai Indians
2025-04-02 - club - IPL - male - 1473451 - Royal Challengers Bengaluru vs Gujarat Titans
2025-03-28 - club - IPL - male - 1473445 - Royal Challengers Bengaluru vs Chennai Super Kings
2025-03-22 - club - IPL - male - 1473438 - Kolkata Knight Riders vs Royal Challengers Bengaluru
2024-05-22 - club - IPL - male - 1426310 - Royal Challengers Bengaluru vs Rajasthan Royals
2024-05-18 - club - IPL - male - 1426306 - Royal Challengers Bengaluru vs Chennai Super Kings
2024-05-12 - club - IPL - male - 1426300 - Royal Challengers Bengaluru vs Delhi Capitals
2024-05-09 - club - IPL - male - 1426296 - Royal Challengers Bengaluru vs Punjab Kings
2024-05-04 - club - IPL - male - 1426290 - Gujarat Titans vs Royal Challengers Bengaluru
2024-04-28 - club - IPL - male - 1426283 - Gujarat Titans vs Royal Challengers Bengaluru
2024-04-25 - club - IPL - male - 1426279 - Royal Challengers Bengaluru vs Sunrisers Hyderabad
2024-04-21 - club - IPL - male - 1426274 - Kolkata Knight Riders vs Royal Challengers Bengaluru
2024-04-15 - club - IPL - male - 1426268 - Sunrisers Hyderabad vs Royal Challengers Bengaluru
2024-04-11 - club - IPL - male - 1426263 - Royal Challengers Bengaluru vs Mumbai Indians
2024-04-06 - club - IPL - male - 1422137 - Royal Challengers Bengaluru vs Rajasthan Royals
2024-04-02 - club - IPL - male - 1422133 - Lucknow Super Giants vs Royal Challengers Bengaluru
2024-03-29 - club - IPL - male - 1422128 - Royal Challengers Bengaluru vs Kolkata Knight Riders
2024-03-25 - club - IPL - male - 1422124 - Punjab Kings vs Royal Challengers Bengaluru
2024-03-22 - club - IPL - male - 1422119 - Royal Challengers Bengaluru vs Chennai Super Kings
