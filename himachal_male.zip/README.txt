This zip archive contains data files from Cricsheet in YAML format. This
archive contains 29 Himachal matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/himachal_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2021-11-16 - club - SMA - male - 1280295 - Himachal vs Kerala
2021-11-09 - club - SMA - male - 1280280 - Himachal vs Andhra
2021-11-05 - club - SMA - male - 1280224 - Himachal vs Jharkhand
2021-11-04 - club - SMA - male - 1280204 - Himachal vs Haryana
2021-01-26 - club - SMA - male - 1244402 - Himachal vs Tamil Nadu
2021-01-18 - club - SMA - male - 1244390 - Maharashtra vs Himachal
2021-01-16 - club - SMA - male - 1244369 - Uttarakhand vs Himachal
2021-01-14 - club - SMA - male - 1244351 - Himachal vs Gujarat
2021-01-12 - club - SMA - male - 1244333 - Himachal vs Baroda
2021-01-10 - club - SMA - male - 1244313 - Himachal vs Chhattisgarh
2019-11-18 - club - SMA - male - 1205835 - Himachal vs Railways
2019-11-15 - club - SMA - male - 1205816 - Himachal vs Maharashtra
2019-11-14 - club - SMA - male - 1205798 - Arunachal Pradesh vs Himachal
2019-11-12 - club - SMA - male - 1205780 - Himachal vs Punjab
2019-11-11 - club - SMA - male - 1205755 - Himachal vs Hyderabad (India)
2019-11-09 - club - SMA - male - 1205737 - Himachal vs Chhattisgarh
2019-02-28 - club - SMA - male - 1157181 - Himachal vs Rajasthan
2019-02-27 - club - SMA - male - 1157164 - Tamil Nadu vs Himachal
2019-02-25 - club - SMA - male - 1157146 - Bihar vs Himachal
2019-02-24 - club - SMA - male - 1157128 - Gujarat vs Himachal
2019-02-22 - club - SMA - male - 1157112 - Himachal vs Meghalaya
2018-01-15 - club - SMA - male - 1130720 - Punjab vs Himachal
2018-01-14 - club - SMA - male - 1130710 - Himachal vs Delhi
2018-01-13 - club - SMA - male - 1130704 - Himachal vs Services
2018-01-09 - club - SMA - male - 1130678 - Himachal vs Jammu & Kashmir
2018-01-08 - club - SMA - male - 1130664 - Himachal vs Haryana
2016-01-04 - club - SMA - male - 902139 - Bengal vs Himachal
2016-01-03 - club - SMA - male - 902113 - Hyderabad (India) vs Himachal
2016-01-02 - club - SMA - male - 902087 - Gujarat vs Himachal
