This zip archive contains data files from Cricsheet in JSON format. This
archive contains 47 Uttar Pradesh matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/uttar_pradesh_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2024-12-11 - club - SMA - male - 1446102 - Delhi vs Uttar Pradesh
2023-11-02 - club - SMA - male - 1383562 - Uttar Pradesh vs Punjab
2023-10-31 - club - SMA - male - 1383560 - Gujarat vs Uttar Pradesh
2023-10-25 - club - SMA - male - 1383539 - Uttar Pradesh vs Karnataka
2023-10-23 - club - SMA - male - 1383523 - Uttar Pradesh vs Tripura
2023-10-21 - club - SMA - male - 1383504 - Uttar Pradesh vs Nagaland
2022-10-22 - club - SMA - male - 1333029 - Uttar Pradesh vs Punjab
2022-10-14 - club - SMA - male - 1332958 - Delhi vs Uttar Pradesh
2021-11-09 - club - SMA - male - 1280288 - Hyderabad (India) vs Uttar Pradesh
2021-11-05 - club - SMA - male - 1280229 - Saurashtra vs Uttar Pradesh
2021-11-04 - club - SMA - male - 1280211 - Uttar Pradesh vs Chandigarh
2021-01-16 - club - SMA - male - 1244363 - Tripura vs Uttar Pradesh
2021-01-12 - club - SMA - male - 1244327 - Uttar Pradesh vs Railways
2021-01-10 - club - SMA - male - 1244307 - Punjab vs Uttar Pradesh
2019-11-17 - club - SMA - male - 1205824 - Kerala vs Uttar Pradesh
2019-11-15 - club - SMA - male - 1205807 - Manipur vs Uttar Pradesh
2019-11-12 - club - SMA - male - 1205771 - Tripura vs Uttar Pradesh
2019-11-11 - club - SMA - male - 1205753 - Tamil Nadu vs Uttar Pradesh
2019-11-09 - club - SMA - male - 1205743 - Uttar Pradesh vs Vidarbha
2019-03-12 - club - SMA - male - 1175042 - Mumbai vs Uttar Pradesh
2019-03-11 - club - SMA - male - 1175040 - Uttar Pradesh vs Delhi
2019-03-10 - club - SMA - male - 1175034 - Vidarbha vs Uttar Pradesh
2019-03-09 - club - SMA - male - 1175032 - Karnataka vs Uttar Pradesh
2019-03-02 - club - SMA - male - 1157206 - Baroda vs Uttar Pradesh
2019-02-28 - club - SMA - male - 1157192 - Uttar Pradesh vs Uttarakhand
2019-02-27 - club - SMA - male - 1157175 - Uttar Pradesh vs Services
2019-02-25 - club - SMA - male - 1157157 - Uttar Pradesh vs Puducherry
2019-02-24 - club - SMA - male - 1157141 - Uttar Pradesh vs Tripura
2019-02-22 - club - SMA - male - 1157122 - Hyderabad (India) vs Uttar Pradesh
2019-02-21 - club - SMA - male - 1157106 - Maharashtra vs Uttar Pradesh
2018-01-25 - club - SMA - male - 1133419 - Delhi vs Uttar Pradesh
2018-01-24 - club - SMA - male - 1133415 - Baroda vs Uttar Pradesh
2018-01-23 - club - SMA - male - 1133411 - Uttar Pradesh vs Tamil Nadu
2018-01-22 - club - SMA - male - 1133407 - Uttar Pradesh vs Bengal
2018-01-16 - club - SMA - male - 1130724 - Chhattisgarh vs Uttar Pradesh
2018-01-15 - club - SMA - male - 1130719 - Uttar Pradesh vs Vidarbha
2018-01-13 - club - SMA - male - 1130703 - Railways vs Uttar Pradesh
2018-01-10 - club - SMA - male - 1130681 - Uttar Pradesh vs Madhya Pradesh
2018-01-09 - club - SMA - male - 1130674 - Uttar Pradesh vs Rajasthan
2016-01-20 - club - SMA - male - 955069 - Uttar Pradesh vs Baroda
2016-01-18 - club - SMA - male - 955067 - Delhi vs Uttar Pradesh
2016-01-16 - club - SMA - male - 955059 - Gujarat vs Uttar Pradesh
2016-01-08 - club - SMA - male - 902179 - Uttar Pradesh vs Services
2016-01-07 - club - SMA - male - 902203 - Mumbai vs Uttar Pradesh
2016-01-04 - club - SMA - male - 902153 - Karnataka vs Uttar Pradesh
2016-01-03 - club - SMA - male - 902129 - Uttar Pradesh vs Odisha
2016-01-02 - club - SMA - male - 902109 - Maharashtra vs Uttar Pradesh
