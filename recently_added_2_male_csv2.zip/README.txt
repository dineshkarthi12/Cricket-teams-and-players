All recently added Men's match data in CSV format
=================================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the YAML data provided on the site into a CSV format. That
initial version was heavily influenced by the format used by the baseball
project Retrosheet. I wasn't sure of the usefulness of my CSV format, but
nothing better was suggested so I persisted with it. Later Ashwin Raman
(https://twitter.com/AshwinRaman_) send me a detailed example of a format
he felt might work and, liking what I saw, I started to produce data in
a slightly modified version of that initial example.

This particular zip folder contains the CSV data for...
  All recently added Men's matches
...for which we have data.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the original? Ideally I'd like
to settle on a single CSV format so what should be kept from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_ashwin/
but the following is a brief summary of the details...

This format consists of 2 files per match, although you can get all of
the ball-by-ball data from just one of the files. The files for a match
are named <id>.csv (for the ball-by-ball data), and <id>_info.csv (for
the match info), where <id> is the Cricinfo id for the match. The
ball-by-ball file contains one row per delivery in the match, while the
match info file contains match information such as dates the match was
played, the outcome, and lists of the players involved in the match.

The match info file format
--------------------------

The info section contains the information on the actual match, such as
when and where it was played, any event it was part of, the type of
match etc. The fields included in the info section will each appear as
one or more rows in the data. Some of the fields are required, whereas
some are optional. If a field has multiple values, such as team, then
each value will appear on a row of it's own.

The ball-by-ball file format
----------------------------

The first row of each ball-by-ball CSV file contains the headers for the
file, with each subsequent row providing details on a single delivery.
The headers in the file are:

  * match_id
  * season
  * start_date
  * venue
  * innings
  * ball
  * batting_team
  * bowling_team
  * striker
  * non_striker
  * bowler
  * runs_off_bat
  * extras
  * wides
  * noballs
  * byes
  * legbyes
  * penalty
  * wicket_type
  * player_dismissed
  * other_wicket_type
  * other_player_dismissed

Most of the fields above should, hopefully, be self-explanatory, but some may
benefit from clarification...

"innings" contains the number of the innings within the match. If a match is
one that would normally have 2 innings, such as a T20 or ODI, then any innings
of more than 2 can be regarded as a super over.

"ball" is a combination of the over and delivery. For example, "0.3" represents
the 3rd ball of the 1st over.

"wides", "noballs", "byes", "legbyes", and "penalty" contain the total of each
particular type of extras, or are blank if not relevant to the delivery.

If a wicket occurred on a delivery then "wicket_type" will contain the method
of dismissal, while "player_dismissed" will indicate who was dismissed. There
is also the, admittedly remote, possibility that a second dismissal can be
recorded on the delivery (such as when a player retires on the same delivery
as another dismissal occurs). In this case "other_wicket_type" will record
the reason, while "other_player_dismissed" will show who was dismissed.

Matches included in this archive
--------------------------------

2026-09-17 - international - T20 - male - 1552923 - Kenya vs Botswana
2026-09-17 - international - T20 - male - 1552922 - Uganda vs Rwanda
2026-09-17 - international - T20 - male - 1552897 - United Arab Emirates vs Malaysia
2026-09-17 - international - T20 - male - 1496586 - Sri Lanka vs England
2026-09-17 - club - ETPL - male - 1547901 - Rotterdam Dockers vs Dublin Guardians
2026-09-17 - club - ETPL - male - 1547900 - Belfast Wolves vs Edinburgh Castle Rockers
2026-09-16 - international - T20 - male - 1552921 - Sierra Leone vs Rwanda
2026-09-16 - international - T20 - male - 1552920 - Botswana vs Uganda
2026-09-16 - international - T20 - male - 1552896 - Malaysia vs United Arab Emirates
2026-09-16 - club - MCT - male - 1535542 - Sinhalese Sports Club vs Tamil Union Cricket and Athletic Club
2026-09-16 - club - ETPL - male - 1547899 - Glasgow Cosmic vs Amsterdam Flames
2026-09-16 - club - CPL - male - 1534214 - Barbados Tridents vs Jamaica Kingsmen
2026-09-15 - international - T20 - male - 1552919 - Kenya vs Rwanda
2026-09-15 - international - T20 - male - 1552918 - Sierra Leone vs Uganda
2026-09-15 - international - T20 - male - 1496585 - England vs Sri Lanka
2026-09-15 - international - ODI - male - 1530203 - Australia vs Zimbabwe
2026-09-15 - club - ETPL - male - 1547898 - Rotterdam Dockers vs Edinburgh Castle Rockers
2026-09-15 - club - ETPL - male - 1547897 - Amsterdam Flames vs Dublin Guardians
2026-09-15 - club - CCH - male - 1513447 - Lancashire vs Kent
2026-09-15 - club - CCH - male - 1513386 - Essex vs Warwickshire
2026-09-14 - international - T20 - male - 1552895 - Malaysia vs United Arab Emirates
2026-09-13 - international - T20 - male - 1552917 - Rwanda vs Botswana
2026-09-13 - international - T20 - male - 1552916 - Sierra Leone vs Kenya
2026-09-13 - international - ODI - male - 1549533 - Namibia vs South Africa
2026-09-13 - club - MCT - male - 1535541 - Sinhalese Sports Club vs Nondescripts Cricket Club
2026-09-13 - club - MCT - male - 1535540 - Tamil Union Cricket and Athletic Club vs Colombo Cricket Club
2026-09-13 - club - ETPL - male - 1547896 - Belfast Wolves vs Glasgow Cosmic
2026-09-13 - club - ETPL - male - 1547895 - Edinburgh Castle Rockers vs Amsterdam Flames
2026-09-13 - club - CPL - male - 1534213 - Guyana Amazon Warriors vs Barbados Tridents
2026-09-12 - international - T20 - male - 1552915 - Botswana vs Sierra Leone
2026-09-12 - international - T20 - male - 1552914 - Uganda vs Kenya
2026-09-12 - international - ODI - male - 1549969 - Nepal vs United Arab Emirates
2026-09-12 - club - ETPL - male - 1547894 - Dublin Guardians vs Glasgow Cosmic
2026-09-12 - club - ETPL - male - 1547893 - Belfast Wolves vs Rotterdam Dockers
2026-09-12 - club - CPL - male - 1534212 - Jamaica Kingsmen vs Barbados Tridents
2026-09-11 - international - T20 - male - 1552913 - Botswana vs Kenya
2026-09-11 - international - T20 - male - 1552912 - Uganda vs Rwanda
2026-09-11 - international - ODI - male - 1549532 - South Africa vs Namibia
2026-09-11 - club - MCL - male - 1547446 - Moors Sports Club vs Sinhalese Sports Club
2026-09-11 - club - ETPL - male - 1547892 - Edinburgh Castle Rockers vs Dublin Guardians
2026-09-11 - club - CPL - male - 1534211 - Trinbago Knight Riders vs Guyana Amazon Warriors
2026-09-10 - international - T20 - male - 1552911 - Rwanda vs Sierra Leone
2026-09-10 - international - T20 - male - 1552910 - Botswana vs Uganda
2026-09-10 - international - ODI - male - 1549966 - Nepal vs Oman
2026-09-10 - club - ETPL - male - 1547891 - Amsterdam Flames vs Belfast Wolves
2026-09-10 - club - ETPL - male - 1547890 - Rotterdam Dockers vs Glasgow Cosmic
2026-09-10 - club - CPL - male - 1534210 - St Kitts and Nevis Patriots vs Barbados Tridents
2026-09-09 - international - Test - male - 1496584 - Pakistan vs England
2026-09-09 - club - CPL - male - 1534209 - St Lucia Kings vs Guyana Amazon Warriors
2026-09-08 - club - CCH - male - 1513443 - Gloucestershire vs Lancashire
2026-09-08 - club - CCH - male - 1513442 - Durham vs Middlesex
2026-09-08 - club - CCH - male - 1513441 - Worcestershire vs Northamptonshire
2026-09-08 - club - CCH - male - 1513440 - Derbyshire vs Kent
2026-09-08 - club - CCH - male - 1513385 - Somerset vs Leicestershire
2026-09-08 - club - CCH - male - 1513384 - Sussex vs Surrey
2026-09-08 - club - CCH - male - 1513382 - Yorkshire vs Essex
2026-09-08 - club - CCH - male - 1513381 - Nottinghamshire vs Hampshire

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
