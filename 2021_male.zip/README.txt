This zip archive contains data files from Cricsheet in YAML format. This
archive contains 1296 matches of all types from 2021. A further 13 matches
have been withheld due to either featuring the Afghanistan men's team or being
played in the Afghanistan Premier League, due to the Cricsheet policy to no
longer feature matches involving Afghanistan men or played in Afghanistan
Premier League (see https://cricsheet.org/withheld-matches for more
information).


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/2021_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2021-12-31 - club - SSM - male - 1289622 - Central Districts vs Canterbury
2021-12-31 - club - BBL - male - 1269665 - Sydney Thunder vs Adelaide Strikers
2021-12-30 - club - SSM - male - 1289621 - Central Districts vs Northern Districts
2021-12-29 - club - SSM - male - 1289620 - Otago vs Auckland
2021-12-29 - club - BBL - male - 1269663 - Hobart Hurricanes vs Melbourne Renegades
2021-12-29 - club - BBL - male - 1269662 - Brisbane Heat vs Sydney Sixers
2021-12-28 - club - SSM - male - 1289619 - Otago vs Wellington
2021-12-28 - club - BBL - male - 1269661 - Sydney Thunder vs Perth Scorchers
2021-12-27 - club - SSM - male - 1289618 - Central Districts vs Auckland
2021-12-27 - club - BBL - male - 1269660 - Melbourne Stars vs Brisbane Heat
2021-12-27 - club - BBL - male - 1269659 - Adelaide Strikers vs Hobart Hurricanes
2021-12-26 - international - Test - male - 1277079 - India vs South Africa
2021-12-26 - international - Test - male - 1263464 - England vs Australia
2021-12-26 - club - SSM - male - 1289617 - Canterbury vs Otago
2021-12-26 - club - BBL - male - 1269658 - Melbourne Renegades vs Perth Scorchers
2021-12-26 - club - BBL - male - 1269657 - Sydney Sixers vs Sydney Thunder
2021-12-24 - club - SSM - male - 1289616 - Auckland vs Wellington
2021-12-24 - club - BBL - male - 1269656 - Hobart Hurricanes vs Melbourne Stars
2021-12-23 - international - T20 - male - 1291188 - Ireland vs United States of America
2021-12-23 - club - SSM - male - 1289615 - Canterbury vs Northern Districts
2021-12-23 - club - LPL - male - 1291218 - Jaffna Kings vs Galle Gladiators
2021-12-23 - club - BBL - male - 1269655 - Brisbane Heat vs Adelaide Strikers
2021-12-22 - international - T20 - male - 1291187 - United States of America vs Ireland
2021-12-22 - club - BBL - male - 1269654 - Perth Scorchers vs Melbourne Renegades
2021-12-21 - club - LPL - male - 1291217 - Jaffna Kings vs Dambulla Giants
2021-12-21 - club - BBL - male - 1269653 - Adelaide Strikers vs Sydney Sixers
2021-12-20 - club - SSM - male - 1289604 - Auckland vs Northern Districts
2021-12-20 - club - BBL - male - 1269652 - Perth Scorchers vs Hobart Hurricanes
2021-12-19 - club - SSM - male - 1289614 - Wellington vs Canterbury
2021-12-19 - club - LPL - male - 1291216 - Galle Gladiators vs Jaffna Kings
2021-12-19 - club - LPL - male - 1291215 - Colombo Stars vs Dambulla Giants
2021-12-19 - club - BBL - male - 1269651 - Sydney Thunder vs Brisbane Heat
2021-12-18 - club - SSM - male - 1289613 - Central Districts vs Otago
2021-12-17 - club - SSM - male - 1289612 - Auckland vs Northern Districts
2021-12-17 - club - LPL - male - 1291214 - Colombo Stars vs Kandy Warriors
2021-12-17 - club - LPL - male - 1291213 - Galle Gladiators vs Jaffna Kings
2021-12-16 - international - Test - male - 1263463 - Australia vs England
2021-12-16 - international - T20 - male - 1287775 - West Indies vs Pakistan
2021-12-16 - club - LPL - male - 1291212 - Dambulla Giants vs Kandy Warriors
2021-12-16 - club - LPL - male - 1291211 - Jaffna Kings vs Colombo Stars
2021-12-15 - club - BBL - male - 1269650 - Melbourne Stars vs Sydney Sixers
2021-12-14 - international - T20 - male - 1287774 - Pakistan vs West Indies
2021-12-14 - club - LPL - male - 1291210 - Galle Gladiators vs Dambulla Giants
2021-12-14 - club - LPL - male - 1291209 - Kandy Warriors vs Colombo Stars
2021-12-14 - club - BBL - male - 1269649 - Perth Scorchers vs Hobart Hurricanes
2021-12-13 - international - T20 - male - 1287773 - Pakistan vs West Indies
2021-12-13 - club - LPL - male - 1291208 - Dambulla Giants vs Jaffna Kings
2021-12-13 - club - BBL - male - 1269648 - Melbourne Renegades vs Brisbane Heat
2021-12-12 - club - SSM - male - 1289611 - Northern Districts vs Otago
2021-12-12 - club - LPL - male - 1291207 - Colombo Stars vs Galle Gladiators
2021-12-12 - club - LPL - male - 1291206 - Kandy Warriors vs Jaffna Kings
2021-12-12 - club - BBL - male - 1269647 - Sydney Thunder vs Melbourne Stars
2021-12-11 - club - LPL - male - 1291205 - Dambulla Giants vs Colombo Stars
2021-12-11 - club - LPL - male - 1291204 - Galle Gladiators vs Kandy Warriors
2021-12-11 - club - BBL - male - 1269646 - Perth Scorchers vs Adelaide Strikers
2021-12-11 - club - BBL - male - 1269645 - Hobart Hurricanes vs Sydney Sixers
2021-12-10 - club - SSM - male - 1289609 - Canterbury vs Central Districts
2021-12-10 - club - LPL - male - 1291203 - Jaffna Kings vs Colombo Stars
2021-12-10 - club - LPL - male - 1291202 - Dambulla Giants vs Galle Gladiators
2021-12-10 - club - BBL - male - 1269644 - Melbourne Stars vs Sydney Thunder
2021-12-09 - club - BBL - male - 1269643 - Adelaide Strikers vs Melbourne Renegades
2021-12-08 - international - Test - male - 1263462 - England vs Australia
2021-12-08 - club - LPL - male - 1291201 - Jaffna Kings vs Kandy Warriors
2021-12-08 - club - LPL - male - 1291200 - Dambulla Giants vs Colombo Stars
2021-12-08 - club - BBL - male - 1269642 - Perth Scorchers vs Brisbane Heat
2021-12-08 - club - BBL - male - 1269641 - Sydney Sixers vs Hobart Hurricanes
2021-12-07 - club - LPL - male - 1291199 - Kandy Warriors vs Galle Gladiators
2021-12-07 - club - LPL - male - 1291198 - Dambulla Giants vs Jaffna Kings
2021-12-07 - club - BBL - male - 1269640 - Melbourne Renegades vs Adelaide Strikers
2021-12-06 - club - LPL - male - 1291197 - Galle Gladiators vs Colombo Stars
2021-12-06 - club - LPL - male - 1291196 - Dambulla Giants vs Kandy Warriors
2021-12-06 - club - BBL - male - 1269639 - Brisbane Heat vs Sydney Thunder
2021-12-05 - club - SSM - male - 1289608 - Central Districts vs Wellington
2021-12-05 - club - LPL - male - 1291195 - Galle Gladiators vs Jaffna Kings
2021-12-05 - club - BBL - male - 1269638 - Sydney Sixers vs Melbourne Stars
2021-12-04 - international - Test - male - 1277978 - Pakistan vs Bangladesh
2021-12-03 - international - Test - male - 1278675 - India vs New Zealand
2021-12-03 - club - SSM - male - 1289606 - Northern Districts vs Otago
2021-11-29 - international - Test - male - 1288346 - Sri Lanka vs West Indies
2021-11-28 - club - SSM - male - 1289605 - Otago vs Central Districts
2021-11-28 - club - ODC - male - 1270476 - South Australia vs Queensland
2021-11-26 - international - Test - male - 1277977 - Bangladesh vs Pakistan
2021-11-26 - international - ODI - male - 1290881 - Namibia vs Oman
2021-11-26 - international - ODI - male - 1277073 - South Africa vs Netherlands
2021-11-26 - club - SSM - male - 1289603 - Wellington vs Canterbury
2021-11-26 - club - ODC - male - 1270487 - Western Australia vs Tasmania
2021-11-25 - international - Test - male - 1278674 - India vs New Zealand
2021-11-24 - club - ODC - male - 1270479 - New South Wales vs Victoria
2021-11-23 - club - SSH - male - 1270441 - Queensland vs South Australia
2021-11-22 - international - T20 - male - 1277976 - Bangladesh vs Pakistan
2021-11-22 - club - SMA - male - 1280302 - Karnataka vs Tamil Nadu
2021-11-22 - club - PKS - male - 1279995 - Otago Volts vs Northern Districts
2021-11-21 - international - Test - male - 1288345 - Sri Lanka vs West Indies
2021-11-21 - international - T20 - male - 1278673 - India vs New Zealand
2021-11-20 - international - T20 - male - 1289053 - Tanzania vs Nigeria
2021-11-20 - international - T20 - male - 1289052 - Kenya vs Uganda
2021-11-20 - international - T20 - male - 1289051 - Kenya vs Nigeria
2021-11-20 - international - T20 - male - 1289050 - Tanzania vs Uganda
2021-11-20 - international - T20 - male - 1277975 - Bangladesh vs Pakistan
2021-11-20 - club - SSH - male - 1270462 - New South Wales vs Victoria
2021-11-20 - club - SMA - male - 1280301 - Karnataka vs Vidarbha
2021-11-20 - club - SMA - male - 1280300 - Hyderabad (India) vs Tamil Nadu
2021-11-19 - international - T20 - male - 1278672 - New Zealand vs India
2021-11-19 - international - T20 - male - 1277974 - Bangladesh vs Pakistan
2021-11-18 - international - T20 - male - 1289049 - Nigeria vs Uganda
2021-11-18 - international - T20 - male - 1289048 - Tanzania vs Kenya
2021-11-18 - international - T20 - male - 1289047 - Nigeria vs Kenya
2021-11-18 - international - T20 - male - 1289046 - Tanzania vs Uganda
2021-11-18 - club - SMA - male - 1280299 - Hyderabad (India) vs Gujarat
2021-11-18 - club - SMA - male - 1280298 - Rajasthan vs Vidarbha
2021-11-18 - club - SMA - male - 1280297 - Karnataka vs Bengal
2021-11-18 - club - SMA - male - 1280296 - Kerala vs Tamil Nadu
2021-11-17 - international - T20 - male - 1289045 - Tanzania vs Kenya
2021-11-17 - international - T20 - male - 1289044 - Uganda vs Nigeria
2021-11-17 - international - T20 - male - 1289043 - Kenya vs Uganda
2021-11-17 - international - T20 - male - 1289042 - Nigeria vs Tanzania
2021-11-17 - international - T20 - male - 1278671 - New Zealand vs India
2021-11-16 - club - SMA - male - 1280295 - Himachal vs Kerala
2021-11-16 - club - SMA - male - 1280294 - Saurashtra vs Karnataka
2021-11-16 - club - SMA - male - 1280293 - Maharashtra vs Vidarbha
2021-11-15 - club - PKS - male - 1279998 - Wellington Firebirds vs Central Stags
2021-11-15 - club - PKS - male - 1279997 - Northern Districts vs Canterbury
2021-11-15 - club - ODC - male - 1270484 - Western Australia vs Queensland
2021-11-14 - international - T20 - male - 1286686 - Canada vs Panama
2021-11-14 - international - T20 - male - 1273756 - New Zealand vs Australia
2021-11-13 - international - T20 - male - 1286685 - Argentina vs Canada
2021-11-13 - international - T20 - male - 1286684 - Panama vs Bahamas
2021-11-13 - international - T20 - male - 1286683 - Belize vs Bermuda
2021-11-13 - international - T20 - male - 1286682 - Bahamas vs United States of America
2021-11-11 - international - T20 - male - 1286681 - Argentina vs United States of America
2021-11-11 - international - T20 - male - 1273755 - Pakistan vs Australia
2021-11-10 - international - T20 - male - 1286677 - Bermuda vs Bahamas
2021-11-10 - international - T20 - male - 1286675 - Argentina vs Belize
2021-11-10 - international - T20 - male - 1286674 - Canada vs United States of America
2021-11-10 - international - T20 - male - 1273754 - England vs New Zealand
2021-11-10 - club - SSH - male - 1270456 - Queensland vs Western Australia
2021-11-10 - club - SSH - male - 1270446 - South Australia vs Tasmania
2021-11-09 - club - SMA - male - 1280292 - Meghalaya vs Arunachal Pradesh
2021-11-09 - club - SMA - male - 1280291 - Vidarbha vs Sikkim
2021-11-09 - club - SMA - male - 1280290 - Manipur vs Mizoram
2021-11-09 - club - SMA - male - 1280289 - Nagaland vs Tripura
2021-11-09 - club - SMA - male - 1280288 - Hyderabad (India) vs Uttar Pradesh
2021-11-09 - club - SMA - male - 1280287 - Saurashtra vs Delhi
2021-11-09 - club - SMA - male - 1280286 - Uttarakhand vs Chandigarh
2021-11-09 - club - SMA - male - 1280285 - Railways vs Assam
2021-11-09 - club - SMA - male - 1280284 - Madhya Pradesh vs Kerala
2021-11-09 - club - SMA - male - 1280283 - Bihar vs Gujarat
2021-11-09 - club - SMA - male - 1280282 - Jammu & Kashmir vs Jharkhand
2021-11-09 - club - SMA - male - 1280281 - Rajasthan vs Haryana
2021-11-09 - club - SMA - male - 1280280 - Himachal vs Andhra
2021-11-09 - club - SMA - male - 1280279 - Karnataka vs Bengal
2021-11-09 - club - SMA - male - 1280278 - Chhattisgarh vs Services
2021-11-09 - club - SMA - male - 1280277 - Mumbai vs Baroda
2021-11-09 - club - SMA - male - 1280276 - Punjab vs Tamil Nadu
2021-11-09 - club - SMA - male - 1280275 - Maharashtra vs Goa
2021-11-09 - club - SMA - male - 1280274 - Odisha vs Puducherry
2021-11-08 - international - T20 - male - 1286673 - United States of America vs Bermuda
2021-11-08 - international - T20 - male - 1286672 - Belize vs Panama
2021-11-08 - international - T20 - male - 1286671 - Bahamas vs Argentina
2021-11-08 - international - T20 - male - 1286670 - Canada vs Belize
2021-11-08 - international - T20 - male - 1273753 - Namibia vs India
2021-11-08 - club - SMA - male - 1280273 - Vidarbha vs Manipur
2021-11-08 - club - SMA - male - 1280272 - Tripura vs Meghalaya
2021-11-08 - club - SMA - male - 1280271 - Nagaland vs Arunachal Pradesh
2021-11-08 - club - SMA - male - 1280270 - Mizoram vs Sikkim
2021-11-08 - club - SMA - male - 1280269 - Saurashtra vs Chandigarh
2021-11-08 - club - SMA - male - 1280266 - Bihar vs Madhya Pradesh
2021-11-08 - club - SMA - male - 1280264 - Assam vs Kerala
2021-11-08 - club - SMA - male - 1280263 - Rajasthan vs Andhra
2021-11-08 - club - SMA - male - 1280260 - Chhattisgarh vs Mumbai
2021-11-08 - club - SMA - male - 1280259 - Baroda vs Karnataka
2021-11-08 - club - SMA - male - 1280258 - Services vs Bengal
2021-11-08 - club - SMA - male - 1280257 - Maharashtra vs Puducherry
2021-11-08 - club - SMA - male - 1280255 - Tamil Nadu vs Goa
2021-11-07 - international - T20 - male - 1286667 - Belize vs United States of America
2021-11-07 - international - T20 - male - 1283051 - Tanzania vs Botswana
2021-11-07 - international - T20 - male - 1283050 - Cameroon vs Sierra Leone
2021-11-07 - international - T20 - male - 1273752 - Pakistan vs Scotland
2021-11-07 - club - PKS - male - 1280003 - Canterbury vs Wellington Firebirds
2021-11-07 - club - PKS - male - 1280001 - Otago Volts vs Central Stags
2021-11-06 - international - T20 - male - 1283049 - Tanzania vs Cameroon
2021-11-06 - international - T20 - male - 1283048 - Botswana vs Mozambique
2021-11-06 - international - T20 - male - 1273750 - South Africa vs England
2021-11-06 - international - T20 - male - 1273749 - West Indies vs Australia
2021-11-06 - club - SMA - male - 1280252 - Meghalaya vs Vidarbha
2021-11-06 - club - SMA - male - 1280251 - Tripura vs Manipur
2021-11-06 - club - SMA - male - 1280250 - Saurashtra vs Uttarakhand
2021-11-06 - club - SMA - male - 1280249 - Chandigarh vs Hyderabad (India)
2021-11-06 - club - SMA - male - 1280247 - Gujarat vs Madhya Pradesh
2021-11-06 - club - SMA - male - 1280246 - Bihar vs Assam
2021-11-06 - club - SMA - male - 1280245 - Railways vs Kerala
2021-11-06 - club - SMA - male - 1280243 - Andhra vs Jharkhand
2021-11-06 - club - SMA - male - 1280242 - Haryana vs Jammu & Kashmir
2021-11-06 - club - SMA - male - 1280241 - Chhattisgarh vs Baroda
2021-11-06 - club - SMA - male - 1280240 - Mumbai vs Bengal
2021-11-06 - club - SMA - male - 1280239 - Karnataka vs Services
2021-11-06 - club - SMA - male - 1280238 - Maharashtra vs Odisha
2021-11-06 - club - SMA - male - 1280237 - Puducherry vs Tamil Nadu
2021-11-06 - club - SMA - male - 1280236 - Punjab vs Goa
2021-11-05 - international - T20 - male - 1283047 - Mozambique vs Sierra Leone
2021-11-05 - international - T20 - male - 1283046 - Cameroon vs Botswana
2021-11-05 - international - T20 - male - 1273748 - Scotland vs India
2021-11-05 - international - T20 - male - 1273747 - New Zealand vs Namibia
2021-11-05 - club - SSH - male - 1270437 - Victoria vs New South Wales
2021-11-05 - club - SMA - male - 1280235 - Tripura vs Mizoram
2021-11-05 - club - SMA - male - 1280234 - Arunachal Pradesh vs Manipur
2021-11-05 - club - SMA - male - 1280233 - Nagaland vs Vidarbha
2021-11-05 - club - SMA - male - 1280232 - Sikkim vs Meghalaya
2021-11-05 - club - SMA - male - 1280231 - Chandigarh vs Delhi
2021-11-05 - club - SMA - male - 1280230 - Hyderabad (India) vs Uttarakhand
2021-11-05 - club - SMA - male - 1280229 - Saurashtra vs Uttar Pradesh
2021-11-05 - club - SMA - male - 1280228 - Bihar vs Kerala
2021-11-05 - club - SMA - male - 1280227 - Gujarat vs Assam
2021-11-05 - club - SMA - male - 1280226 - Railways vs Madhya Pradesh
2021-11-05 - club - SMA - male - 1280225 - Andhra vs Haryana
2021-11-05 - club - SMA - male - 1280224 - Himachal vs Jharkhand
2021-11-05 - club - SMA - male - 1280223 - Jammu & Kashmir vs Rajasthan
2021-11-05 - club - SMA - male - 1280221 - Bengal vs Baroda
2021-11-05 - club - SMA - male - 1280220 - Chhattisgarh vs Karnataka
2021-11-05 - club - SMA - male - 1280219 - Goa vs Puducherry
2021-11-05 - club - SMA - male - 1280217 - Punjab vs Maharashtra
2021-11-04 - international - T20 - male - 1273746 - Sri Lanka vs West Indies
2021-11-04 - international - T20 - male - 1273745 - Bangladesh vs Australia
2021-11-04 - club - SMA - male - 1280216 - Mizoram vs Meghalaya
2021-11-04 - club - SMA - male - 1280214 - Tripura vs Sikkim
2021-11-04 - club - SMA - male - 1280213 - Vidarbha vs Arunachal Pradesh
2021-11-04 - club - SMA - male - 1280212 - Delhi vs Uttarakhand
2021-11-04 - club - SMA - male - 1280211 - Uttar Pradesh vs Chandigarh
2021-11-04 - club - SMA - male - 1280210 - Saurashtra vs Hyderabad (India)
2021-11-04 - club - SMA - male - 1280209 - Kerala vs Gujarat
2021-11-04 - club - SMA - male - 1280208 - Bihar vs Railways
2021-11-04 - club - SMA - male - 1280207 - Assam vs Madhya Pradesh
2021-11-04 - club - SMA - male - 1280204 - Himachal vs Haryana
2021-11-04 - club - SMA - male - 1280203 - Baroda vs Services
2021-11-04 - club - SMA - male - 1280202 - Karnataka vs Mumbai
2021-11-04 - club - SMA - male - 1280201 - Chhattisgarh vs Bengal
2021-11-04 - club - SMA - male - 1280200 - Goa vs Odisha
2021-11-04 - club - SMA - male - 1280198 - Tamil Nadu vs Maharashtra
2021-11-03 - international - T20 - male - 1283045 - Sierra Leone vs Tanzania
2021-11-03 - international - T20 - male - 1283044 - Mozambique vs Cameroon
2021-11-03 - international - T20 - male - 1273743 - New Zealand vs Scotland
2021-11-02 - international - T20 - male - 1283043 - Tanzania vs Mozambique
2021-11-02 - international - T20 - male - 1283042 - Botswana vs Sierra Leone
2021-11-02 - international - T20 - male - 1273742 - Pakistan vs Namibia
2021-11-02 - international - T20 - male - 1273741 - Bangladesh vs South Africa
2021-11-01 - international - T20 - male - 1273740 - England vs Sri Lanka
2021-11-01 - club - ODC - male - 1270472 - Queensland vs Tasmania
2021-10-31 - international - T20 - male - 1273739 - India vs New Zealand
2021-10-31 - club - PKS - male - 1279994 - Canterbury vs Wellington Firebirds
2021-10-31 - club - PKS - male - 1279992 - Central Stags vs Otago Volts
2021-10-30 - international - T20 - male - 1273737 - Australia vs England
2021-10-30 - international - T20 - male - 1273736 - Sri Lanka vs South Africa
2021-10-29 - international - T20 - male - 1284497 - Kuwait vs Qatar
2021-10-29 - international - T20 - male - 1273734 - West Indies vs Bangladesh
2021-10-28 - international - T20 - male - 1284496 - Bahrain vs Saudi Arabia
2021-10-28 - international - T20 - male - 1284495 - Maldives vs Kuwait
2021-10-28 - international - T20 - male - 1273733 - Sri Lanka vs Australia
2021-10-27 - international - T20 - male - 1284493 - Maldives vs Bahrain
2021-10-27 - international - T20 - male - 1273732 - Scotland vs Namibia
2021-10-27 - international - T20 - male - 1273731 - Bangladesh vs England
2021-10-27 - club - SSH - male - 1270442 - Victoria vs New South Wales
2021-10-26 - international - T20 - male - 1283094 - Nigeria vs Sierra Leone
2021-10-26 - international - T20 - male - 1273730 - New Zealand vs Pakistan
2021-10-26 - international - T20 - male - 1273729 - West Indies vs South Africa
2021-10-25 - club - ODC - male - 1270482 - South Australia vs Western Australia
2021-10-24 - international - T20 - male - 1284491 - Qatar vs Maldives
2021-10-24 - international - T20 - male - 1284490 - Bahrain vs Kuwait
2021-10-24 - international - T20 - male - 1283093 - Nigeria vs Sierra Leone
2021-10-24 - international - T20 - male - 1282279 - Malta vs Switzerland
2021-10-24 - international - T20 - male - 1282278 - Gibraltar vs Bulgaria
2021-10-24 - international - T20 - male - 1273727 - India vs Pakistan
2021-10-24 - international - T20 - male - 1273726 - Bangladesh vs Sri Lanka
2021-10-23 - international - T20 - male - 1284489 - Maldives vs Saudi Arabia
2021-10-23 - international - T20 - male - 1283092 - Sierra Leone vs Nigeria
2021-10-23 - international - T20 - male - 1282276 - Switzerland vs Malta
2021-10-23 - international - T20 - male - 1273725 - West Indies vs England
2021-10-23 - international - T20 - male - 1273724 - South Africa vs Australia
2021-10-23 - club - PKS - male - 1279990 - Central Stags vs Canterbury
2021-10-23 - club - PKS - male - 1279989 - Otago Volts vs Wellington Firebirds
2021-10-22 - international - T20 - male - 1283041 - Uganda vs Seychelles
2021-10-22 - international - T20 - male - 1283040 - Malawi vs Rwanda
2021-10-22 - international - T20 - male - 1283038 - Swaziland vs Rwanda
2021-10-22 - international - T20 - male - 1282275 - Bulgaria vs Switzerland
2021-10-22 - international - T20 - male - 1282273 - Gibraltar vs Switzerland
2021-10-22 - international - T20 - male - 1273723 - Netherlands vs Sri Lanka
2021-10-22 - international - T20 - male - 1273722 - Ireland vs Namibia
2021-10-21 - international - T20 - male - 1283091 - Nigeria vs Sierra Leone
2021-10-21 - international - T20 - male - 1283037 - Uganda vs Ghana
2021-10-21 - international - T20 - male - 1282749 - Denmark vs Jersey
2021-10-21 - international - T20 - male - 1282748 - Italy vs Germany
2021-10-21 - international - T20 - male - 1282272 - Malta vs Gibraltar
2021-10-21 - international - T20 - male - 1273721 - Oman vs Scotland
2021-10-21 - international - T20 - male - 1273720 - Bangladesh vs Papua New Guinea
2021-10-20 - international - T20 - male - 1283036 - Rwanda vs Lesotho
2021-10-20 - international - T20 - male - 1283035 - Swaziland vs Seychelles
2021-10-20 - international - T20 - male - 1283034 - Swaziland vs Ghana
2021-10-20 - international - T20 - male - 1283033 - Malawi vs Seychelles
2021-10-20 - international - T20 - male - 1282747 - Germany vs Denmark
2021-10-20 - international - T20 - male - 1282746 - Italy vs Jersey
2021-10-20 - international - T20 - male - 1273719 - Sri Lanka vs Ireland
2021-10-20 - international - T20 - male - 1273718 - Netherlands vs Namibia
2021-10-19 - international - T20 - male - 1283089 - Nigeria vs Sierra Leone
2021-10-19 - international - T20 - male - 1283032 - Swaziland vs Uganda
2021-10-19 - international - T20 - male - 1283030 - Lesotho vs Uganda
2021-10-19 - international - T20 - male - 1283029 - Malawi vs Ghana
2021-10-19 - international - T20 - male - 1282745 - Germany vs Jersey
2021-10-19 - international - T20 - male - 1282744 - Italy vs Denmark
2021-10-19 - international - T20 - male - 1273717 - Bangladesh vs Oman
2021-10-19 - international - T20 - male - 1273716 - Scotland vs Papua New Guinea
2021-10-18 - international - T20 - male - 1273715 - Namibia vs Sri Lanka
2021-10-18 - international - T20 - male - 1273714 - Netherlands vs Ireland
2021-10-17 - international - T20 - male - 1283028 - Uganda vs Rwanda
2021-10-17 - international - T20 - male - 1283026 - Swaziland vs Malawi
2021-10-17 - international - T20 - male - 1283025 - Lesotho vs Seychelles
2021-10-17 - international - T20 - male - 1282743 - Italy vs Germany
2021-10-17 - international - T20 - male - 1282742 - Jersey vs Denmark
2021-10-17 - international - T20 - male - 1273713 - Scotland vs Bangladesh
2021-10-17 - international - T20 - male - 1273712 - Papua New Guinea vs Oman
2021-10-17 - club - SSH - male - 1270452 - Western Australia vs Tasmania
2021-10-16 - international - T20 - male - 1283024 - Malawi vs Uganda
2021-10-16 - international - T20 - male - 1283023 - Seychelles vs Ghana
2021-10-16 - international - T20 - male - 1283021 - Rwanda vs Ghana
2021-10-16 - international - T20 - male - 1282741 - Jersey vs Italy
2021-10-16 - international - T20 - male - 1282740 - Denmark vs Germany
2021-10-15 - international - T20 - male - 1282739 - Denmark vs Italy
2021-10-15 - international - T20 - male - 1282738 - Jersey vs Germany
2021-10-15 - club - SSH - male - 1270448 - Queensland vs South Australia
2021-10-15 - club - ODC - male - 1270480 - Western Australia vs Tasmania
2021-10-15 - club - IPL - male - 1254117 - Chennai Super Kings vs Kolkata Knight Riders
2021-10-13 - club - ODC - male - 1270478 - South Australia vs Queensland
2021-10-13 - club - IPL - male - 1254116 - Delhi Capitals vs Kolkata Knight Riders
2021-10-11 - club - IPL - male - 1254115 - Royal Challengers Bangalore vs Kolkata Knight Riders
2021-10-10 - international - T20 - male - 1280062 - Ireland vs United Arab Emirates
2021-10-10 - international - T20 - male - 1280059 - Namibia vs Papua New Guinea
2021-10-10 - club - IPL - male - 1254114 - Delhi Capitals vs Chennai Super Kings
2021-10-09 - international - T20 - male - 1280058 - Scotland vs Namibia
2021-10-08 - international - T20 - male - 1280063 - Papua New Guinea vs Scotland
2021-10-08 - international - T20 - male - 1280061 - United Arab Emirates vs Ireland
2021-10-08 - international - T20 - male - 1279386 - Estonia vs Isle of Man
2021-10-08 - international - T20 - male - 1279385 - Cyprus vs Estonia
2021-10-08 - club - IPL - male - 1254101 - Delhi Capitals vs Royal Challengers Bangalore
2021-10-08 - club - IPL - male - 1254088 - Mumbai Indians vs Sunrisers Hyderabad
2021-10-07 - international - T20 - male - 1280060 - United Arab Emirates vs Ireland
2021-10-07 - international - T20 - male - 1279383 - Cyprus vs Isle of Man
2021-10-07 - club - SSH - male - 1270435 - Tasmania vs Queensland
2021-10-07 - club - IPL - male - 1254106 - Kolkata Knight Riders vs Rajasthan Royals
2021-10-07 - club - IPL - male - 1254094 - Chennai Super Kings vs Punjab Kings
2021-10-06 - international - T20 - male - 1279382 - Estonia vs Isle of Man
2021-10-06 - international - T20 - male - 1279381 - Cyprus vs Isle of Man
2021-10-06 - club - IPL - male - 1254095 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2021-10-05 - international - T20 - male - 1279380 - Estonia vs Cyprus
2021-10-05 - international - T20 - male - 1279379 - Estonia vs Cyprus
2021-10-05 - club - IPL - male - 1254093 - Rajasthan Royals vs Mumbai Indians
2021-10-04 - club - IPL - male - 1254110 - Chennai Super Kings vs Delhi Capitals
2021-10-03 - club - IPL - male - 1254109 - Sunrisers Hyderabad vs Kolkata Knight Riders
2021-10-03 - club - IPL - male - 1254090 - Royal Challengers Bangalore vs Punjab Kings
2021-10-02 - international - ODI - male - 1275260 - Scotland vs Oman
2021-10-02 - club - IPL - male - 1254112 - Mumbai Indians vs Delhi Capitals
2021-10-02 - club - IPL - male - 1254089 - Chennai Super Kings vs Rajasthan Royals
2021-10-01 - international - ODI - male - 1275259 - Papua New Guinea vs Oman
2021-10-01 - club - IPL - male - 1254102 - Kolkata Knight Riders vs Punjab Kings
2021-09-30 - club - IPL - male - 1254091 - Sunrisers Hyderabad vs Chennai Super Kings
2021-09-29 - international - ODI - male - 1275258 - Papua New Guinea vs Scotland
2021-09-29 - club - IPL - male - 1254103 - Rajasthan Royals vs Royal Challengers Bangalore
2021-09-28 - international - ODI - male - 1275257 - Scotland vs Oman
2021-09-28 - club - IPL - male - 1254099 - Punjab Kings vs Mumbai Indians
2021-09-28 - club - IPL - male - 1254092 - Delhi Capitals vs Kolkata Knight Riders
2021-09-28 - club - BWT - male - 1279470 - Lancashire vs Warwickshire
2021-09-27 - club - IPL - male - 1254100 - Rajasthan Royals vs Sunrisers Hyderabad
2021-09-26 - international - ODI - male - 1275256 - Oman vs Papua New Guinea
2021-09-26 - club - IPL - male - 1254108 - Royal Challengers Bangalore vs Mumbai Indians
2021-09-26 - club - IPL - male - 1254098 - Kolkata Knight Riders vs Chennai Super Kings
2021-09-25 - international - ODI - male - 1275255 - Papua New Guinea vs Scotland
2021-09-25 - club - IPL - male - 1254107 - Punjab Kings vs Sunrisers Hyderabad
2021-09-25 - club - IPL - male - 1254097 - Delhi Capitals vs Rajasthan Royals
2021-09-24 - club - SSH - male - 1270436 - Western Australia vs South Australia
2021-09-24 - club - IPL - male - 1254113 - Royal Challengers Bangalore vs Chennai Super Kings
2021-09-23 - club - IPL - male - 1254096 - Mumbai Indians vs Kolkata Knight Riders
2021-09-22 - club - ODC - male - 1270473 - Western Australia vs South Australia
2021-09-22 - club - IPL - male - 1254105 - Sunrisers Hyderabad vs Delhi Capitals
2021-09-21 - club - IPL - male - 1254111 - Rajasthan Royals vs Punjab Kings
2021-09-21 - club - CCH - male - 1271416 - Leicestershire vs Worcestershire
2021-09-21 - club - CCH - male - 1271415 - Derbyshire vs Sussex
2021-09-21 - club - CCH - male - 1271414 - Middlesex vs Kent
2021-09-21 - club - CCH - male - 1271413 - Glamorgan vs Surrey
2021-09-21 - club - CCH - male - 1271412 - Durham vs Gloucestershire
2021-09-21 - club - CCH - male - 1271411 - Northamptonshire vs Essex
2021-09-21 - club - CCH - male - 1271410 - Warwickshire vs Somerset
2021-09-21 - club - CCH - male - 1271409 - Nottinghamshire vs Yorkshire
2021-09-21 - club - CCH - male - 1271408 - Hampshire vs Lancashire
2021-09-20 - club - IPL - male - 1254087 - Royal Challengers Bangalore vs Kolkata Knight Riders
2021-09-19 - international - T20 - male - 1273273 - Scotland vs Zimbabwe
2021-09-19 - international - ODI - male - 1275253 - Oman vs Nepal
2021-09-19 - club - IPT - male - 1259552 - Leinster Lightning vs North-West Warriors
2021-09-19 - club - IPT - male - 1259551 - Munster Reds vs Northern Knights
2021-09-19 - club - IPL - male - 1254104 - Chennai Super Kings vs Mumbai Indians
2021-09-18 - club - NTB - male - 1250368 - Kent vs Somerset
2021-09-18 - club - NTB - male - 1250367 - Kent vs Sussex
2021-09-18 - club - NTB - male - 1250366 - Hampshire vs Somerset
2021-09-18 - club - IPT - male - 1259550 - North-West Warriors vs Munster Reds
2021-09-17 - international - T20 - male - 1275051 - Uganda vs Kenya
2021-09-17 - international - T20 - male - 1273272 - Zimbabwe vs Scotland
2021-09-16 - international - T20 - male - 1275045 - Nigeria vs Kenya
2021-09-16 - international - ODI - male - 1275251 - United States of America vs Oman
2021-09-15 - international - T20 - male - 1275047 - Uganda vs Nigeria
2021-09-15 - international - T20 - male - 1273271 - Scotland vs Zimbabwe
2021-09-15 - club - CPL - male - 1269732 - St Lucia Kings vs St Kitts and Nevis Patriots
2021-09-14 - international - T20 - male - 1271632 - Sri Lanka vs South Africa
2021-09-14 - international - ODI - male - 1275250 - Nepal vs Oman
2021-09-14 - club - CPL - male - 1269731 - Guyana Amazon Warriors vs St Kitts and Nevis Patriots
2021-09-14 - club - CPL - male - 1269730 - St Lucia Kings vs Trinbago Knight Riders
2021-09-13 - international - T20 - male - 1275043 - Nigeria vs Uganda
2021-09-13 - international - T20 - male - 1275042 - Kenya vs Nigeria
2021-09-13 - international - ODI - male - 1275249 - United States of America vs Nepal
2021-09-13 - international - ODI - male - 1272381 - Zimbabwe vs Ireland
2021-09-12 - international - T20 - male - 1271631 - Sri Lanka vs South Africa
2021-09-12 - club - CPL - male - 1269729 - St Kitts and Nevis Patriots vs Trinbago Knight Riders
2021-09-12 - club - CPL - male - 1269728 - Guyana Amazon Warriors vs Jamaica Tallawahs
2021-09-12 - club - CPL - male - 1269727 - St Lucia Kings vs Barbados Royals
2021-09-12 - club - CCH - male - 1271407 - Middlesex vs Worcestershire
2021-09-12 - club - CCH - male - 1271406 - Sussex vs Leicestershire
2021-09-12 - club - CCH - male - 1271405 - Kent vs Derbyshire
2021-09-12 - club - CCH - male - 1271404 - Essex vs Surrey
2021-09-12 - club - CCH - male - 1271403 - Northamptonshire vs Durham
2021-09-12 - club - CCH - male - 1271402 - Glamorgan vs Gloucestershire
2021-09-12 - club - CCH - male - 1271401 - Warwickshire vs Yorkshire
2021-09-12 - club - CCH - male - 1271400 - Lancashire vs Somerset
2021-09-12 - club - CCH - male - 1271399 - Hampshire vs Nottinghamshire
2021-09-11 - international - T20 - male - 1275054 - Germany vs Spain
2021-09-11 - international - T20 - male - 1275053 - Germany vs Spain
2021-09-11 - international - T20 - male - 1275040 - Uganda vs Nigeria
2021-09-11 - international - T20 - male - 1275039 - Nigeria vs Kenya
2021-09-11 - club - CPL - male - 1269726 - Trinbago Knight Riders vs St Kitts and Nevis Patriots
2021-09-11 - club - CPL - male - 1269725 - Guyana Amazon Warriors vs Jamaica Tallawahs
2021-09-11 - club - CPL - male - 1269724 - St Lucia Kings vs Barbados Royals
2021-09-10 - international - T20 - male - 1275052 - Spain vs Germany
2021-09-10 - international - T20 - male - 1275044 - Kenya vs Uganda
2021-09-10 - international - T20 - male - 1272097 - New Zealand vs Bangladesh
2021-09-10 - international - T20 - male - 1271630 - South Africa vs Sri Lanka
2021-09-10 - international - ODI - male - 1276296 - Nepal vs Papua New Guinea
2021-09-10 - international - ODI - male - 1272380 - Ireland vs Zimbabwe
2021-09-09 - international - ODI - male - 1276294 - United States of America vs Papua New Guinea
2021-09-09 - club - CPL - male - 1269723 - Jamaica Tallawahs vs St Lucia Kings
2021-09-09 - club - CPL - male - 1269722 - Barbados Royals vs Trinbago Knight Riders
2021-09-08 - international - T20 - male - 1272096 - New Zealand vs Bangladesh
2021-09-08 - international - ODI - male - 1272379 - Zimbabwe vs Ireland
2021-09-08 - club - CPL - male - 1269721 - Guyana Amazon Warriors vs St Lucia Kings
2021-09-08 - club - CPL - male - 1269720 - Jamaica Tallawahs vs St Kitts and Nevis Patriots
2021-09-07 - international - ODI - male - 1276295 - Papua New Guinea vs Nepal
2021-09-07 - international - ODI - male - 1271629 - Sri Lanka vs South Africa
2021-09-07 - club - CPL - male - 1269719 - Barbados Royals vs Guyana Amazon Warriors
2021-09-07 - club - CPL - male - 1269718 - Trinbago Knight Riders vs Jamaica Tallawahs
2021-09-06 - international - ODI - male - 1276293 - Papua New Guinea vs United States of America
2021-09-06 - club - CCH - male - 1271398 - Middlesex vs Sussex
2021-09-05 - international - T20 - male - 1275277 - Romania vs Luxembourg
2021-09-05 - international - T20 - male - 1275276 - Malta vs Hungary
2021-09-05 - international - T20 - male - 1272095 - New Zealand vs Bangladesh
2021-09-05 - club - CPL - male - 1269717 - Jamaica Tallawahs vs Trinbago Knight Riders
2021-09-05 - club - CPL - male - 1269716 - St Kitts and Nevis Patriots vs St Lucia Kings
2021-09-05 - club - CCH - male - 1271397 - Worcestershire vs Kent
2021-09-05 - club - CCH - male - 1271396 - Leicestershire vs Derbyshire
2021-09-05 - club - CCH - male - 1271395 - Surrey vs Northamptonshire
2021-09-05 - club - CCH - male - 1271394 - Gloucestershire vs Essex
2021-09-05 - club - CCH - male - 1271393 - Glamorgan vs Durham
2021-09-05 - club - CCH - male - 1271392 - Somerset vs Yorkshire
2021-09-05 - club - CCH - male - 1271391 - Hampshire vs Warwickshire
2021-09-05 - club - CCH - male - 1271390 - Nottinghamshire vs Lancashire
2021-09-04 - international - T20 - male - 1275275 - Romania vs Malta
2021-09-04 - international - T20 - male - 1275274 - Luxembourg vs Hungary
2021-09-04 - international - T20 - male - 1272377 - Zimbabwe vs Ireland
2021-09-04 - international - ODI - male - 1271628 - South Africa vs Sri Lanka
2021-09-04 - club - CPL - male - 1269715 - Barbados Royals vs Guyana Amazon Warriors
2021-09-04 - club - CPL - male - 1269714 - St Lucia Kings vs St Kitts and Nevis Patriots
2021-09-03 - international - T20 - male - 1275272 - Romania vs Hungary
2021-09-03 - international - T20 - male - 1275271 - Bulgaria vs Malta
2021-09-03 - international - T20 - male - 1275268 - Romania vs Czech Republic
2021-09-03 - international - T20 - male - 1272094 - Bangladesh vs New Zealand
2021-09-02 - international - Test - male - 1239546 - India vs England
2021-09-02 - international - T20 - male - 1275270 - Hungary vs Czech Republic
2021-09-02 - international - T20 - male - 1275269 - Luxembourg vs Bulgaria
2021-09-02 - international - T20 - male - 1272376 - Ireland vs Zimbabwe
2021-09-02 - international - ODI - male - 1271627 - Sri Lanka vs South Africa
2021-09-02 - club - CPL - male - 1269713 - Barbados Royals vs St Kitts and Nevis Patriots
2021-09-02 - club - CPL - male - 1269712 - St Lucia Kings vs Guyana Amazon Warriors
2021-09-01 - international - T20 - male - 1272375 - Ireland vs Zimbabwe
2021-09-01 - international - T20 - male - 1272093 - New Zealand vs Bangladesh
2021-09-01 - club - CPL - male - 1269711 - Jamaica Tallawahs vs St Kitts and Nevis Patriots
2021-09-01 - club - CPL - male - 1269710 - Trinbago Knight Riders vs Guyana Amazon Warriors
2021-08-31 - club - CPL - male - 1269709 - Barbados Royals vs Jamaica Tallawahs
2021-08-31 - club - CPL - male - 1269708 - Trinbago Knight Riders vs St Lucia Kings
2021-08-30 - club - CCH - male - 1271389 - Sussex vs Worcestershire
2021-08-30 - club - CCH - male - 1271388 - Middlesex vs Derbyshire
2021-08-30 - club - CCH - male - 1271387 - Kent vs Leicestershire
2021-08-30 - club - CCH - male - 1271386 - Northamptonshire vs Gloucestershire
2021-08-30 - club - CCH - male - 1271385 - Glamorgan vs Essex
2021-08-30 - club - CCH - male - 1271383 - Nottinghamshire vs Somerset
2021-08-30 - club - CCH - male - 1271382 - Warwickshire vs Lancashire
2021-08-30 - club - CCH - male - 1271381 - Yorkshire vs Hampshire
2021-08-29 - international - T20 - male - 1272374 - Zimbabwe vs Ireland
2021-08-29 - club - CPL - male - 1269707 - Guyana Amazon Warriors vs St Kitts and Nevis Patriots
2021-08-29 - club - CPL - male - 1269706 - St Lucia Kings vs Trinbago Knight Riders
2021-08-28 - club - CPL - male - 1269705 - Barbados Royals vs Jamaica Tallawahs
2021-08-28 - club - CPL - male - 1269704 - Guyana Amazon Warriors vs St Kitts and Nevis Patriots
2021-08-27 - international - T20 - male - 1272373 - Zimbabwe vs Ireland
2021-08-27 - club - NTB - male - 1250365 - Kent vs Birmingham Bears
2021-08-27 - club - CPL - male - 1269703 - Barbados Royals vs Trinbago Knight Riders
2021-08-27 - club - CPL - male - 1269702 - Jamaica Tallawahs vs St Lucia Kings
2021-08-26 - club - NTB - male - 1250364 - Lancashire vs Somerset
2021-08-26 - club - CPL - male - 1269701 - St Kitts and Nevis Patriots vs Barbados Royals
2021-08-26 - club - CPL - male - 1269700 - Guyana Amazon Warriors vs Trinbago Knight Riders
2021-08-25 - international - Test - male - 1239545 - India vs England
2021-08-25 - club - NTB - male - 1250363 - Hampshire vs Nottinghamshire
2021-08-24 - club - NTB - male - 1250362 - Yorkshire vs Sussex
2021-08-22 - international - T20 - male - 1273149 - Finland vs Sweden
2021-08-22 - international - T20 - male - 1273148 - Finland vs Sweden
2021-08-22 - international - T20 - male - 1273139 - Portugal vs Gibraltar
2021-08-21 - international - T20 - male - 1273147 - Sweden vs Finland
2021-08-21 - international - T20 - male - 1273146 - Sweden vs Finland
2021-08-21 - international - T20 - male - 1273145 - Rwanda vs Ghana
2021-08-21 - international - T20 - male - 1273138 - Malta vs Gibraltar
2021-08-21 - club - HND - male - 1252699 - Southern Brave vs Birmingham Phoenix
2021-08-20 - international - Test - male - 1263170 - Pakistan vs West Indies
2021-08-20 - international - T20 - male - 1273144 - Ghana vs Rwanda
2021-08-20 - international - T20 - male - 1273143 - Rwanda vs Ghana
2021-08-20 - international - T20 - male - 1273136 - Gibraltar vs Malta
2021-08-20 - club - HND - male - 1252698 - Trent Rockets vs Southern Brave
2021-08-19 - club - RLC - male - 1250235 - Glamorgan vs Durham
2021-08-18 - international - T20 - male - 1273141 - Ghana vs Rwanda
2021-08-18 - club - HND - male - 1252697 - London Spirit vs Welsh Fire
2021-08-17 - club - RLC - male - 1250234 - Surrey vs Durham
2021-08-17 - club - HND - male - 1252696 - Northern Superchargers vs Birmingham Phoenix
2021-08-16 - club - RLC - male - 1250233 - Essex vs Glamorgan
2021-08-16 - club - HND - male - 1252695 - Oval Invincibles vs Southern Brave
2021-08-15 - international - T20 - male - 1273134 - Sweden vs Denmark
2021-08-15 - club - RLC - male - 1250232 - Gloucestershire vs Surrey
2021-08-15 - club - HND - male - 1252694 - Manchester Originals vs Trent Rockets
2021-08-14 - international - T20 - male - 1273133 - Denmark vs Sweden
2021-08-14 - club - RLC - male - 1250231 - Essex vs Yorkshire
2021-08-14 - club - HND - male - 1252693 - London Spirit vs Oval Invincibles
2021-08-13 - club - HND - male - 1252692 - Birmingham Phoenix vs Trent Rockets
2021-08-12 - international - Test - male - 1263169 - Pakistan vs West Indies
2021-08-12 - international - Test - male - 1239544 - India vs England
2021-08-12 - club - RLC - male - 1250230 - Somerset vs Warwickshire
2021-08-12 - club - RLC - male - 1250229 - Sussex vs Middlesex
2021-08-12 - club - RLC - male - 1250228 - Leicestershire vs Northamptonshire
2021-08-12 - club - RLC - male - 1250227 - Lancashire vs Essex
2021-08-12 - club - RLC - male - 1250226 - Kent vs Gloucestershire
2021-08-12 - club - RLC - male - 1250225 - Yorkshire vs Glamorgan
2021-08-12 - club - RLC - male - 1250224 - Hampshire vs Durham
2021-08-12 - club - RLC - male - 1250223 - Derbyshire vs Surrey
2021-08-12 - club - HND - male - 1252691 - Northern Superchargers vs Manchester Originals
2021-08-11 - club - HND - male - 1252690 - Welsh Fire vs Southern Brave
2021-08-10 - club - RLC - male - 1250222 - Durham vs Worcestershire
2021-08-10 - club - RLC - male - 1250221 - Warwickshire vs Surrey
2021-08-10 - club - RLC - male - 1250220 - Somerset vs Leicestershire
2021-08-10 - club - RLC - male - 1250219 - Northamptonshire vs Nottinghamshire
2021-08-10 - club - RLC - male - 1250218 - Essex vs Sussex
2021-08-10 - club - HND - male - 1252689 - London Spirit vs Manchester Originals
2021-08-09 - international - T20 - male - 1270838 - Bangladesh vs Australia
2021-08-09 - club - HND - male - 1252688 - Birmingham Phoenix vs Welsh Fire
2021-08-08 - international - T20 - male - 1271451 - Norway vs Germany
2021-08-08 - international - T20 - male - 1271450 - Norway vs Germany
2021-08-08 - club - RLC - male - 1250217 - Northamptonshire vs Somerset
2021-08-08 - club - RLC - male - 1250214 - Kent vs Hampshire
2021-08-08 - club - RLC - male - 1250213 - Nottinghamshire vs Glamorgan
2021-08-08 - club - RLC - male - 1250212 - Essex vs Durham
2021-08-08 - club - RLC - male - 1250211 - Derbyshire vs Yorkshire
2021-08-08 - club - HND - male - 1252687 - Oval Invincibles vs Trent Rockets
2021-08-07 - international - T20 - male - 1271449 - Norway vs France
2021-08-07 - international - T20 - male - 1271448 - Germany vs France
2021-08-07 - international - T20 - male - 1270837 - Bangladesh vs Australia
2021-08-07 - club - RLC - male - 1250210 - Leicestershire vs Surrey
2021-08-07 - club - HND - male - 1252686 - Northern Superchargers vs Southern Brave
2021-08-06 - international - T20 - male - 1271447 - France vs Germany
2021-08-06 - international - T20 - male - 1270836 - Bangladesh vs Australia
2021-08-06 - club - RLC - male - 1250209 - Nottinghamshire vs Yorkshire
2021-08-06 - club - RLC - male - 1250208 - Worcestershire vs Sussex
2021-08-06 - club - RLC - male - 1250207 - Warwickshire vs Northamptonshire
2021-08-06 - club - RLC - male - 1250206 - Kent vs Middlesex
2021-08-06 - club - RLC - male - 1250205 - Hampshire vs Gloucestershire
2021-08-06 - club - HND - male - 1252685 - Welsh Fire vs Trent Rockets
2021-08-05 - international - T20 - male - 1271446 - Norway vs France
2021-08-05 - international - T20 - male - 1271445 - Norway vs Germany
2021-08-05 - club - RLC - male - 1250204 - Somerset vs Surrey
2021-08-05 - club - RLC - male - 1250203 - Glamorgan vs Leicestershire
2021-08-05 - club - RLC - male - 1250202 - Durham vs Lancashire
2021-08-05 - club - HND - male - 1252684 - Manchester Originals vs Southern Brave
2021-08-04 - international - Test - male - 1239543 - England vs India
2021-08-04 - international - T20 - male - 1270835 - Australia vs Bangladesh
2021-08-04 - club - RLC - male - 1250201 - Derbyshire vs Nottinghamshire
2021-08-04 - club - RLC - male - 1250200 - Worcestershire vs Hampshire
2021-08-04 - club - HND - male - 1252683 - Oval Invincibles vs Birmingham Phoenix
2021-08-03 - international - T20 - male - 1270834 - Bangladesh vs Australia
2021-08-03 - international - T20 - male - 1263167 - West Indies vs Pakistan
2021-08-03 - club - RLC - male - 1250199 - Yorkshire vs Warwickshire
2021-08-03 - club - RLC - male - 1250198 - Middlesex vs Lancashire
2021-08-03 - club - RLC - male - 1250197 - Gloucestershire vs Essex
2021-08-03 - club - RLC - male - 1250196 - Surrey vs Glamorgan
2021-08-03 - club - HND - male - 1252682 - Northern Superchargers vs London Spirit
2021-08-02 - club - HND - male - 1252681 - Welsh Fire vs Oval Invincibles
2021-08-01 - international - T20 - male - 1263166 - West Indies vs Pakistan
2021-08-01 - club - RLC - male - 1250195 - Middlesex vs Worcestershire
2021-08-01 - club - RLC - male - 1250194 - Gloucestershire vs Sussex
2021-08-01 - club - RLC - male - 1250193 - Yorkshire vs Somerset
2021-08-01 - club - RLC - male - 1250192 - Leicestershire vs Nottinghamshire
2021-08-01 - club - RLC - male - 1250191 - Derbyshire vs Northamptonshire
2021-08-01 - club - RLC - male - 1250190 - Hampshire vs Lancashire
2021-08-01 - club - RLC - male - 1250189 - Kent vs Essex
2021-08-01 - club - HND - male - 1252680 - Southern Brave vs London Spirit
2021-08-01 - club - HND - male - 1252679 - Trent Rockets vs Birmingham Phoenix
2021-07-31 - international - T20 - male - 1263165 - Pakistan vs West Indies
2021-07-31 - club - HND - male - 1252678 - Oval Invincibles vs Northern Superchargers
2021-07-31 - club - HND - male - 1252677 - Welsh Fire vs Manchester Originals
2021-07-30 - club - RLC - male - 1250188 - Sussex vs Kent
2021-07-30 - club - RLC - male - 1250187 - Northamptonshire vs Surrey
2021-07-30 - club - RLC - male - 1250186 - Nottinghamshire vs Somerset
2021-07-30 - club - HND - male - 1252676 - Birmingham Phoenix vs Southern Brave
2021-07-29 - international - T20 - male - 1262760 - India vs Sri Lanka
2021-07-29 - club - RLC - male - 1250183 - Warwickshire vs Leicestershire
2021-07-29 - club - RLC - male - 1250182 - Worcestershire vs Essex
2021-07-29 - club - RLC - male - 1250181 - Durham vs Gloucestershire
2021-07-29 - club - HND - male - 1252675 - Trent Rockets vs London Spirit
2021-07-28 - international - T20 - male - 1263164 - West Indies vs Pakistan
2021-07-28 - international - T20 - male - 1262759 - India vs Sri Lanka
2021-07-28 - club - RLC - male - 1250180 - Yorkshire vs Northamptonshire
2021-07-28 - club - RLC - male - 1250179 - Somerset vs Glamorgan
2021-07-28 - club - RLC - male - 1250178 - Lancashire vs Kent
2021-07-27 - club - RLC - male - 1250177 - Surrey vs Nottinghamshire
2021-07-27 - club - RLC - male - 1250176 - Durham vs Middlesex
2021-07-27 - club - RLC - male - 1250175 - Hampshire vs Sussex
2021-07-27 - club - RLC - male - 1250174 - Worcestershire vs Gloucestershire
2021-07-27 - club - RLC - male - 1250173 - Derbyshire vs Warwickshire
2021-07-27 - club - HND - male - 1252673 - Welsh Fire vs Southern Brave
2021-07-26 - international - ODI - male - 1263163 - West Indies vs Australia
2021-07-26 - club - HND - male - 1252672 - Northern Superchargers vs Trent Rockets
2021-07-25 - international - T20 - male - 1267682 - Zimbabwe vs Bangladesh
2021-07-25 - international - T20 - male - 1262758 - India vs Sri Lanka
2021-07-25 - club - RLC - male - 1250172 - Kent vs Worcestershire
2021-07-25 - club - RLC - male - 1250171 - Nottinghamshire vs Warwickshire
2021-07-25 - club - RLC - male - 1250169 - Derbyshire vs Somerset
2021-07-25 - club - RLC - male - 1250168 - Glamorgan vs Northamptonshire
2021-07-25 - club - RLC - male - 1250167 - Leicestershire vs Yorkshire
2021-07-25 - club - RLC - male - 1250166 - Gloucestershire vs Lancashire
2021-07-25 - club - RLC - male - 1250165 - Middlesex vs Essex
2021-07-25 - club - HND - male - 1252671 - Birmingham Phoenix vs Manchester Originals
2021-07-24 - international - T20 - male - 1251955 - South Africa vs Ireland
2021-07-24 - club - HND - male - 1252669 - Welsh Fire vs Northern Superchargers
2021-07-24 - club - HND - male - 1252668 - Southern Brave vs Trent Rockets
2021-07-23 - international - T20 - male - 1267681 - Zimbabwe vs Bangladesh
2021-07-23 - international - ODI - male - 1262757 - India vs Sri Lanka
2021-07-23 - club - RLC - male - 1250164 - Sussex vs Lancashire
2021-07-23 - club - HND - male - 1252667 - London Spirit vs Birmingham Phoenix
2021-07-22 - international - T20 - male - 1267680 - Zimbabwe vs Bangladesh
2021-07-22 - international - T20 - male - 1251954 - South Africa vs Ireland
2021-07-22 - international - ODI - male - 1263162 - Australia vs West Indies
2021-07-22 - club - RLC - male - 1250163 - Yorkshire vs Surrey
2021-07-22 - club - RLC - male - 1250162 - Derbyshire vs Leicestershire
2021-07-22 - club - RLC - male - 1250161 - Durham vs Kent
2021-07-22 - club - RLC - male - 1250160 - Hampshire vs Essex
2021-07-22 - club - RLC - male - 1250159 - Warwickshire vs Glamorgan
2021-07-22 - club - HND - male - 1252666 - Oval Invincibles vs Manchester Originals
2021-07-20 - international - T20 - male - 1239542 - Pakistan vs England
2021-07-20 - international - ODI - male - 1267679 - Zimbabwe vs Bangladesh
2021-07-20 - international - ODI - male - 1263161 - Australia vs West Indies
2021-07-20 - international - ODI - male - 1262756 - Sri Lanka vs India
2021-07-19 - international - T20 - male - 1251953 - South Africa vs Ireland
2021-07-18 - international - T20 - male - 1239541 - England vs Pakistan
2021-07-18 - international - ODI - male - 1267678 - Zimbabwe vs Bangladesh
2021-07-18 - international - ODI - male - 1262755 - Sri Lanka vs India
2021-07-18 - club - NTB - male - 1269930 - Nottinghamshire vs Durham
2021-07-18 - club - NTB - male - 1250361 - Worcestershire vs Leicestershire
2021-07-18 - club - NTB - male - 1250359 - Somerset vs Gloucestershire
2021-07-18 - club - NTB - male - 1250358 - Middlesex vs Essex
2021-07-18 - club - NTB - male - 1250357 - Birmingham Bears vs Northamptonshire
2021-07-18 - club - NTB - male - 1250355 - Kent vs Sussex
2021-07-18 - club - NTB - male - 1250354 - Glamorgan vs Hampshire
2021-07-17 - club - NTB - male - 1250353 - Yorkshire vs Lancashire
2021-07-16 - international - T20 - male - 1263160 - West Indies vs Australia
2021-07-16 - international - T20 - male - 1239540 - Pakistan vs England
2021-07-16 - international - ODI - male - 1267677 - Bangladesh vs Zimbabwe
2021-07-16 - international - ODI - male - 1251952 - South Africa vs Ireland
2021-07-16 - club - NTB - male - 1269929 - Lancashire vs Durham
2021-07-16 - club - NTB - male - 1250352 - Nottinghamshire vs Leicestershire
2021-07-16 - club - NTB - male - 1250350 - Somerset vs Glamorgan
2021-07-16 - club - NTB - male - 1250349 - Kent vs Middlesex
2021-07-16 - club - NTB - male - 1250347 - Birmingham Bears vs Worcestershire
2021-07-16 - club - NTB - male - 1250346 - Gloucestershire vs Surrey
2021-07-16 - club - NTB - male - 1250345 - Sussex vs Hampshire
2021-07-16 - club - NTB - male - 1250344 - Hampshire vs Essex
2021-07-14 - international - T20 - male - 1263159 - Australia vs West Indies
2021-07-13 - international - ODI - male - 1251951 - Ireland vs South Africa
2021-07-13 - international - ODI - male - 1239539 - Pakistan vs England
2021-07-12 - international - T20 - male - 1263158 - Australia vs West Indies
2021-07-11 - international - ODI - male - 1251950 - Ireland vs South Africa
2021-07-11 - club - CCH - male - 1244304 - Sussex vs Kent
2021-07-11 - club - CCH - male - 1244303 - Northamptonshire vs Glamorgan
2021-07-11 - club - CCH - male - 1244302 - Somerset vs Surrey
2021-07-11 - club - CCH - male - 1244301 - Middlesex vs Leicestershire
2021-07-11 - club - CCH - male - 1244300 - Gloucestershire vs Hampshire
2021-07-11 - club - CCH - male - 1244299 - Lancashire vs Yorkshire
2021-07-11 - club - CCH - male - 1244298 - Warwickshire vs Worcestershire
2021-07-11 - club - CCH - male - 1244297 - Nottinghamshire vs Durham
2021-07-11 - club - CCH - male - 1244296 - Derbyshire vs Essex
2021-07-10 - international - T20 - male - 1268192 - Belgium vs Malta
2021-07-10 - international - T20 - male - 1268191 - Belgium vs Malta
2021-07-10 - international - T20 - male - 1263157 - West Indies vs Australia
2021-07-10 - international - ODI - male - 1239538 - England vs Pakistan
2021-07-09 - international - T20 - male - 1268190 - Malta vs Belgium
2021-07-09 - international - T20 - male - 1263156 - West Indies vs Australia
2021-07-09 - club - NTB - male - 1250343 - Yorkshire vs Nottinghamshire
2021-07-09 - club - NTB - male - 1250342 - Essex vs Sussex
2021-07-09 - club - NTB - male - 1250341 - Worcestershire vs Birmingham Bears
2021-07-09 - club - NTB - male - 1250340 - Surrey vs Kent
2021-07-09 - club - NTB - male - 1250339 - Durham vs Derbyshire
2021-07-09 - club - NTB - male - 1250338 - Northamptonshire vs Lancashire
2021-07-09 - club - NTB - male - 1250337 - Gloucestershire vs Middlesex
2021-07-09 - club - NTB - male - 1250336 - Hampshire vs Somerset
2021-07-08 - international - T20 - male - 1268189 - Malta vs Belgium
2021-07-08 - international - T20 - male - 1268188 - Belgium vs Malta
2021-07-08 - international - ODI - male - 1239537 - Pakistan vs England
2021-07-07 - international - Test - male - 1267676 - Bangladesh vs Zimbabwe
2021-07-05 - club - CCH - male - 1244290 - Gloucestershire vs Middlesex
2021-07-04 - international - ODI - male - 1239536 - Sri Lanka vs England
2021-07-04 - club - CCH - male - 1244295 - Somerset vs Leicestershire
2021-07-04 - club - CCH - male - 1244294 - Hampshire vs Surrey
2021-07-04 - club - CCH - male - 1244293 - Warwickshire vs Durham
2021-07-04 - club - CCH - male - 1244292 - Derbyshire vs Nottinghamshire
2021-07-04 - club - CCH - male - 1244291 - Sussex vs Glamorgan
2021-07-04 - club - CCH - male - 1244289 - Yorkshire vs Northamptonshire
2021-07-04 - club - CCH - male - 1244288 - Kent vs Lancashire
2021-07-03 - international - T20 - male - 1263155 - South Africa vs West Indies
2021-07-02 - club - NTB - male - 1250335 - Derbyshire vs Worcestershire
2021-07-02 - club - NTB - male - 1250334 - Somerset vs Middlesex
2021-07-02 - club - NTB - male - 1250333 - Sussex vs Glamorgan
2021-07-02 - club - NTB - male - 1250332 - Durham vs Leicestershire
2021-07-02 - club - NTB - male - 1250331 - Yorkshire vs Lancashire
2021-07-02 - club - NTB - male - 1250330 - Nottinghamshire vs Birmingham Bears
2021-07-02 - club - NTB - male - 1250329 - Kent vs Surrey
2021-07-02 - club - NTB - male - 1250328 - Hampshire vs Gloucestershire
2021-07-01 - international - T20 - male - 1263154 - West Indies vs South Africa
2021-07-01 - international - ODI - male - 1239535 - Sri Lanka vs England
2021-07-01 - club - NTB - male - 1250327 - Leicestershire vs Nottinghamshire
2021-07-01 - club - NTB - male - 1250326 - Glamorgan vs Essex
2021-07-01 - club - NTB - male - 1250325 - Middlesex vs Sussex
2021-07-01 - club - NTB - male - 1250324 - Lancashire vs Worcestershire
2021-07-01 - club - NTB - male - 1250323 - Gloucestershire vs Somerset
2021-06-30 - club - NTB - male - 1250322 - Northamptonshire vs Durham
2021-06-30 - club - NTB - male - 1250321 - Yorkshire vs Birmingham Bears
2021-06-30 - club - NTB - male - 1250320 - Surrey vs Hampshire
2021-06-30 - club - IPO - male - 1259533 - Munster Reds vs Northern Knights
2021-06-29 - international - T20 - male - 1263153 - South Africa vs West Indies
2021-06-29 - international - ODI - male - 1239534 - Sri Lanka vs England
2021-06-29 - club - NTB - male - 1250319 - Leicestershire vs Northamptonshire
2021-06-29 - club - NTB - male - 1250318 - Somerset vs Essex
2021-06-29 - club - NTB - male - 1250316 - Glamorgan vs Surrey
2021-06-28 - club - NTB - male - 1250315 - Kent vs Somerset
2021-06-27 - international - T20 - male - 1263152 - South Africa vs West Indies
2021-06-27 - club - NTB - male - 1250313 - Surrey vs Sussex
2021-06-27 - club - NTB - male - 1250312 - Glamorgan vs Middlesex
2021-06-27 - club - NTB - male - 1250311 - Leicestershire vs Worcestershire
2021-06-27 - club - IPT - male - 1259546 - Northern Knights vs Munster Reds
2021-06-27 - club - IPT - male - 1259545 - Leinster Lightning vs North-West Warriors
2021-06-26 - international - T20 - male - 1267311 - Bulgaria vs Greece
2021-06-26 - international - T20 - male - 1267310 - Serbia vs Romania
2021-06-26 - international - T20 - male - 1263151 - South Africa vs West Indies
2021-06-26 - international - T20 - male - 1249208 - England vs Sri Lanka
2021-06-26 - club - NTB - male - 1250310 - Nottinghamshire vs Lancashire
2021-06-26 - club - NTB - male - 1250309 - Yorkshire vs Northamptonshire
2021-06-26 - club - NTB - male - 1250308 - Durham vs Birmingham Bears
2021-06-26 - club - IPT - male - 1259544 - Leinster Lightning vs Northern Knights
2021-06-26 - club - IPT - male - 1259543 - Munster Reds vs North-West Warriors
2021-06-25 - international - T20 - male - 1267308 - Romania vs Serbia
2021-06-25 - international - T20 - male - 1267307 - Bulgaria vs Romania
2021-06-25 - international - T20 - male - 1267306 - Serbia vs Greece
2021-06-25 - club - NTB - male - 1250307 - Leicestershire vs Yorkshire
2021-06-25 - club - NTB - male - 1250306 - Nottinghamshire vs Derbyshire
2021-06-25 - club - NTB - male - 1250305 - Lancashire vs Northamptonshire
2021-06-25 - club - NTB - male - 1250304 - Somerset vs Hampshire
2021-06-25 - club - NTB - male - 1250303 - Kent vs Essex
2021-06-25 - club - NTB - male - 1250302 - Gloucestershire vs Sussex
2021-06-25 - club - NTB - male - 1250301 - Durham vs Worcestershire
2021-06-25 - club - NTB - male - 1250300 - Middlesex vs Surrey
2021-06-25 - club - IPT - male - 1259542 - Leinster Lightning vs Munster Reds
2021-06-25 - club - IPT - male - 1259541 - North-West Warriors vs Northern Knights
2021-06-24 - international - T20 - male - 1267304 - Greece vs Romania
2021-06-24 - international - T20 - male - 1249207 - Sri Lanka vs England
2021-06-24 - club - PSL - male - 1247044 - Multan Sultans vs Peshawar Zalmi
2021-06-24 - club - NTB - male - 1250299 - Gloucestershire vs Glamorgan
2021-06-24 - club - NTB - male - 1250298 - Middlesex vs Essex
2021-06-24 - club - NTB - male - 1250297 - Birmingham Bears vs Derbyshire
2021-06-23 - international - T20 - male - 1249206 - Sri Lanka vs England
2021-06-23 - club - NTB - male - 1250296 - Surrey vs Somerset
2021-06-23 - club - NTB - male - 1250295 - Durham vs Northamptonshire
2021-06-23 - club - NTB - male - 1250294 - Yorkshire vs Worcestershire
2021-06-22 - club - PSL - male - 1247043 - Islamabad United vs Peshawar Zalmi
2021-06-22 - club - NTB - male - 1250293 - Worcestershire vs Nottinghamshire
2021-06-22 - club - NTB - male - 1250292 - Leicestershire vs Derbyshire
2021-06-22 - club - NTB - male - 1250290 - Kent vs Gloucestershire
2021-06-21 - club - PSL - male - 1247042 - Karachi Kings vs Peshawar Zalmi
2021-06-21 - club - PSL - male - 1247041 - Multan Sultans vs Islamabad United
2021-06-21 - club - NTB - male - 1250289 - Surrey vs Essex
2021-06-20 - club - NTB - male - 1250288 - Leicestershire vs Northamptonshire
2021-06-20 - club - NTB - male - 1250287 - Nottinghamshire vs Lancashire
2021-06-20 - club - NTB - male - 1250286 - Durham vs Birmingham Bears
2021-06-20 - club - NTB - male - 1250285 - Yorkshire vs Derbyshire
2021-06-20 - club - NTB - male - 1250284 - Kent vs Essex
2021-06-20 - club - IPT - male - 1259540 - Munster Reds vs Northern Knights
2021-06-20 - club - IPT - male - 1259539 - Leinster Lightning vs North-West Warriors
2021-06-19 - club - PSL - male - 1247040 - Multan Sultans vs Islamabad United
2021-06-19 - club - PSL - male - 1247039 - Karachi Kings vs Quetta Gladiators
2021-06-19 - club - IPT - male - 1259538 - North-West Warriors vs Munster Reds
2021-06-19 - club - IPT - male - 1259537 - Northern Knights vs Leinster Lightning
2021-06-18 - international - Test - male - 1263150 - South Africa vs West Indies
2021-06-18 - international - Test - male - 1249875 - India vs New Zealand
2021-06-18 - club - PSL - male - 1247038 - Multan Sultans vs Lahore Qalandars
2021-06-18 - club - NTB - male - 1250281 - Nottinghamshire vs Derbyshire
2021-06-18 - club - NTB - male - 1250278 - Glamorgan vs Middlesex
2021-06-18 - club - IPT - male - 1259536 - Northern Knights vs North-West Warriors
2021-06-18 - club - IPT - male - 1259535 - Munster Reds vs Leinster Lightning
2021-06-17 - club - PSL - male - 1247037 - Karachi Kings vs Lahore Qalandars
2021-06-17 - club - PSL - male - 1247036 - Islamabad United vs Peshawar Zalmi
2021-06-17 - club - NTB - male - 1250273 - Northamptonshire vs Derbyshire
2021-06-17 - club - NTB - male - 1250272 - Middlesex vs Gloucestershire
2021-06-17 - club - NTB - male - 1250271 - Surrey vs Sussex
2021-06-17 - club - NTB - male - 1250270 - Lancashire vs Durham
2021-06-16 - club - PSL - male - 1247035 - Multan Sultans vs Quetta Gladiators
2021-06-16 - club - NTB - male - 1250269 - Birmingham Bears vs Leicestershire
2021-06-16 - club - NTB - male - 1250268 - Kent vs Glamorgan
2021-06-16 - club - NTB - male - 1250267 - Yorkshire vs Worcestershire
2021-06-15 - club - PSL - male - 1247034 - Karachi Kings vs Peshawar Zalmi
2021-06-15 - club - PSL - male - 1247033 - Quetta Gladiators vs Lahore Qalandars
2021-06-15 - club - NTB - male - 1250266 - Derbyshire vs Lancashire
2021-06-15 - club - NTB - male - 1250265 - Birmingham Bears vs Northamptonshire
2021-06-15 - club - NTB - male - 1250264 - Somerset vs Kent
2021-06-15 - club - NTB - male - 1250263 - Essex vs Sussex
2021-06-15 - club - NTB - male - 1250262 - Hampshire vs Middlesex
2021-06-15 - club - NTB - male - 1250261 - Nottinghamshire vs Durham
2021-06-15 - club - NTB - male - 1250260 - Yorkshire vs Leicestershire
2021-06-15 - club - IPO - male - 1259534 - Munster Reds vs North-West Warriors
2021-06-14 - club - PSL - male - 1247032 - Karachi Kings vs Islamabad United
2021-06-14 - club - NTB - male - 1250259 - Glamorgan vs Surrey
2021-06-13 - club - PSL - male - 1247031 - Peshawar Zalmi vs Multan Sultans
2021-06-13 - club - PSL - male - 1247029 - Islamabad United vs Lahore Qalandars
2021-06-13 - club - NTB - male - 1250258 - Leicestershire vs Durham
2021-06-13 - club - NTB - male - 1250257 - Derbyshire vs Birmingham Bears
2021-06-13 - club - NTB - male - 1250256 - Nottinghamshire vs Northamptonshire
2021-06-13 - club - NTB - male - 1250255 - Essex vs Glamorgan
2021-06-13 - club - NTB - male - 1250254 - Lancashire vs Worcestershire
2021-06-13 - club - NTB - male - 1250253 - Kent vs Gloucestershire
2021-06-12 - club - PSL - male - 1247030 - Peshawar Zalmi vs Quetta Gladiators
2021-06-12 - club - NTB - male - 1250252 - Hampshire vs Sussex
2021-06-11 - club - PSL - male - 1247028 - Quetta Gladiators vs Islamabad United
2021-06-11 - club - NTB - male - 1250251 - Derbyshire vs Leicestershire
2021-06-11 - club - NTB - male - 1250250 - Birmingham Bears vs Nottinghamshire
2021-06-11 - club - NTB - male - 1250249 - Worcestershire vs Northamptonshire
2021-06-11 - club - NTB - male - 1250248 - Somerset vs Surrey
2021-06-11 - club - NTB - male - 1250247 - Hampshire vs Essex
2021-06-11 - club - NTB - male - 1250246 - Durham vs Yorkshire
2021-06-11 - club - NTB - male - 1250245 - Kent vs Middlesex
2021-06-11 - club - NTB - male - 1250244 - Gloucestershire vs Sussex
2021-06-10 - international - Test - male - 1263149 - West Indies vs South Africa
2021-06-10 - international - Test - male - 1249211 - England vs New Zealand
2021-06-10 - club - PSL - male - 1247026 - Lahore Qalandars vs Peshawar Zalmi
2021-06-10 - club - PSL - male - 1247025 - Multan Sultans vs Karachi Kings
2021-06-10 - club - NTB - male - 1250243 - Gloucestershire vs Glamorgan
2021-06-10 - club - NTB - male - 1250242 - Surrey vs Middlesex
2021-06-10 - club - NTB - male - 1250241 - Lancashire vs Leicestershire
2021-06-10 - club - NTB - male - 1250240 - Birmingham Bears vs Yorkshire
2021-06-09 - club - PSL - male - 1247027 - Islamabad United vs Lahore Qalandars
2021-06-09 - club - NTB - male - 1250239 - Somerset vs Essex
2021-06-09 - club - NTB - male - 1250238 - Worcestershire vs Nottinghamshire
2021-06-09 - club - NTB - male - 1250237 - Derbyshire vs Lancashire
2021-06-09 - club - NTB - male - 1250236 - Kent vs Hampshire
2021-06-07 - international - ODI - male - 1251964 - Ireland vs Netherlands
2021-06-04 - international - ODI - male - 1251963 - Netherlands vs Ireland
2021-06-03 - club - CCH - male - 1244287 - Leicestershire vs Gloucestershire
2021-06-03 - club - CCH - male - 1244286 - Somerset vs Hampshire
2021-06-03 - club - CCH - male - 1244285 - Lancashire vs Glamorgan
2021-06-03 - club - CCH - male - 1244284 - Northamptonshire vs Kent
2021-06-03 - club - CCH - male - 1244283 - Warwickshire vs Derbyshire
2021-06-03 - club - CCH - male - 1244281 - Worcestershire vs Durham
2021-06-03 - club - CCH - male - 1244280 - Sussex vs Yorkshire
2021-06-02 - international - Test - male - 1249210 - New Zealand vs England
2021-06-02 - international - ODI - male - 1251962 - Netherlands vs Ireland
2021-05-28 - international - ODI - male - 1262347 - Sri Lanka vs Bangladesh
2021-05-27 - club - IPO - male - 1259532 - Northern Knights vs Munster Reds
2021-05-27 - club - CCH - male - 1244279 - Middlesex vs Leicestershire
2021-05-27 - club - CCH - male - 1244278 - Surrey vs Gloucestershire
2021-05-27 - club - CCH - male - 1244277 - Sussex vs Northamptonshire
2021-05-27 - club - CCH - male - 1244276 - Yorkshire vs Lancashire
2021-05-27 - club - CCH - male - 1244275 - Worcestershire vs Derbyshire
2021-05-27 - club - CCH - male - 1244274 - Warwickshire vs Nottinghamshire
2021-05-27 - club - CCH - male - 1244273 - Essex vs Durham
2021-05-25 - international - ODI - male - 1262346 - Bangladesh vs Sri Lanka
2021-05-25 - club - IPO - male - 1259531 - North-West Warriors vs Leinster Lightning
2021-05-23 - international - T20 - male - 1263713 - Czech Republic vs Austria
2021-05-23 - international - T20 - male - 1263712 - Austria vs Luxembourg
2021-05-23 - international - ODI - male - 1262344 - Bangladesh vs Sri Lanka
2021-05-22 - international - T20 - male - 1263711 - Czech Republic vs Luxembourg
2021-05-22 - international - T20 - male - 1263710 - Austria vs Czech Republic
2021-05-22 - club - IPO - male - 1259530 - Leinster Lightning vs Munster Reds
2021-05-21 - international - T20 - male - 1263708 - Luxembourg vs Czech Republic
2021-05-20 - international - ODI - male - 1260085 - Netherlands vs Scotland
2021-05-20 - club - IPO - male - 1259528 - Munster Reds vs Leinster Lightning
2021-05-20 - club - CCH - male - 1244272 - Surrey vs Middlesex
2021-05-20 - club - CCH - male - 1244271 - Somerset vs Gloucestershire
2021-05-20 - club - CCH - male - 1244269 - Kent vs Glamorgan
2021-05-20 - club - CCH - male - 1244268 - Lancashire vs Northamptonshire
2021-05-20 - club - CCH - male - 1244267 - Derbyshire vs Durham
2021-05-20 - club - CCH - male - 1244266 - Warwickshire vs Essex
2021-05-20 - club - CCH - male - 1244265 - Nottinghamshire vs Worcestershire
2021-05-19 - international - ODI - male - 1260084 - Netherlands vs Scotland
2021-05-19 - club - CCH - male - 1244270 - Hampshire vs Leicestershire
2021-05-18 - club - IPO - male - 1259527 - North-West Warriors vs Northern Knights
2021-05-16 - club - IPO - male - 1259526 - Leinster Lightning vs Northern Knights
2021-05-13 - club - CCH - male - 1244264 - Surrey vs Somerset
2021-05-13 - club - CCH - male - 1244263 - Durham vs Worcestershire
2021-05-13 - club - CCH - male - 1244262 - Middlesex vs Hampshire
2021-05-13 - club - CCH - male - 1244261 - Glamorgan vs Yorkshire
2021-05-13 - club - CCH - male - 1244260 - Kent vs Sussex
2021-05-13 - club - CCH - male - 1244259 - Essex vs Derbyshire
2021-05-07 - international - Test - male - 1257187 - Pakistan vs Zimbabwe
2021-05-06 - club - IPO - male - 1259525 - Munster Reds vs North-West Warriors
2021-05-06 - club - CCH - male - 1244258 - Essex vs Nottinghamshire
2021-05-06 - club - CCH - male - 1244257 - Hampshire vs Somerset
2021-05-06 - club - CCH - male - 1244256 - Sussex vs Northamptonshire
2021-05-06 - club - CCH - male - 1244255 - Glamorgan vs Lancashire
2021-05-06 - club - CCH - male - 1244254 - Middlesex vs Gloucestershire
2021-05-06 - club - CCH - male - 1244253 - Warwickshire vs Worcestershire
2021-05-06 - club - CCH - male - 1244252 - Leicestershire vs Surrey
2021-05-06 - club - CCH - male - 1244251 - Kent vs Yorkshire
2021-05-04 - club - IPO - male - 1259524 - Leinster Lightning vs Northern Knights
2021-05-02 - club - IPL - male - 1254086 - Punjab Kings vs Delhi Capitals
2021-05-02 - club - IPL - male - 1254085 - Rajasthan Royals vs Sunrisers Hyderabad
2021-05-01 - club - IPO - male - 1259523 - North-West Warriors vs Leinster Lightning
2021-05-01 - club - IPL - male - 1254084 - Chennai Super Kings vs Mumbai Indians
2021-04-30 - club - IPL - male - 1254083 - Punjab Kings vs Royal Challengers Bangalore
2021-04-29 - international - Test - male - 1257186 - Zimbabwe vs Pakistan
2021-04-29 - international - Test - male - 1255829 - Sri Lanka vs Bangladesh
2021-04-29 - club - IPL - male - 1254082 - Kolkata Knight Riders vs Delhi Capitals
2021-04-29 - club - IPL - male - 1254081 - Rajasthan Royals vs Mumbai Indians
2021-04-29 - club - CCH - male - 1244250 - Hampshire vs Surrey
2021-04-29 - club - CCH - male - 1244249 - Yorkshire vs Northamptonshire
2021-04-29 - club - CCH - male - 1244248 - Kent vs Glamorgan
2021-04-29 - club - CCH - male - 1244247 - Middlesex vs Somerset
2021-04-29 - club - CCH - male - 1244246 - Leicestershire vs Gloucestershire
2021-04-29 - club - CCH - male - 1244245 - Warwickshire vs Durham
2021-04-29 - club - CCH - male - 1244244 - Essex vs Worcestershire
2021-04-29 - club - CCH - male - 1244243 - Nottinghamshire vs Derbyshire
2021-04-29 - club - CCH - male - 1244242 - Sussex vs Lancashire
2021-04-28 - club - IPL - male - 1254080 - Sunrisers Hyderabad vs Chennai Super Kings
2021-04-27 - club - IPL - male - 1254079 - Royal Challengers Bangalore vs Delhi Capitals
2021-04-26 - club - IPL - male - 1254078 - Punjab Kings vs Kolkata Knight Riders
2021-04-25 - international - T20 - male - 1257185 - Pakistan vs Zimbabwe
2021-04-25 - club - IPL - male - 1254077 - Delhi Capitals vs Sunrisers Hyderabad
2021-04-25 - club - IPL - male - 1254076 - Chennai Super Kings vs Royal Challengers Bangalore
2021-04-24 - international - T20 - male - 1257951 - Nepal vs Netherlands
2021-04-24 - club - IPL - male - 1254075 - Kolkata Knight Riders vs Rajasthan Royals
2021-04-23 - international - T20 - male - 1257184 - Zimbabwe vs Pakistan
2021-04-23 - club - IPL - male - 1254074 - Mumbai Indians vs Punjab Kings
2021-04-22 - international - T20 - male - 1257950 - Nepal vs Malaysia
2021-04-22 - club - IPL - male - 1254073 - Rajasthan Royals vs Royal Challengers Bangalore
2021-04-22 - club - CCH - male - 1244240 - Glamorgan vs Northamptonshire
2021-04-22 - club - CCH - male - 1244239 - Surrey vs Middlesex
2021-04-22 - club - CCH - male - 1244238 - Essex vs Warwickshire
2021-04-22 - club - CCH - male - 1244237 - Hampshire vs Gloucestershire
2021-04-22 - club - CCH - male - 1244236 - Worcestershire vs Nottinghamshire
2021-04-22 - club - CCH - male - 1244235 - Lancashire vs Kent
2021-04-22 - club - CCH - male - 1244234 - Durham vs Derbyshire
2021-04-22 - club - CCH - male - 1244233 - Yorkshire vs Sussex
2021-04-21 - international - Test - male - 1255828 - Sri Lanka vs Bangladesh
2021-04-21 - international - T20 - male - 1257949 - Netherlands vs Malaysia
2021-04-21 - international - T20 - male - 1257183 - Pakistan vs Zimbabwe
2021-04-21 - club - IPL - male - 1254072 - Chennai Super Kings vs Kolkata Knight Riders
2021-04-21 - club - IPL - male - 1254071 - Punjab Kings vs Sunrisers Hyderabad
2021-04-20 - international - T20 - male - 1257948 - Nepal vs Netherlands
2021-04-20 - club - IPL - male - 1254070 - Mumbai Indians vs Delhi Capitals
2021-04-19 - international - T20 - male - 1257947 - Malaysia vs Nepal
2021-04-19 - club - IPL - male - 1254069 - Chennai Super Kings vs Rajasthan Royals
2021-04-18 - international - T20 - male - 1257946 - Netherlands vs Malaysia
2021-04-18 - club - IPL - male - 1254068 - Punjab Kings vs Delhi Capitals
2021-04-18 - club - IPL - male - 1254067 - Royal Challengers Bangalore vs Kolkata Knight Riders
2021-04-17 - international - T20 - male - 1257945 - Netherlands vs Nepal
2021-04-17 - club - IPL - male - 1254066 - Mumbai Indians vs Sunrisers Hyderabad
2021-04-16 - international - T20 - male - 1251578 - South Africa vs Pakistan
2021-04-16 - club - IPL - male - 1254065 - Punjab Kings vs Chennai Super Kings
2021-04-15 - club - SSH - male - 1244521 - New South Wales vs Queensland
2021-04-15 - club - IPL - male - 1254064 - Delhi Capitals vs Rajasthan Royals
2021-04-15 - club - CCH - male - 1244232 - Leicestershire vs Surrey
2021-04-15 - club - CCH - male - 1244231 - Nottinghamshire vs Warwickshire
2021-04-15 - club - CCH - male - 1244230 - Essex vs Durham
2021-04-15 - club - CCH - male - 1244229 - Derbyshire vs Worcestershire
2021-04-15 - club - CCH - male - 1244228 - Somerset vs Gloucestershire
2021-04-15 - club - CCH - male - 1244227 - Glamorgan vs Sussex
2021-04-15 - club - CCH - male - 1244226 - Yorkshire vs Kent
2021-04-15 - club - CCH - male - 1244225 - Lancashire vs Northamptonshire
2021-04-15 - club - CCH - male - 1244224 - Hampshire vs Middlesex
2021-04-14 - international - T20 - male - 1251577 - South Africa vs Pakistan
2021-04-14 - club - IPL - male - 1254063 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2021-04-13 - club - IPL - male - 1254062 - Mumbai Indians vs Kolkata Knight Riders
2021-04-12 - international - T20 - male - 1251576 - Pakistan vs South Africa
2021-04-12 - club - IPL - male - 1254061 - Punjab Kings vs Rajasthan Royals
2021-04-11 - club - ODC - male - 1244141 - New South Wales vs Western Australia
2021-04-11 - club - IPL - male - 1254060 - Kolkata Knight Riders vs Sunrisers Hyderabad
2021-04-10 - international - T20 - male - 1251575 - South Africa vs Pakistan
2021-04-10 - club - IPL - male - 1254059 - Chennai Super Kings vs Delhi Capitals
2021-04-09 - club - IPL - male - 1254058 - Mumbai Indians vs Royal Challengers Bangalore
2021-04-08 - international - ODM - male - 1257408 - Namibia vs Uganda
2021-04-08 - club - ODC - male - 1244137 - Victoria vs South Australia
2021-04-08 - club - ODC - male - 1244120 - Western Australia vs Tasmania
2021-04-08 - club - CCH - male - 1244223 - Derbyshire vs Warwickshire
2021-04-08 - club - CCH - male - 1244222 - Glamorgan vs Yorkshire
2021-04-08 - club - CCH - male - 1244221 - Durham vs Nottinghamshire
2021-04-08 - club - CCH - male - 1244220 - Surrey vs Gloucestershire
2021-04-08 - club - CCH - male - 1244219 - Hampshire vs Leicestershire
2021-04-08 - club - CCH - male - 1244218 - Middlesex vs Somerset
2021-04-08 - club - CCH - male - 1244217 - Sussex vs Lancashire
2021-04-08 - club - CCH - male - 1244216 - Essex vs Worcestershire
2021-04-08 - club - CCH - male - 1244215 - Kent vs Northamptonshire
2021-04-07 - international - ODM - male - 1257407 - Namibia vs Uganda
2021-04-07 - international - ODI - male - 1251574 - Pakistan vs South Africa
2021-04-05 - international - T20 - male - 1257406 - Namibia vs Uganda
2021-04-05 - international - T20 - male - 1257405 - Namibia vs Uganda
2021-04-04 - international - ODI - male - 1251573 - South Africa vs Pakistan
2021-04-03 - international - T20 - male - 1257404 - Uganda vs Namibia
2021-04-03 - club - SSH - male - 1251085 - Tasmania vs Western Australia
2021-04-03 - club - SSH - male - 1251084 - South Australia vs Victoria
2021-04-03 - club - SSH - male - 1251083 - New South Wales vs Queensland
2021-04-03 - club - PKS - male - 1234930 - Otago Volts vs Northern Districts
2021-04-03 - club - PKS - male - 1234929 - Central Stags vs Canterbury
2021-04-03 - club - PKS - male - 1234928 - Wellington Firebirds vs Auckland Aces
2021-04-02 - international - ODI - male - 1251572 - South Africa vs Pakistan
2021-04-01 - international - T20 - male - 1233981 - New Zealand vs Bangladesh
2021-03-31 - club - ODC - male - 1244128 - Queensland vs New South Wales
2021-03-30 - international - T20 - male - 1233980 - New Zealand vs Bangladesh
2021-03-29 - international - Test - male - 1252074 - West Indies vs Sri Lanka
2021-03-28 - international - T20 - male - 1233979 - New Zealand vs Bangladesh
2021-03-28 - international - ODI - male - 1243395 - India vs England
2021-03-28 - club - ODC - male - 1244123 - Queensland vs South Australia
2021-03-27 - club - PKS - male - 1234927 - Auckland Aces vs Canterbury
2021-03-27 - club - PKS - male - 1234925 - Wellington Firebirds vs Northern Districts
2021-03-26 - international - ODI - male - 1243394 - India vs England
2021-03-26 - international - ODI - male - 1233978 - New Zealand vs Bangladesh
2021-03-26 - club - PKS - male - 1234926 - Otago Volts vs Central Stags
2021-03-23 - international - ODI - male - 1243393 - India vs England
2021-03-23 - international - ODI - male - 1233977 - Bangladesh vs New Zealand
2021-03-23 - club - ODC - male - 1244131 - Western Australia vs Victoria
2021-03-21 - international - Test - male - 1252073 - Sri Lanka vs West Indies
2021-03-20 - international - T20 - male - 1243392 - India vs England
2021-03-20 - international - ODI - male - 1233976 - Bangladesh vs New Zealand
2021-03-20 - club - SSH - male - 1244510 - Tasmania vs New South Wales
2021-03-19 - club - PKS - male - 1234924 - Central Stags vs Canterbury
2021-03-18 - international - T20 - male - 1243391 - India vs England
2021-03-18 - club - PKS - male - 1234923 - Auckland Aces vs Otago Volts
2021-03-18 - club - PKS - male - 1234922 - Northern Districts vs Wellington Firebirds
2021-03-18 - club - ODC - male - 1244135 - Tasmania vs New South Wales
2021-03-16 - international - T20 - male - 1243390 - India vs England
2021-03-15 - club - SSH - male - 1244504 - Victoria vs Queensland
2021-03-14 - international - T20 - male - 1243389 - England vs India
2021-03-14 - international - ODI - male - 1252071 - West Indies vs Sri Lanka
2021-03-12 - international - T20 - male - 1243388 - India vs England
2021-03-12 - international - ODI - male - 1252070 - West Indies vs Sri Lanka
2021-03-12 - club - ODC - male - 1244138 - South Australia vs Tasmania
2021-03-11 - club - PKS - male - 1234921 - Canterbury vs Otago Volts
2021-03-11 - club - PKS - male - 1234920 - Auckland Aces vs Northern Districts
2021-03-11 - club - PKS - male - 1234919 - Central Stags vs Wellington Firebirds
2021-03-11 - club - ODC - male - 1244133 - Queensland vs Western Australia
2021-03-10 - international - ODI - male - 1252069 - West Indies vs Sri Lanka
2021-03-10 - club - ODC - male - 1244121 - Victoria vs Tasmania
2021-03-07 - international - T20 - male - 1252068 - Sri Lanka vs West Indies
2021-03-07 - international - T20 - male - 1233975 - Australia vs New Zealand
2021-03-06 - club - SSH - male - 1251095 - South Australia vs New South Wales
2021-03-06 - club - SSH - male - 1244505 - Western Australia vs Queensland
2021-03-05 - international - T20 - male - 1252067 - Sri Lanka vs West Indies
2021-03-05 - international - T20 - male - 1233974 - Australia vs New Zealand
2021-03-05 - club - SSH - male - 1244506 - Tasmania vs Victoria
2021-03-04 - international - Test - male - 1243387 - England vs India
2021-03-04 - club - ODC - male - 1244124 - South Australia vs New South Wales
2021-03-03 - international - T20 - male - 1252066 - Sri Lanka vs West Indies
2021-03-03 - international - T20 - male - 1233973 - Australia vs New Zealand
2021-03-03 - club - PSL - male - 1247024 - Quetta Gladiators vs Multan Sultans
2021-03-03 - club - PSL - male - 1247023 - Peshawar Zalmi vs Karachi Kings
2021-03-02 - club - PSL - male - 1247022 - Quetta Gladiators vs Islamabad United
2021-03-02 - club - ODC - male - 1244129 - Western Australia vs South Australia
2021-02-28 - club - PSL - male - 1247021 - Karachi Kings vs Lahore Qalandars
2021-02-28 - club - CTC - male - 1250547 - Dolphins vs Lions
2021-02-27 - club - PSL - male - 1247020 - Islamabad United vs Peshawar Zalmi
2021-02-27 - club - PSL - male - 1247019 - Multan Sultans vs Karachi Kings
2021-02-27 - club - CTC - male - 1250546 - Warriors vs Lions
2021-02-26 - club - PSL - male - 1247018 - Quetta Gladiators vs Peshawar Zalmi
2021-02-26 - club - PSL - male - 1247017 - Lahore Qalandars vs Multan Sultans
2021-02-26 - club - CTC - male - 1235386 - Cape Cobras vs Lions
2021-02-26 - club - CTC - male - 1235377 - Dolphins vs Titans
2021-02-25 - international - T20 - male - 1233972 - New Zealand vs Australia
2021-02-25 - club - CTC - male - 1235383 - Warriors vs Knights
2021-02-24 - international - Test - male - 1243386 - England vs India
2021-02-24 - club - PSL - male - 1247016 - Karachi Kings vs Islamabad United
2021-02-24 - club - CTC - male - 1235375 - Dolphins vs Lions
2021-02-24 - club - CTC - male - 1235373 - Warriors vs Titans
2021-02-23 - club - PSL - male - 1247015 - Multan Sultans vs Peshawar Zalmi
2021-02-23 - club - CTC - male - 1235378 - Knights vs Lions
2021-02-23 - club - CTC - male - 1235376 - Cape Cobras vs Warriors
2021-02-22 - international - T20 - male - 1233971 - New Zealand vs Australia
2021-02-22 - club - PSL - male - 1247014 - Quetta Gladiators vs Lahore Qalandars
2021-02-22 - club - ODC - male - 1244130 - Tasmania vs Queensland
2021-02-22 - club - CTC - male - 1235384 - Lions vs Titans
2021-02-22 - club - CTC - male - 1235374 - Cape Cobras vs Knights
2021-02-21 - club - PSL - male - 1247013 - Multan Sultans vs Islamabad United
2021-02-21 - club - PSL - male - 1247012 - Peshawar Zalmi vs Lahore Qalandars
2021-02-21 - club - CTC - male - 1235385 - Warriors vs Dolphins
2021-02-21 - club - CTC - male - 1235380 - Titans vs Cape Cobras
2021-02-20 - club - PSL - male - 1247011 - Quetta Gladiators vs Karachi Kings
2021-02-20 - club - CTC - male - 1235381 - Knights vs Dolphins
2021-02-19 - club - CTC - male - 1235387 - Knights vs Titans
2021-02-19 - club - CTC - male - 1235379 - Dolphins vs Cape Cobras
2021-02-17 - club - SSH - male - 1244519 - Tasmania vs Queensland
2021-02-17 - club - SSH - male - 1244512 - New South Wales vs Victoria
2021-02-15 - club - ODC - male - 1244127 - New South Wales vs Victoria
2021-02-14 - international - T20 - male - 1243021 - South Africa vs Pakistan
2021-02-13 - international - Test - male - 1243385 - India vs England
2021-02-13 - international - T20 - male - 1243020 - Pakistan vs South Africa
2021-02-13 - club - SSM - male - 1234028 - Canterbury vs Wellington
2021-02-11 - international - Test - male - 1244026 - West Indies vs Bangladesh
2021-02-11 - international - T20 - male - 1243019 - Pakistan vs South Africa
2021-02-11 - club - SSM - male - 1234027 - Central Districts vs Canterbury
2021-02-07 - club - SSM - male - 1234026 - Wellington vs Auckland
2021-02-06 - club - SSM - male - 1234025 - Northern Districts vs Otago
2021-02-06 - club - BBL - male - 1226882 - Sydney Sixers vs Perth Scorchers
2021-02-05 - international - Test - male - 1243384 - England vs India
2021-02-05 - club - SSM - male - 1234024 - Central Districts vs Canterbury
2021-02-04 - international - Test - male - 1243018 - Pakistan vs South Africa
2021-02-04 - club - BBL - male - 1226886 - Perth Scorchers vs Brisbane Heat
2021-02-03 - international - Test - male - 1244025 - Bangladesh vs West Indies
2021-02-01 - club - SSM - male - 1234023 - Auckland vs Otago
2021-01-31 - club - SSM - male - 1234022 - Central Districts vs Wellington
2021-01-31 - club - SMA - male - 1244407 - Baroda vs Tamil Nadu
2021-01-31 - club - BBL - male - 1226885 - Sydney Thunder vs Brisbane Heat
2021-01-30 - club - SSM - male - 1234021 - Otago vs Canterbury
2021-01-30 - club - BBL - male - 1226884 - Perth Scorchers vs Sydney Sixers
2021-01-29 - club - SSM - male - 1234020 - Auckland vs Northern Districts
2021-01-29 - club - SMA - male - 1244406 - Baroda vs Punjab
2021-01-29 - club - SMA - male - 1244405 - Rajasthan vs Tamil Nadu
2021-01-29 - club - BBL - male - 1226883 - Adelaide Strikers vs Brisbane Heat
2021-01-27 - club - SMA - male - 1244403 - Haryana vs Baroda
2021-01-26 - international - Test - male - 1243017 - South Africa vs Pakistan
2021-01-26 - club - SMA - male - 1244402 - Himachal vs Tamil Nadu
2021-01-26 - club - SMA - male - 1244401 - Karnataka vs Punjab
2021-01-26 - club - BBL - male - 1226862 - Brisbane Heat vs Perth Scorchers
2021-01-26 - club - BBL - male - 1226860 - Melbourne Renegades vs Hobart Hurricanes
2021-01-26 - club - BBL - male - 1226858 - Melbourne Stars vs Sydney Sixers
2021-01-25 - international - ODI - male - 1244024 - Bangladesh vs West Indies
2021-01-25 - club - SSM - male - 1234019 - Canterbury vs Wellington
2021-01-25 - club - BBL - male - 1226836 - Adelaide Strikers vs Sydney Thunder
2021-01-24 - club - SSM - male - 1234018 - Otago vs Wellington
2021-01-24 - club - BBL - male - 1226847 - Adelaide Strikers vs Sydney Thunder
2021-01-24 - club - BBL - male - 1226827 - Hobart Hurricanes vs Sydney Sixers
2021-01-23 - club - SSM - male - 1234017 - Auckland vs Central Districts
2021-01-23 - club - BBL - male - 1226849 - Perth Scorchers vs Melbourne Stars
2021-01-23 - club - BBL - male - 1226848 - Brisbane Heat vs Melbourne Renegades
2021-01-22 - international - Test - male - 1243016 - Sri Lanka vs England
2021-01-22 - international - ODI - male - 1244023 - West Indies vs Bangladesh
2021-01-22 - club - BBL - male - 1226880 - Sydney Thunder vs Sydney Sixers
2021-01-22 - club - BBL - male - 1226834 - Perth Scorchers vs Hobart Hurricanes
2021-01-21 - club - SSM - male - 1234016 - Canterbury vs Northern Districts
2021-01-21 - club - BBL - male - 1226859 - Adelaide Strikers vs Brisbane Heat
2021-01-20 - international - ODI - male - 1244022 - West Indies vs Bangladesh
2021-01-20 - club - BBL - male - 1226869 - Melbourne Stars vs Melbourne Renegades
2021-01-19 - club - SMA - male - 1244400 - Manipur vs Nagaland
2021-01-19 - club - SMA - male - 1244399 - Mizoram vs Bihar
2021-01-19 - club - SMA - male - 1244398 - Sikkim vs Meghalaya
2021-01-19 - club - SMA - male - 1244396 - Andhra vs Mumbai
2021-01-19 - club - SMA - male - 1244395 - Delhi vs Puducherry
2021-01-19 - club - SMA - male - 1244394 - Haryana vs Kerala
2021-01-19 - club - SMA - male - 1244393 - Rajasthan vs Saurashtra
2021-01-19 - club - SMA - male - 1244391 - Madhya Pradesh vs Services
2021-01-19 - club - BBL - male - 1226838 - Perth Scorchers vs Brisbane Heat
2021-01-18 - international - ODI - male - 1244525 - Ireland vs United Arab Emirates
2021-01-18 - club - SSM - male - 1234015 - Otago vs Central Districts
2021-01-18 - club - SMA - male - 1244390 - Maharashtra vs Himachal
2021-01-18 - club - SMA - male - 1244389 - Uttarakhand vs Chhattisgarh
2021-01-18 - club - SMA - male - 1244388 - Baroda vs Gujarat
2021-01-18 - club - SMA - male - 1244387 - Bengal vs Tamil Nadu
2021-01-18 - club - SMA - male - 1244386 - Hyderabad (India) vs Jharkhand
2021-01-18 - club - SMA - male - 1244385 - Assam vs Odisha
2021-01-18 - club - SMA - male - 1244383 - Punjab vs Tripura
2021-01-18 - club - SMA - male - 1244382 - Railways vs Jammu & Kashmir
2021-01-18 - club - BBL - male - 1226840 - Sydney Thunder vs Hobart Hurricanes
2021-01-17 - club - SSM - male - 1234014 - Auckland vs Northern Districts
2021-01-17 - club - SMA - male - 1244381 - Nagaland vs Mizoram
2021-01-17 - club - SMA - male - 1244380 - Chandigarh vs Sikkim
2021-01-17 - club - SMA - male - 1244379 - Arunachal Pradesh vs Meghalaya
2021-01-17 - club - SMA - male - 1244378 - Manipur vs Bihar
2021-01-17 - club - SMA - male - 1244377 - Delhi vs Haryana
2021-01-17 - club - SMA - male - 1244376 - Kerala vs Andhra
2021-01-17 - club - SMA - male - 1244375 - Mumbai vs Puducherry
2021-01-17 - club - SMA - male - 1244374 - Vidarbha vs Services
2021-01-17 - club - SMA - male - 1244373 - Saurashtra vs Madhya Pradesh
2021-01-17 - club - SMA - male - 1244372 - Goa vs Rajasthan
2021-01-17 - club - BBL - male - 1226864 - Melbourne Renegades vs Melbourne Stars
2021-01-16 - club - SSM - male - 1234013 - Wellington vs Canterbury
2021-01-16 - club - SMA - male - 1244371 - Chhattisgarh vs Gujarat
2021-01-16 - club - SMA - male - 1244370 - Baroda vs Maharashtra
2021-01-16 - club - SMA - male - 1244369 - Uttarakhand vs Himachal
2021-01-16 - club - SMA - male - 1244368 - Jharkhand vs Odisha
2021-01-16 - club - SMA - male - 1244367 - Assam vs Bengal
2021-01-16 - club - SMA - male - 1244366 - Hyderabad (India) vs Tamil Nadu
2021-01-16 - club - SMA - male - 1244365 - Jammu & Kashmir vs Punjab
2021-01-16 - club - SMA - male - 1244364 - Railways vs Karnataka
2021-01-16 - club - SMA - male - 1244363 - Tripura vs Uttar Pradesh
2021-01-16 - club - BBL - male - 1226865 - Perth Scorchers vs Sydney Sixers
2021-01-15 - international - Test - male - 1223872 - Australia vs India
2021-01-15 - club - SSM - male - 1234012 - Northern Districts vs Canterbury
2021-01-15 - club - SMA - male - 1244362 - Manipur vs Arunachal Pradesh
2021-01-15 - club - SMA - male - 1244361 - Nagaland vs Sikkim
2021-01-15 - club - SMA - male - 1244360 - Chandigarh vs Mizoram
2021-01-15 - club - SMA - male - 1244359 - Meghalaya vs Bihar
2021-01-15 - club - SMA - male - 1244358 - Andhra vs Puducherry
2021-01-15 - club - SMA - male - 1244357 - Mumbai vs Haryana
2021-01-15 - club - SMA - male - 1244356 - Delhi vs Kerala
2021-01-15 - club - SMA - male - 1244355 - Saurashtra vs Goa
2021-01-15 - club - SMA - male - 1244353 - Madhya Pradesh vs Vidarbha
2021-01-15 - club - BBL - male - 1226839 - Melbourne Stars vs Adelaide Strikers
2021-01-14 - international - Test - male - 1243015 - Sri Lanka vs England
2021-01-14 - club - SSM - male - 1234011 - Otago vs Wellington
2021-01-14 - club - SMA - male - 1244352 - Maharashtra vs Uttarakhand
2021-01-14 - club - SMA - male - 1244351 - Himachal vs Gujarat
2021-01-14 - club - SMA - male - 1244350 - Chhattisgarh vs Baroda
2021-01-14 - club - SMA - male - 1244349 - Hyderabad (India) vs Bengal
2021-01-14 - club - SMA - male - 1244348 - Odisha vs Tamil Nadu
2021-01-14 - club - SMA - male - 1244347 - Jharkhand vs Assam
2021-01-14 - club - SMA - male - 1244346 - Karnataka vs Tripura
2021-01-14 - club - SMA - male - 1244344 - Punjab vs Railways
2021-01-14 - club - BBL - male - 1226843 - Melbourne Renegades vs Brisbane Heat
2021-01-13 - club - SMA - male - 1244343 - Arunachal Pradesh vs Nagaland
2021-01-13 - club - SMA - male - 1244342 - Sikkim vs Bihar
2021-01-13 - club - SMA - male - 1244341 - Chandigarh vs Manipur
2021-01-13 - club - SMA - male - 1244340 - Meghalaya vs Mizoram
2021-01-13 - club - SMA - male - 1244338 - Puducherry vs Haryana
2021-01-13 - club - SMA - male - 1244337 - Andhra vs Delhi
2021-01-13 - club - SMA - male - 1244336 - Rajasthan vs Madhya Pradesh
2021-01-13 - club - SMA - male - 1244335 - Services vs Goa
2021-01-13 - club - SMA - male - 1244334 - Saurashtra vs Vidarbha
2021-01-13 - club - BBL - male - 1226861 - Sydney Thunder vs Sydney Sixers
2021-01-12 - club - SMA - male - 1244333 - Himachal vs Baroda
2021-01-12 - club - SMA - male - 1244332 - Gujarat vs Uttarakhand
2021-01-12 - club - SMA - male - 1244331 - Chhattisgarh vs Maharashtra
2021-01-12 - club - SMA - male - 1244330 - Assam vs Tamil Nadu
2021-01-12 - club - SMA - male - 1244327 - Uttar Pradesh vs Railways
2021-01-12 - club - SMA - male - 1244326 - Tripura vs Jammu & Kashmir
2021-01-12 - club - SMA - male - 1244325 - Karnataka vs Punjab
2021-01-12 - club - BBL - male - 1226857 - Hobart Hurricanes vs Perth Scorchers
2021-01-11 - club - SSM - male - 1234010 - Canterbury vs Auckland
2021-01-11 - club - SMA - male - 1244324 - Mizoram vs Sikkim
2021-01-11 - club - SMA - male - 1244323 - Bihar vs Arunachal Pradesh
2021-01-11 - club - SMA - male - 1244322 - Meghalaya vs Manipur
2021-01-11 - club - SMA - male - 1244320 - Puducherry vs Kerala
2021-01-11 - club - SMA - male - 1244319 - Delhi vs Mumbai
2021-01-11 - club - SMA - male - 1244318 - Andhra vs Haryana
2021-01-11 - club - SMA - male - 1244317 - Madhya Pradesh vs Goa
2021-01-11 - club - SMA - male - 1244316 - Vidarbha vs Rajasthan
2021-01-11 - club - SMA - male - 1244315 - Services vs Saurashtra
2021-01-11 - club - BBL - male - 1226876 - Melbourne Stars vs Adelaide Strikers
2021-01-10 - club - SSM - male - 1234009 - Central Districts vs Canterbury
2021-01-10 - club - SMA - male - 1244314 - Baroda vs Uttarakhand
2021-01-10 - club - SMA - male - 1244313 - Himachal vs Chhattisgarh
2021-01-10 - club - SMA - male - 1244312 - Gujarat vs Maharashtra
2021-01-10 - club - SMA - male - 1244311 - Assam vs Hyderabad (India)
2021-01-10 - club - SMA - male - 1244310 - Tamil Nadu vs Jharkhand
2021-01-10 - club - SMA - male - 1244309 - Odisha vs Bengal
2021-01-10 - club - SMA - male - 1244308 - Tripura vs Railways
2021-01-10 - club - SMA - male - 1244307 - Punjab vs Uttar Pradesh
2021-01-10 - club - SMA - male - 1244306 - Karnataka vs Jammu & Kashmir
2021-01-10 - club - BBL - male - 1226855 - Brisbane Heat vs Sydney Sixers
2021-01-09 - club - SSM - male - 1234008 - Wellington vs Northern Districts
2021-01-09 - club - BBL - male - 1226878 - Perth Scorchers vs Sydney Thunder
2021-01-08 - international - ODI - male - 1244524 - Ireland vs United Arab Emirates
2021-01-08 - club - SSM - male - 1234007 - Central Districts vs Otago
2021-01-08 - club - BBL - male - 1226826 - Adelaide Strikers vs Melbourne Renegades
2021-01-07 - international - Test - male - 1223871 - Australia vs India
2021-01-07 - club - BBL - male - 1226871 - Sydney Thunder vs Hobart Hurricanes
2021-01-07 - club - BBL - male - 1226835 - Brisbane Heat vs Melbourne Stars
2021-01-06 - club - BBL - male - 1226829 - Perth Scorchers vs Sydney Sixers
2021-01-05 - club - BBL - male - 1226833 - Adelaide Strikers vs Melbourne Renegades
2021-01-04 - club - SSM - male - 1234006 - Central Districts vs Northern Districts
2021-01-04 - club - BBL - male - 1226879 - Melbourne Stars vs Hobart Hurricanes
2021-01-04 - club - BBL - male - 1226851 - Sydney Thunder vs Brisbane Heat
2021-01-03 - international - Test - male - 1237357 - Sri Lanka vs South Africa
2021-01-03 - international - Test - male - 1233963 - Pakistan vs New Zealand
2021-01-03 - club - SSM - male - 1234005 - Auckland vs Canterbury
2021-01-03 - club - BBL - male - 1226853 - Perth Scorchers vs Melbourne Renegades
2021-01-03 - club - BBL - male - 1226842 - Adelaide Strikers vs Sydney Sixers
2021-01-02 - club - SSM - male - 1234004 - Northern Districts vs Otago
2021-01-02 - club - BBL - male - 1226844 - Hobart Hurricanes vs Melbourne Stars
2021-01-02 - club - BBL - male - 1226832 - Sydney Sixers vs Brisbane Heat
2021-01-01 - club - SSM - male - 1234003 - Northern Districts vs Wellington
2021-01-01 - club - BBL - male - 1226856 - Melbourne Renegades vs Sydney Thunder
