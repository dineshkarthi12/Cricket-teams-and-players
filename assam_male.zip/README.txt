This zip archive contains data files from Cricsheet in YAML format. This
archive contains 37 Assam matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/assam_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-11-04 - club - SMA - male - 1383567 - Assam vs Baroda
2023-11-02 - club - SMA - male - 1383563 - Kerala vs Assam
2023-10-31 - club - SMA - male - 1383561 - Bengal vs Assam
2022-10-22 - club - SMA - male - 1333033 - Madhya Pradesh vs Assam
2022-10-16 - club - SMA - male - 1332981 - Mizoram vs Assam
2022-10-14 - club - SMA - male - 1332962 - Mumbai vs Assam
2021-11-09 - club - SMA - male - 1280285 - Railways vs Assam
2021-11-08 - club - SMA - male - 1280264 - Assam vs Kerala
2021-11-06 - club - SMA - male - 1280246 - Bihar vs Assam
2021-11-05 - club - SMA - male - 1280227 - Gujarat vs Assam
2021-11-04 - club - SMA - male - 1280207 - Assam vs Madhya Pradesh
2021-01-18 - club - SMA - male - 1244385 - Assam vs Odisha
2021-01-16 - club - SMA - male - 1244367 - Assam vs Bengal
2021-01-14 - club - SMA - male - 1244347 - Jharkhand vs Assam
2021-01-12 - club - SMA - male - 1244330 - Assam vs Tamil Nadu
2021-01-10 - club - SMA - male - 1244311 - Assam vs Hyderabad (India)
2019-11-18 - club - SMA - male - 1205729 - Assam vs Bengal
2019-11-17 - club - SMA - male - 1205828 - Mumbai vs Assam
2019-11-15 - club - SMA - male - 1205819 - Assam vs Puducherry
2019-11-14 - club - SMA - male - 1205800 - Mizoram vs Assam
2019-11-12 - club - SMA - male - 1205774 - Assam vs Meghalaya
2019-11-11 - club - SMA - male - 1205765 - Assam vs Haryana
2019-03-02 - club - SMA - male - 1157202 - Arunachal Pradesh vs Assam
2019-02-28 - club - SMA - male - 1157185 - Assam vs Haryana
2019-02-27 - club - SMA - male - 1157168 - Assam vs Odisha
2019-02-25 - club - SMA - male - 1157151 - Assam vs Bengal
2019-02-24 - club - SMA - male - 1157134 - Chhattisgarh vs Assam
2019-02-22 - club - SMA - male - 1157117 - Assam vs Mizoram
2018-01-16 - club - SMA - male - 1130697 - Assam vs Bengal
2018-01-14 - club - SMA - male - 1130725 - Assam vs Jharkhand
2018-01-10 - club - SMA - male - 1130714 - Odisha vs Assam
2018-01-08 - club - SMA - male - 1130666 - Tripura vs Assam
2016-01-10 - club - SMA - male - 902237 - Assam vs Madhya Pradesh
2016-01-09 - club - SMA - male - 902221 - Railways vs Assam
2016-01-07 - club - SMA - male - 902199 - Andhra vs Assam
2016-01-06 - club - SMA - male - 902171 - Assam vs Delhi
2016-01-04 - club - SMA - male - 902147 - Goa vs Assam
