This zip archive contains data files from Cricsheet in JSON format. This
archive contains 92 Knights matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/knights_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2024-10-18 - club - CTC - male - 1444789 - Knights vs Western Province
2024-10-16 - club - CTC - male - 1444786 - Knights vs Dolphins
2024-10-13 - club - CTC - male - 1444784 - Knights vs Titans
2024-10-09 - club - CTC - male - 1444779 - Lions vs Knights
2024-10-06 - club - CTC - male - 1444773 - Knights vs Warriors
2024-09-28 - club - CTC - male - 1444766 - North West vs Knights
2022-11-02 - club - CTC - male - 1334919 - Titans vs Knights
2022-11-01 - club - CTC - male - 1334917 - North West vs Knights
2022-10-31 - club - CTC - male - 1334915 - Titans vs Knights
2022-10-28 - club - CTC - male - 1334911 - Knights vs Dolphins
2022-10-26 - club - CTC - male - 1334908 - Knights vs Boland
2022-10-23 - club - CTC - male - 1334903 - Knights vs Lions
2022-10-20 - club - CTC - male - 1334897 - Western Province vs Knights
2022-10-18 - club - CTC - male - 1334893 - Warriors vs Knights
2022-02-22 - club - CTC - male - 1299627 - Knights vs Boland
2022-02-20 - club - CTC - male - 1299625 - Knights vs Lions
2022-02-18 - club - CTC - male - 1299620 - Knights vs Western Province
2022-02-14 - club - CTC - male - 1299615 - Warriors vs Knights
2022-02-12 - club - CTC - male - 1299611 - Titans vs Knights
2022-02-10 - club - CTC - male - 1299608 - Knights vs North West
2022-02-08 - club - CTC - male - 1299605 - Knights vs Dolphins
2021-02-25 - club - CTC - male - 1235383 - Warriors vs Knights
2021-02-23 - club - CTC - male - 1235378 - Knights vs Lions
2021-02-22 - club - CTC - male - 1235374 - Cape Cobras vs Knights
2021-02-20 - club - CTC - male - 1235381 - Knights vs Dolphins
2021-02-19 - club - CTC - male - 1235387 - Knights vs Titans
2019-04-26 - club - CTC - male - 1157250 - Knights vs Titans
2019-04-16 - club - CTC - male - 1157236 - Cape Cobras vs Knights
2019-04-12 - club - CTC - male - 1157231 - Lions vs Knights
2019-04-06 - club - CTC - male - 1157225 - Knights vs Dolphins
2017-12-10 - club - CTC - male - 1124687 - Lions vs Knights
2017-12-08 - club - CTC - male - 1124683 - Knights vs Dolphins
2017-12-06 - club - CTC - male - 1124681 - Cape Cobras vs Knights
2017-12-03 - club - CTC - male - 1124678 - Knights vs Titans
2017-12-01 - club - CTC - male - 1124676 - Knights vs Lions
2017-11-26 - club - CTC - male - 1124672 - Knights vs Cape Cobras
2017-11-24 - club - CTC - male - 1124669 - Warriors vs Knights
2017-11-15 - club - CTC - male - 1124661 - Titans vs Knights
2017-11-10 - club - CTC - male - 1124658 - Warriors vs Knights
2016-12-11 - club - CTC - male - 1003901 - Dolphins vs Knights
2016-12-09 - club - CTC - male - 1003895 - Lions vs Knights
2016-12-07 - club - CTC - male - 1003887 - Knights vs Cape Cobras
2016-12-02 - club - CTC - male - 1003879 - Lions vs Knights
2016-11-30 - club - CTC - male - 1003875 - Knights vs Warriors
2016-11-27 - club - CTC - male - 1003871 - Titans vs Knights
2016-11-25 - club - CTC - male - 1003867 - Knights vs Dolphins
2016-11-20 - club - CTC - male - 1003859 - Warriors vs Knights
2016-11-18 - club - CTC - male - 1003855 - Knights vs Titans
2016-11-12 - club - CTC - male - 1003843 - Knights vs Cape Cobras
2015-12-06 - club - CTC - male - 851985 - Titans vs Knights
2015-12-04 - club - CTC - male - 851981 - Knights vs Warriors
2015-11-28 - club - CTC - male - 851971 - Dolphins vs Knights
2015-11-25 - club - CTC - male - 851969 - Knights vs Lions
2015-11-22 - club - CTC - male - 851965 - Knights vs Cape Cobras
2015-11-15 - club - CTC - male - 851957 - Lions vs Knights
2015-11-11 - club - CTC - male - 851947 - Knights vs Cape Cobras
2015-11-06 - club - CTC - male - 851939 - Knights vs Dolphins
2014-12-12 - club - CTC - male - 736317 - Cape Cobras vs Knights
2014-12-07 - club - CTC - male - 736315 - Lions vs Knights
2014-12-03 - club - CTC - male - 736313 - Knights vs Lions
2014-11-30 - club - CTC - male - 736309 - Cape Cobras vs Knights
2014-11-28 - club - CTC - male - 736301 - Knights vs Dolphins
2014-11-21 - club - CTC - male - 736287 - Knights vs Warriors
2014-11-16 - club - CTC - male - 736285 - Dolphins vs Knights
2014-11-14 - club - CTC - male - 736277 - Titans vs Knights
2014-11-07 - club - CTC - male - 736267 - Knights vs Titans
2014-11-02 - club - CTC - male - 736255 - Knights vs Warriors
2014-02-02 - club - CTC - male - 652313 - Knights vs Titans
2014-01-31 - club - CTC - male - 652307 - Dolphins vs Knights
2014-01-22 - club - CTC - male - 652289 - Knights vs Warriors
2014-01-19 - club - CTC - male - 652283 - Titans vs Knights
2014-01-17 - club - CTC - male - 652273 - Cape Cobras vs Knights
2014-01-12 - club - CTC - male - 652267 - Lions vs Knights
2014-01-10 - club - CTC - male - 652259 - Knights vs Dolphins
2014-01-08 - club - CTC - male - 652257 - Knights vs Warriors
2013-03-26 - club - CTC - male - 575183 - Knights vs Titans
2013-03-22 - club - CTC - male - 575180 - Cape Cobras vs Knights
2013-03-14 - club - CTC - male - 575176 - Knights vs Warriors
2013-03-12 - club - CTC - male - 575175 - Knights vs Lions
2013-03-08 - club - CTC - male - 575172 - Dolphins vs Knights
2013-03-06 - club - CTC - male - 575170 - Knights vs Titans
2013-02-27 - club - CTC - male - 575165 - Dolphins vs Knights
2013-02-22 - club - CTC - male - 575160 - Cape Cobras vs Knights
2013-02-17 - club - CTC - male - 575157 - Knights vs Warriors
2012-03-18 - club - CTC - male - 530358 - Warriors vs Knights
2012-03-16 - club - CTC - male - 530356 - Impi vs Knights
2012-03-14 - club - CTC - male - 530352 - Knights vs Dolphins
2012-03-11 - club - CTC - male - 530349 - Knights vs Cape Cobras
2012-03-07 - club - CTC - male - 530345 - Knights vs Lions
2012-02-26 - club - CTC - male - 530334 - Lions vs Knights
2012-02-19 - club - CTC - male - 530326 - Titans vs Knights
2012-02-17 - club - CTC - male - 530323 - Cape Cobras vs Knights
