This zip archive contains data files from Cricsheet in JSON format. This
archive contains 240 Namibia matches of all types. A further 6 matches have
been withheld due to either featuring the Afghanistan men's team or being
played in the Afghanistan Premier League, due to the Cricsheet policy to no
longer feature matches involving Afghanistan men or played in Afghanistan
Premier League (see https://cricsheet.org/withheld-matches for more
information).


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/namibia_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-09-13 - international - ODI - male - 1549533 - Namibia vs South Africa
2026-09-11 - international - ODI - male - 1549532 - South Africa vs Namibia
2026-09-09 - international - ODI - male - 1549531 - South Africa vs Namibia
2026-09-04 - international - T20 - male - 1549529 - South Africa vs Namibia
2026-09-03 - international - T20 - male - 1549528 - Namibia vs Zimbabwe
2026-08-31 - international - T20 - male - 1549526 - Zimbabwe vs Namibia
2026-08-28 - international - T20 - male - 1549524 - Namibia vs South Africa
2026-07-31 - international - ODI - male - 1544129 - Netherlands vs Namibia
2026-07-27 - international - ODI - male - 1544127 - Namibia vs Nepal
2026-07-25 - international - ODI - male - 1544126 - Netherlands vs Namibia
2026-07-21 - international - ODI - male - 1544124 - Nepal vs Namibia
2026-06-23 - international - T20 - male - 1539744 - Namibia vs Nigeria
2026-06-22 - international - T20 - male - 1539743 - Namibia vs Hong Kong
2026-06-20 - international - T20 - male - 1539741 - Namibia vs Nigeria
2026-06-19 - international - T20 - male - 1539740 - Hong Kong vs Namibia
2026-04-18 - international - T20 - male - 1529147 - Scotland vs Namibia
2026-04-17 - international - T20 - male - 1529146 - Scotland vs Namibia
2026-04-15 - international - T20 - male - 1529145 - Namibia vs Scotland
2026-04-12 - international - ODI - male - 1529144 - Namibia vs Scotland
2026-04-10 - international - ODI - male - 1529143 - Oman vs Namibia
2026-04-06 - international - ODI - male - 1529141 - Namibia vs Scotland
2026-04-04 - international - ODI - male - 1529140 - Namibia vs Oman
2026-02-18 - international - T20 - male - 1512753 - Pakistan vs Namibia
2026-02-15 - international - T20 - male - 1512744 - United States of America vs Namibia
2026-02-12 - international - T20 - male - 1512736 - India vs Namibia
2026-02-10 - international - T20 - male - 1512728 - Namibia vs Netherlands
2025-10-11 - international - T20 - male - 1487824 - South Africa vs Namibia
2025-10-04 - international - T20 - male - 1502762 - Namibia vs Zimbabwe
2025-10-02 - international - T20 - male - 1502755 - Namibia vs Tanzania
2025-09-30 - international - T20 - male - 1502753 - Malawi vs Namibia
2025-09-28 - international - T20 - male - 1502747 - Namibia vs Nigeria
2025-09-26 - international - T20 - male - 1502743 - Namibia vs Kenya
2025-09-18 - international - T20 - male - 1502166 - Namibia vs Zimbabwe
2025-09-16 - international - T20 - male - 1502165 - Namibia vs Zimbabwe
2025-09-15 - international - T20 - male - 1502164 - Zimbabwe vs Namibia
2025-09-04 - international - ODI - male - 1498185 - Scotland vs Namibia
2025-09-02 - international - ODI - male - 1498184 - Namibia vs Canada
2025-08-27 - international - ODI - male - 1498181 - Canada vs Namibia
2025-03-23 - international - T20 - male - 1476798 - Canada vs Namibia
2025-03-22 - international - T20 - male - 1476797 - Canada vs Namibia
2025-03-19 - international - T20 - male - 1476795 - Canada vs Namibia
2025-03-15 - international - ODI - male - 1474414 - Namibia vs Canada
2025-03-13 - international - ODI - male - 1474413 - Namibia vs Netherlands
2025-03-09 - international - ODI - male - 1474411 - Canada vs Namibia
2025-03-07 - international - ODI - male - 1474410 - Netherlands vs Namibia
2025-02-16 - international - ODI - male - 1468883 - Namibia vs Oman
2025-02-14 - international - ODI - male - 1468882 - United States of America vs Namibia
2025-02-10 - international - ODI - male - 1468880 - Namibia vs Oman
2025-02-08 - international - ODI - male - 1468879 - United States of America vs Namibia
2024-10-05 - international - T20 - male - 1450822 - Namibia vs United States of America
2024-10-02 - international - T20 - male - 1450820 - Namibia vs United Arab Emirates
2024-10-01 - international - T20 - male - 1450819 - United States of America vs Namibia
2024-09-29 - international - T20 - male - 1450817 - United Arab Emirates vs Namibia
2024-09-26 - international - ODI - male - 1450695 - United Arab Emirates vs Namibia
2024-09-22 - international - ODI - male - 1450693 - Namibia vs United States of America
2024-09-20 - international - ODI - male - 1450692 - Namibia vs United Arab Emirates
2024-09-16 - international - ODI - male - 1450690 - Namibia vs United States of America
2024-07-26 - international - ODI - male - 1428961 - Scotland vs Namibia
2024-07-24 - international - ODI - male - 1428960 - Namibia vs Oman
2024-07-20 - international - ODI - male - 1428958 - Scotland vs Namibia
2024-07-18 - international - ODI - male - 1428957 - Oman vs Namibia
2024-06-15 - international - T20 - male - 1415734 - England vs Namibia
2024-06-11 - international - T20 - male - 1415724 - Namibia vs Australia
2024-06-06 - international - T20 - male - 1415712 - Namibia vs Scotland
2024-06-02 - international - T20 - male - 1415703 - Oman vs Namibia
2024-04-07 - international - T20 - male - 1426454 - Namibia vs Oman
2024-04-05 - international - T20 - male - 1426453 - Namibia vs Oman
2024-04-04 - international - T20 - male - 1426452 - Namibia vs Oman
2024-04-02 - international - T20 - male - 1426451 - Oman vs Namibia
2024-04-01 - international - T20 - male - 1426450 - Oman vs Namibia
2024-03-23 - international - T20 - male - 1424767 - Namibia vs Zimbabwe
2024-03-21 - international - T20 - male - 1424764 - Namibia vs Uganda
2024-03-20 - international - T20 - male - 1424763 - Tanzania vs Namibia
2024-03-18 - international - T20 - male - 1424757 - Namibia vs Nigeria
2024-03-17 - international - T20 - male - 1424752 - Zimbabwe vs Namibia
2024-03-03 - international - T20 - male - 1422042 - Namibia vs Netherlands
2024-03-01 - international - T20 - male - 1422040 - Nepal vs Namibia
2024-02-29 - international - T20 - male - 1422039 - Netherlands vs Namibia
2024-02-27 - international - T20 - male - 1422037 - Namibia vs Nepal
2024-02-23 - international - ODI - male - 1420533 - Namibia vs Netherlands
2024-02-21 - international - ODI - male - 1420532 - Nepal vs Namibia
2024-02-19 - international - ODI - male - 1420531 - Namibia vs Netherlands
2024-02-15 - international - ODI - male - 1420529 - Nepal vs Namibia
2023-11-30 - international - T20 - male - 1407109 - Nigeria vs Namibia
2023-11-28 - international - T20 - male - 1407103 - Namibia vs Tanzania
2023-11-27 - international - T20 - male - 1407102 - Kenya vs Namibia
2023-11-25 - international - T20 - male - 1407097 - Namibia vs Rwanda
2023-11-24 - international - T20 - male - 1407095 - Uganda vs Namibia
2023-11-22 - international - T20 - male - 1407091 - Zimbabwe vs Namibia
2023-10-30 - international - T20 - male - 1404394 - Namibia vs Zimbabwe
2023-10-29 - international - T20 - male - 1404393 - Zimbabwe vs Namibia
2023-10-27 - international - T20 - male - 1404392 - Namibia vs Zimbabwe
2023-10-25 - international - T20 - male - 1404391 - Namibia vs Zimbabwe
2023-10-24 - international - T20 - male - 1404390 - Zimbabwe vs Namibia
2023-04-04 - international - ODI - male - 1365103 - Namibia vs Canada
2023-04-02 - international - ODI - male - 1365102 - United Arab Emirates vs Namibia
2023-03-30 - international - ODI - male - 1365097 - Jersey vs Namibia
2023-03-26 - international - ODI - male - 1365092 - United States of America vs Namibia
2023-02-25 - international - ODI - male - 1358080 - United Arab Emirates vs Namibia
2023-02-23 - international - ODI - male - 1358079 - Namibia vs United Arab Emirates
2023-02-20 - international - ODI - male - 1358077 - Scotland vs Namibia
2023-02-18 - international - ODI - male - 1358076 - Namibia vs Nepal
2023-02-15 - international - ODI - male - 1358074 - Namibia vs Scotland
2023-02-14 - international - ODI - male - 1358073 - Namibia vs Nepal
2022-12-07 - international - ODI - male - 1341979 - Namibia vs Nepal
2022-12-05 - international - ODI - male - 1341978 - Scotland vs Namibia
2022-12-02 - international - ODI - male - 1341976 - Nepal vs Namibia
2022-12-01 - international - ODI - male - 1341975 - Namibia vs Scotland
2022-11-26 - international - ODI - male - 1341974 - United States of America vs Namibia
2022-11-23 - international - ODI - male - 1341972 - Papua New Guinea vs Namibia
2022-11-20 - international - ODI - male - 1341970 - United States of America vs Namibia
2022-11-19 - international - ODI - male - 1341969 - Papua New Guinea vs Namibia
2022-10-20 - international - T20 - male - 1298144 - United Arab Emirates vs Namibia
2022-10-18 - international - T20 - male - 1298139 - Namibia vs Netherlands
2022-10-16 - international - T20 - male - 1298135 - Namibia vs Sri Lanka
2022-09-21 - international - ODI - male - 1331370 - Namibia vs Papua New Guinea
2022-09-20 - international - ODI - male - 1331369 - Namibia vs Papua New Guinea
2022-09-17 - international - ODI - male - 1331368 - Namibia vs United States of America
2022-09-15 - international - ODI - male - 1331367 - Namibia vs United States of America
2022-07-16 - international - ODI - male - 1322034 - Namibia vs Nepal
2022-07-14 - international - ODI - male - 1322033 - Namibia vs Scotland
2022-07-11 - international - ODI - male - 1322031 - Namibia vs Nepal
2022-05-24 - international - T20 - male - 1310942 - Namibia vs Zimbabwe
2022-05-22 - international - T20 - male - 1310941 - Zimbabwe vs Namibia
2022-05-21 - international - T20 - male - 1310940 - Namibia vs Zimbabwe
2022-05-19 - international - T20 - male - 1310939 - Zimbabwe vs Namibia
2022-05-17 - international - T20 - male - 1310938 - Zimbabwe vs Namibia
2022-04-10 - international - T20 - male - 1309703 - Namibia vs Uganda
2022-04-09 - international - T20 - male - 1309702 - Namibia vs Uganda
2022-04-08 - international - T20 - male - 1309701 - Uganda vs Namibia
2022-03-14 - international - ODI - male - 1302622 - Oman vs Namibia
2022-03-12 - international - ODI - male - 1302621 - United Arab Emirates vs Namibia
2022-03-11 - international - ODI - male - 1302620 - Namibia vs Oman
2022-03-08 - international - ODI - male - 1302618 - Namibia vs United Arab Emirates
2022-03-06 - international - ODI - male - 1302617 - Namibia vs Oman
2021-11-26 - international - ODI - male - 1290881 - Namibia vs Oman
2021-11-08 - international - T20 - male - 1273753 - Namibia vs India
2021-11-05 - international - T20 - male - 1273747 - New Zealand vs Namibia
2021-11-02 - international - T20 - male - 1273742 - Pakistan vs Namibia
2021-10-27 - international - T20 - male - 1273732 - Scotland vs Namibia
2021-10-22 - international - T20 - male - 1273722 - Ireland vs Namibia
2021-10-20 - international - T20 - male - 1273718 - Netherlands vs Namibia
2021-10-18 - international - T20 - male - 1273715 - Namibia vs Sri Lanka
2021-10-10 - international - T20 - male - 1280059 - Namibia vs Papua New Guinea
2021-10-09 - international - T20 - male - 1280058 - Scotland vs Namibia
2021-04-08 - international - ODM - male - 1257408 - Namibia vs Uganda
2021-04-07 - international - ODM - male - 1257407 - Namibia vs Uganda
2021-04-05 - international - T20 - male - 1257406 - Namibia vs Uganda
2021-04-05 - international - T20 - male - 1257405 - Namibia vs Uganda
2021-04-03 - international - T20 - male - 1257404 - Uganda vs Namibia
2020-01-09 - international - ODI - male - 1211173 - Namibia vs United Arab Emirates
2020-01-08 - international - ODI - male - 1211171 - Oman vs Namibia
2020-01-06 - international - ODI - male - 1211170 - Namibia vs United Arab Emirates
2019-11-02 - international - T20 - male - 1199548 - Ireland vs Namibia
2019-11-01 - international - T20 - male - 1199547 - Namibia vs Papua New Guinea
2019-10-29 - international - T20 - male - 1199542 - Namibia vs Oman
2019-10-26 - international - T20 - male - 1199535 - Namibia vs Singapore
2019-10-25 - international - T20 - male - 1199531 - Kenya vs Namibia
2019-10-23 - international - T20 - male - 1199520 - Bermuda vs Namibia
2019-10-22 - international - T20 - male - 1199517 - Namibia vs Scotland
2019-10-20 - international - T20 - male - 1199508 - Namibia vs Papua New Guinea
2019-10-19 - international - T20 - male - 1199505 - Namibia vs Netherlands
2019-09-23 - international - ODI - male - 1199230 - Namibia vs Papua New Guinea
2019-09-22 - international - ODI - male - 1199229 - Namibia vs Papua New Guinea
2019-09-17 - international - ODI - male - 1199226 - United States of America vs Namibia
2019-08-23 - international - T20 - male - 1197510 - Namibia vs Botswana
2019-08-22 - international - T20 - male - 1197509 - Namibia vs Botswana
2019-08-20 - international - T20 - male - 1197508 - Namibia vs Botswana
2019-08-19 - international - T20 - male - 1197507 - Namibia vs Botswana
2019-05-22 - international - T20 - male - 1184901 - Botswana vs Namibia
2019-05-21 - international - T20 - male - 1184262 - Uganda vs Namibia
2019-05-20 - international - T20 - male - 1184258 - Ghana vs Namibia
2019-04-27 - international - ODI - male - 1174845 - Namibia vs Oman
2019-04-26 - international - ODM - male - 1174841 - Namibia vs Hong Kong
2019-04-24 - international - ODM - male - 1174838 - Namibia vs Oman
2019-04-23 - international - ODM - male - 1174836 - Namibia vs Canada
2019-04-21 - international - ODM - male - 1174831 - Namibia vs United States of America
2019-04-20 - international - ODM - male - 1174828 - Namibia vs Papua New Guinea
2018-11-03 - international - IT20 - male - 1163067 - Namibia vs Botswana
2018-11-02 - international - IT20 - male - 1163066 - Namibia vs St Helena
2018-11-01 - international - IT20 - male - 1163060 - Namibia vs Lesotho
2018-10-29 - international - IT20 - male - 1163054 - Namibia vs Mozambique
2018-10-28 - international - IT20 - male - 1163048 - Swaziland vs Namibia
2018-02-15 - international - ODM - male - 1133945 - Canada vs Namibia
2018-02-14 - international - ODM - male - 1133942 - United Arab Emirates vs Namibia
2018-02-13 - international - ODM - male - 1136314 - Kenya vs Namibia
2018-02-12 - international - ODM - male - 1133940 - Namibia vs Canada
2018-02-11 - international - ODM - male - 1133935 - Oman vs Namibia
2018-02-09 - international - ODM - male - 1133934 - Kenya vs Namibia
2017-09-21 - international - ODM - male - 1105002 - Namibia vs United Arab Emirates
2017-09-16 - international - MDM - male - 1105001 - United Arab Emirates vs Namibia
2017-06-13 - international - ODM - male - 1068740 - Scotland vs Namibia
2017-06-11 - international - ODM - male - 1068739 - Scotland vs Namibia
2017-01-17 - international - IT20 - male - 1074963 - Ireland vs Namibia
2017-01-15 - international - IT20 - male - 1074960 - United Arab Emirates vs Namibia
2016-10-23 - international - ODM - male - 1004255 - Papua New Guinea vs Namibia
2016-10-21 - international - ODM - male - 1004253 - Papua New Guinea vs Namibia
2016-10-16 - international - MDM - male - 1004251 - Papua New Guinea vs Namibia
2016-04-18 - international - ODM - male - 952199 - Nepal vs Namibia
2016-04-16 - international - ODM - male - 952197 - Nepal vs Namibia
2015-11-01 - international - ODM - male - 911045 - Kenya vs Namibia
2015-10-30 - international - ODM - male - 911043 - Kenya vs Namibia
2015-10-24 - international - MDM - male - 911041 - Namibia vs Ireland
2015-07-23 - international - IT20 - male - 875547 - Namibia vs Oman
2015-07-21 - international - IT20 - male - 875543 - Namibia vs Netherlands
2015-07-19 - international - IT20 - male - 875539 - Hong Kong vs Namibia
2015-07-18 - international - IT20 - male - 875529 - Namibia vs Papua New Guinea
2015-07-17 - international - IT20 - male - 875515 - Jersey vs Namibia
2015-07-11 - international - IT20 - male - 875475 - Namibia vs Nepal
2015-07-10 - international - IT20 - male - 875461 - Ireland vs Namibia
2015-05-18 - international - IT20 - male - 877507 - Namibia vs Hong Kong
2015-01-24 - international - ODM - male - 812809 - Namibia vs Netherlands
2015-01-23 - international - ODM - male - 812801 - Namibia vs Canada
2015-01-21 - international - ODM - male - 812795 - Namibia vs Nepal
2015-01-20 - international - ODM - male - 812791 - Namibia vs Netherlands
2015-01-18 - international - ODM - male - 812781 - Namibia vs Uganda
2015-01-17 - international - ODM - male - 812775 - Namibia vs Kenya
2013-11-28 - international - IT20 - male - 660221 - Italy vs Namibia
2013-11-23 - international - IT20 - male - 660183 - Canada vs Namibia
2013-11-20 - international - IT20 - male - 660157 - Hong Kong vs Namibia
2013-11-19 - international - IT20 - male - 660141 - Italy vs Namibia
2013-11-17 - international - IT20 - male - 660125 - Namibia vs United States of America
2013-11-16 - international - IT20 - male - 660109 - Namibia vs United Arab Emirates
2013-11-15 - international - IT20 - male - 660093 - Ireland vs Namibia
2013-09-29 - international - ODM - male - 661889 - United Arab Emirates vs Namibia
2013-09-27 - international - ODM - male - 661887 - United Arab Emirates vs Namibia
2013-04-18 - international - ODM - male - 592275 - Namibia vs Netherlands
2013-04-16 - international - ODM - male - 592274 - Netherlands vs Namibia
2012-10-04 - international - ODM - male - 555888 - Kenya vs Namibia
2012-10-02 - international - ODM - male - 555887 - Namibia vs Kenya
2012-09-29 - international - MDM - male - 516852 - Kenya vs Namibia
2012-04-12 - international - ODM - male - 543891 - Namibia vs Canada
2012-04-10 - international - ODM - male - 543890 - Namibia vs Canada
2011-09-28 - international - ODM - male - 523806 - Namibia vs Scotland
2003-03-03 - international - ODI - male - 65271 - Netherlands vs Namibia
2003-02-27 - international - ODI - male - 65263 - Australia vs Namibia
2003-02-23 - international - ODI - male - 65257 - India vs Namibia
2003-02-19 - international - ODI - male - 65252 - England vs Namibia
2003-02-16 - international - ODI - male - 65247 - Pakistan vs Namibia
2003-02-10 - international - ODI - male - 65236 - Zimbabwe vs Namibia
