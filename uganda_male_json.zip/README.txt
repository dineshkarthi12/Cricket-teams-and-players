This zip archive contains data files from Cricsheet in JSON format. This
archive contains 173 Uganda matches of all types. A further match has been
withheld due to either featuring the Afghanistan men's team or being played in
the Afghanistan Premier League, due to the Cricsheet policy to no longer
feature matches involving Afghanistan men or played in Afghanistan Premier
League (see https://cricsheet.org/withheld-matches for more information).


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/uganda_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-09-17 - international - T20 - male - 1552922 - Uganda vs Rwanda
2026-09-16 - international - T20 - male - 1552920 - Botswana vs Uganda
2026-09-15 - international - T20 - male - 1552918 - Sierra Leone vs Uganda
2026-09-12 - international - T20 - male - 1552914 - Uganda vs Kenya
2026-09-11 - international - T20 - male - 1552912 - Uganda vs Rwanda
2026-09-10 - international - T20 - male - 1552910 - Botswana vs Uganda
2026-09-09 - international - T20 - male - 1552908 - Uganda vs Sierra Leone
2026-08-18 - international - ODM - male - 1546354 - Uganda vs Bahrain
2026-08-15 - international - ODM - male - 1546349 - Singapore vs Uganda
2026-08-12 - international - ODM - male - 1546346 - Hong Kong vs Uganda
2026-08-11 - international - ODM - male - 1546344 - Italy vs Uganda
2026-08-08 - international - ODM - male - 1546340 - Uganda vs Tanzania
2025-10-04 - international - T20 - male - 1502761 - Uganda vs Nigeria
2025-10-02 - international - T20 - male - 1502758 - Uganda vs Malawi
2025-09-30 - international - T20 - male - 1502752 - Botswana vs Uganda
2025-09-28 - international - T20 - male - 1502748 - Tanzania vs Uganda
2025-09-26 - international - T20 - male - 1502745 - Uganda vs Zimbabwe
2025-07-27 - international - T20 - male - 1494111 - Uganda vs United Arab Emirates
2025-07-25 - international - T20 - male - 1494114 - Kenya vs Uganda
2025-07-22 - international - T20 - male - 1494583 - Uganda vs Nigeria
2025-07-21 - international - T20 - male - 1494103 - Uganda vs Kenya
2025-07-19 - international - T20 - male - 1494108 - Uganda vs United Arab Emirates
2025-07-18 - international - T20 - male - 1494116 - Uganda vs Nigeria
2025-02-15 - international - ODM - male - 1471839 - Uganda vs Tanzania
2025-02-13 - international - ODM - male - 1471838 - Uganda vs Hong Kong
2025-02-10 - international - ODM - male - 1471834 - Singapore vs Uganda
2025-02-07 - international - ODM - male - 1471829 - Uganda vs Bahrain
2024-12-14 - international - T20 - male - 1462932 - Nigeria vs Uganda
2024-12-13 - international - T20 - male - 1462930 - Uganda vs Botswana
2024-12-12 - international - T20 - male - 1462923 - Uganda vs Rwanda
2024-12-11 - international - T20 - male - 1462917 - Uganda vs Nigeria
2024-12-09 - international - T20 - male - 1462928 - Uganda vs Botswana
2024-12-08 - international - T20 - male - 1462925 - Nigeria vs Uganda
2024-12-07 - international - T20 - male - 1462931 - Uganda vs Rwanda
2024-12-06 - international - T20 - male - 1462915 - Nigeria vs Uganda
2024-12-05 - international - T20 - male - 1462921 - Uganda vs Rwanda
2024-12-04 - international - T20 - male - 1462912 - Uganda vs Botswana
2024-11-13 - international - ODM - male - 1451903 - Uganda vs Italy
2024-11-10 - international - ODM - male - 1451898 - Uganda vs Hong Kong
2024-11-09 - international - ODM - male - 1451896 - Uganda vs Tanzania
2024-11-06 - international - ODM - male - 1451893 - Singapore vs Uganda
2024-10-29 - international - T20 - male - 1457351 - Bahrain vs Uganda
2024-10-28 - international - T20 - male - 1457350 - Bahrain vs Uganda
2024-06-14 - international - T20 - male - 1415732 - Uganda vs New Zealand
2024-06-08 - international - T20 - male - 1415718 - West Indies vs Uganda
2024-06-05 - international - T20 - male - 1415709 - Papua New Guinea vs Uganda
2024-03-23 - international - T20 - male - 1424766 - Uganda vs Kenya
2024-03-21 - international - T20 - male - 1424764 - Namibia vs Uganda
2024-03-18 - international - T20 - male - 1424759 - Uganda vs Ghana
2024-03-17 - international - T20 - male - 1424755 - Uganda vs Kenya
2023-11-30 - international - T20 - male - 1407108 - Rwanda vs Uganda
2023-11-29 - international - T20 - male - 1407106 - Uganda vs Kenya
2023-11-27 - international - T20 - male - 1407100 - Nigeria vs Uganda
2023-11-26 - international - T20 - male - 1407099 - Zimbabwe vs Uganda
2023-11-24 - international - T20 - male - 1407095 - Uganda vs Namibia
2023-11-22 - international - T20 - male - 1407090 - Tanzania vs Uganda
2023-08-31 - international - T20 - male - 1393320 - Rwanda vs Uganda
2023-08-30 - international - T20 - male - 1393319 - Uganda vs Tanzania
2023-08-28 - international - T20 - male - 1393318 - Rwanda vs Uganda
2023-08-28 - international - T20 - male - 1393317 - Uganda vs Tanzania
2023-08-27 - international - T20 - male - 1393316 - Rwanda vs Uganda
2023-08-25 - international - T20 - male - 1393329 - Uganda vs Tanzania
2023-08-24 - international - T20 - male - 1393314 - Uganda vs Tanzania
2023-08-24 - international - T20 - male - 1393313 - Uganda vs Rwanda
2023-08-22 - international - T20 - male - 1393312 - Uganda vs Rwanda
2023-08-21 - international - T20 - male - 1393311 - Uganda vs Tanzania
2023-08-20 - international - T20 - male - 1393310 - Tanzania vs Uganda
2023-08-20 - international - T20 - male - 1393309 - Uganda vs Rwanda
2023-06-21 - international - T20 - male - 1379592 - Uganda vs Kenya
2023-06-19 - international - T20 - male - 1379587 - Uganda vs Rwanda
2023-06-18 - international - T20 - male - 1379581 - Kenya vs Uganda
2023-06-17 - international - T20 - male - 1379575 - Botswana vs Uganda
2023-06-15 - international - T20 - male - 1379584 - Rwanda vs Uganda
2023-06-14 - international - T20 - male - 1379583 - Uganda vs Botswana
2023-06-13 - international - T20 - male - 1379589 - Uganda vs Kenya
2023-06-11 - international - T20 - male - 1379578 - Rwanda vs Uganda
2023-06-10 - international - T20 - male - 1379577 - Kenya vs Uganda
2022-12-23 - international - T20 - male - 1349140 - Uganda vs Rwanda
2022-12-22 - international - T20 - male - 1349139 - Uganda vs Tanzania
2022-12-20 - international - T20 - male - 1349137 - Rwanda vs Uganda
2022-12-19 - international - T20 - male - 1349134 - Uganda vs Tanzania
2022-12-18 - international - T20 - male - 1349132 - Uganda vs Tanzania
2022-12-15 - international - T20 - male - 1349129 - Uganda vs Tanzania
2022-12-15 - international - T20 - male - 1349128 - Uganda vs Rwanda
2022-12-14 - international - T20 - male - 1349127 - Tanzania vs Uganda
2022-12-14 - international - T20 - male - 1349126 - Uganda vs Rwanda
2022-09-22 - international - T20 - male - 1332510 - Tanzania vs Uganda
2022-09-21 - international - T20 - male - 1332508 - Kenya vs Uganda
2022-09-20 - international - T20 - male - 1332501 - Ghana vs Uganda
2022-09-18 - international - T20 - male - 1332503 - Uganda vs Mozambique
2022-09-15 - international - T20 - male - 1332496 - Botswana vs Uganda
2022-08-10 - international - ODM - male - 1326864 - Kenya vs Uganda
2022-08-07 - international - ODM - male - 1326860 - Italy vs Uganda
2022-08-05 - international - ODM - male - 1326859 - Uganda vs Jersey
2022-07-17 - international - T20 - male - 1321481 - Uganda vs Hong Kong
2022-07-15 - international - T20 - male - 1321477 - Uganda vs Jersey
2022-07-14 - international - T20 - male - 1321473 - Netherlands vs Uganda
2022-07-12 - international - T20 - male - 1321472 - Uganda vs Papua New Guinea
2022-07-11 - international - T20 - male - 1321468 - Hong Kong vs Uganda
2022-06-26 - international - ODM - male - 1317961 - Kenya vs Uganda
2022-06-24 - international - ODM - male - 1317960 - Italy vs Uganda
2022-06-21 - international - ODM - male - 1317955 - Bermuda vs Uganda
2022-06-20 - international - ODM - male - 1317954 - Uganda vs Hong Kong
2022-06-17 - international - ODM - male - 1317950 - Jersey vs Uganda
2022-04-10 - international - T20 - male - 1309703 - Namibia vs Uganda
2022-04-09 - international - T20 - male - 1309702 - Namibia vs Uganda
2022-04-08 - international - T20 - male - 1309701 - Uganda vs Namibia
2021-11-20 - international - T20 - male - 1289052 - Kenya vs Uganda
2021-11-20 - international - T20 - male - 1289050 - Tanzania vs Uganda
2021-11-18 - international - T20 - male - 1289049 - Nigeria vs Uganda
2021-11-18 - international - T20 - male - 1289046 - Tanzania vs Uganda
2021-11-17 - international - T20 - male - 1289044 - Uganda vs Nigeria
2021-11-17 - international - T20 - male - 1289043 - Kenya vs Uganda
2021-10-22 - international - T20 - male - 1283041 - Uganda vs Seychelles
2021-10-21 - international - T20 - male - 1283037 - Uganda vs Ghana
2021-10-19 - international - T20 - male - 1283032 - Swaziland vs Uganda
2021-10-19 - international - T20 - male - 1283030 - Lesotho vs Uganda
2021-10-17 - international - T20 - male - 1283028 - Uganda vs Rwanda
2021-10-16 - international - T20 - male - 1283024 - Malawi vs Uganda
2021-09-17 - international - T20 - male - 1275051 - Uganda vs Kenya
2021-09-15 - international - T20 - male - 1275047 - Uganda vs Nigeria
2021-09-13 - international - T20 - male - 1275043 - Nigeria vs Uganda
2021-09-11 - international - T20 - male - 1275040 - Uganda vs Nigeria
2021-09-10 - international - T20 - male - 1275044 - Kenya vs Uganda
2021-04-08 - international - ODM - male - 1257408 - Namibia vs Uganda
2021-04-07 - international - ODM - male - 1257407 - Namibia vs Uganda
2021-04-05 - international - T20 - male - 1257406 - Namibia vs Uganda
2021-04-05 - international - T20 - male - 1257405 - Namibia vs Uganda
2021-04-03 - international - T20 - male - 1257404 - Uganda vs Namibia
2019-05-23 - international - T20 - male - 1184266 - Uganda vs Ghana
2019-05-22 - international - T20 - male - 1184902 - Uganda vs Kenya
2019-05-21 - international - T20 - male - 1184262 - Uganda vs Namibia
2019-05-20 - international - T20 - male - 1184260 - Uganda vs Botswana
2018-11-18 - international - ODM - male - 1162858 - Uganda vs Oman
2018-11-15 - international - ODM - male - 1162853 - Singapore vs Uganda
2018-11-13 - international - ODM - male - 1162852 - Uganda vs Kenya
2018-11-10 - international - ODM - male - 1162847 - United States of America vs Uganda
2018-11-09 - international - ODM - male - 1162846 - Denmark vs Uganda
2018-07-14 - international - IT20 - male - 1151254 - Kenya vs Uganda
2018-07-13 - international - IT20 - male - 1151252 - Uganda vs Rwanda
2018-07-11 - international - IT20 - male - 1151249 - Uganda vs Tanzania
2018-07-10 - international - IT20 - male - 1151248 - Uganda vs Rwanda
2018-07-07 - international - IT20 - male - 1151243 - Uganda vs Kenya
2018-05-06 - international - ODM - male - 1145319 - Uganda vs Jersey
2018-05-03 - international - ODM - male - 1144330 - Uganda vs Denmark
2018-05-02 - international - ODM - male - 1144328 - Uganda vs Vanuatu
2018-04-30 - international - ODM - male - 1144326 - Uganda vs Bermuda
2018-04-29 - international - ODM - male - 1144321 - Malaysia vs Uganda
2017-05-27 - international - ODM - male - 1090946 - Malaysia vs Uganda
2017-05-26 - international - ODM - male - 1090944 - Uganda vs Oman
2017-05-24 - international - ODM - male - 1090942 - Uganda vs Singapore
2016-09-28 - international - IT20 - male - 1058155 - Kenya vs Uganda
2016-09-27 - international - IT20 - male - 1058153 - Qatar vs Uganda
2015-01-24 - international - ODM - male - 812807 - Canada vs Uganda
2015-01-23 - international - ODM - male - 812799 - Netherlands vs Uganda
2015-01-21 - international - ODM - male - 812797 - Canada vs Uganda
2015-01-20 - international - ODM - male - 812789 - Kenya vs Uganda
2015-01-18 - international - ODM - male - 812781 - Namibia vs Uganda
2015-01-17 - international - ODM - male - 812779 - Nepal vs Uganda
2014-10-30 - international - ODM - male - 785993 - Nepal vs Uganda
2014-10-29 - international - ODM - male - 785985 - Bermuda vs Uganda
2014-10-27 - international - ODM - male - 785979 - Malaysia vs Uganda
2014-10-26 - international - ODM - male - 785975 - Uganda vs United States of America
2014-10-24 - international - ODM - male - 785965 - Singapore vs Uganda
2014-10-23 - international - ODM - male - 785959 - Nepal vs Uganda
2013-11-26 - international - IT20 - male - 660205 - Bermuda vs Uganda
2013-11-22 - international - IT20 - male - 660177 - Ireland vs Uganda
2013-11-19 - international - IT20 - male - 660147 - Canada vs Uganda
2013-11-18 - international - IT20 - male - 660133 - Italy vs Uganda
2013-11-16 - international - IT20 - male - 660115 - Uganda vs Hong Kong
2013-11-15 - international - IT20 - male - 660095 - Uganda vs United Arab Emirates
2013-05-05 - international - ODM - male - 628096 - Nepal vs Uganda
2013-05-04 - international - ODM - male - 628093 - Oman vs Uganda
