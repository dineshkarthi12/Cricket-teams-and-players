This zip archive contains data files from Cricsheet in JSON format. This
archive contains 29 Mizoram matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/mizoram_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-25 - club - SMA - male - 1383527 - Jammu & Kashmir vs Mizoram
2023-10-23 - club - SMA - male - 1383507 - Haryana vs Mizoram
2023-10-21 - club - SMA - male - 1383491 - Mizoram vs Hyderabad (India)
2022-10-20 - club - SMA - male - 1333017 - Uttarakhand vs Mizoram
2022-10-18 - club - SMA - male - 1332997 - Mizoram vs Madhya Pradesh
2022-10-16 - club - SMA - male - 1332981 - Mizoram vs Assam
2021-11-09 - club - SMA - male - 1280290 - Manipur vs Mizoram
2021-11-08 - club - SMA - male - 1280270 - Mizoram vs Sikkim
2021-11-05 - club - SMA - male - 1280235 - Tripura vs Mizoram
2021-11-04 - club - SMA - male - 1280216 - Mizoram vs Meghalaya
2021-01-19 - club - SMA - male - 1244399 - Mizoram vs Bihar
2021-01-17 - club - SMA - male - 1244381 - Nagaland vs Mizoram
2021-01-15 - club - SMA - male - 1244360 - Chandigarh vs Mizoram
2021-01-13 - club - SMA - male - 1244340 - Meghalaya vs Mizoram
2021-01-11 - club - SMA - male - 1244324 - Mizoram vs Sikkim
2019-11-17 - club - SMA - male - 1205836 - Meghalaya vs Mizoram
2019-11-15 - club - SMA - male - 1205810 - Mizoram vs Haryana
2019-11-14 - club - SMA - male - 1205800 - Mizoram vs Assam
2019-11-12 - club - SMA - male - 1205775 - Madhya Pradesh vs Mizoram
2019-11-11 - club - SMA - male - 1205757 - Puducherry vs Mizoram
2019-11-09 - club - SMA - male - 1205746 - Mizoram vs Bengal
2019-11-08 - club - SMA - male - 1205721 - Mizoram vs Mumbai
2019-03-02 - club - SMA - male - 1157203 - Chhattisgarh vs Mizoram
2019-02-28 - club - SMA - male - 1157188 - Mizoram vs Arunachal Pradesh
2019-02-27 - club - SMA - male - 1157170 - Haryana vs Mizoram
2019-02-25 - club - SMA - male - 1157154 - Karnataka vs Mizoram
2019-02-24 - club - SMA - male - 1157136 - Mizoram vs Odisha
2019-02-22 - club - SMA - male - 1157117 - Assam vs Mizoram
2019-02-21 - club - SMA - male - 1157103 - Bengal vs Mizoram
