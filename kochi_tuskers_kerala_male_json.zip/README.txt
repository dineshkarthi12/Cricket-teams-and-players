This zip archive contains data files from Cricsheet in JSON format. This
archive contains 14 Kochi Tuskers Kerala matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/kochi_tuskers_kerala_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2011-05-18 - club - IPL - male - 501261 - Chennai Super Kings vs Kochi Tuskers Kerala
2011-05-15 - club - IPL - male - 501258 - Kochi Tuskers Kerala vs Rajasthan Royals
2011-05-13 - club - IPL - male - 501254 - Kochi Tuskers Kerala vs Kings XI Punjab
2011-05-08 - club - IPL - male - 501247 - Royal Challengers Bangalore vs Kochi Tuskers Kerala
2011-05-05 - club - IPL - male - 501242 - Kochi Tuskers Kerala vs Kolkata Knight Riders
2011-05-02 - club - IPL - male - 501238 - Delhi Daredevils vs Kochi Tuskers Kerala
2011-04-30 - club - IPL - male - 501233 - Kochi Tuskers Kerala vs Delhi Daredevils
2011-04-27 - club - IPL - male - 501229 - Kochi Tuskers Kerala vs Deccan Chargers
2011-04-24 - club - IPL - male - 501225 - Rajasthan Royals vs Kochi Tuskers Kerala
2011-04-20 - club - IPL - male - 501219 - Kolkata Knight Riders vs Kochi Tuskers Kerala
2011-04-18 - club - IPL - male - 501215 - Kochi Tuskers Kerala vs Chennai Super Kings
2011-04-15 - club - IPL - male - 501210 - Mumbai Indians vs Kochi Tuskers Kerala
2011-04-13 - club - IPL - male - 501207 - Pune Warriors vs Kochi Tuskers Kerala
2011-04-09 - club - IPL - male - 501200 - Kochi Tuskers Kerala vs Royal Challengers Bangalore
