This zip archive contains data files from Cricsheet in JSON format. This
archive contains 30 Gujarat Lions matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/gujarat_lions_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2017-05-13 - club - IPL - male - 1082643 - Gujarat Lions vs Sunrisers Hyderabad
2017-05-10 - club - IPL - male - 1082640 - Gujarat Lions vs Delhi Daredevils
2017-05-07 - club - IPL - male - 1082637 - Kings XI Punjab vs Gujarat Lions
2017-05-04 - club - IPL - male - 1082632 - Delhi Daredevils vs Gujarat Lions
2017-05-01 - club - IPL - male - 1082629 - Rising Pune Supergiant vs Gujarat Lions
2017-04-29 - club - IPL - male - 1082625 - Gujarat Lions vs Mumbai Indians
2017-04-27 - club - IPL - male - 1082621 - Royal Challengers Bangalore vs Gujarat Lions
2017-04-23 - club - IPL - male - 1082616 - Gujarat Lions vs Kings XI Punjab
2017-04-21 - club - IPL - male - 1082613 - Kolkata Knight Riders vs Gujarat Lions
2017-04-18 - club - IPL - male - 1082610 - Gujarat Lions vs Royal Challengers Bangalore
2017-04-16 - club - IPL - male - 1082606 - Mumbai Indians vs Gujarat Lions
2017-04-14 - club - IPL - male - 1082603 - Gujarat Lions vs Rising Pune Supergiant
2017-04-09 - club - IPL - male - 1082596 - Sunrisers Hyderabad vs Gujarat Lions
2017-04-07 - club - IPL - male - 1082593 - Gujarat Lions vs Kolkata Knight Riders
2016-05-27 - club - IPL - male - 981017 - Gujarat Lions vs Sunrisers Hyderabad
2016-05-24 - club - IPL - male - 981013 - Gujarat Lions vs Royal Challengers Bangalore
2016-05-21 - club - IPL - male - 981007 - Gujarat Lions vs Mumbai Indians
2016-05-19 - club - IPL - male - 981001 - Gujarat Lions vs Kolkata Knight Riders
2016-05-14 - club - IPL - male - 980987 - Royal Challengers Bangalore vs Gujarat Lions
2016-05-08 - club - IPL - male - 980975 - Kolkata Knight Riders vs Gujarat Lions
2016-05-06 - club - IPL - male - 980967 - Sunrisers Hyderabad vs Gujarat Lions
2016-05-03 - club - IPL - male - 980961 - Gujarat Lions vs Delhi Daredevils
2016-05-01 - club - IPL - male - 980955 - Gujarat Lions vs Kings XI Punjab
2016-04-29 - club - IPL - male - 980949 - Rising Pune Supergiants vs Gujarat Lions
2016-04-27 - club - IPL - male - 980945 - Delhi Daredevils vs Gujarat Lions
2016-04-24 - club - IPL - male - 980937 - Gujarat Lions vs Royal Challengers Bangalore
2016-04-21 - club - IPL - male - 980929 - Gujarat Lions vs Sunrisers Hyderabad
2016-04-16 - club - IPL - male - 980917 - Mumbai Indians vs Gujarat Lions
2016-04-14 - club - IPL - male - 980911 - Gujarat Lions vs Rising Pune Supergiants
2016-04-11 - club - IPL - male - 980905 - Kings XI Punjab vs Gujarat Lions
