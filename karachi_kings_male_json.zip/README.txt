This zip archive contains data files from Cricsheet in JSON format. This
archive contains 114 Karachi Kings matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/karachi_kings_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-04-25 - club - PSL - male - 1527588 - Quetta Gladiators vs Karachi Kings
2026-04-23 - club - PSL - male - 1527586 - Lahore Qalandars vs Karachi Kings
2026-04-22 - club - PSL - male - 1527583 - Karachi Kings vs Peshawar Zalmi
2026-04-19 - club - PSL - male - 1527579 - Multan Sultans vs Karachi Kings
2026-04-16 - club - PSL - male - 1527576 - Karachi Kings vs Islamabad United
2026-04-11 - club - PSL - male - 1527571 - Karachi Kings vs Hyderabad Kingsmen
2026-04-09 - club - PSL - male - 1527568 - Peshawar Zalmi vs Karachi Kings
2026-04-02 - club - PSL - male - 1527561 - Rawalpindiz vs Karachi Kings
2026-03-29 - club - PSL - male - 1527557 - Lahore Qalandars vs Karachi Kings
2026-03-27 - club - PSL - male - 1527553 - Karachi Kings vs Quetta Gladiators
2025-05-22 - club - PSL - male - 1475269 - Karachi Kings vs Lahore Qalandars
2025-05-19 - club - PSL - male - 1475267 - Islamabad United vs Karachi Kings
2025-05-17 - club - PSL - male - 1475264 - Karachi Kings vs Peshawar Zalmi
2025-05-04 - club - PSL - male - 1475261 - Lahore Qalandars vs Karachi Kings
2025-05-01 - club - PSL - male - 1475257 - Karachi Kings vs Multan Sultans
2025-04-25 - club - PSL - male - 1475252 - Quetta Gladiators vs Karachi Kings
2025-04-21 - club - PSL - male - 1475248 - Peshawar Zalmi vs Karachi Kings
2025-04-20 - club - PSL - male - 1475247 - Karachi Kings vs Islamabad United
2025-04-18 - club - PSL - male - 1475245 - Karachi Kings vs Quetta Gladiators
2025-04-15 - club - PSL - male - 1475243 - Lahore Qalandars vs Karachi Kings
2025-04-12 - club - PSL - male - 1475240 - Multan Sultans vs Karachi Kings
2024-03-11 - club - PSL - male - 1416500 - Peshawar Zalmi vs Karachi Kings
2024-03-09 - club - PSL - male - 1416497 - Lahore Qalandars vs Karachi Kings
2024-03-07 - club - PSL - male - 1416495 - Karachi Kings vs Islamabad United
2024-03-06 - club - PSL - male - 1416493 - Quetta Gladiators vs Karachi Kings
2024-03-03 - club - PSL - male - 1416490 - Multan Sultans vs Karachi Kings
2024-02-29 - club - PSL - male - 1416487 - Karachi Kings vs Quetta Gladiators
2024-02-28 - club - PSL - male - 1416486 - Karachi Kings vs Islamabad United
2024-02-24 - club - PSL - male - 1416481 - Lahore Qalandars vs Karachi Kings
2024-02-21 - club - PSL - male - 1416477 - Peshawar Zalmi vs Karachi Kings
2024-02-18 - club - PSL - male - 1416474 - Multan Sultans vs Karachi Kings
2023-03-12 - club - PSL - male - 1354953 - Karachi Kings vs Lahore Qalandars
2023-03-06 - club - PSL - male - 1354945 - Karachi Kings vs Quetta Gladiators
2023-03-03 - club - PSL - male - 1354942 - Karachi Kings vs Islamabad United
2023-03-01 - club - PSL - male - 1354940 - Peshawar Zalmi vs Karachi Kings
2023-02-26 - club - PSL - male - 1354937 - Karachi Kings vs Multan Sultans
2023-02-22 - club - PSL - male - 1354934 - Multan Sultans vs Karachi Kings
2023-02-19 - club - PSL - male - 1354931 - Karachi Kings vs Lahore Qalandars
2023-02-18 - club - PSL - male - 1354929 - Quetta Gladiators vs Karachi Kings
2023-02-16 - club - PSL - male - 1354927 - Karachi Kings vs Islamabad United
2023-02-14 - club - PSL - male - 1354925 - Peshawar Zalmi vs Karachi Kings
2022-02-20 - club - PSL - male - 1293027 - Quetta Gladiators vs Karachi Kings
2022-02-18 - club - PSL - male - 1293025 - Karachi Kings vs Lahore Qalandars
2022-02-16 - club - PSL - male - 1293022 - Karachi Kings vs Multan Sultans
2022-02-14 - club - PSL - male - 1293020 - Islamabad United vs Karachi Kings
2022-02-13 - club - PSL - male - 1293018 - Peshawar Zalmi vs Karachi Kings
2022-02-06 - club - PSL - male - 1293013 - Islamabad United vs Karachi Kings
2022-02-04 - club - PSL - male - 1293010 - Peshawar Zalmi vs Karachi Kings
2022-01-30 - club - PSL - male - 1293005 - Karachi Kings vs Lahore Qalandars
2022-01-29 - club - PSL - male - 1293003 - Karachi Kings vs Quetta Gladiators
2022-01-27 - club - PSL - male - 1293000 - Karachi Kings vs Multan Sultans
2021-06-21 - club - PSL - male - 1247042 - Karachi Kings vs Peshawar Zalmi
2021-06-19 - club - PSL - male - 1247039 - Karachi Kings vs Quetta Gladiators
2021-06-17 - club - PSL - male - 1247037 - Karachi Kings vs Lahore Qalandars
2021-06-15 - club - PSL - male - 1247034 - Karachi Kings vs Peshawar Zalmi
2021-06-14 - club - PSL - male - 1247032 - Karachi Kings vs Islamabad United
2021-06-10 - club - PSL - male - 1247025 - Multan Sultans vs Karachi Kings
2021-03-03 - club - PSL - male - 1247023 - Peshawar Zalmi vs Karachi Kings
2021-02-28 - club - PSL - male - 1247021 - Karachi Kings vs Lahore Qalandars
2021-02-27 - club - PSL - male - 1247019 - Multan Sultans vs Karachi Kings
2021-02-24 - club - PSL - male - 1247016 - Karachi Kings vs Islamabad United
2021-02-20 - club - PSL - male - 1247011 - Quetta Gladiators vs Karachi Kings
2020-11-17 - club - PSL - male - 1231146 - Lahore Qalandars vs Karachi Kings
2020-11-14 - club - PSL - male - 1211672 - Multan Sultans vs Karachi Kings
2020-03-15 - club - PSL - male - 1211671 - Karachi Kings vs Quetta Gladiators
2020-03-14 - club - PSL - male - 1211669 - Karachi Kings vs Islamabad United
2020-03-12 - club - PSL - male - 1211667 - Karachi Kings vs Lahore Qalandars
2020-03-08 - club - PSL - male - 1211664 - Lahore Qalandars vs Karachi Kings
2020-03-06 - club - PSL - male - 1211660 - Karachi Kings vs Multan Sultans
2020-03-02 - club - PSL - male - 1211656 - Karachi Kings vs Peshawar Zalmi
2020-03-01 - club - PSL - male - 1211655 - Islamabad United vs Karachi Kings
2020-02-28 - club - PSL - male - 1211651 - Multan Sultans vs Karachi Kings
2020-02-23 - club - PSL - male - 1211647 - Karachi Kings vs Quetta Gladiators
2020-02-21 - club - PSL - male - 1211643 - Karachi Kings vs Peshawar Zalmi
2019-03-14 - club - PSL - male - 1168850 - Islamabad United vs Karachi Kings
2019-03-11 - club - PSL - male - 1168846 - Karachi Kings vs Peshawar Zalmi
2019-03-10 - club - PSL - male - 1168848 - Karachi Kings vs Quetta Gladiators
2019-03-04 - club - PSL - male - 1168843 - Karachi Kings vs Multan Sultans
2019-02-28 - club - PSL - male - 1168839 - Karachi Kings vs Lahore Qalandars
2019-02-27 - club - PSL - male - 1168837 - Islamabad United vs Karachi Kings
2019-02-24 - club - PSL - male - 1168834 - Karachi Kings vs Quetta Gladiators
2019-02-23 - club - PSL - male - 1168832 - Islamabad United vs Karachi Kings
2019-02-21 - club - PSL - male - 1168828 - Karachi Kings vs Peshawar Zalmi
2019-02-16 - club - PSL - male - 1168824 - Karachi Kings vs Lahore Qalandars
2019-02-15 - club - PSL - male - 1168821 - Karachi Kings vs Multan Sultans
2018-03-21 - club - PSL - male - 1128850 - Karachi Kings vs Peshawar Zalmi
2018-03-18 - club - PSL - male - 1128848 - Islamabad United vs Karachi Kings
2018-03-16 - club - PSL - male - 1128847 - Islamabad United vs Karachi Kings
2018-03-15 - club - PSL - male - 1128844 - Peshawar Zalmi vs Karachi Kings
2018-03-11 - club - PSL - male - 1128841 - Karachi Kings vs Lahore Qalandars
2018-03-10 - club - PSL - male - 1128839 - Multan Sultans vs Karachi Kings
2018-03-08 - club - PSL - male - 1128836 - Karachi Kings vs Quetta Gladiators
2018-03-04 - club - PSL - male - 1128832 - Islamabad United vs Karachi Kings
2018-02-26 - club - PSL - male - 1128825 - Karachi Kings vs Lahore Qalandars
2018-02-25 - club - PSL - male - 1128824 - Karachi Kings vs Peshawar Zalmi
2018-02-23 - club - PSL - male - 1128819 - Karachi Kings vs Quetta Gladiators
2017-03-03 - club - PSL - male - 1076008 - Peshawar Zalmi vs Karachi Kings
2017-03-01 - club - PSL - male - 1076007 - Karachi Kings vs Islamabad United
2017-02-26 - club - PSL - male - 1076005 - Islamabad United vs Karachi Kings
2017-02-25 - club - PSL - male - 1076003 - Karachi Kings vs Lahore Qalandars
2017-02-23 - club - PSL - male - 1076000 - Karachi Kings vs Quetta Gladiators
2017-02-19 - club - PSL - male - 1075998 - Karachi Kings vs Peshawar Zalmi
2017-02-17 - club - PSL - male - 1075995 - Islamabad United vs Karachi Kings
2017-02-16 - club - PSL - male - 1075993 - Karachi Kings vs Lahore Qalandars
2017-02-11 - club - PSL - male - 1075990 - Karachi Kings vs Quetta Gladiators
2017-02-10 - club - PSL - male - 1075988 - Karachi Kings vs Peshawar Zalmi
2016-02-20 - club - PSL - male - 959217 - Karachi Kings vs Islamabad United
2016-02-17 - club - PSL - male - 959211 - Karachi Kings vs Peshawar Zalmi
2016-02-14 - club - PSL - male - 959205 - Karachi Kings vs Islamabad United
2016-02-13 - club - PSL - male - 959201 - Karachi Kings vs Quetta Gladiators
2016-02-12 - club - PSL - male - 959197 - Karachi Kings vs Lahore Qalandars
2016-02-07 - club - PSL - male - 959185 - Islamabad United vs Karachi Kings
2016-02-06 - club - PSL - male - 959181 - Karachi Kings vs Quetta Gladiators
2016-02-05 - club - PSL - male - 959177 - Lahore Qalandars vs Karachi Kings
