This zip archive contains data files from Cricsheet in JSON format. This
archive contains 36 Rajasthan matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/rajasthan_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2022-10-16 - club - SMA - male - 1332978 - Rajasthan vs Uttarakhand
2022-10-14 - club - SMA - male - 1332960 - Rajasthan vs Railways
2021-11-18 - club - SMA - male - 1280298 - Rajasthan vs Vidarbha
2021-11-09 - club - SMA - male - 1280281 - Rajasthan vs Haryana
2021-11-08 - club - SMA - male - 1280263 - Rajasthan vs Andhra
2021-11-05 - club - SMA - male - 1280223 - Jammu & Kashmir vs Rajasthan
2021-01-29 - club - SMA - male - 1244405 - Rajasthan vs Tamil Nadu
2021-01-19 - club - SMA - male - 1244393 - Rajasthan vs Saurashtra
2021-01-17 - club - SMA - male - 1244372 - Goa vs Rajasthan
2021-01-13 - club - SMA - male - 1244336 - Rajasthan vs Madhya Pradesh
2021-01-11 - club - SMA - male - 1244316 - Vidarbha vs Rajasthan
2019-11-27 - club - SMA - male - 1205856 - Rajasthan vs Delhi
2019-11-25 - club - SMA - male - 1205853 - Maharashtra vs Rajasthan
2019-11-22 - club - SMA - male - 1205845 - Rajasthan vs Haryana
2019-11-17 - club - SMA - male - 1205825 - Tripura vs Rajasthan
2019-11-15 - club - SMA - male - 1205806 - Kerala vs Rajasthan
2019-11-12 - club - SMA - male - 1205779 - Vidarbha vs Rajasthan
2019-11-09 - club - SMA - male - 1205735 - Tamil Nadu vs Rajasthan
2019-11-08 - club - SMA - male - 1205725 - Rajasthan vs Manipur
2019-02-28 - club - SMA - male - 1157181 - Himachal vs Rajasthan
2019-02-25 - club - SMA - male - 1157147 - Vidarbha vs Rajasthan
2019-02-24 - club - SMA - male - 1157129 - Rajasthan vs Meghalaya
2019-02-21 - club - SMA - male - 1157095 - Rajasthan vs Tamil Nadu
2018-01-25 - club - SMA - male - 1133417 - Punjab vs Rajasthan
2018-01-24 - club - SMA - male - 1133413 - Rajasthan vs Mumbai
2018-01-23 - club - SMA - male - 1133409 - Rajasthan vs Karnataka
2018-01-22 - club - SMA - male - 1133405 - Jharkhand vs Rajasthan
2018-01-13 - club - SMA - male - 1130706 - Vidarbha vs Rajasthan
2018-01-12 - club - SMA - male - 1130698 - Chhattisgarh vs Rajasthan
2018-01-09 - club - SMA - male - 1130674 - Uttar Pradesh vs Rajasthan
2018-01-08 - club - SMA - male - 1130663 - Rajasthan vs Madhya Pradesh
2016-01-10 - club - SMA - male - 902233 - Rajasthan vs Jammu & Kashmir
2016-01-09 - club - SMA - male - 902217 - Rajasthan vs Tripura
2016-01-07 - club - SMA - male - 902193 - Saurashtra vs Rajasthan
2016-01-03 - club - SMA - male - 902119 - Kerala vs Rajasthan
2016-01-02 - club - SMA - male - 902093 - Punjab vs Rajasthan
