This zip archive contains data files from Cricsheet in YAML format. This
archive contains 953 England matches of all types. A further 7 matches have
been withheld due to either featuring the Afghanistan men's team or being
played in the Afghanistan Premier League, due to the Cricsheet policy to no
longer feature matches involving Afghanistan men or played in Afghanistan
Premier League (see https://cricsheet.org/withheld-matches for more
information).


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/england_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-09-17 - international - T20 - male - 1496586 - Sri Lanka vs England
2026-09-15 - international - T20 - male - 1496585 - England vs Sri Lanka
2026-09-09 - international - Test - male - 1496584 - Pakistan vs England
2026-08-27 - international - Test - male - 1496583 - England vs Pakistan
2026-08-19 - international - Test - male - 1496582 - Pakistan vs England
2026-07-19 - international - ODI - male - 1496581 - England vs India
2026-07-16 - international - ODI - male - 1496580 - India vs England
2026-07-14 - international - ODI - male - 1496579 - England vs India
2026-07-11 - international - T20 - male - 1496578 - England vs India
2026-07-09 - international - T20 - male - 1496577 - India vs England
2026-07-07 - international - T20 - male - 1496576 - England vs India
2026-07-04 - international - T20 - male - 1496575 - India vs England
2026-07-01 - international - T20 - male - 1496574 - India vs England
2026-06-25 - international - Test - male - 1496573 - New Zealand vs England
2026-06-17 - international - Test - male - 1496572 - New Zealand vs England
2026-06-04 - international - Test - male - 1496571 - England vs New Zealand
2026-03-05 - international - T20 - male - 1512772 - India vs England
2026-02-27 - international - T20 - male - 1512767 - New Zealand vs England
2026-02-24 - international - T20 - male - 1512763 - Pakistan vs England
2026-02-22 - international - T20 - male - 1512760 - England vs Sri Lanka
2026-02-16 - international - T20 - male - 1512747 - England vs Italy
2026-02-14 - international - T20 - male - 1512741 - Scotland vs England
2026-02-11 - international - T20 - male - 1512733 - West Indies vs England
2026-02-08 - international - T20 - male - 1512723 - England vs Nepal
2026-02-03 - international - T20 - male - 1507721 - England vs Sri Lanka
2026-02-01 - international - T20 - male - 1507720 - Sri Lanka vs England
2026-01-30 - international - T20 - male - 1507719 - Sri Lanka vs England
2026-01-27 - international - ODI - male - 1507718 - England vs Sri Lanka
2026-01-24 - international - ODI - male - 1507717 - Sri Lanka vs England
2026-01-22 - international - ODI - male - 1507716 - Sri Lanka vs England
2026-01-04 - international - Test - male - 1455615 - England vs Australia
2025-12-26 - international - Test - male - 1455614 - Australia vs England
2025-12-17 - international - Test - male - 1455613 - Australia vs England
2025-12-04 - international - Test - male - 1455612 - England vs Australia
2025-11-21 - international - Test - male - 1455611 - England vs Australia
2025-11-01 - international - ODI - male - 1491722 - England vs New Zealand
2025-10-29 - international - ODI - male - 1491721 - England vs New Zealand
2025-10-26 - international - ODI - male - 1491720 - England vs New Zealand
2025-10-23 - international - T20 - male - 1491719 - New Zealand vs England
2025-10-20 - international - T20 - male - 1491718 - England vs New Zealand
2025-10-18 - international - T20 - male - 1491717 - England vs New Zealand
2025-09-21 - international - T20 - male - 1448362 - Ireland vs England
2025-09-17 - international - T20 - male - 1448360 - Ireland vs England
2025-09-12 - international - T20 - male - 1448358 - England vs South Africa
2025-09-10 - international - T20 - male - 1448357 - South Africa vs England
2025-09-07 - international - ODI - male - 1448356 - England vs South Africa
2025-09-04 - international - ODI - male - 1448355 - South Africa vs England
2025-09-02 - international - ODI - male - 1448354 - England vs South Africa
2025-07-31 - international - Test - male - 1448353 - India vs England
2025-07-23 - international - Test - male - 1448352 - India vs England
2025-07-10 - international - Test - male - 1448351 - England vs India
2025-07-02 - international - Test - male - 1448350 - India vs England
2025-06-20 - international - Test - male - 1448349 - India vs England
2025-06-10 - international - T20 - male - 1448348 - England vs West Indies
2025-06-08 - international - T20 - male - 1448347 - West Indies vs England
2025-06-06 - international - T20 - male - 1448346 - England vs West Indies
2025-06-03 - international - ODI - male - 1448345 - West Indies vs England
2025-06-01 - international - ODI - male - 1448344 - West Indies vs England
2025-05-29 - international - ODI - male - 1448343 - England vs West Indies
2025-05-22 - international - Test - male - 1392691 - England vs Zimbabwe
2025-03-01 - international - ODI - male - 1466424 - England vs South Africa
2025-02-22 - international - ODI - male - 1466417 - England vs Australia
2025-02-12 - international - ODI - male - 1439906 - India vs England
2025-02-09 - international - ODI - male - 1439905 - England vs India
2025-02-06 - international - ODI - male - 1439904 - England vs India
2025-02-02 - international - T20 - male - 1439903 - India vs England
2025-01-31 - international - T20 - male - 1439902 - India vs England
2025-01-28 - international - T20 - male - 1439901 - England vs India
2025-01-25 - international - T20 - male - 1439900 - England vs India
2025-01-22 - international - T20 - male - 1439899 - England vs India
2024-12-14 - international - Test - male - 1428556 - New Zealand vs England
2024-12-06 - international - Test - male - 1428555 - England vs New Zealand
2024-11-28 - international - Test - male - 1428554 - New Zealand vs England
2024-11-17 - international - T20 - male - 1433377 - West Indies vs England
2024-11-16 - international - T20 - male - 1433376 - England vs West Indies
2024-11-14 - international - T20 - male - 1433375 - West Indies vs England
2024-11-10 - international - T20 - male - 1433374 - West Indies vs England
2024-11-09 - international - T20 - male - 1433373 - West Indies vs England
2024-11-06 - international - ODI - male - 1433372 - England vs West Indies
2024-11-02 - international - ODI - male - 1433371 - West Indies vs England
2024-10-31 - international - ODI - male - 1433370 - England vs West Indies
2024-10-24 - international - Test - male - 1442217 - England vs Pakistan
2024-10-15 - international - Test - male - 1442216 - Pakistan vs England
2024-10-07 - international - Test - male - 1442215 - Pakistan vs England
2024-09-29 - international - ODI - male - 1385704 - England vs Australia
2024-09-27 - international - ODI - male - 1385703 - England vs Australia
2024-09-24 - international - ODI - male - 1385702 - Australia vs England
2024-09-21 - international - ODI - male - 1385701 - Australia vs England
2024-09-19 - international - ODI - male - 1385700 - England vs Australia
2024-09-13 - international - T20 - male - 1385698 - Australia vs England
2024-09-11 - international - T20 - male - 1385697 - Australia vs England
2024-09-06 - international - Test - male - 1385696 - England vs Sri Lanka
2024-08-29 - international - Test - male - 1385695 - England vs Sri Lanka
2024-08-21 - international - Test - male - 1385694 - Sri Lanka vs England
2024-07-26 - international - Test - male - 1385693 - West Indies vs England
2024-07-18 - international - Test - male - 1385692 - England vs West Indies
2024-07-10 - international - Test - male - 1385691 - West Indies vs England
2024-06-27 - international - T20 - male - 1415754 - India vs England
2024-06-23 - international - T20 - male - 1415749 - United States of America vs England
2024-06-21 - international - T20 - male - 1415745 - South Africa vs England
2024-06-19 - international - T20 - male - 1415742 - West Indies vs England
2024-06-15 - international - T20 - male - 1415734 - England vs Namibia
2024-06-13 - international - T20 - male - 1415728 - Oman vs England
2024-06-08 - international - T20 - male - 1415717 - Australia vs England
2024-06-04 - international - T20 - male - 1415706 - Scotland vs England
2024-05-30 - international - T20 - male - 1385690 - Pakistan vs England
2024-05-25 - international - T20 - male - 1385688 - England vs Pakistan
2024-03-07 - international - Test - male - 1389403 - England vs India
2024-02-23 - international - Test - male - 1389402 - England vs India
2024-02-15 - international - Test - male - 1389401 - India vs England
2024-02-02 - international - Test - male - 1389400 - India vs England
2024-01-25 - international - Test - male - 1389399 - England vs India
2023-12-21 - international - T20 - male - 1373583 - England vs West Indies
2023-12-19 - international - T20 - male - 1373582 - England vs West Indies
2023-12-16 - international - T20 - male - 1373581 - West Indies vs England
2023-12-14 - international - T20 - male - 1373580 - West Indies vs England
2023-12-12 - international - T20 - male - 1373579 - England vs West Indies
2023-12-09 - international - ODI - male - 1373578 - England vs West Indies
2023-12-06 - international - ODI - male - 1373577 - West Indies vs England
2023-12-03 - international - ODI - male - 1373576 - England vs West Indies
2023-11-11 - international - ODI - male - 1384435 - England vs Pakistan
2023-11-08 - international - ODI - male - 1384431 - England vs Netherlands
2023-11-04 - international - ODI - male - 1384427 - Australia vs England
2023-10-29 - international - ODI - male - 1384420 - India vs England
2023-10-26 - international - ODI - male - 1384416 - England vs Sri Lanka
2023-10-21 - international - ODI - male - 1384411 - South Africa vs England
2023-10-10 - international - ODI - male - 1384398 - England vs Bangladesh
2023-10-05 - international - ODI - male - 1384392 - England vs New Zealand
2023-09-26 - international - ODI - male - 1336130 - England vs Ireland
2023-09-23 - international - ODI - male - 1336129 - England vs Ireland
2023-09-15 - international - ODI - male - 1336055 - England vs New Zealand
2023-09-13 - international - ODI - male - 1336054 - England vs New Zealand
2023-09-10 - international - ODI - male - 1336053 - England vs New Zealand
2023-09-08 - international - ODI - male - 1336052 - England vs New Zealand
2023-09-05 - international - T20 - male - 1336051 - England vs New Zealand
2023-09-03 - international - T20 - male - 1336050 - New Zealand vs England
2023-09-01 - international - T20 - male - 1336049 - England vs New Zealand
2023-08-30 - international - T20 - male - 1336048 - New Zealand vs England
2023-07-27 - international - Test - male - 1336047 - England vs Australia
2023-07-19 - international - Test - male - 1336046 - Australia vs England
2023-07-06 - international - Test - male - 1336045 - Australia vs England
2023-06-28 - international - Test - male - 1336044 - Australia vs England
2023-06-16 - international - Test - male - 1336043 - England vs Australia
2023-06-01 - international - Test - male - 1336127 - Ireland vs England
2023-03-14 - international - T20 - male - 1351402 - Bangladesh vs England
2023-03-12 - international - T20 - male - 1351401 - England vs Bangladesh
2023-03-09 - international - T20 - male - 1351400 - England vs Bangladesh
2023-03-06 - international - ODI - male - 1351399 - Bangladesh vs England
2023-03-03 - international - ODI - male - 1351398 - England vs Bangladesh
2023-03-01 - international - ODI - male - 1351397 - Bangladesh vs England
2023-02-24 - international - Test - male - 1322356 - England vs New Zealand
2023-02-16 - international - Test - male - 1322355 - England vs New Zealand
2023-02-01 - international - ODI - male - 1339597 - England vs South Africa
2023-01-29 - international - ODI - male - 1339596 - England vs South Africa
2023-01-27 - international - ODI - male - 1339595 - South Africa vs England
2022-12-17 - international - Test - male - 1330873 - Pakistan vs England
2022-12-09 - international - Test - male - 1330872 - England vs Pakistan
2022-12-01 - international - Test - male - 1330871 - England vs Pakistan
2022-11-22 - international - ODI - male - 1317491 - Australia vs England
2022-11-19 - international - ODI - male - 1317490 - Australia vs England
2022-11-17 - international - ODI - male - 1317489 - England vs Australia
2022-11-13 - international - T20 - male - 1298179 - Pakistan vs England
2022-11-10 - international - T20 - male - 1298178 - India vs England
2022-11-05 - international - T20 - male - 1298173 - Sri Lanka vs England
2022-11-01 - international - T20 - male - 1298167 - England vs New Zealand
2022-10-26 - international - T20 - male - 1298154 - Ireland vs England
2022-10-14 - international - T20 - male - 1317488 - England vs Australia
2022-10-12 - international - T20 - male - 1317487 - England vs Australia
2022-10-09 - international - T20 - male - 1317486 - England vs Australia
2022-10-02 - international - T20 - male - 1327234 - England vs Pakistan
2022-09-30 - international - T20 - male - 1327233 - Pakistan vs England
2022-09-28 - international - T20 - male - 1327232 - Pakistan vs England
2022-09-25 - international - T20 - male - 1327231 - Pakistan vs England
2022-09-23 - international - T20 - male - 1327230 - England vs Pakistan
2022-09-22 - international - T20 - male - 1327229 - England vs Pakistan
2022-09-20 - international - T20 - male - 1327228 - Pakistan vs England
2022-09-08 - international - Test - male - 1276918 - South Africa vs England
2022-08-25 - international - Test - male - 1276917 - South Africa vs England
2022-08-17 - international - Test - male - 1276916 - England vs South Africa
2022-07-31 - international - T20 - male - 1276915 - South Africa vs England
2022-07-28 - international - T20 - male - 1276914 - South Africa vs England
2022-07-27 - international - T20 - male - 1276913 - England vs South Africa
2022-07-24 - international - ODI - male - 1276912 - South Africa vs England
2022-07-22 - international - ODI - male - 1276911 - England vs South Africa
2022-07-19 - international - ODI - male - 1276910 - South Africa vs England
2022-07-17 - international - ODI - male - 1276909 - England vs India
2022-07-14 - international - ODI - male - 1276908 - England vs India
2022-07-12 - international - ODI - male - 1276907 - England vs India
2022-07-10 - international - T20 - male - 1276906 - England vs India
2022-07-09 - international - T20 - male - 1276905 - India vs England
2022-07-07 - international - T20 - male - 1276904 - India vs England
2022-07-01 - international - Test - male - 1320741 - India vs England
2022-06-23 - international - Test - male - 1276903 - New Zealand vs England
2022-06-22 - international - ODI - male - 1281446 - Netherlands vs England
2022-06-19 - international - ODI - male - 1281445 - Netherlands vs England
2022-06-17 - international - ODI - male - 1281444 - England vs Netherlands
2022-06-10 - international - Test - male - 1276902 - New Zealand vs England
2022-06-02 - international - Test - male - 1276901 - New Zealand vs England
2022-03-24 - international - Test - male - 1256728 - England vs West Indies
2022-03-16 - international - Test - male - 1256727 - England vs West Indies
2022-03-08 - international - Test - male - 1256726 - England vs West Indies
2022-01-30 - international - T20 - male - 1256724 - West Indies vs England
2022-01-29 - international - T20 - male - 1256723 - England vs West Indies
2022-01-26 - international - T20 - male - 1256722 - West Indies vs England
2022-01-23 - international - T20 - male - 1256721 - England vs West Indies
2022-01-22 - international - T20 - male - 1256720 - England vs West Indies
2022-01-14 - international - Test - male - 1263466 - Australia vs England
2022-01-05 - international - Test - male - 1263465 - Australia vs England
2021-12-26 - international - Test - male - 1263464 - England vs Australia
2021-12-16 - international - Test - male - 1263463 - Australia vs England
2021-12-08 - international - Test - male - 1263462 - England vs Australia
2021-11-10 - international - T20 - male - 1273754 - England vs New Zealand
2021-11-06 - international - T20 - male - 1273750 - South Africa vs England
2021-11-01 - international - T20 - male - 1273740 - England vs Sri Lanka
2021-10-30 - international - T20 - male - 1273737 - Australia vs England
2021-10-27 - international - T20 - male - 1273731 - Bangladesh vs England
2021-10-23 - international - T20 - male - 1273725 - West Indies vs England
2021-09-02 - international - Test - male - 1239546 - India vs England
2021-08-25 - international - Test - male - 1239545 - India vs England
2021-08-12 - international - Test - male - 1239544 - India vs England
2021-08-04 - international - Test - male - 1239543 - England vs India
2021-07-20 - international - T20 - male - 1239542 - Pakistan vs England
2021-07-18 - international - T20 - male - 1239541 - England vs Pakistan
2021-07-16 - international - T20 - male - 1239540 - Pakistan vs England
2021-07-13 - international - ODI - male - 1239539 - Pakistan vs England
2021-07-10 - international - ODI - male - 1239538 - England vs Pakistan
2021-07-08 - international - ODI - male - 1239537 - Pakistan vs England
2021-07-04 - international - ODI - male - 1239536 - Sri Lanka vs England
2021-07-01 - international - ODI - male - 1239535 - Sri Lanka vs England
2021-06-29 - international - ODI - male - 1239534 - Sri Lanka vs England
2021-06-26 - international - T20 - male - 1249208 - England vs Sri Lanka
2021-06-24 - international - T20 - male - 1249207 - Sri Lanka vs England
2021-06-23 - international - T20 - male - 1249206 - Sri Lanka vs England
2021-06-10 - international - Test - male - 1249211 - England vs New Zealand
2021-06-02 - international - Test - male - 1249210 - New Zealand vs England
2021-03-28 - international - ODI - male - 1243395 - India vs England
2021-03-26 - international - ODI - male - 1243394 - India vs England
2021-03-23 - international - ODI - male - 1243393 - India vs England
2021-03-20 - international - T20 - male - 1243392 - India vs England
2021-03-18 - international - T20 - male - 1243391 - India vs England
2021-03-16 - international - T20 - male - 1243390 - India vs England
2021-03-14 - international - T20 - male - 1243389 - England vs India
2021-03-12 - international - T20 - male - 1243388 - India vs England
2021-03-04 - international - Test - male - 1243387 - England vs India
2021-02-24 - international - Test - male - 1243386 - England vs India
2021-02-13 - international - Test - male - 1243385 - India vs England
2021-02-05 - international - Test - male - 1243384 - England vs India
2021-01-22 - international - Test - male - 1243016 - Sri Lanka vs England
2021-01-14 - international - Test - male - 1243015 - Sri Lanka vs England
2020-12-01 - international - T20 - male - 1237124 - South Africa vs England
2020-11-29 - international - T20 - male - 1237123 - South Africa vs England
2020-11-27 - international - T20 - male - 1237122 - South Africa vs England
2020-09-16 - international - ODI - male - 1198240 - England vs Australia
2020-09-13 - international - ODI - male - 1198239 - England vs Australia
2020-09-11 - international - ODI - male - 1198238 - Australia vs England
2020-09-08 - international - T20 - male - 1198237 - England vs Australia
2020-09-06 - international - T20 - male - 1198236 - Australia vs England
2020-09-04 - international - T20 - male - 1198235 - England vs Australia
2020-09-01 - international - T20 - male - 1198246 - Pakistan vs England
2020-08-30 - international - T20 - male - 1198245 - Pakistan vs England
2020-08-28 - international - T20 - male - 1198244 - England vs Pakistan
2020-08-21 - international - Test - male - 1198243 - England vs Pakistan
2020-08-13 - international - Test - male - 1198242 - Pakistan vs England
2020-08-05 - international - Test - male - 1198241 - Pakistan vs England
2020-08-04 - international - ODI - male - 1198249 - England vs Ireland
2020-08-01 - international - ODI - male - 1198248 - Ireland vs England
2020-07-30 - international - ODI - male - 1198247 - Ireland vs England
2020-07-24 - international - Test - male - 1225249 - England vs West Indies
2020-07-16 - international - Test - male - 1225248 - England vs West Indies
2020-07-08 - international - Test - male - 1225247 - England vs West Indies
2020-02-16 - international - T20 - male - 1185315 - South Africa vs England
2020-02-14 - international - T20 - male - 1185314 - South Africa vs England
2020-02-12 - international - T20 - male - 1185313 - South Africa vs England
2020-02-09 - international - ODI - male - 1185312 - South Africa vs England
2020-02-07 - international - ODI - male - 1185311 - South Africa vs England
2020-02-04 - international - ODI - male - 1185310 - South Africa vs England
2020-01-24 - international - Test - male - 1185307 - South Africa vs England
2020-01-16 - international - Test - male - 1185306 - South Africa vs England
2020-01-03 - international - Test - male - 1185305 - South Africa vs England
2019-12-26 - international - Test - male - 1185304 - South Africa vs England
2019-11-29 - international - Test - male - 1187672 - New Zealand vs England
2019-11-21 - international - Test - male - 1187671 - New Zealand vs England
2019-11-10 - international - T20 - male - 1187669 - New Zealand vs England
2019-11-08 - international - T20 - male - 1187668 - New Zealand vs England
2019-11-05 - international - T20 - male - 1187667 - New Zealand vs England
2019-11-03 - international - T20 - male - 1187666 - New Zealand vs England
2019-11-01 - international - T20 - male - 1187665 - New Zealand vs England
2019-09-12 - international - Test - male - 1152850 - England vs Australia
2019-09-04 - international - Test - male - 1152849 - England vs Australia
2019-08-22 - international - Test - male - 1152848 - England vs Australia
2019-08-14 - international - Test - male - 1152847 - England vs Australia
2019-08-01 - international - Test - male - 1152846 - England vs Australia
2019-07-24 - international - Test - male - 1152839 - England vs Ireland
2019-07-14 - international - ODI - male - 1144530 - England vs New Zealand
2019-07-11 - international - ODI - male - 1144529 - Australia vs England
2019-07-03 - international - ODI - male - 1144523 - England vs New Zealand
2019-06-30 - international - ODI - male - 1144520 - England vs India
2019-06-25 - international - ODI - male - 1144514 - England vs Australia
2019-06-21 - international - ODI - male - 1144509 - England vs Sri Lanka
2019-06-14 - international - ODI - male - 1144501 - England vs West Indies
2019-06-08 - international - ODI - male - 1144494 - England vs Bangladesh
2019-06-03 - international - ODI - male - 1144488 - England vs Pakistan
2019-05-30 - international - ODI - male - 1144483 - England vs South Africa
2019-05-19 - international - ODI - male - 1152845 - England vs Pakistan
2019-05-17 - international - ODI - male - 1152844 - England vs Pakistan
2019-05-14 - international - ODI - male - 1152843 - England vs Pakistan
2019-05-11 - international - ODI - male - 1152842 - England vs Pakistan
2019-05-08 - international - ODI - male - 1152841 - England vs Pakistan
2019-05-05 - international - T20 - male - 1152840 - England vs Pakistan
2019-05-03 - international - ODI - male - 1161014 - Ireland vs England
2019-03-10 - international - T20 - male - 1158073 - West Indies vs England
2019-03-08 - international - T20 - male - 1158072 - West Indies vs England
2019-03-05 - international - T20 - male - 1158071 - West Indies vs England
2019-03-02 - international - ODI - male - 1158070 - West Indies vs England
2019-02-27 - international - ODI - male - 1158069 - West Indies vs England
2019-02-22 - international - ODI - male - 1158067 - West Indies vs England
2019-02-20 - international - ODI - male - 1158066 - West Indies vs England
2019-02-09 - international - Test - male - 1158064 - West Indies vs England
2019-01-31 - international - Test - male - 1158063 - West Indies vs England
2019-01-23 - international - Test - male - 1158062 - West Indies vs England
2018-11-23 - international - Test - male - 1140387 - England vs Sri Lanka
2018-11-14 - international - Test - male - 1140386 - England vs Sri Lanka
2018-11-06 - international - Test - male - 1140385 - England vs Sri Lanka
2018-10-27 - international - T20 - male - 1140384 - England vs Sri Lanka
2018-10-23 - international - ODI - male - 1140383 - Sri Lanka vs England
2018-10-20 - international - ODI - male - 1140382 - Sri Lanka vs England
2018-10-17 - international - ODI - male - 1140381 - Sri Lanka vs England
2018-10-13 - international - ODI - male - 1140380 - England vs Sri Lanka
2018-10-10 - international - ODI - male - 1140379 - England vs Sri Lanka
2018-09-07 - international - Test - male - 1119553 - England vs India
2018-08-30 - international - Test - male - 1119552 - England vs India
2018-08-18 - international - Test - male - 1119551 - India vs England
2018-08-09 - international - Test - male - 1119550 - India vs England
2018-08-01 - international - Test - male - 1119549 - England vs India
2018-07-17 - international - ODI - male - 1119548 - India vs England
2018-07-14 - international - ODI - male - 1119547 - England vs India
2018-07-12 - international - ODI - male - 1119546 - England vs India
2018-07-08 - international - T20 - male - 1119545 - England vs India
2018-07-06 - international - T20 - male - 1119544 - India vs England
2018-07-03 - international - T20 - male - 1119543 - England vs India
2018-06-27 - international - T20 - male - 1119542 - England vs Australia
2018-06-24 - international - ODI - male - 1119541 - Australia vs England
2018-06-21 - international - ODI - male - 1119540 - Australia vs England
2018-06-19 - international - ODI - male - 1119539 - England vs Australia
2018-06-16 - international - ODI - male - 1119538 - England vs Australia
2018-06-13 - international - ODI - male - 1119537 - Australia vs England
2018-06-01 - international - Test - male - 1119536 - Pakistan vs England
2018-05-24 - international - Test - male - 1119535 - England vs Pakistan
2018-03-30 - international - Test - male - 1115781 - England vs New Zealand
2018-03-22 - international - Test - male - 1115780 - England vs New Zealand
2018-03-10 - international - ODI - male - 1115779 - New Zealand vs England
2018-03-07 - international - ODI - male - 1115778 - England vs New Zealand
2018-03-03 - international - ODI - male - 1115777 - England vs New Zealand
2018-02-28 - international - ODI - male - 1115776 - New Zealand vs England
2018-02-25 - international - ODI - male - 1115775 - England vs New Zealand
2018-02-18 - international - T20 - male - 1072321 - England vs New Zealand
2018-02-13 - international - T20 - male - 1072319 - New Zealand vs England
2018-02-10 - international - T20 - male - 1072318 - England vs Australia
2018-02-07 - international - T20 - male - 1072317 - England vs Australia
2018-01-28 - international - ODI - male - 1072314 - England vs Australia
2018-01-26 - international - ODI - male - 1072313 - England vs Australia
2018-01-21 - international - ODI - male - 1072312 - England vs Australia
2018-01-19 - international - ODI - male - 1072311 - Australia vs England
2018-01-14 - international - ODI - male - 1072310 - Australia vs England
2018-01-04 - international - Test - male - 1072309 - England vs Australia
2017-12-26 - international - Test - male - 1072308 - Australia vs England
2017-12-14 - international - Test - male - 1072307 - England vs Australia
2017-12-02 - international - Test - male - 1072306 - Australia vs England
2017-11-23 - international - Test - male - 1072305 - England vs Australia
2017-09-29 - international - ODI - male - 1031675 - West Indies vs England
2017-09-27 - international - ODI - male - 1031673 - West Indies vs England
2017-09-24 - international - ODI - male - 1031671 - England vs West Indies
2017-09-21 - international - ODI - male - 1031669 - England vs West Indies
2017-09-19 - international - ODI - male - 1031667 - West Indies vs England
2017-09-16 - international - T20 - male - 1031665 - West Indies vs England
2017-09-07 - international - Test - male - 1031663 - West Indies vs England
2017-08-25 - international - Test - male - 1031661 - England vs West Indies
2017-08-17 - international - Test - male - 1031659 - England vs West Indies
2017-08-04 - international - Test - male - 1031443 - England vs South Africa
2017-07-27 - international - Test - male - 1031441 - England vs South Africa
2017-07-14 - international - Test - male - 1031439 - South Africa vs England
2017-07-06 - international - Test - male - 1031437 - England vs South Africa
2017-06-25 - international - T20 - male - 1031435 - England vs South Africa
2017-06-23 - international - T20 - male - 1031433 - England vs South Africa
2017-06-21 - international - T20 - male - 1031431 - England vs South Africa
2017-06-14 - international - ODI - male - 1022371 - England vs Pakistan
2017-06-10 - international - ODI - male - 1022365 - England vs Australia
2017-06-06 - international - ODI - male - 1022357 - England vs New Zealand
2017-06-01 - international - ODI - male - 1022347 - England vs Bangladesh
2017-05-29 - international - ODI - male - 1031429 - England vs South Africa
2017-05-27 - international - ODI - male - 1031427 - England vs South Africa
2017-05-24 - international - ODI - male - 1031425 - England vs South Africa
2017-05-07 - international - ODI - male - 1029003 - England vs Ireland
2017-05-05 - international - ODI - male - 1029001 - England vs Ireland
2017-03-09 - international - ODI - male - 1027319 - West Indies vs England
2017-03-05 - international - ODI - male - 1027317 - West Indies vs England
2017-03-03 - international - ODI - male - 1027315 - West Indies vs England
2017-02-01 - international - T20 - male - 1034829 - India vs England
2017-01-29 - international - T20 - male - 1034827 - India vs England
2017-01-26 - international - T20 - male - 1034825 - India vs England
2017-01-22 - international - ODI - male - 1034823 - India vs England
2017-01-19 - international - ODI - male - 1034821 - India vs England
2017-01-15 - international - ODI - male - 1034819 - India vs England
2016-12-16 - international - Test - male - 1034817 - India vs England
2016-12-08 - international - Test - male - 1034815 - India vs England
2016-11-26 - international - Test - male - 1034813 - India vs England
2016-11-17 - international - Test - male - 1034811 - India vs England
2016-11-09 - international - Test - male - 1034809 - India vs England
2016-10-28 - international - Test - male - 1029827 - Bangladesh vs England
2016-10-20 - international - Test - male - 1029825 - Bangladesh vs England
2016-10-12 - international - ODI - male - 1029823 - Bangladesh vs England
2016-10-09 - international - ODI - male - 1029821 - Bangladesh vs England
2016-10-07 - international - ODI - male - 1029819 - Bangladesh vs England
2016-09-07 - international - T20 - male - 913663 - England vs Pakistan
2016-09-04 - international - ODI - male - 913661 - England vs Pakistan
2016-09-01 - international - ODI - male - 913659 - England vs Pakistan
2016-08-30 - international - ODI - male - 913657 - England vs Pakistan
2016-08-27 - international - ODI - male - 913655 - England vs Pakistan
2016-08-24 - international - ODI - male - 913653 - England vs Pakistan
2016-08-11 - international - Test - male - 913647 - England vs Pakistan
2016-08-03 - international - Test - male - 913645 - England vs Pakistan
2016-07-22 - international - Test - male - 913643 - England vs Pakistan
2016-07-14 - international - Test - male - 913641 - England vs Pakistan
2016-07-05 - international - T20 - male - 913633 - England vs Sri Lanka
2016-07-02 - international - ODI - male - 913631 - England vs Sri Lanka
2016-06-29 - international - ODI - male - 913629 - England vs Sri Lanka
2016-06-26 - international - ODI - male - 913627 - England vs Sri Lanka
2016-06-24 - international - ODI - male - 913625 - England vs Sri Lanka
2016-06-21 - international - ODI - male - 913623 - England vs Sri Lanka
2016-06-09 - international - Test - male - 913617 - England vs Sri Lanka
2016-05-27 - international - Test - male - 913615 - England vs Sri Lanka
2016-05-19 - international - Test - male - 913613 - England vs Sri Lanka
2016-04-03 - international - T20 - male - 951373 - England vs West Indies
2016-03-30 - international - T20 - male - 951369 - England vs New Zealand
2016-03-26 - international - T20 - male - 951361 - England vs Sri Lanka
2016-03-18 - international - T20 - male - 951339 - England vs South Africa
2016-03-16 - international - T20 - male - 951331 - England vs West Indies
2016-02-21 - international - T20 - male - 800481 - South Africa vs England
2016-02-19 - international - T20 - male - 800479 - South Africa vs England
2016-02-14 - international - ODI - male - 800477 - South Africa vs England
2016-02-12 - international - ODI - male - 800475 - South Africa vs England
2016-02-09 - international - ODI - male - 800473 - South Africa vs England
2016-02-06 - international - ODI - male - 800471 - South Africa vs England
2016-02-03 - international - ODI - male - 800469 - South Africa vs England
2016-01-22 - international - Test - male - 800467 - South Africa vs England
2016-01-14 - international - Test - male - 800465 - South Africa vs England
2016-01-02 - international - Test - male - 800463 - South Africa vs England
2015-12-26 - international - Test - male - 800461 - South Africa vs England
2015-11-30 - international - T20 - male - 902653 - England vs Pakistan
2015-11-27 - international - T20 - male - 902651 - England vs Pakistan
2015-11-26 - international - T20 - male - 902649 - England vs Pakistan
2015-11-20 - international - ODI - male - 902647 - England vs Pakistan
2015-11-17 - international - ODI - male - 902645 - England vs Pakistan
2015-11-13 - international - ODI - male - 902643 - England vs Pakistan
2015-11-11 - international - ODI - male - 902641 - England vs Pakistan
2015-11-01 - international - Test - male - 902639 - England vs Pakistan
2015-10-22 - international - Test - male - 902637 - England vs Pakistan
2015-10-13 - international - Test - male - 902635 - England vs Pakistan
2015-09-13 - international - ODI - male - 743985 - England vs Australia
2015-09-11 - international - ODI - male - 743983 - England vs Australia
2015-09-08 - international - ODI - male - 743981 - England vs Australia
2015-09-05 - international - ODI - male - 743979 - England vs Australia
2015-09-03 - international - ODI - male - 743977 - England vs Australia
2015-08-31 - international - T20 - male - 743975 - England vs Australia
2015-08-20 - international - Test - male - 743971 - England vs Australia
2015-08-06 - international - Test - male - 743969 - England vs Australia
2015-07-29 - international - Test - male - 743967 - England vs Australia
2015-07-16 - international - Test - male - 743965 - England vs Australia
2015-07-08 - international - Test - male - 743963 - England vs Australia
2015-06-23 - international - T20 - male - 743953 - England vs New Zealand
2015-06-20 - international - ODI - male - 743951 - England vs New Zealand
2015-06-17 - international - ODI - male - 743949 - England vs New Zealand
2015-06-14 - international - ODI - male - 743947 - England vs New Zealand
2015-06-12 - international - ODI - male - 743945 - England vs New Zealand
2015-06-09 - international - ODI - male - 743943 - England vs New Zealand
2015-05-29 - international - Test - male - 743941 - England vs New Zealand
2015-05-21 - international - Test - male - 743939 - England vs New Zealand
2015-05-08 - international - ODI - male - 760889 - Ireland vs England
2015-05-01 - international - Test - male - 766933 - West Indies vs England
2015-04-21 - international - Test - male - 766931 - West Indies vs England
2015-04-13 - international - Test - male - 766929 - West Indies vs England
2015-03-09 - international - ODI - male - 656463 - Bangladesh vs England
2015-03-01 - international - ODI - male - 656441 - England vs Sri Lanka
2015-02-23 - international - ODI - male - 656425 - England vs Scotland
2015-02-20 - international - ODI - male - 656415 - New Zealand vs England
2015-02-14 - international - ODI - male - 656401 - Australia vs England
2015-02-01 - international - ODI - male - 754761 - Australia vs England
2015-01-30 - international - ODI - male - 754759 - England vs India
2015-01-23 - international - ODI - male - 754755 - Australia vs England
2015-01-20 - international - ODI - male - 754753 - England vs India
2015-01-16 - international - ODI - male - 754751 - Australia vs England
2014-12-16 - international - ODI - male - 750675 - Sri Lanka vs England
2014-12-13 - international - ODI - male - 750673 - Sri Lanka vs England
2014-12-10 - international - ODI - male - 750671 - Sri Lanka vs England
2014-12-07 - international - ODI - male - 750669 - Sri Lanka vs England
2014-12-03 - international - ODI - male - 750667 - Sri Lanka vs England
2014-11-29 - international - ODI - male - 750665 - Sri Lanka vs England
2014-11-26 - international - ODI - male - 750663 - Sri Lanka vs England
2014-09-07 - international - T20 - male - 667731 - England vs India
2014-09-05 - international - ODI - male - 667729 - England vs India
2014-09-02 - international - ODI - male - 667727 - England vs India
2014-08-30 - international - ODI - male - 667725 - England vs India
2014-08-27 - international - ODI - male - 667723 - England vs India
2014-08-15 - international - Test - male - 667719 - England vs India
2014-08-07 - international - Test - male - 667717 - England vs India
2014-07-27 - international - Test - male - 667715 - England vs India
2014-07-17 - international - Test - male - 667713 - England vs India
2014-07-09 - international - Test - male - 667711 - England vs India
2014-06-20 - international - Test - male - 667901 - England vs Sri Lanka
2014-06-12 - international - Test - male - 667899 - England vs Sri Lanka
2014-06-03 - international - ODI - male - 667897 - England vs Sri Lanka
2014-05-31 - international - ODI - male - 667895 - England vs Sri Lanka
2014-05-28 - international - ODI - male - 667893 - England vs Sri Lanka
2014-05-25 - international - ODI - male - 667891 - England vs Sri Lanka
2014-05-22 - international - ODI - male - 667889 - England vs Sri Lanka
2014-05-20 - international - T20 - male - 667887 - England vs Sri Lanka
2014-05-09 - international - ODI - male - 684679 - Scotland vs England
2014-03-31 - international - T20 - male - 682953 - England vs Netherlands
2014-03-29 - international - T20 - male - 682947 - England vs South Africa
2014-03-27 - international - T20 - male - 682939 - England vs Sri Lanka
2014-03-22 - international - T20 - male - 682925 - England vs New Zealand
2014-03-13 - international - T20 - male - 636538 - West Indies vs England
2014-03-11 - international - T20 - male - 636537 - West Indies vs England
2014-03-09 - international - T20 - male - 636536 - West Indies vs England
2014-03-05 - international - ODI - male - 636535 - West Indies vs England
2014-03-02 - international - ODI - male - 636534 - West Indies vs England
2014-02-28 - international - ODI - male - 636533 - West Indies vs England
2014-02-02 - international - T20 - male - 636166 - Australia vs England
2014-01-31 - international - T20 - male - 636165 - Australia vs England
2014-01-29 - international - T20 - male - 636164 - Australia vs England
2014-01-26 - international - ODI - male - 636163 - Australia vs England
2014-01-24 - international - ODI - male - 636162 - Australia vs England
2014-01-19 - international - ODI - male - 636161 - Australia vs England
2014-01-17 - international - ODI - male - 636160 - Australia vs England
2014-01-12 - international - ODI - male - 636159 - Australia vs England
2014-01-03 - international - Test - male - 592401 - Australia vs England
2013-12-26 - international - Test - male - 592400 - Australia vs England
2013-12-13 - international - Test - male - 592399 - Australia vs England
2013-12-05 - international - Test - male - 592398 - Australia vs England
2013-11-21 - international - Test - male - 592397 - Australia vs England
2013-09-16 - international - ODI - male - 566945 - England vs Australia
2013-09-14 - international - ODI - male - 566944 - England vs Australia
2013-09-11 - international - ODI - male - 566943 - England vs Australia
2013-09-08 - international - ODI - male - 566942 - England vs Australia
2013-09-03 - international - ODI - male - 566940 - Ireland vs England
2013-08-31 - international - T20 - male - 566938 - England vs Australia
2013-08-29 - international - T20 - male - 566937 - England vs Australia
2013-08-21 - international - Test - male - 566936 - England vs Australia
2013-08-09 - international - Test - male - 566935 - England vs Australia
2013-08-01 - international - Test - male - 566934 - England vs Australia
2013-07-18 - international - Test - male - 566933 - England vs Australia
2013-07-10 - international - Test - male - 566932 - England vs Australia
2013-06-27 - international - T20 - male - 566927 - England vs New Zealand
2013-06-25 - international - T20 - male - 566926 - England vs New Zealand
2013-06-23 - international - ODI - male - 566948 - England vs India
2013-06-19 - international - ODI - male - 566946 - England vs South Africa
2013-06-16 - international - ODI - male - 578624 - England vs New Zealand
2013-06-13 - international - ODI - male - 578621 - England vs Sri Lanka
2013-06-08 - international - ODI - male - 578616 - England vs Australia
2013-06-05 - international - ODI - male - 566925 - England vs New Zealand
2013-06-02 - international - ODI - male - 566924 - England vs New Zealand
2013-05-31 - international - ODI - male - 566923 - England vs New Zealand
2013-05-24 - international - Test - male - 566922 - England vs New Zealand
2013-05-16 - international - Test - male - 566921 - England vs New Zealand
2013-03-22 - international - Test - male - 569245 - New Zealand vs England
2013-03-14 - international - Test - male - 569244 - New Zealand vs England
2013-03-06 - international - Test - male - 569243 - New Zealand vs England
2013-02-23 - international - ODI - male - 569242 - New Zealand vs England
2013-02-20 - international - ODI - male - 569241 - New Zealand vs England
2013-02-17 - international - ODI - male - 569240 - New Zealand vs England
2013-02-15 - international - T20 - male - 569239 - New Zealand vs England
2013-02-12 - international - T20 - male - 569238 - New Zealand vs England
2013-02-09 - international - T20 - male - 569237 - New Zealand vs England
2013-01-27 - international - ODI - male - 565816 - India vs England
2013-01-23 - international - ODI - male - 565815 - India vs England
2013-01-19 - international - ODI - male - 565814 - India vs England
2013-01-15 - international - ODI - male - 565813 - India vs England
2013-01-11 - international - ODI - male - 565812 - India vs England
2012-12-22 - international - T20 - male - 565811 - India vs England
2012-12-20 - international - T20 - male - 565810 - India vs England
2012-12-13 - international - Test - male - 565809 - India vs England
2012-12-05 - international - Test - male - 565808 - India vs England
2012-11-23 - international - Test - male - 565807 - India vs England
2012-11-15 - international - Test - male - 565806 - India vs England
2012-10-01 - international - T20 - male - 533293 - Sri Lanka vs England
2012-09-29 - international - T20 - male - 533288 - England vs New Zealand
2012-09-27 - international - T20 - male - 533285 - England vs West Indies
2012-09-23 - international - T20 - male - 533281 - England vs India
2012-09-12 - international - T20 - male - 534235 - England vs South Africa
2012-09-10 - international - T20 - male - 534234 - England vs South Africa
2012-09-08 - international - T20 - male - 534233 - England vs South Africa
2012-09-05 - international - ODI - male - 534232 - England vs South Africa
2012-09-02 - international - ODI - male - 534231 - England vs South Africa
2012-08-31 - international - ODI - male - 534230 - England vs South Africa
2012-08-28 - international - ODI - male - 534229 - England vs South Africa
2012-08-24 - international - ODI - male - 534228 - England vs South Africa
2012-08-16 - international - Test - male - 534227 - England vs South Africa
2012-08-02 - international - Test - male - 534226 - England vs South Africa
2012-07-19 - international - Test - male - 534225 - England vs South Africa
2012-07-10 - international - ODI - male - 534219 - England vs Australia
2012-07-07 - international - ODI - male - 534218 - England vs Australia
2012-07-01 - international - ODI - male - 534216 - England vs Australia
2012-06-29 - international - ODI - male - 534215 - England vs Australia
2012-06-24 - international - T20 - male - 534208 - England vs West Indies
2012-06-19 - international - ODI - male - 534210 - England vs West Indies
2012-06-16 - international - ODI - male - 534209 - England vs West Indies
2012-06-07 - international - Test - male - 534207 - England vs West Indies
2012-05-25 - international - Test - male - 534206 - England vs West Indies
2012-05-17 - international - Test - male - 534205 - England vs West Indies
2012-04-03 - international - Test - male - 521226 - Sri Lanka vs England
2012-03-26 - international - Test - male - 521225 - Sri Lanka vs England
2012-02-27 - international - T20 - male - 531637 - England vs Pakistan
2012-02-25 - international - T20 - male - 531636 - England vs Pakistan
2012-02-23 - international - T20 - male - 531635 - England vs Pakistan
2012-02-21 - international - ODI - male - 531634 - England vs Pakistan
2012-02-18 - international - ODI - male - 531633 - England vs Pakistan
2012-02-15 - international - ODI - male - 531632 - England vs Pakistan
2012-02-13 - international - ODI - male - 531631 - England vs Pakistan
2012-02-03 - international - Test - male - 531630 - England vs Pakistan
2012-01-25 - international - Test - male - 531629 - England vs Pakistan
2012-01-17 - international - Test - male - 531628 - England vs Pakistan
2011-10-29 - international - T20 - male - 521217 - India vs England
2011-10-25 - international - ODI - male - 521222 - India vs England
2011-10-23 - international - ODI - male - 521221 - India vs England
2011-10-20 - international - ODI - male - 521220 - India vs England
2011-10-17 - international - ODI - male - 521219 - India vs England
2011-10-14 - international - ODI - male - 521218 - India vs England
2011-09-25 - international - T20 - male - 525817 - England vs West Indies
2011-09-23 - international - T20 - male - 525816 - England vs West Indies
2011-09-16 - international - ODI - male - 474481 - England vs India
2011-09-11 - international - ODI - male - 474480 - England vs India
2011-09-09 - international - ODI - male - 474479 - England vs India
2011-09-06 - international - ODI - male - 474478 - England vs India
2011-09-03 - international - ODI - male - 474477 - England vs India
2011-08-31 - international - T20 - male - 474476 - England vs India
2011-08-25 - international - ODI - male - 483126 - Ireland vs England
2011-08-18 - international - Test - male - 474475 - England vs India
2011-08-10 - international - Test - male - 474474 - England vs India
2011-07-29 - international - Test - male - 474473 - England vs India
2011-07-21 - international - Test - male - 474472 - England vs India
2011-07-09 - international - ODI - male - 474471 - England vs Sri Lanka
2011-07-06 - international - ODI - male - 474470 - England vs Sri Lanka
2011-07-03 - international - ODI - male - 474469 - England vs Sri Lanka
2011-07-01 - international - ODI - male - 474468 - England vs Sri Lanka
2011-06-28 - international - ODI - male - 474467 - England vs Sri Lanka
2011-06-25 - international - T20 - male - 474466 - England vs Sri Lanka
2011-06-16 - international - Test - male - 474465 - England vs Sri Lanka
2011-06-03 - international - Test - male - 474464 - England vs Sri Lanka
2011-05-26 - international - Test - male - 474463 - England vs Sri Lanka
2011-03-26 - international - ODI - male - 433603 - Sri Lanka vs England
2011-03-17 - international - ODI - male - 433593 - England vs West Indies
2011-03-11 - international - ODI - male - 433585 - Bangladesh vs England
2011-03-06 - international - ODI - male - 433579 - England vs South Africa
2011-03-02 - international - ODI - male - 433572 - England vs Ireland
2011-02-27 - international - ODI - male - 433568 - India vs England
2011-02-22 - international - ODI - male - 433562 - England vs Netherlands
2011-02-06 - international - ODI - male - 446968 - Australia vs England
2011-02-02 - international - ODI - male - 446967 - Australia vs England
2011-01-30 - international - ODI - male - 446966 - Australia vs England
2011-01-26 - international - ODI - male - 446965 - Australia vs England
2011-01-23 - international - ODI - male - 446964 - Australia vs England
2011-01-21 - international - ODI - male - 446963 - Australia vs England
2011-01-16 - international - ODI - male - 446962 - Australia vs England
2011-01-14 - international - T20 - male - 446961 - Australia vs England
2011-01-12 - international - T20 - male - 446960 - Australia vs England
2011-01-03 - international - Test - male - 428753 - Australia vs England
2010-12-26 - international - Test - male - 428752 - Australia vs England
2010-12-16 - international - Test - male - 428751 - Australia vs England
2010-12-03 - international - Test - male - 428750 - Australia vs England
2010-11-25 - international - Test - male - 428749 - Australia vs England
2010-09-22 - international - ODI - male - 426432 - England vs Pakistan
2010-09-20 - international - ODI - male - 426431 - England vs Pakistan
2010-09-17 - international - ODI - male - 426430 - England vs Pakistan
2010-09-12 - international - ODI - male - 426429 - England vs Pakistan
2010-09-10 - international - ODI - male - 426428 - England vs Pakistan
2010-09-07 - international - T20 - male - 426418 - England vs Pakistan
2010-09-05 - international - T20 - male - 426417 - England vs Pakistan
2010-08-26 - international - Test - male - 426416 - England vs Pakistan
2010-08-18 - international - Test - male - 426415 - England vs Pakistan
2010-08-06 - international - Test - male - 426414 - England vs Pakistan
2010-07-29 - international - Test - male - 426413 - England vs Pakistan
2010-07-12 - international - ODI - male - 426405 - England vs Bangladesh
2010-07-10 - international - ODI - male - 426404 - England vs Bangladesh
2010-07-08 - international - ODI - male - 426403 - England vs Bangladesh
2010-07-03 - international - ODI - male - 426391 - England vs Australia
2010-06-30 - international - ODI - male - 426390 - England vs Australia
2010-06-27 - international - ODI - male - 426389 - England vs Australia
2010-06-24 - international - ODI - male - 426388 - England vs Australia
2010-06-22 - international - ODI - male - 426387 - England vs Australia
2010-06-04 - international - Test - male - 426402 - England vs Bangladesh
2010-05-27 - international - Test - male - 426401 - England vs Bangladesh
2010-05-16 - international - T20 - male - 412703 - Australia vs England
2010-05-13 - international - T20 - male - 412701 - England vs Sri Lanka
2010-05-10 - international - T20 - male - 412698 - England vs New Zealand
2010-05-08 - international - T20 - male - 412694 - England vs South Africa
2010-05-06 - international - T20 - male - 412689 - England vs Pakistan
2010-05-04 - international - T20 - male - 412681 - England vs Ireland
2010-05-03 - international - T20 - male - 412685 - West Indies vs England
2010-03-20 - international - Test - male - 426424 - Bangladesh vs England
2010-03-12 - international - Test - male - 426423 - Bangladesh vs England
2010-03-05 - international - ODI - male - 426422 - Bangladesh vs England
2010-03-02 - international - ODI - male - 426421 - Bangladesh vs England
2010-02-28 - international - ODI - male - 426420 - Bangladesh vs England
2010-02-20 - international - T20 - male - 440946 - England vs Pakistan
2010-02-19 - international - T20 - male - 440945 - England vs Pakistan
2010-01-14 - international - Test - male - 387573 - South Africa vs England
2010-01-03 - international - Test - male - 387572 - South Africa vs England
2009-12-26 - international - Test - male - 387571 - South Africa vs England
2009-12-16 - international - Test - male - 387570 - South Africa vs England
2009-11-29 - international - ODI - male - 387568 - South Africa vs England
2009-11-27 - international - ODI - male - 387567 - South Africa vs England
2009-11-22 - international - ODI - male - 387566 - South Africa vs England
2009-11-15 - international - T20 - male - 387564 - South Africa vs England
2009-11-13 - international - T20 - male - 387563 - South Africa vs England
2009-10-02 - international - ODI - male - 415285 - Australia vs England
2009-09-29 - international - ODI - male - 415282 - England vs New Zealand
2009-09-27 - international - ODI - male - 415280 - South Africa vs England
2009-09-25 - international - ODI - male - 415276 - England vs Sri Lanka
2009-09-20 - international - ODI - male - 350049 - England vs Australia
2009-09-17 - international - ODI - male - 350048 - England vs Australia
2009-09-15 - international - ODI - male - 350047 - England vs Australia
2009-09-12 - international - ODI - male - 350046 - England vs Australia
2009-09-09 - international - ODI - male - 350045 - England vs Australia
2009-09-06 - international - ODI - male - 350044 - England vs Australia
2009-09-04 - international - ODI - male - 350043 - England vs Australia
2009-08-30 - international - T20 - male - 350050 - England vs Australia
2009-08-27 - international - ODI - male - 383275 - Ireland vs England
2009-08-20 - international - Test - male - 345974 - England vs Australia
2009-08-07 - international - Test - male - 345973 - England vs Australia
2009-07-30 - international - Test - male - 345972 - England vs Australia
2009-07-16 - international - Test - male - 345971 - England vs Australia
2009-07-08 - international - Test - male - 345970 - England vs Australia
2009-06-15 - international - T20 - male - 356011 - England vs West Indies
2009-06-14 - international - T20 - male - 356010 - England vs India
2009-06-11 - international - T20 - male - 356004 - England vs South Africa
2009-06-07 - international - T20 - male - 355996 - England vs Pakistan
2009-06-05 - international - T20 - male - 355991 - England vs Netherlands
2009-05-26 - international - ODI - male - 380716 - England vs West Indies
2009-05-24 - international - ODI - male - 380715 - England vs West Indies
2009-05-14 - international - Test - male - 380713 - England vs West Indies
2009-05-06 - international - Test - male - 380712 - England vs West Indies
2009-04-03 - international - ODI - male - 352669 - West Indies vs England
2009-03-29 - international - ODI - male - 352668 - West Indies vs England
2009-03-27 - international - ODI - male - 352667 - West Indies vs England
2009-03-22 - international - ODI - male - 352666 - West Indies vs England
2009-03-20 - international - ODI - male - 352665 - West Indies vs England
2009-03-15 - international - T20 - male - 352674 - West Indies vs England
2009-03-06 - international - Test - male - 352664 - West Indies vs England
2009-02-26 - international - Test - male - 352663 - West Indies vs England
2009-02-15 - international - Test - male - 390680 - West Indies vs England
2009-02-13 - international - Test - male - 352662 - West Indies vs England
2009-02-04 - international - Test - male - 352661 - West Indies vs England
2008-12-19 - international - Test - male - 361051 - India vs England
2008-12-11 - international - Test - male - 361050 - India vs England
2008-11-26 - international - ODI - male - 361047 - India vs England
2008-11-23 - international - ODI - male - 361046 - India vs England
2008-11-20 - international - ODI - male - 361045 - India vs England
2008-11-17 - international - ODI - male - 361044 - India vs England
2008-11-14 - international - ODI - male - 361043 - India vs England
2008-09-03 - international - ODI - male - 296918 - England vs South Africa
2008-08-31 - international - ODI - male - 296917 - England vs South Africa
2008-08-29 - international - ODI - male - 296916 - England vs South Africa
2008-08-26 - international - ODI - male - 296915 - England vs South Africa
2008-08-22 - international - ODI - male - 296914 - England vs South Africa
2008-08-07 - international - Test - male - 296912 - England vs South Africa
2008-07-30 - international - Test - male - 296911 - England vs South Africa
2008-07-18 - international - Test - male - 296910 - England vs South Africa
2008-07-10 - international - Test - male - 296909 - England vs South Africa
2008-06-28 - international - ODI - male - 296908 - England vs New Zealand
2008-06-25 - international - ODI - male - 296907 - England vs New Zealand
2008-06-21 - international - ODI - male - 296906 - England vs New Zealand
2008-06-18 - international - ODI - male - 296905 - England vs New Zealand
2008-06-15 - international - ODI - male - 296904 - England vs New Zealand
2008-06-13 - international - T20 - male - 296903 - England vs New Zealand
2008-06-05 - international - Test - male - 296902 - England vs New Zealand
2008-05-23 - international - Test - male - 296901 - England vs New Zealand
2008-05-15 - international - Test - male - 296900 - England vs New Zealand
2008-03-22 - international - Test - male - 300444 - New Zealand vs England
2008-03-13 - international - Test - male - 300443 - New Zealand vs England
2008-03-05 - international - Test - male - 300442 - New Zealand vs England
2008-02-23 - international - ODI - male - 300441 - New Zealand vs England
2008-02-20 - international - ODI - male - 300440 - New Zealand vs England
2008-02-15 - international - ODI - male - 300439 - New Zealand vs England
2008-02-12 - international - ODI - male - 300438 - New Zealand vs England
2008-02-09 - international - ODI - male - 300437 - New Zealand vs England
2008-02-07 - international - T20 - male - 300436 - New Zealand vs England
2008-02-05 - international - T20 - male - 300435 - New Zealand vs England
2007-12-18 - international - Test - male - 291224 - Sri Lanka vs England
2007-12-09 - international - Test - male - 291223 - England vs Sri Lanka
2007-12-01 - international - Test - male - 291222 - Sri Lanka vs England
2007-10-13 - international - ODI - male - 291221 - Sri Lanka vs England
2007-10-10 - international - ODI - male - 291220 - Sri Lanka vs England
2007-10-04 - international - ODI - male - 291218 - Sri Lanka vs England
2007-10-01 - international - ODI - male - 291217 - Sri Lanka vs England
2007-09-19 - international - T20 - male - 287873 - England vs India
2007-09-18 - international - T20 - male - 287869 - England vs New Zealand
2007-09-16 - international - T20 - male - 287867 - South Africa vs England
2007-09-14 - international - T20 - male - 287861 - Australia vs England
2007-09-13 - international - T20 - male - 287858 - England vs Zimbabwe
2007-09-08 - international - ODI - male - 258477 - England vs India
2007-09-05 - international - ODI - male - 258476 - England vs India
2007-09-02 - international - ODI - male - 258475 - England vs India
2007-08-30 - international - ODI - male - 258474 - England vs India
2007-08-27 - international - ODI - male - 258473 - England vs India
2007-08-24 - international - ODI - male - 258472 - England vs India
2007-08-21 - international - ODI - male - 258471 - England vs India
2007-08-09 - international - Test - male - 258470 - India vs England
2007-07-27 - international - Test - male - 258469 - England vs India
2007-07-19 - international - Test - male - 258468 - England vs India
2007-07-07 - international - ODI - male - 258467 - England vs West Indies
2007-07-04 - international - ODI - male - 258466 - England vs West Indies
2007-07-01 - international - ODI - male - 258465 - England vs West Indies
2007-06-29 - international - T20 - male - 258464 - England vs West Indies
2007-06-28 - international - T20 - male - 258463 - England vs West Indies
2007-06-15 - international - Test - male - 258462 - West Indies vs England
2007-06-07 - international - Test - male - 258461 - England vs West Indies
2007-05-25 - international - Test - male - 258460 - England vs West Indies
2007-05-17 - international - Test - male - 258459 - England vs West Indies
2007-04-21 - international - ODI - male - 247504 - West Indies vs England
2007-04-17 - international - ODI - male - 247500 - England vs South Africa
2007-04-11 - international - ODI - male - 247494 - Bangladesh vs England
2007-04-08 - international - ODI - male - 247491 - Australia vs England
2007-04-04 - international - ODI - male - 247489 - England vs Sri Lanka
2007-03-30 - international - ODI - male - 247484 - England vs Ireland
2007-03-24 - international - ODI - male - 247479 - England vs Kenya
2007-03-18 - international - ODI - male - 247467 - Canada vs England
2007-03-16 - international - ODI - male - 247463 - England vs New Zealand
2007-02-11 - international - ODI - male - 249241 - Australia vs England
2007-02-09 - international - ODI - male - 249240 - Australia vs England
2007-02-06 - international - ODI - male - 249239 - England vs New Zealand
2007-02-02 - international - ODI - male - 249235 - Australia vs England
2007-01-30 - international - ODI - male - 249238 - England vs New Zealand
2007-01-26 - international - ODI - male - 249234 - Australia vs England
2007-01-23 - international - ODI - male - 249237 - England vs New Zealand
2007-01-19 - international - ODI - male - 249233 - Australia vs England
2007-01-16 - international - ODI - male - 249236 - England vs New Zealand
2007-01-12 - international - ODI - male - 249232 - Australia vs England
2007-01-09 - international - T20 - male - 249227 - Australia vs England
2007-01-02 - international - Test - male - 249226 - England vs Australia
2006-12-26 - international - Test - male - 249225 - England vs Australia
2006-12-14 - international - Test - male - 249224 - Australia vs England
2006-12-01 - international - Test - male - 249223 - England vs Australia
2006-11-23 - international - Test - male - 249222 - Australia vs England
2006-10-28 - international - ODI - male - 249755 - England vs West Indies
2006-10-21 - international - ODI - male - 249750 - Australia vs England
2006-10-15 - international - ODI - male - 249745 - India vs England
2006-09-10 - international - ODI - male - 225249 - England vs Pakistan
2006-09-08 - international - ODI - male - 225248 - England vs Pakistan
2006-09-05 - international - ODI - male - 225247 - England vs Pakistan
2006-09-02 - international - ODI - male - 225246 - England vs Pakistan
2006-08-30 - international - ODI - male - 225245 - England vs Pakistan
2006-08-28 - international - T20 - male - 225263 - England vs Pakistan
2006-08-17 - international - Test - male - 225258 - England vs Pakistan
2006-08-04 - international - Test - male - 225257 - England vs Pakistan
2006-07-27 - international - Test - male - 225256 - Pakistan vs England
2006-07-13 - international - Test - male - 225255 - England vs Pakistan
2006-07-01 - international - ODI - male - 225254 - England vs Sri Lanka
2006-06-28 - international - ODI - male - 225253 - England vs Sri Lanka
2006-06-24 - international - ODI - male - 225252 - England vs Sri Lanka
2006-06-20 - international - ODI - male - 225251 - England vs Sri Lanka
2006-06-17 - international - ODI - male - 225250 - England vs Sri Lanka
2006-06-15 - international - T20 - male - 225271 - England vs Sri Lanka
2006-06-13 - international - ODI - male - 225171 - Ireland vs England
2006-06-02 - international - Test - male - 225266 - Sri Lanka vs England
2006-05-25 - international - Test - male - 225265 - Sri Lanka vs England
2006-05-11 - international - Test - male - 225264 - England vs Sri Lanka
2006-04-15 - international - ODI - male - 238194 - India vs England
2006-04-12 - international - ODI - male - 238193 - India vs England
2006-04-03 - international - ODI - male - 238190 - India vs England
2006-03-31 - international - ODI - male - 238189 - India vs England
2006-03-28 - international - ODI - male - 238188 - India vs England
2006-03-09 - international - Test - male - 238186 - England vs India
2006-03-01 - international - Test - male - 239025 - England vs India
2005-12-21 - international - ODI - male - 226356 - England vs Pakistan
2005-12-15 - international - ODI - male - 226354 - Pakistan vs England
2005-12-10 - international - ODI - male - 226352 - England vs Pakistan
2005-11-20 - international - Test - male - 226350 - Pakistan vs England
2005-11-12 - international - Test - male - 225443 - Pakistan vs England
2005-09-08 - international - Test - male - 218383 - England vs Australia
2005-08-25 - international - Test - male - 216994 - England vs Australia
2005-08-04 - international - Test - male - 215010 - England vs Australia
2005-07-21 - international - Test - male - 213856 - Australia vs England
2005-07-12 - international - ODI - male - 213288 - England vs Australia
2005-07-02 - international - ODI - male - 212452 - Australia vs England
2005-06-28 - international - ODI - male - 212020 - Australia vs England
2005-06-26 - international - ODI - male - 211860 - Bangladesh vs England
2005-06-23 - international - ODI - male - 211678 - Australia vs England
2005-06-16 - international - ODI - male - 211244 - Bangladesh vs England
2005-06-13 - international - T20 - male - 211028 - England vs Australia
2005-06-03 - international - Test - male - 210366 - Bangladesh vs England
2005-02-13 - international - ODI - male - 64929 - England vs South Africa
2005-02-11 - international - ODI - male - 64928 - South Africa vs England
2005-02-09 - international - ODI - male - 64927 - South Africa vs England
2005-02-06 - international - ODI - male - 64926 - South Africa vs England
2005-02-04 - international - ODI - male - 64925 - England vs South Africa
2005-02-02 - international - ODI - male - 64924 - England vs South Africa
2005-01-30 - international - ODI - male - 64922 - South Africa vs England
2005-01-02 - international - Test - male - 64118 - South Africa vs England
2004-12-05 - international - ODI - male - 64913 - England vs Zimbabwe
2004-12-01 - international - ODI - male - 64911 - England vs Zimbabwe
2004-11-28 - international - ODI - male - 64910 - Zimbabwe vs England
2004-09-25 - international - ODI - male - 66210 - England vs West Indies
2004-09-21 - international - ODI - male - 66208 - Australia vs England
2004-09-17 - international - ODI - male - 66205 - England vs Sri Lanka
2004-09-10 - international - ODI - male - 66196 - England vs Zimbabwe
2004-09-05 - international - ODI - male - 65034 - India vs England
2004-09-03 - international - ODI - male - 65033 - England vs India
2004-09-01 - international - ODI - male - 65032 - India vs England
2004-08-19 - international - Test - male - 64096 - England vs West Indies
2004-07-29 - international - Test - male - 64094 - England vs West Indies
2004-07-06 - international - ODI - male - 66309 - England vs West Indies
2004-07-01 - international - ODI - male - 66306 - West Indies vs England
2004-06-29 - international - ODI - male - 66305 - England vs New Zealand
2004-06-27 - international - ODI - male - 66304 - England vs West Indies
2004-05-02 - international - ODI - male - 64894 - England vs West Indies
2004-04-24 - international - ODI - male - 64889 - West Indies vs England
2004-04-10 - international - Test - male - 64080 - West Indies vs England
2003-12-18 - international - Test - male - 64058 - England vs Sri Lanka
2003-11-18 - international - ODI - male - 64846 - England vs Sri Lanka
2003-11-12 - international - ODI - male - 64845 - Bangladesh vs England
2003-11-10 - international - ODI - male - 64844 - Bangladesh vs England
2003-11-07 - international - ODI - male - 64843 - Bangladesh vs England
2003-10-29 - international - Test - male - 64053 - England vs Bangladesh
2003-10-21 - international - Test - male - 64052 - Bangladesh vs England
2003-09-04 - international - Test - male - 64042 - South Africa vs England
2003-08-21 - international - Test - male - 64041 - South Africa vs England
2003-08-14 - international - Test - male - 64040 - England vs South Africa
2003-07-24 - international - Test - male - 64038 - South Africa vs England
2003-07-12 - international - ODI - male - 66302 - South Africa vs England
2003-07-06 - international - ODI - male - 66299 - Zimbabwe vs England
2003-07-03 - international - ODI - male - 66297 - England vs South Africa
2003-07-01 - international - ODI - male - 66296 - England vs Zimbabwe
2003-06-28 - international - ODI - male - 66294 - South Africa vs England
2003-06-26 - international - ODI - male - 66293 - England vs Zimbabwe
2003-06-22 - international - ODI - male - 65031 - Pakistan vs England
2003-06-20 - international - ODI - male - 65030 - Pakistan vs England
2003-06-17 - international - ODI - male - 65029 - England vs Pakistan
2003-03-02 - international - ODI - male - 65269 - England vs Australia
2003-02-26 - international - ODI - male - 65262 - India vs England
2003-02-22 - international - ODI - male - 65255 - England vs Pakistan
2003-02-19 - international - ODI - male - 65252 - England vs Namibia
2003-02-16 - international - ODI - male - 65246 - Netherlands vs England
2003-01-25 - international - ODI - male - 65642 - Australia vs England
2003-01-23 - international - ODI - male - 65641 - England vs Australia
2003-01-19 - international - ODI - male - 65639 - England vs Australia
2003-01-17 - international - ODI - male - 65638 - England vs Sri Lanka
2003-01-13 - international - ODI - male - 65636 - Sri Lanka vs England
2003-01-11 - international - ODI - male - 65635 - Australia vs England
2003-01-02 - international - Test - male - 64013 - England vs Australia
2002-12-26 - international - Test - male - 64012 - Australia vs England
2002-06-29 - international - ODI - male - 66284 - England vs India
2002-06-27 - international - ODI - male - 66283 - England vs Sri Lanka
2001-12-19 - international - Test - male - 63963 - England vs India
