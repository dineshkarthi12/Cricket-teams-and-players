This zip archive contains data files from Cricsheet in YAML format. This
archive contains 37 Jharkhand matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/jharkhand_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2021-11-09 - club - SMA - male - 1280282 - Jammu & Kashmir vs Jharkhand
2021-11-06 - club - SMA - male - 1280243 - Andhra vs Jharkhand
2021-11-05 - club - SMA - male - 1280224 - Himachal vs Jharkhand
2021-01-18 - club - SMA - male - 1244386 - Hyderabad (India) vs Jharkhand
2021-01-16 - club - SMA - male - 1244368 - Jharkhand vs Odisha
2021-01-14 - club - SMA - male - 1244347 - Jharkhand vs Assam
2021-01-10 - club - SMA - male - 1244310 - Tamil Nadu vs Jharkhand
2019-11-27 - club - SMA - male - 1205858 - Jharkhand vs Tamil Nadu
2019-11-24 - club - SMA - male - 1205851 - Jharkhand vs Mumbai
2019-11-22 - club - SMA - male - 1205846 - Karnataka vs Jharkhand
2019-11-15 - club - SMA - male - 1205812 - Delhi vs Jharkhand
2019-11-14 - club - SMA - male - 1205802 - Nagaland vs Jharkhand
2019-11-12 - club - SMA - male - 1205785 - Sikkim vs Jharkhand
2019-11-09 - club - SMA - male - 1205748 - Saurashtra vs Jharkhand
2019-03-10 - club - SMA - male - 1175035 - Jharkhand vs Bengal
2019-03-09 - club - SMA - male - 1175031 - Railways vs Jharkhand
2019-03-08 - club - SMA - male - 1175025 - Jharkhand vs Gujarat
2019-03-02 - club - SMA - male - 1157194 - Kerala vs Jharkhand
2019-02-28 - club - SMA - male - 1157176 - Andhra vs Jharkhand
2019-02-27 - club - SMA - male - 1157160 - Jharkhand vs Nagaland
2019-02-24 - club - SMA - male - 1157126 - Jharkhand vs Manipur
2019-02-22 - club - SMA - male - 1157109 - Jammu & Kashmir vs Jharkhand
2019-02-21 - club - SMA - male - 1157091 - Jharkhand vs Delhi
2018-01-24 - club - SMA - male - 1133414 - Karnataka vs Jharkhand
2018-01-22 - club - SMA - male - 1133405 - Jharkhand vs Rajasthan
2018-01-21 - club - SMA - male - 1133402 - Mumbai vs Jharkhand
2018-01-16 - club - SMA - male - 1130684 - Odisha vs Jharkhand
2018-01-14 - club - SMA - male - 1130725 - Assam vs Jharkhand
2018-01-12 - club - SMA - male - 1130711 - Jharkhand vs Bengal
2018-01-10 - club - SMA - male - 1130700 - Jharkhand vs Tripura
2016-01-18 - club - SMA - male - 955063 - Jharkhand vs Gujarat
2016-01-16 - club - SMA - male - 955055 - Jharkhand vs Delhi
2016-01-10 - club - SMA - male - 902235 - Kerala vs Jharkhand
2016-01-09 - club - SMA - male - 902215 - Saurashtra vs Jharkhand
2016-01-07 - club - SMA - male - 902189 - Jharkhand vs Jammu & Kashmir
2016-01-06 - club - SMA - male - 902167 - Jharkhand vs Punjab
2016-01-03 - club - SMA - male - 902121 - Tripura vs Jharkhand
