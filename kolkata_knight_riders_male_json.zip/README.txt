This zip archive contains data files from Cricsheet in JSON format. This
archive contains 278 Kolkata Knight Riders matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/kolkata_knight_riders_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-05-24 - club - IPL - male - 1529313 - Delhi Capitals vs Kolkata Knight Riders
2026-05-20 - club - IPL - male - 1529308 - Mumbai Indians vs Kolkata Knight Riders
2026-05-16 - club - IPL - male - 1529303 - Kolkata Knight Riders vs Gujarat Titans
2026-05-13 - club - IPL - male - 1529300 - Kolkata Knight Riders vs Royal Challengers Bengaluru
2026-05-08 - club - IPL - male - 1529294 - Delhi Capitals vs Kolkata Knight Riders
2026-05-03 - club - IPL - male - 1529288 - Sunrisers Hyderabad vs Kolkata Knight Riders
2026-04-26 - club - IPL - male - 1529281 - Kolkata Knight Riders vs Lucknow Super Giants
2026-04-19 - club - IPL - male - 1529271 - Rajasthan Royals vs Kolkata Knight Riders
2026-04-17 - club - IPL - male - 1529268 - Kolkata Knight Riders vs Gujarat Titans
2026-04-14 - club - IPL - male - 1529265 - Chennai Super Kings vs Kolkata Knight Riders
2026-04-09 - club - IPL - male - 1527688 - Kolkata Knight Riders vs Lucknow Super Giants
2026-04-06 - club - IPL - male - 1527685 - Kolkata Knight Riders vs Punjab Kings
2026-04-02 - club - IPL - male - 1527679 - Sunrisers Hyderabad vs Kolkata Knight Riders
2026-03-29 - club - IPL - male - 1527675 - Kolkata Knight Riders vs Mumbai Indians
2025-05-25 - club - IPL - male - 1473505 - Sunrisers Hyderabad vs Kolkata Knight Riders
2025-05-07 - club - IPL - male - 1473494 - Kolkata Knight Riders vs Chennai Super Kings
2025-05-04 - club - IPL - male - 1473490 - Kolkata Knight Riders vs Rajasthan Royals
2025-04-29 - club - IPL - male - 1473485 - Kolkata Knight Riders vs Delhi Capitals
2025-04-26 - club - IPL - male - 1473481 - Punjab Kings vs Kolkata Knight Riders
2025-04-21 - club - IPL - male - 1473476 - Gujarat Titans vs Kolkata Knight Riders
2025-04-15 - club - IPL - male - 1473468 - Punjab Kings vs Kolkata Knight Riders
2025-04-11 - club - IPL - male - 1473462 - Chennai Super Kings vs Kolkata Knight Riders
2025-04-08 - club - IPL - male - 1473456 - Lucknow Super Giants vs Kolkata Knight Riders
2025-04-03 - club - IPL - male - 1473452 - Kolkata Knight Riders vs Sunrisers Hyderabad
2025-03-31 - club - IPL - male - 1473449 - Kolkata Knight Riders vs Mumbai Indians
2025-03-26 - club - IPL - male - 1473443 - Rajasthan Royals vs Kolkata Knight Riders
2025-03-22 - club - IPL - male - 1473438 - Kolkata Knight Riders vs Royal Challengers Bengaluru
2024-05-26 - club - IPL - male - 1426312 - Sunrisers Hyderabad vs Kolkata Knight Riders
2024-05-21 - club - IPL - male - 1426309 - Sunrisers Hyderabad vs Kolkata Knight Riders
2024-05-11 - club - IPL - male - 1426298 - Kolkata Knight Riders vs Mumbai Indians
2024-05-05 - club - IPL - male - 1426292 - Kolkata Knight Riders vs Lucknow Super Giants
2024-05-03 - club - IPL - male - 1426289 - Kolkata Knight Riders vs Mumbai Indians
2024-04-29 - club - IPL - male - 1426285 - Delhi Capitals vs Kolkata Knight Riders
2024-04-26 - club - IPL - male - 1426280 - Kolkata Knight Riders vs Punjab Kings
2024-04-21 - club - IPL - male - 1426274 - Kolkata Knight Riders vs Royal Challengers Bengaluru
2024-04-16 - club - IPL - male - 1426269 - Kolkata Knight Riders vs Rajasthan Royals
2024-04-14 - club - IPL - male - 1426266 - Lucknow Super Giants vs Kolkata Knight Riders
2024-04-08 - club - IPL - male - 1426260 - Kolkata Knight Riders vs Chennai Super Kings
2024-04-03 - club - IPL - male - 1422134 - Kolkata Knight Riders vs Delhi Capitals
2024-03-29 - club - IPL - male - 1422128 - Royal Challengers Bengaluru vs Kolkata Knight Riders
2024-03-23 - club - IPL - male - 1422121 - Kolkata Knight Riders vs Sunrisers Hyderabad
2023-05-20 - club - IPL - male - 1359542 - Lucknow Super Giants vs Kolkata Knight Riders
2023-05-14 - club - IPL - male - 1359535 - Chennai Super Kings vs Kolkata Knight Riders
2023-05-11 - club - IPL - male - 1359530 - Kolkata Knight Riders vs Rajasthan Royals
2023-05-08 - club - IPL - male - 1359527 - Punjab Kings vs Kolkata Knight Riders
2023-05-04 - club - IPL - male - 1359521 - Kolkata Knight Riders vs Sunrisers Hyderabad
2023-04-29 - club - IPL - male - 1359513 - Kolkata Knight Riders vs Gujarat Titans
2023-04-26 - club - IPL - male - 1359510 - Kolkata Knight Riders vs Royal Challengers Bangalore
2023-04-23 - club - IPL - male - 1359507 - Chennai Super Kings vs Kolkata Knight Riders
2023-04-20 - club - IPL - male - 1359502 - Kolkata Knight Riders vs Delhi Capitals
2023-04-16 - club - IPL - male - 1359496 - Kolkata Knight Riders vs Mumbai Indians
2023-04-14 - club - IPL - male - 1359493 - Sunrisers Hyderabad vs Kolkata Knight Riders
2023-04-09 - club - IPL - male - 1359487 - Gujarat Titans vs Kolkata Knight Riders
2023-04-06 - club - IPL - male - 1359483 - Kolkata Knight Riders vs Royal Challengers Bangalore
2023-04-01 - club - IPL - male - 1359476 - Punjab Kings vs Kolkata Knight Riders
2022-05-18 - club - IPL - male - 1304112 - Lucknow Super Giants vs Kolkata Knight Riders
2022-05-14 - club - IPL - male - 1304107 - Kolkata Knight Riders vs Sunrisers Hyderabad
2022-05-09 - club - IPL - male - 1304102 - Kolkata Knight Riders vs Mumbai Indians
2022-05-07 - club - IPL - male - 1304099 - Lucknow Super Giants vs Kolkata Knight Riders
2022-05-02 - club - IPL - male - 1304093 - Rajasthan Royals vs Kolkata Knight Riders
2022-04-28 - club - IPL - male - 1304087 - Kolkata Knight Riders vs Delhi Capitals
2022-04-23 - club - IPL - male - 1304081 - Gujarat Titans vs Kolkata Knight Riders
2022-04-18 - club - IPL - male - 1304076 - Rajasthan Royals vs Kolkata Knight Riders
2022-04-15 - club - IPL - male - 1304071 - Kolkata Knight Riders vs Sunrisers Hyderabad
2022-04-10 - club - IPL - male - 1304065 - Delhi Capitals vs Kolkata Knight Riders
2022-04-06 - club - IPL - male - 1304060 - Mumbai Indians vs Kolkata Knight Riders
2022-04-01 - club - IPL - male - 1304054 - Punjab Kings vs Kolkata Knight Riders
2022-03-30 - club - IPL - male - 1304052 - Kolkata Knight Riders vs Royal Challengers Bangalore
2022-03-26 - club - IPL - male - 1304047 - Chennai Super Kings vs Kolkata Knight Riders
2021-10-15 - club - IPL - male - 1254117 - Chennai Super Kings vs Kolkata Knight Riders
2021-10-13 - club - IPL - male - 1254116 - Delhi Capitals vs Kolkata Knight Riders
2021-10-11 - club - IPL - male - 1254115 - Royal Challengers Bangalore vs Kolkata Knight Riders
2021-10-07 - club - IPL - male - 1254106 - Kolkata Knight Riders vs Rajasthan Royals
2021-10-03 - club - IPL - male - 1254109 - Sunrisers Hyderabad vs Kolkata Knight Riders
2021-10-01 - club - IPL - male - 1254102 - Kolkata Knight Riders vs Punjab Kings
2021-09-28 - club - IPL - male - 1254092 - Delhi Capitals vs Kolkata Knight Riders
2021-09-26 - club - IPL - male - 1254098 - Kolkata Knight Riders vs Chennai Super Kings
2021-09-23 - club - IPL - male - 1254096 - Mumbai Indians vs Kolkata Knight Riders
2021-09-20 - club - IPL - male - 1254087 - Royal Challengers Bangalore vs Kolkata Knight Riders
2021-04-29 - club - IPL - male - 1254082 - Kolkata Knight Riders vs Delhi Capitals
2021-04-26 - club - IPL - male - 1254078 - Punjab Kings vs Kolkata Knight Riders
2021-04-24 - club - IPL - male - 1254075 - Kolkata Knight Riders vs Rajasthan Royals
2021-04-21 - club - IPL - male - 1254072 - Chennai Super Kings vs Kolkata Knight Riders
2021-04-18 - club - IPL - male - 1254067 - Royal Challengers Bangalore vs Kolkata Knight Riders
2021-04-13 - club - IPL - male - 1254062 - Mumbai Indians vs Kolkata Knight Riders
2021-04-11 - club - IPL - male - 1254060 - Kolkata Knight Riders vs Sunrisers Hyderabad
2020-11-01 - club - IPL - male - 1216530 - Kolkata Knight Riders vs Rajasthan Royals
2020-10-29 - club - IPL - male - 1216536 - Kolkata Knight Riders vs Chennai Super Kings
2020-10-26 - club - IPL - male - 1216520 - Kolkata Knight Riders vs Kings XI Punjab
2020-10-24 - club - IPL - male - 1216497 - Kolkata Knight Riders vs Delhi Capitals
2020-10-21 - club - IPL - male - 1216494 - Kolkata Knight Riders vs Royal Challengers Bangalore
2020-10-18 - club - IPL - male - 1216512 - Kolkata Knight Riders vs Sunrisers Hyderabad
2020-10-16 - club - IPL - male - 1216526 - Kolkata Knight Riders vs Mumbai Indians
2020-10-12 - club - IPL - male - 1216540 - Royal Challengers Bangalore vs Kolkata Knight Riders
2020-10-10 - club - IPL - male - 1216523 - Kolkata Knight Riders vs Kings XI Punjab
2020-10-07 - club - IPL - male - 1216501 - Kolkata Knight Riders vs Chennai Super Kings
2020-10-03 - club - IPL - male - 1216515 - Delhi Capitals vs Kolkata Knight Riders
2020-09-30 - club - IPL - male - 1216504 - Kolkata Knight Riders vs Rajasthan Royals
2020-09-26 - club - IPL - male - 1216545 - Sunrisers Hyderabad vs Kolkata Knight Riders
2020-09-23 - club - IPL - male - 1216508 - Mumbai Indians vs Kolkata Knight Riders
2019-05-05 - club - IPL - male - 1178431 - Mumbai Indians vs Kolkata Knight Riders
2019-05-03 - club - IPL - male - 1178427 - Kings XI Punjab vs Kolkata Knight Riders
2019-04-28 - club - IPL - male - 1178422 - Kolkata Knight Riders vs Mumbai Indians
2019-04-25 - club - IPL - male - 1178418 - Kolkata Knight Riders vs Rajasthan Royals
2019-04-21 - club - IPL - male - 1178413 - Sunrisers Hyderabad vs Kolkata Knight Riders
2019-04-19 - club - IPL - male - 1178410 - Kolkata Knight Riders vs Royal Challengers Bangalore
2019-04-14 - club - IPL - male - 1178404 - Kolkata Knight Riders vs Chennai Super Kings
2019-04-12 - club - IPL - male - 1178401 - Kolkata Knight Riders vs Delhi Capitals
2019-04-09 - club - IPL - male - 1178398 - Chennai Super Kings vs Kolkata Knight Riders
2019-04-07 - club - IPL - male - 1178396 - Rajasthan Royals vs Kolkata Knight Riders
2019-04-05 - club - IPL - male - 1175372 - Royal Challengers Bangalore vs Kolkata Knight Riders
2019-03-30 - club - IPL - male - 1175365 - Delhi Capitals vs Kolkata Knight Riders
2019-03-27 - club - IPL - male - 1175361 - Kolkata Knight Riders vs Kings XI Punjab
2019-03-24 - club - IPL - male - 1175357 - Kolkata Knight Riders vs Sunrisers Hyderabad
2018-05-25 - club - IPL - male - 1136619 - Kolkata Knight Riders vs Sunrisers Hyderabad
2018-05-23 - club - IPL - male - 1136618 - Kolkata Knight Riders vs Rajasthan Royals
2018-05-19 - club - IPL - male - 1136614 - Sunrisers Hyderabad vs Kolkata Knight Riders
2018-05-15 - club - IPL - male - 1136609 - Kolkata Knight Riders vs Rajasthan Royals
2018-05-12 - club - IPL - male - 1136604 - Kings XI Punjab vs Kolkata Knight Riders
2018-05-09 - club - IPL - male - 1136601 - Kolkata Knight Riders vs Mumbai Indians
2018-05-06 - club - IPL - male - 1136597 - Mumbai Indians vs Kolkata Knight Riders
2018-05-03 - club - IPL - male - 1136593 - Kolkata Knight Riders vs Chennai Super Kings
2018-04-29 - club - IPL - male - 1136589 - Royal Challengers Bangalore vs Kolkata Knight Riders
2018-04-27 - club - IPL - male - 1136586 - Delhi Daredevils vs Kolkata Knight Riders
2018-04-21 - club - IPL - male - 1136578 - Kolkata Knight Riders vs Kings XI Punjab
2018-04-18 - club - IPL - male - 1136575 - Rajasthan Royals vs Kolkata Knight Riders
2018-04-16 - club - IPL - male - 1136573 - Kolkata Knight Riders vs Delhi Daredevils
2018-04-14 - club - IPL - male - 1136570 - Kolkata Knight Riders vs Sunrisers Hyderabad
2018-04-10 - club - IPL - male - 1136565 - Chennai Super Kings vs Kolkata Knight Riders
2018-04-08 - club - IPL - male - 1136563 - Kolkata Knight Riders vs Royal Challengers Bangalore
2017-05-19 - club - IPL - male - 1082649 - Mumbai Indians vs Kolkata Knight Riders
2017-05-17 - club - IPL - male - 1082648 - Sunrisers Hyderabad vs Kolkata Knight Riders
2017-05-13 - club - IPL - male - 1082644 - Kolkata Knight Riders vs Mumbai Indians
2017-05-09 - club - IPL - male - 1082639 - Kings XI Punjab vs Kolkata Knight Riders
2017-05-07 - club - IPL - male - 1082636 - Royal Challengers Bangalore vs Kolkata Knight Riders
2017-05-03 - club - IPL - male - 1082631 - Kolkata Knight Riders vs Rising Pune Supergiant
2017-04-30 - club - IPL - male - 1082627 - Sunrisers Hyderabad vs Kolkata Knight Riders
2017-04-28 - club - IPL - male - 1082622 - Kolkata Knight Riders vs Delhi Daredevils
2017-04-26 - club - IPL - male - 1082620 - Rising Pune Supergiant vs Kolkata Knight Riders
2017-04-23 - club - IPL - male - 1082617 - Kolkata Knight Riders vs Royal Challengers Bangalore
2017-04-21 - club - IPL - male - 1082613 - Kolkata Knight Riders vs Gujarat Lions
2017-04-17 - club - IPL - male - 1082608 - Delhi Daredevils vs Kolkata Knight Riders
2017-04-15 - club - IPL - male - 1082604 - Kolkata Knight Riders vs Sunrisers Hyderabad
2017-04-13 - club - IPL - male - 1082601 - Kolkata Knight Riders vs Kings XI Punjab
2017-04-09 - club - IPL - male - 1082597 - Mumbai Indians vs Kolkata Knight Riders
2017-04-07 - club - IPL - male - 1082593 - Gujarat Lions vs Kolkata Knight Riders
2016-05-25 - club - IPL - male - 981015 - Sunrisers Hyderabad vs Kolkata Knight Riders
2016-05-22 - club - IPL - male - 981009 - Kolkata Knight Riders vs Sunrisers Hyderabad
2016-05-19 - club - IPL - male - 981001 - Gujarat Lions vs Kolkata Knight Riders
2016-05-16 - club - IPL - male - 980995 - Kolkata Knight Riders vs Royal Challengers Bangalore
2016-05-14 - club - IPL - male - 980989 - Kolkata Knight Riders vs Rising Pune Supergiants
2016-05-08 - club - IPL - male - 980975 - Kolkata Knight Riders vs Gujarat Lions
2016-05-04 - club - IPL - male - 980963 - Kolkata Knight Riders vs Kings XI Punjab
2016-05-02 - club - IPL - male - 980959 - Royal Challengers Bangalore vs Kolkata Knight Riders
2016-04-30 - club - IPL - male - 980951 - Delhi Daredevils vs Kolkata Knight Riders
2016-04-28 - club - IPL - male - 980947 - Mumbai Indians vs Kolkata Knight Riders
2016-04-24 - club - IPL - male - 980939 - Rising Pune Supergiants vs Kolkata Knight Riders
2016-04-19 - club - IPL - male - 980925 - Kings XI Punjab vs Kolkata Knight Riders
2016-04-16 - club - IPL - male - 980915 - Sunrisers Hyderabad vs Kolkata Knight Riders
2016-04-13 - club - IPL - male - 980909 - Kolkata Knight Riders vs Mumbai Indians
2016-04-10 - club - IPL - male - 980903 - Kolkata Knight Riders vs Delhi Daredevils
2015-05-16 - club - IPL - male - 829811 - Rajasthan Royals vs Kolkata Knight Riders
2015-05-14 - club - IPL - male - 829805 - Mumbai Indians vs Kolkata Knight Riders
2015-05-09 - club - IPL - male - 829791 - Kolkata Knight Riders vs Kings XI Punjab
2015-05-07 - club - IPL - male - 829761 - Kolkata Knight Riders vs Delhi Daredevils
2015-05-04 - club - IPL - male - 829781 - Kolkata Knight Riders vs Sunrisers Hyderabad
2015-05-02 - club - IPL - male - 829771 - Royal Challengers Bangalore vs Kolkata Knight Riders
2015-04-30 - club - IPL - male - 829723 - Kolkata Knight Riders vs Chennai Super Kings
2015-04-28 - club - IPL - male - 829765 - Chennai Super Kings vs Kolkata Knight Riders
2015-04-22 - club - IPL - male - 829743 - Sunrisers Hyderabad vs Kolkata Knight Riders
2015-04-20 - club - IPL - male - 829739 - Delhi Daredevils vs Kolkata Knight Riders
2015-04-18 - club - IPL - male - 829733 - Kings XI Punjab vs Kolkata Knight Riders
2015-04-11 - club - IPL - male - 829713 - Kolkata Knight Riders vs Royal Challengers Bangalore
2015-04-08 - club - IPL - male - 829705 - Kolkata Knight Riders vs Mumbai Indians
2014-06-01 - club - IPL - male - 734049 - Kolkata Knight Riders vs Kings XI Punjab
2014-05-27 - club - IPL - male - 734043 - Kings XI Punjab vs Kolkata Knight Riders
2014-05-24 - club - IPL - male - 734037 - Kolkata Knight Riders vs Sunrisers Hyderabad
2014-05-22 - club - IPL - male - 734027 - Kolkata Knight Riders vs Royal Challengers Bangalore
2014-05-20 - club - IPL - male - 734023 - Kolkata Knight Riders vs Chennai Super Kings
2014-05-18 - club - IPL - male - 734015 - Sunrisers Hyderabad vs Kolkata Knight Riders
2014-05-14 - club - IPL - male - 734009 - Kolkata Knight Riders vs Mumbai Indians
2014-05-11 - club - IPL - male - 733997 - Kings XI Punjab vs Kolkata Knight Riders
2014-05-07 - club - IPL - male - 733985 - Delhi Daredevils vs Kolkata Knight Riders
2014-05-05 - club - IPL - male - 733979 - Rajasthan Royals vs Kolkata Knight Riders
2014-05-02 - club - IPL - male - 733971 - Chennai Super Kings vs Kolkata Knight Riders
2014-04-29 - club - IPL - male - 729315 - Kolkata Knight Riders vs Rajasthan Royals
2014-04-26 - club - IPL - male - 729307 - Kolkata Knight Riders vs Kings XI Punjab
2014-04-24 - club - IPL - male - 729299 - Royal Challengers Bangalore vs Kolkata Knight Riders
2014-04-19 - club - IPL - male - 729289 - Kolkata Knight Riders vs Delhi Daredevils
2014-04-16 - club - IPL - male - 729279 - Mumbai Indians vs Kolkata Knight Riders
2013-05-19 - club - IPL - male - 598069 - Sunrisers Hyderabad vs Kolkata Knight Riders
2013-05-15 - club - IPL - male - 598061 - Kolkata Knight Riders vs Pune Warriors
2013-05-12 - club - IPL - male - 598057 - Kolkata Knight Riders vs Royal Challengers Bangalore
2013-05-09 - club - IPL - male - 598053 - Pune Warriors vs Kolkata Knight Riders
2013-05-07 - club - IPL - male - 598050 - Mumbai Indians vs Kolkata Knight Riders
2013-05-03 - club - IPL - male - 598043 - Kolkata Knight Riders vs Rajasthan Royals
2013-05-01 - club - IPL - male - 598040 - Delhi Daredevils vs Kolkata Knight Riders
2013-04-28 - club - IPL - male - 598034 - Chennai Super Kings vs Kolkata Knight Riders
2013-04-26 - club - IPL - male - 598031 - Kolkata Knight Riders vs Kings XI Punjab
2013-04-24 - club - IPL - male - 598029 - Kolkata Knight Riders vs Mumbai Indians
2013-04-20 - club - IPL - male - 598022 - Kolkata Knight Riders vs Chennai Super Kings
2013-04-16 - club - IPL - male - 598016 - Kings XI Punjab vs Kolkata Knight Riders
2013-04-14 - club - IPL - male - 598013 - Kolkata Knight Riders vs Sunrisers Hyderabad
2013-04-11 - club - IPL - male - 598008 - Royal Challengers Bangalore vs Kolkata Knight Riders
2013-04-08 - club - IPL - male - 598005 - Rajasthan Royals vs Kolkata Knight Riders
2013-04-03 - club - IPL - male - 597998 - Kolkata Knight Riders vs Delhi Daredevils
2012-05-27 - club - IPL - male - 548381 - Kolkata Knight Riders vs Chennai Super Kings
2012-05-22 - club - IPL - male - 548378 - Delhi Daredevils vs Kolkata Knight Riders
2012-05-19 - club - IPL - male - 548375 - Pune Warriors vs Kolkata Knight Riders
2012-05-16 - club - IPL - male - 548370 - Mumbai Indians vs Kolkata Knight Riders
2012-05-14 - club - IPL - male - 548368 - Kolkata Knight Riders vs Chennai Super Kings
2012-05-12 - club - IPL - male - 548363 - Kolkata Knight Riders vs Mumbai Indians
2012-05-07 - club - IPL - male - 548357 - Delhi Daredevils vs Kolkata Knight Riders
2012-05-05 - club - IPL - male - 548353 - Kolkata Knight Riders vs Pune Warriors
2012-04-30 - club - IPL - male - 548347 - Chennai Super Kings vs Kolkata Knight Riders
2012-04-28 - club - IPL - male - 548344 - Kolkata Knight Riders vs Royal Challengers Bangalore
2012-04-22 - club - IPL - male - 548335 - Deccan Chargers vs Kolkata Knight Riders
2012-04-18 - club - IPL - male - 548328 - Kings XI Punjab vs Kolkata Knight Riders
2012-04-15 - club - IPL - male - 548323 - Kolkata Knight Riders vs Kings XI Punjab
2012-04-13 - club - IPL - male - 548320 - Kolkata Knight Riders vs Rajasthan Royals
2012-04-10 - club - IPL - male - 548315 - Royal Challengers Bangalore vs Kolkata Knight Riders
2012-04-08 - club - IPL - male - 548312 - Rajasthan Royals vs Kolkata Knight Riders
2012-04-05 - club - IPL - male - 548307 - Kolkata Knight Riders vs Delhi Daredevils
2011-05-25 - club - IPL - male - 501269 - Mumbai Indians vs Kolkata Knight Riders
2011-05-22 - club - IPL - male - 501267 - Kolkata Knight Riders vs Mumbai Indians
2011-05-19 - club - IPL - male - 501262 - Pune Warriors vs Kolkata Knight Riders
2011-05-14 - club - IPL - male - 501255 - Royal Challengers Bangalore vs Kolkata Knight Riders
2011-05-07 - club - IPL - male - 501245 - Kolkata Knight Riders vs Chennai Super Kings
2011-05-05 - club - IPL - male - 501242 - Kochi Tuskers Kerala vs Kolkata Knight Riders
2011-05-03 - club - IPL - male - 501239 - Deccan Chargers vs Kolkata Knight Riders
2011-04-30 - club - IPL - male - 501234 - Kolkata Knight Riders vs Kings XI Punjab
2011-04-28 - club - IPL - male - 501230 - Delhi Daredevils vs Kolkata Knight Riders
2011-04-22 - club - IPL - male - 501222 - Kolkata Knight Riders vs Royal Challengers Bangalore
2011-04-20 - club - IPL - male - 501219 - Kolkata Knight Riders vs Kochi Tuskers Kerala
2011-04-17 - club - IPL - male - 501214 - Kolkata Knight Riders vs Rajasthan Royals
2011-04-15 - club - IPL - male - 501209 - Rajasthan Royals vs Kolkata Knight Riders
2011-04-11 - club - IPL - male - 501203 - Kolkata Knight Riders vs Deccan Chargers
2011-04-08 - club - IPL - male - 501198 - Chennai Super Kings vs Kolkata Knight Riders
2010-04-19 - club - IPL - male - 419161 - Kolkata Knight Riders vs Mumbai Indians
2010-04-17 - club - IPL - male - 419158 - Kolkata Knight Riders vs Rajasthan Royals
2010-04-13 - club - IPL - male - 419153 - Chennai Super Kings vs Kolkata Knight Riders
2010-04-10 - club - IPL - male - 419148 - Royal Challengers Bangalore vs Kolkata Knight Riders
2010-04-07 - club - IPL - male - 419144 - Kolkata Knight Riders vs Delhi Daredevils
2010-04-04 - club - IPL - male - 419139 - Kolkata Knight Riders vs Kings XI Punjab
2010-04-01 - club - IPL - male - 419135 - Kolkata Knight Riders vs Deccan Chargers
2010-03-29 - club - IPL - male - 419131 - Delhi Daredevils vs Kolkata Knight Riders
2010-03-27 - club - IPL - male - 419127 - Kings XI Punjab vs Kolkata Knight Riders
2010-03-22 - club - IPL - male - 419122 - Mumbai Indians vs Kolkata Knight Riders
2010-03-20 - club - IPL - male - 419118 - Rajasthan Royals vs Kolkata Knight Riders
2010-03-16 - club - IPL - male - 419113 - Kolkata Knight Riders vs Chennai Super Kings
2010-03-14 - club - IPL - male - 419109 - Kolkata Knight Riders vs Royal Challengers Bangalore
2010-03-12 - club - IPL - male - 419106 - Deccan Chargers vs Kolkata Knight Riders
2009-05-20 - club - IPL - male - 392233 - Kolkata Knight Riders vs Rajasthan Royals
2009-05-18 - club - IPL - male - 392231 - Chennai Super Kings vs Kolkata Knight Riders
2009-05-16 - club - IPL - male - 392228 - Deccan Chargers vs Kolkata Knight Riders
2009-05-12 - club - IPL - male - 392221 - Royal Challengers Bangalore vs Kolkata Knight Riders
2009-05-10 - club - IPL - male - 392219 - Delhi Daredevils vs Kolkata Knight Riders
2009-05-05 - club - IPL - male - 392211 - Delhi Daredevils vs Kolkata Knight Riders
2009-05-03 - club - IPL - male - 392207 - Kings XI Punjab vs Kolkata Knight Riders
2009-05-01 - club - IPL - male - 392203 - Kolkata Knight Riders vs Mumbai Indians
2009-04-29 - club - IPL - male - 392199 - Royal Challengers Bangalore vs Kolkata Knight Riders
2009-04-27 - club - IPL - male - 392197 - Kolkata Knight Riders vs Mumbai Indians
2009-04-23 - club - IPL - male - 392190 - Kolkata Knight Riders vs Rajasthan Royals
2009-04-21 - club - IPL - male - 392186 - Kings XI Punjab vs Kolkata Knight Riders
2009-04-19 - club - IPL - male - 392184 - Deccan Chargers vs Kolkata Knight Riders
2008-05-25 - club - IPL - male - 336035 - Kolkata Knight Riders vs Kings XI Punjab
2008-05-20 - club - IPL - male - 336027 - Kolkata Knight Riders vs Rajasthan Royals
2008-05-18 - club - IPL - male - 336025 - Kolkata Knight Riders vs Chennai Super Kings
2008-05-16 - club - IPL - male - 336021 - Mumbai Indians vs Kolkata Knight Riders
2008-05-13 - club - IPL - male - 336017 - Kolkata Knight Riders vs Delhi Daredevils
2008-05-11 - club - IPL - male - 336014 - Deccan Chargers vs Kolkata Knight Riders
2008-05-08 - club - IPL - male - 336010 - Kolkata Knight Riders vs Royal Challengers Bangalore
2008-05-03 - club - IPL - male - 336003 - Kings XI Punjab vs Kolkata Knight Riders
2008-05-01 - club - IPL - male - 336000 - Rajasthan Royals vs Kolkata Knight Riders
2008-04-29 - club - IPL - male - 335997 - Kolkata Knight Riders vs Mumbai Indians
2008-04-26 - club - IPL - male - 335993 - Chennai Super Kings vs Kolkata Knight Riders
2008-04-20 - club - IPL - male - 335986 - Kolkata Knight Riders vs Deccan Chargers
2008-04-18 - club - IPL - male - 335982 - Royal Challengers Bangalore vs Kolkata Knight Riders
