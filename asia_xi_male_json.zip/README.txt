This zip archive contains data files from Cricsheet in JSON format. This
archive contains 5 Asia XI matches of all types.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/asia_xi_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2007-06-10 - international - ODI - male - 289110 - Africa XI vs Asia XI
2007-06-09 - international - ODI - male - 289108 - Africa XI vs Asia XI
2007-06-06 - international - ODI - male - 289107 - Africa XI vs Asia XI
2005-08-21 - international - ODI - male - 216669 - Africa XI vs Asia XI
2005-08-17 - international - ODI - male - 216271 - Africa XI vs Asia XI
