This zip archive contains data files from Cricsheet in YAML format. This
archive contains 211 Sunrisers Hyderabad matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/sunrisers_hyderabad_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-05-27 - club - IPL - male - 1535463 - Rajasthan Royals vs Sunrisers Hyderabad
2026-05-22 - club - IPL - male - 1529310 - Sunrisers Hyderabad vs Royal Challengers Bengaluru
2026-05-18 - club - IPL - male - 1529306 - Chennai Super Kings vs Sunrisers Hyderabad
2026-05-12 - club - IPL - male - 1529299 - Gujarat Titans vs Sunrisers Hyderabad
2026-05-06 - club - IPL - male - 1529292 - Sunrisers Hyderabad vs Punjab Kings
2026-05-03 - club - IPL - male - 1529288 - Sunrisers Hyderabad vs Kolkata Knight Riders
2026-04-29 - club - IPL - male - 1529284 - Mumbai Indians vs Sunrisers Hyderabad
2026-04-25 - club - IPL - male - 1529279 - Rajasthan Royals vs Sunrisers Hyderabad
2026-04-21 - club - IPL - male - 1529274 - Sunrisers Hyderabad vs Delhi Capitals
2026-04-18 - club - IPL - male - 1529270 - Sunrisers Hyderabad vs Chennai Super Kings
2026-04-13 - club - IPL - male - 1529264 - Sunrisers Hyderabad vs Rajasthan Royals
2026-04-11 - club - IPL - male - 1527690 - Sunrisers Hyderabad vs Punjab Kings
2026-04-05 - club - IPL - male - 1527683 - Sunrisers Hyderabad vs Lucknow Super Giants
2026-04-02 - club - IPL - male - 1527679 - Sunrisers Hyderabad vs Kolkata Knight Riders
2026-03-28 - club - IPL - male - 1527674 - Sunrisers Hyderabad vs Royal Challengers Bengaluru
2025-05-25 - club - IPL - male - 1473505 - Sunrisers Hyderabad vs Kolkata Knight Riders
2025-05-23 - club - IPL - male - 1473503 - Sunrisers Hyderabad vs Royal Challengers Bengaluru
2025-05-19 - club - IPL - male - 1473499 - Lucknow Super Giants vs Sunrisers Hyderabad
2025-05-05 - club - IPL - male - 1473492 - Delhi Capitals vs Sunrisers Hyderabad
2025-05-02 - club - IPL - male - 1473488 - Gujarat Titans vs Sunrisers Hyderabad
2025-04-25 - club - IPL - male - 1473480 - Chennai Super Kings vs Sunrisers Hyderabad
2025-04-23 - club - IPL - male - 1473478 - Sunrisers Hyderabad vs Mumbai Indians
2025-04-17 - club - IPL - male - 1473470 - Sunrisers Hyderabad vs Mumbai Indians
2025-04-12 - club - IPL - male - 1473464 - Punjab Kings vs Sunrisers Hyderabad
2025-04-06 - club - IPL - male - 1473457 - Sunrisers Hyderabad vs Gujarat Titans
2025-04-03 - club - IPL - male - 1473452 - Kolkata Knight Riders vs Sunrisers Hyderabad
2025-03-30 - club - IPL - male - 1473447 - Sunrisers Hyderabad vs Delhi Capitals
2025-03-27 - club - IPL - male - 1473444 - Sunrisers Hyderabad vs Lucknow Super Giants
2025-03-23 - club - IPL - male - 1473439 - Sunrisers Hyderabad vs Rajasthan Royals
2024-05-26 - club - IPL - male - 1426312 - Sunrisers Hyderabad vs Kolkata Knight Riders
2024-05-24 - club - IPL - male - 1426311 - Sunrisers Hyderabad vs Rajasthan Royals
2024-05-21 - club - IPL - male - 1426309 - Sunrisers Hyderabad vs Kolkata Knight Riders
2024-05-19 - club - IPL - male - 1426307 - Punjab Kings vs Sunrisers Hyderabad
2024-05-08 - club - IPL - male - 1426295 - Lucknow Super Giants vs Sunrisers Hyderabad
2024-05-06 - club - IPL - male - 1426293 - Sunrisers Hyderabad vs Mumbai Indians
2024-05-02 - club - IPL - male - 1426288 - Sunrisers Hyderabad vs Rajasthan Royals
2024-04-28 - club - IPL - male - 1426284 - Chennai Super Kings vs Sunrisers Hyderabad
2024-04-25 - club - IPL - male - 1426279 - Royal Challengers Bengaluru vs Sunrisers Hyderabad
2024-04-20 - club - IPL - male - 1426273 - Sunrisers Hyderabad vs Delhi Capitals
2024-04-15 - club - IPL - male - 1426268 - Sunrisers Hyderabad vs Royal Challengers Bengaluru
2024-04-09 - club - IPL - male - 1426261 - Sunrisers Hyderabad vs Punjab Kings
2024-04-05 - club - IPL - male - 1422136 - Chennai Super Kings vs Sunrisers Hyderabad
2024-03-31 - club - IPL - male - 1422130 - Sunrisers Hyderabad vs Gujarat Titans
2024-03-27 - club - IPL - male - 1422126 - Sunrisers Hyderabad vs Mumbai Indians
2024-03-23 - club - IPL - male - 1422121 - Kolkata Knight Riders vs Sunrisers Hyderabad
2023-05-21 - club - IPL - male - 1359543 - Sunrisers Hyderabad vs Mumbai Indians
2023-05-18 - club - IPL - male - 1359539 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2023-05-15 - club - IPL - male - 1359536 - Gujarat Titans vs Sunrisers Hyderabad
2023-05-13 - club - IPL - male - 1359532 - Sunrisers Hyderabad vs Lucknow Super Giants
2023-05-07 - club - IPL - male - 1359526 - Rajasthan Royals vs Sunrisers Hyderabad
2023-05-04 - club - IPL - male - 1359521 - Kolkata Knight Riders vs Sunrisers Hyderabad
2023-04-29 - club - IPL - male - 1359514 - Sunrisers Hyderabad vs Delhi Capitals
2023-04-24 - club - IPL - male - 1359508 - Delhi Capitals vs Sunrisers Hyderabad
2023-04-21 - club - IPL - male - 1359503 - Sunrisers Hyderabad vs Chennai Super Kings
2023-04-18 - club - IPL - male - 1359499 - Mumbai Indians vs Sunrisers Hyderabad
2023-04-14 - club - IPL - male - 1359493 - Sunrisers Hyderabad vs Kolkata Knight Riders
2023-04-09 - club - IPL - male - 1359488 - Punjab Kings vs Sunrisers Hyderabad
2023-04-07 - club - IPL - male - 1359484 - Sunrisers Hyderabad vs Lucknow Super Giants
2023-04-02 - club - IPL - male - 1359478 - Rajasthan Royals vs Sunrisers Hyderabad
2022-05-22 - club - IPL - male - 1304116 - Sunrisers Hyderabad vs Punjab Kings
2022-05-17 - club - IPL - male - 1304111 - Sunrisers Hyderabad vs Mumbai Indians
2022-05-14 - club - IPL - male - 1304107 - Kolkata Knight Riders vs Sunrisers Hyderabad
2022-05-08 - club - IPL - male - 1304100 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2022-05-05 - club - IPL - male - 1304096 - Delhi Capitals vs Sunrisers Hyderabad
2022-05-01 - club - IPL - male - 1304092 - Chennai Super Kings vs Sunrisers Hyderabad
2022-04-27 - club - IPL - male - 1304086 - Sunrisers Hyderabad vs Gujarat Titans
2022-04-23 - club - IPL - male - 1304082 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2022-04-17 - club - IPL - male - 1304074 - Punjab Kings vs Sunrisers Hyderabad
2022-04-15 - club - IPL - male - 1304071 - Kolkata Knight Riders vs Sunrisers Hyderabad
2022-04-11 - club - IPL - male - 1304067 - Gujarat Titans vs Sunrisers Hyderabad
2022-04-09 - club - IPL - male - 1304063 - Chennai Super Kings vs Sunrisers Hyderabad
2022-04-04 - club - IPL - male - 1304058 - Lucknow Super Giants vs Sunrisers Hyderabad
2022-03-29 - club - IPL - male - 1304051 - Rajasthan Royals vs Sunrisers Hyderabad
2021-10-08 - club - IPL - male - 1254088 - Mumbai Indians vs Sunrisers Hyderabad
2021-10-06 - club - IPL - male - 1254095 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2021-10-03 - club - IPL - male - 1254109 - Sunrisers Hyderabad vs Kolkata Knight Riders
2021-09-30 - club - IPL - male - 1254091 - Sunrisers Hyderabad vs Chennai Super Kings
2021-09-27 - club - IPL - male - 1254100 - Rajasthan Royals vs Sunrisers Hyderabad
2021-09-25 - club - IPL - male - 1254107 - Punjab Kings vs Sunrisers Hyderabad
2021-09-22 - club - IPL - male - 1254105 - Sunrisers Hyderabad vs Delhi Capitals
2021-05-02 - club - IPL - male - 1254085 - Rajasthan Royals vs Sunrisers Hyderabad
2021-04-28 - club - IPL - male - 1254080 - Sunrisers Hyderabad vs Chennai Super Kings
2021-04-25 - club - IPL - male - 1254077 - Delhi Capitals vs Sunrisers Hyderabad
2021-04-21 - club - IPL - male - 1254071 - Punjab Kings vs Sunrisers Hyderabad
2021-04-17 - club - IPL - male - 1254066 - Mumbai Indians vs Sunrisers Hyderabad
2021-04-14 - club - IPL - male - 1254063 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2021-04-11 - club - IPL - male - 1254060 - Kolkata Knight Riders vs Sunrisers Hyderabad
2020-11-08 - club - IPL - male - 1237180 - Delhi Capitals vs Sunrisers Hyderabad
2020-11-06 - club - IPL - male - 1237178 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2020-11-03 - club - IPL - male - 1216495 - Mumbai Indians vs Sunrisers Hyderabad
2020-10-31 - club - IPL - male - 1216502 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2020-10-27 - club - IPL - male - 1216524 - Sunrisers Hyderabad vs Delhi Capitals
2020-10-24 - club - IPL - male - 1216498 - Kings XI Punjab vs Sunrisers Hyderabad
2020-10-22 - club - IPL - male - 1216518 - Rajasthan Royals vs Sunrisers Hyderabad
2020-10-18 - club - IPL - male - 1216512 - Kolkata Knight Riders vs Sunrisers Hyderabad
2020-10-13 - club - IPL - male - 1216528 - Chennai Super Kings vs Sunrisers Hyderabad
2020-10-11 - club - IPL - male - 1216507 - Sunrisers Hyderabad vs Rajasthan Royals
2020-10-08 - club - IPL - male - 1216542 - Sunrisers Hyderabad vs Kings XI Punjab
2020-10-04 - club - IPL - male - 1216538 - Mumbai Indians vs Sunrisers Hyderabad
2020-10-02 - club - IPL - male - 1216516 - Sunrisers Hyderabad vs Chennai Super Kings
2020-09-29 - club - IPL - male - 1216532 - Sunrisers Hyderabad vs Delhi Capitals
2020-09-26 - club - IPL - male - 1216545 - Sunrisers Hyderabad vs Kolkata Knight Riders
2020-09-21 - club - IPL - male - 1216534 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2019-05-08 - club - IPL - male - 1181766 - Delhi Capitals vs Sunrisers Hyderabad
2019-05-04 - club - IPL - male - 1178429 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2019-05-02 - club - IPL - male - 1178426 - Mumbai Indians vs Sunrisers Hyderabad
2019-04-29 - club - IPL - male - 1178423 - Sunrisers Hyderabad vs Kings XI Punjab
2019-04-27 - club - IPL - male - 1178420 - Rajasthan Royals vs Sunrisers Hyderabad
2019-04-23 - club - IPL - male - 1178416 - Chennai Super Kings vs Sunrisers Hyderabad
2019-04-21 - club - IPL - male - 1178413 - Sunrisers Hyderabad vs Kolkata Knight Riders
2019-04-17 - club - IPL - male - 1178408 - Sunrisers Hyderabad vs Chennai Super Kings
2019-04-14 - club - IPL - male - 1178405 - Sunrisers Hyderabad vs Delhi Capitals
2019-04-08 - club - IPL - male - 1178397 - Kings XI Punjab vs Sunrisers Hyderabad
2019-04-06 - club - IPL - male - 1178394 - Sunrisers Hyderabad vs Mumbai Indians
2019-04-04 - club - IPL - male - 1175371 - Delhi Capitals vs Sunrisers Hyderabad
2019-03-31 - club - IPL - male - 1175366 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2019-03-29 - club - IPL - male - 1175363 - Sunrisers Hyderabad vs Rajasthan Royals
2019-03-24 - club - IPL - male - 1175357 - Kolkata Knight Riders vs Sunrisers Hyderabad
2018-05-27 - club - IPL - male - 1136620 - Chennai Super Kings vs Sunrisers Hyderabad
2018-05-25 - club - IPL - male - 1136619 - Kolkata Knight Riders vs Sunrisers Hyderabad
2018-05-22 - club - IPL - male - 1136617 - Sunrisers Hyderabad vs Chennai Super Kings
2018-05-19 - club - IPL - male - 1136614 - Sunrisers Hyderabad vs Kolkata Knight Riders
2018-05-17 - club - IPL - male - 1136611 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2018-05-13 - club - IPL - male - 1136606 - Chennai Super Kings vs Sunrisers Hyderabad
2018-05-10 - club - IPL - male - 1136602 - Delhi Daredevils vs Sunrisers Hyderabad
2018-05-07 - club - IPL - male - 1136599 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2018-05-05 - club - IPL - male - 1136596 - Sunrisers Hyderabad vs Delhi Daredevils
2018-04-29 - club - IPL - male - 1136588 - Rajasthan Royals vs Sunrisers Hyderabad
2018-04-26 - club - IPL - male - 1136585 - Sunrisers Hyderabad vs Kings XI Punjab
2018-04-24 - club - IPL - male - 1136583 - Mumbai Indians vs Sunrisers Hyderabad
2018-04-22 - club - IPL - male - 1136580 - Sunrisers Hyderabad vs Chennai Super Kings
2018-04-19 - club - IPL - male - 1136576 - Kings XI Punjab vs Sunrisers Hyderabad
2018-04-14 - club - IPL - male - 1136570 - Kolkata Knight Riders vs Sunrisers Hyderabad
2018-04-12 - club - IPL - male - 1136567 - Sunrisers Hyderabad vs Mumbai Indians
2018-04-09 - club - IPL - male - 1136564 - Sunrisers Hyderabad vs Rajasthan Royals
2017-05-17 - club - IPL - male - 1082648 - Sunrisers Hyderabad vs Kolkata Knight Riders
2017-05-13 - club - IPL - male - 1082643 - Gujarat Lions vs Sunrisers Hyderabad
2017-05-08 - club - IPL - male - 1082638 - Sunrisers Hyderabad vs Mumbai Indians
2017-05-06 - club - IPL - male - 1082634 - Sunrisers Hyderabad vs Rising Pune Supergiant
2017-05-02 - club - IPL - male - 1082630 - Delhi Daredevils vs Sunrisers Hyderabad
2017-04-30 - club - IPL - male - 1082627 - Sunrisers Hyderabad vs Kolkata Knight Riders
2017-04-28 - club - IPL - male - 1082623 - Kings XI Punjab vs Sunrisers Hyderabad
2017-04-22 - club - IPL - male - 1082615 - Rising Pune Supergiant vs Sunrisers Hyderabad
2017-04-19 - club - IPL - male - 1082611 - Sunrisers Hyderabad vs Delhi Daredevils
2017-04-17 - club - IPL - male - 1082609 - Sunrisers Hyderabad vs Kings XI Punjab
2017-04-15 - club - IPL - male - 1082604 - Kolkata Knight Riders vs Sunrisers Hyderabad
2017-04-12 - club - IPL - male - 1082600 - Mumbai Indians vs Sunrisers Hyderabad
2017-04-09 - club - IPL - male - 1082596 - Sunrisers Hyderabad vs Gujarat Lions
2017-04-05 - club - IPL - male - 1082591 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2016-05-29 - club - IPL - male - 981019 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2016-05-27 - club - IPL - male - 981017 - Gujarat Lions vs Sunrisers Hyderabad
2016-05-25 - club - IPL - male - 981015 - Sunrisers Hyderabad vs Kolkata Knight Riders
2016-05-22 - club - IPL - male - 981009 - Kolkata Knight Riders vs Sunrisers Hyderabad
2016-05-20 - club - IPL - male - 981003 - Delhi Daredevils vs Sunrisers Hyderabad
2016-05-15 - club - IPL - male - 980991 - Kings XI Punjab vs Sunrisers Hyderabad
2016-05-12 - club - IPL - male - 980983 - Sunrisers Hyderabad vs Delhi Daredevils
2016-05-10 - club - IPL - male - 980979 - Rising Pune Supergiants vs Sunrisers Hyderabad
2016-05-08 - club - IPL - male - 980973 - Mumbai Indians vs Sunrisers Hyderabad
2016-05-06 - club - IPL - male - 980967 - Sunrisers Hyderabad vs Gujarat Lions
2016-04-30 - club - IPL - male - 980953 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2016-04-26 - club - IPL - male - 980943 - Sunrisers Hyderabad vs Rising Pune Supergiants
2016-04-23 - club - IPL - male - 980935 - Sunrisers Hyderabad vs Kings XI Punjab
2016-04-21 - club - IPL - male - 980929 - Gujarat Lions vs Sunrisers Hyderabad
2016-04-18 - club - IPL - male - 980923 - Sunrisers Hyderabad vs Mumbai Indians
2016-04-16 - club - IPL - male - 980915 - Sunrisers Hyderabad vs Kolkata Knight Riders
2016-04-12 - club - IPL - male - 980907 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2015-05-17 - club - IPL - male - 829815 - Sunrisers Hyderabad vs Mumbai Indians
2015-05-15 - club - IPL - male - 829807 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2015-05-11 - club - IPL - male - 829799 - Sunrisers Hyderabad vs Kings XI Punjab
2015-05-09 - club - IPL - male - 829793 - Delhi Daredevils vs Sunrisers Hyderabad
2015-05-07 - club - IPL - male - 829787 - Rajasthan Royals vs Sunrisers Hyderabad
2015-05-04 - club - IPL - male - 829781 - Kolkata Knight Riders vs Sunrisers Hyderabad
2015-05-02 - club - IPL - male - 829773 - Sunrisers Hyderabad vs Chennai Super Kings
2015-04-27 - club - IPL - male - 829759 - Kings XI Punjab vs Sunrisers Hyderabad
2015-04-25 - club - IPL - male - 829751 - Mumbai Indians vs Sunrisers Hyderabad
2015-04-22 - club - IPL - male - 829743 - Sunrisers Hyderabad vs Kolkata Knight Riders
2015-04-18 - club - IPL - male - 829731 - Sunrisers Hyderabad vs Delhi Daredevils
2015-04-16 - club - IPL - male - 829727 - Sunrisers Hyderabad vs Rajasthan Royals
2015-04-13 - club - IPL - male - 829719 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2015-04-11 - club - IPL - male - 829711 - Chennai Super Kings vs Sunrisers Hyderabad
2014-05-24 - club - IPL - male - 734037 - Kolkata Knight Riders vs Sunrisers Hyderabad
2014-05-22 - club - IPL - male - 734029 - Chennai Super Kings vs Sunrisers Hyderabad
2014-05-20 - club - IPL - male - 734021 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2014-05-18 - club - IPL - male - 734015 - Sunrisers Hyderabad vs Kolkata Knight Riders
2014-05-14 - club - IPL - male - 734007 - Sunrisers Hyderabad vs Kings XI Punjab
2014-05-12 - club - IPL - male - 734001 - Sunrisers Hyderabad vs Mumbai Indians
2014-05-10 - club - IPL - male - 733993 - Delhi Daredevils vs Sunrisers Hyderabad
2014-05-08 - club - IPL - male - 733989 - Rajasthan Royals vs Sunrisers Hyderabad
2014-05-04 - club - IPL - male - 733977 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2014-04-30 - club - IPL - male - 729317 - Mumbai Indians vs Sunrisers Hyderabad
2014-04-27 - club - IPL - male - 729311 - Sunrisers Hyderabad vs Chennai Super Kings
2014-04-25 - club - IPL - male - 729301 - Sunrisers Hyderabad vs Delhi Daredevils
2014-04-22 - club - IPL - male - 729295 - Kings XI Punjab vs Sunrisers Hyderabad
2014-04-18 - club - IPL - male - 729285 - Sunrisers Hyderabad vs Rajasthan Royals
2013-05-22 - club - IPL - male - 598071 - Rajasthan Royals vs Sunrisers Hyderabad
2013-05-19 - club - IPL - male - 598069 - Sunrisers Hyderabad vs Kolkata Knight Riders
2013-05-17 - club - IPL - male - 598065 - Sunrisers Hyderabad vs Rajasthan Royals
2013-05-13 - club - IPL - male - 598060 - Mumbai Indians vs Sunrisers Hyderabad
2013-05-11 - club - IPL - male - 598056 - Kings XI Punjab vs Sunrisers Hyderabad
2013-05-08 - club - IPL - male - 598051 - Sunrisers Hyderabad vs Chennai Super Kings
2013-05-04 - club - IPL - male - 598044 - Sunrisers Hyderabad vs Delhi Daredevils
2013-05-01 - club - IPL - male - 598039 - Sunrisers Hyderabad vs Mumbai Indians
2013-04-27 - club - IPL - male - 598032 - Rajasthan Royals vs Sunrisers Hyderabad
2013-04-25 - club - IPL - male - 598030 - Chennai Super Kings vs Sunrisers Hyderabad
2013-04-19 - club - IPL - male - 598021 - Sunrisers Hyderabad vs Kings XI Punjab
2013-04-17 - club - IPL - male - 598018 - Pune Warriors vs Sunrisers Hyderabad
2013-04-14 - club - IPL - male - 598013 - Kolkata Knight Riders vs Sunrisers Hyderabad
2013-04-12 - club - IPL - male - 598010 - Delhi Daredevils vs Sunrisers Hyderabad
2013-04-09 - club - IPL - male - 598048 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2013-04-07 - club - IPL - male - 598004 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2013-04-05 - club - IPL - male - 598000 - Sunrisers Hyderabad vs Pune Warriors
