This zip archive contains data files from Cricsheet in YAML format. This
archive contains 96 matches of all types from 2004.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/2004_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2004-12-27 - international - ODI - male - 64917 - India vs Bangladesh
2004-12-23 - international - ODI - male - 64914 - India vs Bangladesh
2004-12-16 - international - Test - male - 64113 - Australia vs Pakistan
2004-12-10 - international - Test - male - 64111 - Bangladesh vs India
2004-12-08 - international - ODI - male - 66386 - Australia vs New Zealand
2004-12-05 - international - ODI - male - 66385 - Australia vs New Zealand
2004-12-05 - international - ODI - male - 64913 - England vs Zimbabwe
2004-12-01 - international - ODI - male - 64911 - England vs Zimbabwe
2004-11-28 - international - Test - male - 64110 - South Africa vs India
2004-11-28 - international - ODI - male - 64910 - Zimbabwe vs England
2004-11-26 - international - Test - male - 64108 - Australia vs New Zealand
2004-11-20 - international - Test - male - 64109 - South Africa vs India
2004-11-18 - international - Test - male - 64107 - New Zealand vs Australia
2004-11-03 - international - Test - male - 64102 - India vs Australia
2004-11-02 - international - ODI - male - 64907 - New Zealand vs Bangladesh
2004-10-26 - international - Test - male - 64104 - New Zealand vs Bangladesh
2004-10-16 - international - ODI - male - 66383 - Sri Lanka vs Pakistan
2004-10-14 - international - Test - male - 64100 - Australia vs India
2004-10-09 - international - ODI - male - 66381 - Zimbabwe vs Sri Lanka
2004-10-06 - international - ODI - male - 66380 - Sri Lanka vs Pakistan
2004-10-03 - international - ODI - male - 66379 - Zimbabwe vs Pakistan
2004-09-30 - international - ODI - male - 66378 - Pakistan vs Zimbabwe
2004-09-25 - international - ODI - male - 66210 - England vs West Indies
2004-09-22 - international - ODI - male - 66209 - Pakistan vs West Indies
2004-09-21 - international - ODI - male - 66208 - Australia vs England
2004-09-19 - international - ODI - male - 66207 - India vs Pakistan
2004-09-18 - international - ODI - male - 66206 - South Africa vs West Indies
2004-09-17 - international - ODI - male - 66205 - England vs Sri Lanka
2004-09-16 - international - ODI - male - 66204 - New Zealand vs Australia
2004-09-15 - international - ODI - male - 66203 - West Indies vs Bangladesh
2004-09-14 - international - ODI - male - 66202 - Kenya vs Pakistan
2004-09-14 - international - ODI - male - 66201 - Zimbabwe vs Sri Lanka
2004-09-13 - international - ODI - male - 66200 - United States of America vs Australia
2004-09-11 - international - ODI - male - 66198 - India vs Kenya
2004-09-10 - international - ODI - male - 66197 - New Zealand vs United States of America
2004-09-10 - international - ODI - male - 66196 - England vs Zimbabwe
2004-09-05 - international - ODI - male - 65034 - India vs England
2004-09-04 - international - ODI - male - 66377 - Australia vs Pakistan
2004-09-03 - international - ODI - male - 65033 - England vs India
2004-09-01 - international - ODI - male - 65032 - India vs England
2004-08-31 - international - ODI - male - 64906 - Sri Lanka vs South Africa
2004-08-28 - international - ODI - male - 64905 - South Africa vs Sri Lanka
2004-08-23 - international - ODI - male - 66375 - Australia vs India
2004-08-21 - international - ODI - male - 66374 - Pakistan vs India
2004-08-19 - international - Test - male - 64096 - England vs West Indies
2004-08-01 - international - ODI - male - 65718 - Sri Lanka vs India
2004-07-29 - international - Test - male - 64094 - England vs West Indies
2004-07-27 - international - ODI - male - 65716 - India vs Sri Lanka
2004-07-23 - international - ODI - male - 65714 - Bangladesh vs Sri Lanka
2004-07-21 - international - ODI - male - 65713 - Pakistan vs Sri Lanka
2004-07-17 - international - ODI - male - 65708 - Pakistan vs Bangladesh
2004-07-10 - international - ODI - male - 66311 - New Zealand vs West Indies
2004-07-06 - international - ODI - male - 66309 - England vs West Indies
2004-07-01 - international - ODI - male - 66306 - West Indies vs England
2004-06-29 - international - ODI - male - 66305 - England vs New Zealand
2004-06-27 - international - ODI - male - 66304 - England vs West Indies
2004-05-29 - international - ODI - male - 64901 - Zimbabwe vs Australia
2004-05-27 - international - ODI - male - 64900 - Australia vs Zimbabwe
2004-05-25 - international - ODI - male - 64899 - Zimbabwe vs Australia
2004-05-19 - international - ODI - male - 64898 - Bangladesh vs West Indies
2004-05-16 - international - ODI - male - 64897 - West Indies vs Bangladesh
2004-05-15 - international - ODI - male - 64896 - Bangladesh vs West Indies
2004-05-02 - international - ODI - male - 64894 - England vs West Indies
2004-04-27 - international - ODI - male - 64891 - Sri Lanka vs Zimbabwe
2004-04-24 - international - ODI - male - 64889 - West Indies vs England
2004-04-20 - international - ODI - male - 64887 - Zimbabwe vs Sri Lanka
2004-04-13 - international - Test - male - 64083 - Pakistan vs India
2004-04-10 - international - Test - male - 64080 - West Indies vs England
2004-03-26 - international - Test - male - 64076 - New Zealand vs South Africa
2004-03-24 - international - ODI - male - 64885 - India vs Pakistan
2004-03-21 - international - ODI - male - 64884 - Pakistan vs India
2004-03-19 - international - ODI - male - 64883 - India vs Pakistan
2004-03-18 - international - Test - male - 64075 - South Africa vs New Zealand
2004-03-16 - international - ODI - male - 64882 - Pakistan vs India
2004-03-14 - international - ODI - male - 64881 - Bangladesh vs Zimbabwe
2004-03-08 - international - Test - male - 64071 - Australia vs Sri Lanka
2004-02-27 - international - ODI - male - 64874 - Australia vs Sri Lanka
2004-02-25 - international - ODI - male - 64872 - South Africa vs New Zealand
2004-02-22 - international - ODI - male - 64871 - Sri Lanka vs Australia
2004-02-20 - international - ODI - male - 64870 - Australia vs Sri Lanka
2004-02-08 - international - ODI - male - 65656 - Australia vs India
2004-02-06 - international - ODI - male - 65655 - India vs Australia
2004-02-01 - international - ODI - male - 65653 - India vs Australia
2004-02-01 - international - ODI - male - 64865 - South Africa vs West Indies
2004-01-30 - international - ODI - male - 64864 - West Indies vs South Africa
2004-01-29 - international - ODI - male - 65652 - Australia vs Zimbabwe
2004-01-25 - international - ODI - male - 64862 - South Africa vs West Indies
2004-01-22 - international - ODI - male - 65649 - India vs Australia
2004-01-20 - international - ODI - male - 65648 - India vs Zimbabwe
2004-01-18 - international - ODI - male - 65647 - India vs Australia
2004-01-16 - international - ODI - male - 65646 - Australia vs Zimbabwe
2004-01-14 - international - ODI - male - 65645 - Zimbabwe vs India
2004-01-11 - international - ODI - male - 65644 - Australia vs Zimbabwe
2004-01-09 - international - ODI - male - 65643 - Australia vs India
2004-01-03 - international - ODI - male - 64857 - Pakistan vs New Zealand
2004-01-02 - international - Test - male - 64062 - India vs Australia
