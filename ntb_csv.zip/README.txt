All T20 Blast match data in CSV format
======================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the IPL data from YAML into this CSV format. This then expanded
to include international T20s, for both women and men, before, finally,
expanding again to cover all matches we provide.

This particular zip folder contains the CSV data for...
  All T20 Blast matches
...for which we have data, and is loosely based on the format that Retrosheet
uses for baseball, with some suitable hacks built in.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the newer "Ashwin" format?
Ideally I'd like to settle on a single CSV format so what should be kept
from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_original/
but the following is a brief summary of the details...

Each file has a 'version', multiple 'info' lines, and multiple 'ball' lines.
'version' is just 1.8.0 for now, and will change as I make changes.
The 'info' entries should be fairly self-explanatory but feel free to ask on
Mastodon (@cricsheet@deeden.co.uk) if you're unsure. If you look carefully
you may see some slight hints as to some data we'll be including in the full
data files in the future.

Each 'ball' line has the following fields:

  * The word 'ball' to identify it as such
  * Innings number, starting from 1
  * Over and ball
  * Batting team name
  * Batsman
  * Non-striker
  * Bowler
  * Runs-off-bat
  * Extras
  * Wides
  * No-balls
  * Byes
  * Leg-byes
  * Penalty
  * Kind of wicket, if any
  * Dismissed played, if there was a wicket

Matches included in this archive
--------------------------------

2026-07-18 - club - NTB - male - 1512889 - Northamptonshire vs Hampshire
2026-07-18 - club - NTB - male - 1512888 - Hampshire vs Nottinghamshire
2026-07-18 - club - NTB - male - 1512887 - Northamptonshire vs Somerset
2026-07-15 - club - NTB - male - 1512886 - Yorkshire vs Somerset
2026-07-15 - club - NTB - male - 1512885 - Nottinghamshire vs Surrey
2026-07-15 - club - NTB - male - 1512884 - Gloucestershire vs Northamptonshire
2026-07-15 - club - NTB - male - 1512883 - Hampshire vs Essex
2026-07-12 - club - NTB - male - 1512882 - Middlesex vs Kent
2026-07-12 - club - NTB - male - 1512881 - Glamorgan vs Gloucestershire
2026-07-12 - club - NTB - male - 1512880 - Northamptonshire vs Warwickshire
2026-07-12 - club - NTB - male - 1512879 - Somerset vs Worcestershire
2026-07-12 - club - NTB - male - 1512878 - Leicestershire vs Derbyshire
2026-07-12 - club - NTB - male - 1512877 - Sussex vs Hampshire
2026-07-12 - club - NTB - male - 1512876 - Surrey vs Essex
2026-07-12 - club - NTB - male - 1512875 - Yorkshire vs Nottinghamshire
2026-07-12 - club - NTB - male - 1512874 - Durham vs Lancashire
2026-07-10 - club - NTB - male - 1512873 - Worcestershire vs Gloucestershire
2026-07-10 - club - NTB - male - 1512872 - Leicestershire vs Nottinghamshire
2026-07-10 - club - NTB - male - 1512871 - Kent vs Surrey
2026-07-10 - club - NTB - male - 1512870 - Northamptonshire vs Somerset
2026-07-10 - club - NTB - male - 1512869 - Sussex vs Middlesex
2026-07-10 - club - NTB - male - 1512868 - Lancashire vs Yorkshire
2026-07-10 - club - NTB - male - 1512867 - Glamorgan vs Warwickshire
2026-07-10 - club - NTB - male - 1512866 - Durham vs Derbyshire
2026-07-10 - club - NTB - male - 1512865 - Hampshire vs Essex
2026-07-08 - club - NTB - male - 1512864 - Hampshire vs Middlesex
2026-07-08 - club - NTB - male - 1512863 - Leicestershire vs Durham
2026-07-08 - club - NTB - male - 1512862 - Somerset vs Derbyshire
2026-07-08 - club - NTB - male - 1512861 - Northamptonshire vs Glamorgan
2026-07-08 - club - NTB - male - 1512860 - Sussex vs Surrey
2026-07-06 - club - NTB - male - 1512859 - Derbyshire vs Lancashire
2026-07-05 - club - NTB - male - 1512858 - Hampshire vs Kent
2026-07-05 - club - NTB - male - 1512857 - Somerset vs Northamptonshire
2026-07-05 - club - NTB - male - 1512856 - Worcestershire vs Glamorgan
2026-07-05 - club - NTB - male - 1512855 - Yorkshire vs Leicestershire
2026-07-05 - club - NTB - male - 1512854 - Warwickshire vs Gloucestershire
2026-07-05 - club - NTB - male - 1512853 - Nottinghamshire vs Durham
2026-07-05 - club - NTB - male - 1512852 - Essex vs Middlesex
2026-07-04 - club - NTB - male - 1512851 - Gloucestershire vs Surrey
2026-07-03 - club - NTB - male - 1512850 - Worcestershire vs Kent
2026-07-03 - club - NTB - male - 1512849 - Nottinghamshire vs Lancashire
2026-07-03 - club - NTB - male - 1512848 - Essex vs Sussex
2026-07-03 - club - NTB - male - 1512847 - Warwickshire vs Glamorgan
2026-07-03 - club - NTB - male - 1512846 - Durham vs Yorkshire
2026-07-01 - club - NTB - male - 1512845 - Gloucestershire vs Northamptonshire
2026-07-01 - club - NTB - male - 1512844 - Lancashire vs Derbyshire
2026-07-01 - club - NTB - male - 1512843 - Warwickshire vs Sussex
2026-07-01 - club - NTB - male - 1512842 - Surrey vs Essex
2026-06-28 - club - NTB - male - 1512841 - Worcestershire vs Somerset
2026-06-28 - club - NTB - male - 1512840 - Nottinghamshire vs Leicestershire
2026-06-28 - club - NTB - male - 1512839 - Hampshire vs Kent
2026-06-28 - club - NTB - male - 1512838 - Durham vs Middlesex
2026-06-28 - club - NTB - male - 1512837 - Derbyshire vs Yorkshire
2026-06-26 - club - NTB - male - 1512836 - Yorkshire vs Hampshire
2026-06-26 - club - NTB - male - 1512835 - Leicestershire vs Lancashire
2026-06-26 - club - NTB - male - 1512834 - Kent vs Nottinghamshire
2026-06-26 - club - NTB - male - 1512833 - Northamptonshire vs Essex
2026-06-26 - club - NTB - male - 1512832 - Somerset vs Gloucestershire
2026-06-26 - club - NTB - male - 1512831 - Sussex vs Surrey
2026-06-26 - club - NTB - male - 1512830 - Middlesex vs Glamorgan
2026-06-26 - club - NTB - male - 1512829 - Warwickshire vs Worcestershire
2026-06-09 - club - NTB - male - 1512828 - Worcestershire vs Northamptonshire
2026-06-09 - club - NTB - male - 1512827 - Durham vs Lancashire
2026-06-09 - club - NTB - male - 1512826 - Essex vs Kent
2026-06-07 - club - NTB - male - 1512825 - Leicestershire vs Yorkshire
2026-06-07 - club - NTB - male - 1512824 - Nottinghamshire vs Derbyshire
2026-06-07 - club - NTB - male - 1512823 - Gloucestershire vs Worcestershire
2026-06-07 - club - NTB - male - 1512822 - Somerset vs Warwickshire
2026-06-07 - club - NTB - male - 1512821 - Kent vs Sussex
2026-06-07 - club - NTB - male - 1512820 - Essex vs Middlesex
2026-06-07 - club - NTB - male - 1512819 - Lancashire vs Glamorgan
2026-06-06 - club - NTB - male - 1512818 - Northamptonshire vs Durham
2026-06-05 - club - NTB - male - 1512817 - Worcestershire vs Glamorgan
2026-06-05 - club - NTB - male - 1512816 - Warwickshire vs Nottinghamshire
2026-06-05 - club - NTB - male - 1512815 - Somerset vs Gloucestershire
2026-06-05 - club - NTB - male - 1512814 - Sussex vs Leicestershire
2026-06-05 - club - NTB - male - 1512813 - Hampshire vs Surrey
2026-06-05 - club - NTB - male - 1512812 - Yorkshire vs Lancashire
2026-06-04 - club - NTB - male - 1512811 - Somerset vs Glamorgan
2026-06-03 - club - NTB - male - 1512810 - Middlesex vs Surrey
2026-06-02 - club - NTB - male - 1512809 - Hampshire vs Sussex
2026-05-31 - club - NTB - male - 1512808 - Durham vs Nottinghamshire
2026-05-31 - club - NTB - male - 1512807 - Middlesex vs Hampshire
2026-05-31 - club - NTB - male - 1512806 - Surrey vs Kent
2026-05-31 - club - NTB - male - 1512805 - Gloucestershire vs Yorkshire
2026-05-31 - club - NTB - male - 1512804 - Warwickshire vs Northamptonshire
2026-05-31 - club - NTB - male - 1512803 - Derbyshire vs Essex
2026-05-30 - club - NTB - male - 1512802 - Middlesex vs Sussex
2026-05-29 - club - NTB - male - 1512801 - Warwickshire vs Worcestershire
2026-05-29 - club - NTB - male - 1512800 - Surrey vs Hampshire
2026-05-29 - club - NTB - male - 1512799 - Kent vs Essex
2026-05-29 - club - NTB - male - 1512798 - Gloucestershire vs Northamptonshire
2026-05-29 - club - NTB - male - 1512797 - Derbyshire vs Nottinghamshire
2026-05-29 - club - NTB - male - 1512796 - Somerset vs Glamorgan
2026-05-29 - club - NTB - male - 1512795 - Lancashire vs Leicestershire
2026-05-29 - club - NTB - male - 1512794 - Yorkshire vs Durham
2026-05-27 - club - NTB - male - 1512793 - Derbyshire vs Leicestershire
2026-05-26 - club - NTB - male - 1512792 - Hampshire vs Essex
2026-05-25 - club - NTB - male - 1512791 - Sussex vs Kent
2026-05-25 - club - NTB - male - 1512790 - Lancashire vs Nottinghamshire
2026-05-24 - club - NTB - male - 1512789 - Northamptonshire vs Worcestershire
2026-05-24 - club - NTB - male - 1512788 - Middlesex vs Surrey
2026-05-24 - club - NTB - male - 1512787 - Derbyshire vs Yorkshire
2026-05-24 - club - NTB - male - 1512786 - Birmingham Bears vs Somerset
2026-05-24 - club - NTB - male - 1512785 - Leicestershire vs Durham
2026-05-23 - club - NTB - male - 1512784 - Glamorgan vs Gloucestershire
2026-05-22 - club - NTB - male - 1512783 - Worcestershire vs Leicestershire
2026-05-22 - club - NTB - male - 1512782 - Nottinghamshire vs Yorkshire
2026-05-22 - club - NTB - male - 1512781 - Gloucestershire vs Birmingham Bears
2026-05-22 - club - NTB - male - 1512780 - Northamptonshire vs Glamorgan
2026-05-22 - club - NTB - male - 1512779 - Hampshire vs Somerset
2026-05-22 - club - NTB - male - 1512778 - Durham vs Derbyshire
2026-05-22 - club - NTB - male - 1512777 - Kent vs Middlesex
2026-05-22 - club - NTB - male - 1512776 - Surrey vs Lancashire
2026-05-22 - club - NTB - male - 1512775 - Essex vs Sussex
2025-09-13 - club - NTB - male - 1460886 - Hampshire vs Somerset
2025-09-13 - club - NTB - male - 1460885 - Northamptonshire vs Hampshire
2025-09-13 - club - NTB - male - 1460884 - Somerset vs Lancashire
2025-09-06 - club - NTB - male - 1460883 - Birmingham Bears vs Somerset
2025-09-06 - club - NTB - male - 1460882 - Kent vs Lancashire
2025-09-05 - club - NTB - male - 1460881 - Hampshire vs Durham
2025-09-03 - club - NTB - male - 1460880 - Northamptonshire vs Surrey
2025-07-18 - club - NTB - male - 1460879 - Surrey vs Sussex
2025-07-18 - club - NTB - male - 1460878 - Somerset vs Gloucestershire
2025-07-18 - club - NTB - male - 1460877 - Lancashire vs Nottinghamshire
2025-07-18 - club - NTB - male - 1460876 - Leicestershire vs Yorkshire
2025-07-18 - club - NTB - male - 1460875 - Essex vs Kent
2025-07-18 - club - NTB - male - 1460874 - Glamorgan vs Middlesex
2025-07-18 - club - NTB - male - 1460873 - Northamptonshire vs Durham
2025-07-18 - club - NTB - male - 1460872 - Birmingham Bears vs Derbyshire
2025-07-17 - club - NTB - male - 1460871 - Lancashire vs Yorkshire
2025-07-17 - club - NTB - male - 1460870 - Worcestershire vs Nottinghamshire
2025-07-17 - club - NTB - male - 1460869 - Gloucestershire vs Sussex
2025-07-17 - club - NTB - male - 1460868 - Hampshire vs Essex
2025-07-16 - club - NTB - male - 1460867 - Surrey vs Middlesex
2025-07-13 - club - NTB - male - 1460865 - Yorkshire vs Derbyshire
2025-07-13 - club - NTB - male - 1460864 - Leicestershire vs Worcestershire
2025-07-13 - club - NTB - male - 1460863 - Surrey vs Somerset
2025-07-13 - club - NTB - male - 1460862 - Durham vs Lancashire
2025-07-13 - club - NTB - male - 1460861 - Middlesex vs Kent
2025-07-13 - club - NTB - male - 1460860 - Sussex vs Hampshire
2025-07-13 - club - NTB - male - 1460859 - Gloucestershire vs Glamorgan
2025-07-13 - club - NTB - male - 1460858 - Northamptonshire vs Birmingham Bears
2025-07-11 - club - NTB - male - 1460857 - Birmingham Bears vs Worcestershire
2025-07-11 - club - NTB - male - 1460856 - Glamorgan vs Surrey
2025-07-11 - club - NTB - male - 1460855 - Durham vs Nottinghamshire
2025-07-11 - club - NTB - male - 1460854 - Northamptonshire vs Derbyshire
2025-07-11 - club - NTB - male - 1460853 - Middlesex vs Gloucestershire
2025-07-11 - club - NTB - male - 1460852 - Yorkshire vs Lancashire
2025-07-11 - club - NTB - male - 1460851 - Kent vs Somerset
2025-07-11 - club - NTB - male - 1460850 - Sussex vs Essex
2025-07-10 - club - NTB - male - 1460849 - Northamptonshire vs Leicestershire
2025-07-10 - club - NTB - male - 1460848 - Hampshire vs Glamorgan
2025-07-10 - club - NTB - male - 1460847 - Worcestershire vs Derbyshire
2025-07-09 - club - NTB - male - 1460846 - Sussex vs Kent
2025-07-09 - club - NTB - male - 1460845 - Middlesex vs Hampshire
2025-07-09 - club - NTB - male - 1460844 - Surrey vs Gloucestershire
2025-07-09 - club - NTB - male - 1460843 - Birmingham Bears vs Lancashire
2025-07-08 - club - NTB - male - 1460842 - Somerset vs Essex
2025-07-06 - club - NTB - male - 1460841 - Surrey vs Essex
2025-07-06 - club - NTB - male - 1460840 - Leicestershire vs Nottinghamshire
2025-07-06 - club - NTB - male - 1460839 - Northamptonshire vs Worcestershire
2025-07-06 - club - NTB - male - 1460838 - Hampshire vs Somerset
2025-07-06 - club - NTB - male - 1460837 - Gloucestershire vs Middlesex
2025-07-06 - club - NTB - male - 1460836 - Kent vs Glamorgan
2025-07-06 - club - NTB - male - 1460835 - Durham vs Birmingham Bears
2025-07-06 - club - NTB - male - 1460834 - Yorkshire vs Derbyshire
2025-07-05 - club - NTB - male - 1460833 - Hampshire vs Sussex
2025-07-05 - club - NTB - male - 1460832 - Lancashire vs Derbyshire
2025-07-04 - club - NTB - male - 1460831 - Yorkshire vs Worcestershire
2025-07-04 - club - NTB - male - 1460830 - Glamorgan vs Somerset
2025-07-04 - club - NTB - male - 1460829 - Northamptonshire vs Lancashire
2025-07-04 - club - NTB - male - 1460828 - Leicestershire vs Birmingham Bears
2025-07-04 - club - NTB - male - 1460827 - Sussex vs Kent
2025-07-04 - club - NTB - male - 1460826 - Gloucestershire vs Essex
2025-07-04 - club - NTB - male - 1460825 - Durham vs Nottinghamshire
2025-06-20 - club - NTB - male - 1460824 - Surrey vs Middlesex
2025-06-20 - club - NTB - male - 1460823 - Nottinghamshire vs Northamptonshire
2025-06-20 - club - NTB - male - 1460822 - Hampshire vs Gloucestershire
2025-06-20 - club - NTB - male - 1460821 - Glamorgan vs Somerset
2025-06-20 - club - NTB - male - 1460820 - Kent vs Essex
2025-06-20 - club - NTB - male - 1460819 - Durham vs Yorkshire
2025-06-20 - club - NTB - male - 1460818 - Lancashire vs Derbyshire
2025-06-20 - club - NTB - male - 1460817 - Worcestershire vs Birmingham Bears
2025-06-19 - club - NTB - male - 1460816 - Somerset vs Hampshire
2025-06-19 - club - NTB - male - 1460815 - Middlesex vs Essex
2025-06-19 - club - NTB - male - 1460814 - Nottinghamshire vs Leicestershire
2025-06-18 - club - NTB - male - 1460813 - Durham vs Worcestershire
2025-06-18 - club - NTB - male - 1460812 - Surrey vs Sussex
2025-06-18 - club - NTB - male - 1460811 - Kent vs Gloucestershire
2025-06-17 - club - NTB - male - 1460810 - Surrey vs Hampshire
2025-06-15 - club - NTB - male - 1460809 - Yorkshire vs Durham
2025-06-15 - club - NTB - male - 1460808 - Kent vs Somerset
2025-06-15 - club - NTB - male - 1460807 - Worcestershire vs Leicestershire
2025-06-15 - club - NTB - male - 1460806 - Glamorgan vs Gloucestershire
2025-06-14 - club - NTB - male - 1460805 - Sussex vs Glamorgan
2025-06-14 - club - NTB - male - 1460804 - Leicestershire vs Derbyshire
2025-06-14 - club - NTB - male - 1460803 - Birmingham Bears vs Nottinghamshire
2025-06-13 - club - NTB - male - 1460802 - Birmingham Bears vs Yorkshire
2025-06-13 - club - NTB - male - 1460801 - Worcestershire vs Lancashire
2025-06-13 - club - NTB - male - 1460800 - Essex vs Sussex
2025-06-13 - club - NTB - male - 1460799 - Derbyshire vs Nottinghamshire
2025-06-13 - club - NTB - male - 1460798 - Durham vs Northamptonshire
2025-06-13 - club - NTB - male - 1460797 - Hampshire vs Middlesex
2025-06-13 - club - NTB - male - 1460796 - Gloucestershire vs Somerset
2025-06-12 - club - NTB - male - 1460795 - Kent vs Surrey
2025-06-12 - club - NTB - male - 1460794 - Middlesex vs Somerset
2025-06-12 - club - NTB - male - 1460793 - Glamorgan vs Essex
2025-06-11 - club - NTB - male - 1460792 - Yorkshire vs Nottinghamshire
2025-06-11 - club - NTB - male - 1460791 - Northamptonshire vs Birmingham Bears
2025-06-11 - club - NTB - male - 1460790 - Durham vs Derbyshire
2025-06-08 - club - NTB - male - 1460789 - Yorkshire vs Leicestershire
2025-06-08 - club - NTB - male - 1460788 - Sussex vs Glamorgan
2025-06-08 - club - NTB - male - 1460787 - Northamptonshire vs Lancashire
2025-06-08 - club - NTB - male - 1460786 - Hampshire vs Kent
2025-06-08 - club - NTB - male - 1460785 - Essex vs Middlesex
2025-06-08 - club - NTB - male - 1460784 - Birmingham Bears vs Derbyshire
2025-06-07 - club - NTB - male - 1460783 - Worcestershire vs Nottinghamshire
2025-06-06 - club - NTB - male - 1460782 - Northamptonshire vs Worcestershire
2025-06-06 - club - NTB - male - 1460781 - Sussex vs Somerset
2025-06-06 - club - NTB - male - 1460780 - Leicestershire vs Durham
2025-06-06 - club - NTB - male - 1460779 - Surrey vs Kent
2025-06-06 - club - NTB - male - 1460778 - Gloucestershire vs Hampshire
2025-06-06 - club - NTB - male - 1460777 - Essex vs Glamorgan
2025-06-06 - club - NTB - male - 1460776 - Derbyshire vs Nottinghamshire
2025-06-06 - club - NTB - male - 1460775 - Yorkshire vs Birmingham Bears
2025-06-05 - club - NTB - male - 1460774 - Surrey vs Hampshire
2025-06-05 - club - NTB - male - 1460773 - Kent vs Middlesex
2025-06-04 - club - NTB - male - 1460772 - Lancashire vs Leicestershire
2025-06-04 - club - NTB - male - 1460771 - Northamptonshire vs Derbyshire
2025-06-03 - club - NTB - male - 1460770 - Surrey vs Glamorgan
2025-06-01 - club - NTB - male - 1460769 - Sussex vs Gloucestershire
2025-06-01 - club - NTB - male - 1460768 - Leicestershire vs Northamptonshire
2025-06-01 - club - NTB - male - 1460767 - Middlesex vs Glamorgan
2025-06-01 - club - NTB - male - 1460766 - Essex vs Somerset
2025-06-01 - club - NTB - male - 1460765 - Worcestershire vs Yorkshire
2025-06-01 - club - NTB - male - 1460764 - Durham vs Lancashire
2025-05-31 - club - NTB - male - 1460763 - Lancashire vs Nottinghamshire
2025-05-31 - club - NTB - male - 1460762 - Birmingham Bears vs Durham
2025-05-30 - club - NTB - male - 1460761 - Northamptonshire vs Yorkshire
2025-05-30 - club - NTB - male - 1460760 - Surrey vs Somerset
2025-05-30 - club - NTB - male - 1460759 - Birmingham Bears vs Nottinghamshire
2025-05-30 - club - NTB - male - 1460758 - Derbyshire vs Leicestershire
2025-05-30 - club - NTB - male - 1460757 - Hampshire vs Essex
2025-05-30 - club - NTB - male - 1460756 - Kent vs Gloucestershire
2025-05-29 - club - NTB - male - 1460755 - Sussex vs Middlesex
2025-05-29 - club - NTB - male - 1460754 - Lancashire vs Worcestershire
2024-09-14 - club - NTB - male - 1410502 - Somerset vs Gloucestershire
2024-09-14 - club - NTB - male - 1410501 - Sussex vs Gloucestershire
2024-09-14 - club - NTB - male - 1410500 - Surrey vs Somerset
2024-09-06 - club - NTB - male - 1410499 - Gloucestershire vs Birmingham Bears
2024-09-05 - club - NTB - male - 1410498 - Somerset vs Northamptonshire
2024-09-04 - club - NTB - male - 1410497 - Lancashire vs Sussex
2024-09-03 - club - NTB - male - 1410496 - Durham vs Surrey
2024-07-19 - club - NTB - male - 1410495 - Nottinghamshire vs Yorkshire
2024-07-19 - club - NTB - male - 1410494 - Birmingham Bears vs Leicestershire
2024-07-19 - club - NTB - male - 1410493 - Middlesex vs Sussex
2024-07-19 - club - NTB - male - 1410492 - Lancashire vs Northamptonshire
2024-07-19 - club - NTB - male - 1410491 - Kent vs Surrey
2024-07-19 - club - NTB - male - 1410490 - Hampshire vs Essex
2024-07-19 - club - NTB - male - 1410489 - Glamorgan vs Somerset
2024-07-19 - club - NTB - male - 1410488 - Derbyshire vs Durham
2024-07-18 - club - NTB - male - 1410487 - Worcestershire vs Derbyshire
2024-07-18 - club - NTB - male - 1410486 - Hampshire vs Surrey
2024-07-18 - club - NTB - male - 1410485 - Sussex vs Somerset
2024-07-18 - club - NTB - male - 1410484 - Northamptonshire vs Birmingham Bears
2024-07-18 - club - NTB - male - 1410483 - Gloucestershire vs Middlesex
2024-07-17 - club - NTB - male - 1410482 - Nottinghamshire vs Lancashire
2024-07-16 - club - NTB - male - 1410481 - Glamorgan vs Kent
2024-07-14 - club - NTB - male - 1410480 - Worcestershire vs Yorkshire
2024-07-14 - club - NTB - male - 1410479 - Birmingham Bears vs Derbyshire
2024-07-14 - club - NTB - male - 1410478 - Nottinghamshire vs Leicestershire
2024-07-14 - club - NTB - male - 1410477 - Hampshire vs Somerset
2024-07-14 - club - NTB - male - 1410476 - Gloucestershire vs Glamorgan
2024-07-14 - club - NTB - male - 1410475 - Surrey vs Essex
2024-07-14 - club - NTB - male - 1410474 - Durham vs Northamptonshire
2024-07-13 - club - NTB - male - 1410473 - Sussex vs Essex
2024-07-12 - club - NTB - male - 1410472 - Worcestershire vs Birmingham Bears
2024-07-12 - club - NTB - male - 1410471 - Surrey vs Somerset
2024-07-12 - club - NTB - male - 1410470 - Northamptonshire vs Leicestershire
2024-07-12 - club - NTB - male - 1410468 - Sussex vs Kent
2024-07-12 - club - NTB - male - 1410467 - Gloucestershire vs Hampshire
2024-07-12 - club - NTB - male - 1410466 - Glamorgan vs Middlesex
2024-07-12 - club - NTB - male - 1410465 - Durham vs Nottinghamshire
2024-07-11 - club - NTB - male - 1410464 - Durham vs Yorkshire
2024-07-11 - club - NTB - male - 1410463 - Worcestershire vs Leicestershire
2024-07-11 - club - NTB - male - 1410462 - Middlesex vs Gloucestershire
2024-07-11 - club - NTB - male - 1410461 - Essex vs Kent
2024-07-10 - club - NTB - male - 1410459 - Sussex vs Hampshire
2024-07-07 - club - NTB - male - 1410458 - Surrey vs Kent
2024-07-07 - club - NTB - male - 1410457 - Somerset vs Gloucestershire
2024-07-07 - club - NTB - male - 1410456 - Nottinghamshire vs Birmingham Bears
2024-07-07 - club - NTB - male - 1410455 - Durham vs Northamptonshire
2024-07-07 - club - NTB - male - 1410454 - Worcestershire vs Lancashire
2024-07-07 - club - NTB - male - 1410453 - Glamorgan vs Essex
2024-07-07 - club - NTB - male - 1410452 - Yorkshire vs Derbyshire
2024-07-06 - club - NTB - male - 1410450 - Leicestershire vs Derbyshire
2024-07-05 - club - NTB - male - 1410449 - Birmingham Bears vs Yorkshire
2024-07-05 - club - NTB - male - 1410448 - Glamorgan vs Sussex
2024-07-05 - club - NTB - male - 1410446 - Nottinghamshire vs Leicestershire
2024-07-05 - club - NTB - male - 1410444 - Kent vs Gloucestershire
2024-07-05 - club - NTB - male - 1410442 - Durham vs Worcestershire
2024-06-21 - club - NTB - male - 1410441 - Worcestershire vs Birmingham Bears
2024-06-21 - club - NTB - male - 1410440 - Glamorgan vs Surrey
2024-06-21 - club - NTB - male - 1410439 - Nottinghamshire vs Derbyshire
2024-06-21 - club - NTB - male - 1410438 - Northamptonshire vs Leicestershire
2024-06-21 - club - NTB - male - 1410437 - Kent vs Essex
2024-06-21 - club - NTB - male - 1410436 - Sussex vs Hampshire
2024-06-21 - club - NTB - male - 1410435 - Somerset vs Gloucestershire
2024-06-21 - club - NTB - male - 1410434 - Durham vs Yorkshire
2024-06-20 - club - NTB - male - 1410433 - Yorkshire vs Lancashire
2024-06-20 - club - NTB - male - 1410432 - Birmingham Bears vs Northamptonshire
2024-06-20 - club - NTB - male - 1410431 - Sussex vs Kent
2024-06-20 - club - NTB - male - 1410430 - Surrey vs Middlesex
2024-06-20 - club - NTB - male - 1410429 - Glamorgan vs Gloucestershire
2024-06-20 - club - NTB - male - 1410428 - Hampshire vs Essex
2024-06-16 - club - NTB - male - 1410427 - Leicestershire vs Yorkshire
2024-06-16 - club - NTB - male - 1410426 - Northamptonshire vs Worcestershire
2024-06-16 - club - NTB - male - 1410425 - Somerset vs Glamorgan
2024-06-16 - club - NTB - male - 1410424 - Kent vs Gloucestershire
2024-06-16 - club - NTB - male - 1410423 - Durham vs Lancashire
2024-06-16 - club - NTB - male - 1410422 - Derbyshire vs Birmingham Bears
2024-06-15 - club - NTB - male - 1410421 - Surrey vs Sussex
2024-06-15 - club - NTB - male - 1410420 - Durham vs Nottinghamshire
2024-06-14 - club - NTB - male - 1410419 - Worcestershire vs Nottinghamshire
2024-06-14 - club - NTB - male - 1410418 - Yorkshire vs Birmingham Bears
2024-06-14 - club - NTB - male - 1410417 - Gloucestershire vs Surrey
2024-06-14 - club - NTB - male - 1410416 - Somerset vs Kent
2024-06-14 - club - NTB - male - 1410415 - Lancashire vs Leicestershire
2024-06-14 - club - NTB - male - 1410414 - Middlesex vs Hampshire
2024-06-14 - club - NTB - male - 1410413 - Essex vs Sussex
2024-06-14 - club - NTB - male - 1410412 - Northamptonshire vs Derbyshire
2024-06-13 - club - NTB - male - 1410411 - Essex vs Middlesex
2024-06-12 - club - NTB - male - 1410409 - Leicestershire vs Durham
2024-06-11 - club - NTB - male - 1410408 - Middlesex vs Somerset
2024-06-09 - club - NTB - male - 1410407 - Derbyshire vs Yorkshire
2024-06-09 - club - NTB - male - 1410406 - Somerset vs Hampshire
2024-06-09 - club - NTB - male - 1410405 - Nottinghamshire vs Lancashire
2024-06-09 - club - NTB - male - 1410404 - Leicestershire vs Worcestershire
2024-06-09 - club - NTB - male - 1410403 - Kent vs Middlesex
2024-06-09 - club - NTB - male - 1410402 - Sussex vs Gloucestershire
2024-06-08 - club - NTB - male - 1410401 - Durham vs Birmingham Bears
2024-06-07 - club - NTB - male - 1410400 - Sussex vs Surrey
2024-06-07 - club - NTB - male - 1410399 - Northamptonshire vs Worcestershire
2024-06-07 - club - NTB - male - 1410398 - Leicestershire vs Durham
2024-06-07 - club - NTB - male - 1410397 - Lancashire vs Birmingham Bears
2024-06-07 - club - NTB - male - 1410396 - Somerset vs Kent
2024-06-07 - club - NTB - male - 1410395 - Gloucestershire vs Hampshire
2024-06-07 - club - NTB - male - 1410394 - Glamorgan vs Essex
2024-06-07 - club - NTB - male - 1410393 - Derbyshire vs Nottinghamshire
2024-06-06 - club - NTB - male - 1410392 - Worcestershire vs Nottinghamshire
2024-06-06 - club - NTB - male - 1410391 - Middlesex vs Glamorgan
2024-06-02 - club - NTB - male - 1410390 - Surrey vs Somerset
2024-06-02 - club - NTB - male - 1410389 - Yorkshire vs Northamptonshire
2024-06-02 - club - NTB - male - 1410388 - Lancashire vs Derbyshire
2024-06-02 - club - NTB - male - 1410387 - Kent vs Hampshire
2024-06-02 - club - NTB - male - 1410386 - Glamorgan vs Sussex
2024-06-02 - club - NTB - male - 1410385 - Middlesex vs Essex
2024-06-01 - club - NTB - male - 1410384 - Leicestershire vs Derbyshire
2024-06-01 - club - NTB - male - 1410383 - Birmingham Bears vs Nottinghamshire
2024-05-31 - club - NTB - male - 1423080 - Yorkshire vs Leicestershire
2024-05-31 - club - NTB - male - 1410382 - Lancashire vs Worcestershire
2024-05-31 - club - NTB - male - 1410381 - Gloucestershire vs Sussex
2024-05-31 - club - NTB - male - 1410380 - Essex vs Somerset
2024-05-31 - club - NTB - male - 1410379 - Nottinghamshire vs Northamptonshire
2024-05-31 - club - NTB - male - 1410378 - Kent vs Middlesex
2024-05-31 - club - NTB - male - 1410377 - Surrey vs Glamorgan
2024-05-31 - club - NTB - male - 1410376 - Durham vs Birmingham Bears
2024-05-30 - club - NTB - male - 1410375 - Worcestershire vs Yorkshire
2024-05-30 - club - NTB - male - 1410374 - Derbyshire vs Northamptonshire
2024-05-30 - club - NTB - male - 1410373 - Durham vs Lancashire
2024-05-30 - club - NTB - male - 1410372 - Hampshire vs Surrey
2024-05-30 - club - NTB - male - 1410371 - Essex vs Gloucestershire
2023-07-15 - club - NTB - male - 1347700 - Somerset vs Essex
2023-07-15 - club - NTB - male - 1347699 - Somerset vs Surrey
2023-07-15 - club - NTB - male - 1347698 - Hampshire vs Essex
2023-07-07 - club - NTB - male - 1347697 - Worcestershire vs Hampshire
2023-07-07 - club - NTB - male - 1347696 - Nottinghamshire vs Somerset
2023-07-07 - club - NTB - male - 1347695 - Surrey vs Lancashire
2023-07-06 - club - NTB - male - 1347694 - Birmingham Bears vs Essex
2023-07-02 - club - NTB - male - 1347693 - Nottinghamshire vs Leicestershire
2023-07-02 - club - NTB - male - 1347692 - Gloucestershire vs Hampshire
2023-07-02 - club - NTB - male - 1347691 - Worcestershire vs Derbyshire
2023-07-02 - club - NTB - male - 1347690 - Surrey vs Essex
2023-07-02 - club - NTB - male - 1347689 - Somerset vs Kent
2023-07-02 - club - NTB - male - 1347688 - Northamptonshire vs Lancashire
2023-07-02 - club - NTB - male - 1347687 - Middlesex vs Glamorgan
2023-07-02 - club - NTB - male - 1347686 - Birmingham Bears vs Durham
2023-07-01 - club - NTB - male - 1347685 - Sussex vs Gloucestershire
2023-06-30 - club - NTB - male - 1347684 - Nottinghamshire vs Birmingham Bears
2023-06-30 - club - NTB - male - 1347683 - Sussex vs Kent
2023-06-30 - club - NTB - male - 1347682 - Derbyshire vs Leicestershire
2023-06-30 - club - NTB - male - 1347681 - Essex vs Middlesex
2023-06-30 - club - NTB - male - 1347680 - Durham vs Worcestershire
2023-06-30 - club - NTB - male - 1347679 - Somerset vs Surrey
2023-06-30 - club - NTB - male - 1347677 - Hampshire vs Glamorgan
2023-06-23 - club - NTB - male - 1347676 - Northamptonshire vs Leicestershire
2023-06-23 - club - NTB - male - 1347675 - Kent vs Middlesex
2023-06-23 - club - NTB - male - 1347674 - Gloucestershire vs Somerset
2023-06-23 - club - NTB - male - 1347673 - Sussex vs Glamorgan
2023-06-23 - club - NTB - male - 1347672 - Yorkshire vs Durham
2023-06-23 - club - NTB - male - 1347671 - Lancashire vs Derbyshire
2023-06-23 - club - NTB - male - 1347670 - Birmingham Bears vs Worcestershire
2023-06-23 - club - NTB - male - 1347669 - Essex vs Hampshire
2023-06-22 - club - NTB - male - 1347668 - Gloucestershire vs Sussex
2023-06-22 - club - NTB - male - 1347667 - Essex vs Kent
2023-06-22 - club - NTB - male - 1347666 - Nottinghamshire vs Worcestershire
2023-06-22 - club - NTB - male - 1347665 - Surrey vs Middlesex
2023-06-22 - club - NTB - male - 1347664 - Birmingham Bears vs Yorkshire
2023-06-21 - club - NTB - male - 1347663 - Glamorgan vs Somerset
2023-06-21 - club - NTB - male - 1347662 - Northamptonshire vs Derbyshire
2023-06-20 - club - NTB - male - 1347661 - Nottinghamshire vs Leicestershire
2023-06-20 - club - NTB - male - 1347660 - Hampshire vs Gloucestershire
2023-06-20 - club - NTB - male - 1347659 - Sussex vs Kent
2023-06-20 - club - NTB - male - 1347658 - Durham vs Birmingham Bears
2023-06-20 - club - NTB - male - 1347657 - Lancashire vs Worcestershire
2023-06-20 - club - NTB - male - 1347656 - Surrey vs Glamorgan
2023-06-20 - club - NTB - male - 1347655 - Northamptonshire vs Yorkshire
2023-06-19 - club - NTB - male - 1347654 - Essex vs Somerset
2023-06-18 - club - NTB - male - 1347653 - Leicestershire vs Worcestershire
2023-06-18 - club - NTB - male - 1347652 - Northamptonshire vs Nottinghamshire
2023-06-18 - club - NTB - male - 1347651 - Glamorgan vs Gloucestershire
2023-06-18 - club - NTB - male - 1347650 - Essex vs Middlesex
2023-06-18 - club - NTB - male - 1347649 - Surrey vs Hampshire
2023-06-18 - club - NTB - male - 1347648 - Lancashire vs Durham
2023-06-18 - club - NTB - male - 1347647 - Derbyshire vs Yorkshire
2023-06-17 - club - NTB - male - 1347646 - Gloucestershire vs Kent
2023-06-16 - club - NTB - male - 1347645 - Lancashire vs Northamptonshire
2023-06-16 - club - NTB - male - 1347644 - Surrey vs Somerset
2023-06-16 - club - NTB - male - 1347643 - Glamorgan vs Essex
2023-06-16 - club - NTB - male - 1347642 - Sussex vs Hampshire
2023-06-16 - club - NTB - male - 1347641 - Durham vs Derbyshire
2023-06-16 - club - NTB - male - 1347640 - Birmingham Bears vs Worcestershire
2023-06-16 - club - NTB - male - 1347639 - Kent vs Middlesex
2023-06-16 - club - NTB - male - 1347638 - Leicestershire vs Yorkshire
2023-06-09 - club - NTB - male - 1347637 - Durham vs Leicestershire
2023-06-09 - club - NTB - male - 1347636 - Hampshire vs Kent
2023-06-09 - club - NTB - male - 1347635 - Somerset vs Gloucestershire
2023-06-09 - club - NTB - male - 1347634 - Derbyshire vs Nottinghamshire
2023-06-09 - club - NTB - male - 1347633 - Surrey vs Sussex
2023-06-09 - club - NTB - male - 1347632 - Essex vs Glamorgan
2023-06-09 - club - NTB - male - 1347631 - Yorkshire vs Worcestershire
2023-06-09 - club - NTB - male - 1347630 - Birmingham Bears vs Northamptonshire
2023-06-08 - club - NTB - male - 1347629 - Nottinghamshire vs Durham
2023-06-08 - club - NTB - male - 1347628 - Sussex vs Middlesex
2023-06-07 - club - NTB - male - 1347627 - Birmingham Bears vs Derbyshire
2023-06-07 - club - NTB - male - 1347626 - Kent vs Essex
2023-06-07 - club - NTB - male - 1347625 - Surrey vs Glamorgan
2023-06-07 - club - NTB - male - 1347624 - Worcestershire vs Lancashire
2023-06-07 - club - NTB - male - 1347623 - Hampshire vs Somerset
2023-06-06 - club - NTB - male - 1347622 - Yorkshire vs Leicestershire
2023-06-06 - club - NTB - male - 1347621 - Sussex vs Essex
2023-06-06 - club - NTB - male - 1347620 - Hampshire vs Middlesex
2023-06-06 - club - NTB - male - 1347619 - Northamptonshire vs Durham
2023-06-04 - club - NTB - male - 1347618 - Worcestershire vs Northamptonshire
2023-06-04 - club - NTB - male - 1347617 - Kent vs Surrey
2023-06-04 - club - NTB - male - 1347616 - Somerset vs Essex
2023-06-04 - club - NTB - male - 1347615 - Glamorgan vs Sussex
2023-06-04 - club - NTB - male - 1347614 - Durham vs Leicestershire
2023-06-04 - club - NTB - male - 1347613 - Lancashire vs Nottinghamshire
2023-06-04 - club - NTB - male - 1347612 - Middlesex vs Gloucestershire
2023-06-04 - club - NTB - male - 1347611 - Derbyshire vs Yorkshire
2023-06-03 - club - NTB - male - 1347610 - Nottinghamshire vs Birmingham Bears
2023-06-03 - club - NTB - male - 1347609 - Sussex vs Hampshire
2023-06-02 - club - NTB - male - 1347608 - Worcestershire vs Nottinghamshire
2023-06-02 - club - NTB - male - 1347607 - Surrey vs Gloucestershire
2023-06-02 - club - NTB - male - 1347606 - Derbyshire vs Birmingham Bears
2023-06-02 - club - NTB - male - 1347605 - Leicestershire vs Northamptonshire
2023-06-02 - club - NTB - male - 1347604 - Middlesex vs Somerset
2023-06-02 - club - NTB - male - 1347603 - Hampshire vs Essex
2023-06-02 - club - NTB - male - 1347602 - Kent vs Glamorgan
2023-06-02 - club - NTB - male - 1347601 - Lancashire vs Durham
2023-06-01 - club - NTB - male - 1347600 - Derbyshire vs Leicestershire
2023-06-01 - club - NTB - male - 1347599 - Essex vs Sussex
2023-06-01 - club - NTB - male - 1347598 - Yorkshire vs Lancashire
2023-05-31 - club - NTB - male - 1347597 - Glamorgan vs Middlesex
2023-05-31 - club - NTB - male - 1347596 - Birmingham Bears vs Northamptonshire
2023-05-31 - club - NTB - male - 1347595 - Hampshire vs Surrey
2023-05-30 - club - NTB - male - 1347594 - Yorkshire vs Nottinghamshire
2023-05-30 - club - NTB - male - 1347593 - Somerset vs Kent
2023-05-30 - club - NTB - male - 1347592 - Gloucestershire vs Essex
2023-05-29 - club - NTB - male - 1347591 - Durham vs Nottinghamshire
2023-05-29 - club - NTB - male - 1347590 - Lancashire vs Birmingham Bears
2023-05-29 - club - NTB - male - 1347589 - Gloucestershire vs Middlesex
2023-05-29 - club - NTB - male - 1347588 - Derbyshire vs Northamptonshire
2023-05-29 - club - NTB - male - 1347587 - Worcestershire vs Leicestershire
2023-05-28 - club - NTB - male - 1347586 - Surrey vs Sussex
2023-05-28 - club - NTB - male - 1347585 - Glamorgan vs Somerset
2023-05-28 - club - NTB - male - 1347584 - Durham vs Yorkshire
2023-05-27 - club - NTB - male - 1347583 - Lancashire vs Nottinghamshire
2023-05-26 - club - NTB - male - 1347582 - Yorkshire vs Worcestershire
2023-05-26 - club - NTB - male - 1347581 - Derbyshire vs Nottinghamshire
2023-05-26 - club - NTB - male - 1347580 - Gloucestershire vs Glamorgan
2023-05-26 - club - NTB - male - 1347579 - Northamptonshire vs Durham
2023-05-26 - club - NTB - male - 1347578 - Middlesex vs Hampshire
2023-05-26 - club - NTB - male - 1347577 - Leicestershire vs Birmingham Bears
2023-05-26 - club - NTB - male - 1347576 - Sussex vs Somerset
2023-05-26 - club - NTB - male - 1347575 - Surrey vs Kent
2023-05-25 - club - NTB - male - 1347574 - Surrey vs Middlesex
2023-05-25 - club - NTB - male - 1347573 - Leicestershire vs Lancashire
2023-05-24 - club - NTB - male - 1347572 - Gloucestershire vs Kent
2023-05-24 - club - NTB - male - 1347571 - Worcestershire vs Northamptonshire
2023-05-24 - club - NTB - male - 1347570 - Hampshire vs Somerset
2023-05-20 - club - NTB - male - 1347569 - Derbyshire vs Lancashire
2023-05-20 - club - NTB - male - 1347568 - Birmingham Bears vs Yorkshire
2022-07-16 - club - NTB - male - 1297926 - Hampshire vs Lancashire
2022-07-16 - club - NTB - male - 1297925 - Hampshire vs Somerset
2022-07-16 - club - NTB - male - 1297924 - Yorkshire vs Lancashire
2022-07-09 - club - NTB - male - 1297923 - Somerset vs Derbyshire
2022-07-08 - club - NTB - male - 1297922 - Essex vs Lancashire
2022-07-07 - club - NTB - male - 1297921 - Hampshire vs Birmingham Bears
2022-07-06 - club - NTB - male - 1297920 - Yorkshire vs Surrey
2022-07-03 - club - NTB - male - 1297919 - Leicestershire vs Yorkshire
2022-07-03 - club - NTB - male - 1297918 - Durham vs Derbyshire
2022-07-03 - club - NTB - male - 1297917 - Somerset vs Surrey
2022-07-03 - club - NTB - male - 1297916 - Sussex vs Hampshire
2022-07-03 - club - NTB - male - 1297915 - Worcestershire vs Nottinghamshire
2022-07-03 - club - NTB - male - 1297914 - Birmingham Bears vs Lancashire
2022-07-03 - club - NTB - male - 1297913 - Glamorgan vs Kent
2022-07-03 - club - NTB - male - 1297912 - Middlesex vs Gloucestershire
2022-07-02 - club - NTB - male - 1297911 - Essex vs Glamorgan
2022-07-01 - club - NTB - male - 1297910 - Leicestershire vs Northamptonshire
2022-07-01 - club - NTB - male - 1297909 - Durham vs Nottinghamshire
2022-07-01 - club - NTB - male - 1297908 - Essex vs Sussex
2022-07-01 - club - NTB - male - 1297907 - Worcestershire vs Lancashire
2022-07-01 - club - NTB - male - 1297906 - Middlesex vs Somerset
2022-07-01 - club - NTB - male - 1297905 - Kent vs Surrey
2022-07-01 - club - NTB - male - 1297904 - Birmingham Bears vs Yorkshire
2022-07-01 - club - NTB - male - 1297903 - Hampshire vs Gloucestershire
2022-06-24 - club - NTB - male - 1297902 - Derbyshire vs Lancashire
2022-06-24 - club - NTB - male - 1297901 - Yorkshire vs Northamptonshire
2022-06-24 - club - NTB - male - 1297900 - Essex vs Surrey
2022-06-24 - club - NTB - male - 1297899 - Somerset vs Glamorgan
2022-06-24 - club - NTB - male - 1297898 - Nottinghamshire vs Durham
2022-06-24 - club - NTB - male - 1297897 - Birmingham Bears vs Worcestershire
2022-06-24 - club - NTB - male - 1297896 - Sussex vs Kent
2022-06-24 - club - NTB - male - 1297895 - Hampshire vs Gloucestershire
2022-06-23 - club - NTB - male - 1297894 - Nottinghamshire vs Derbyshire
2022-06-23 - club - NTB - male - 1297893 - Hampshire vs Somerset
2022-06-23 - club - NTB - male - 1297892 - Sussex vs Surrey
2022-06-23 - club - NTB - male - 1297891 - Lancashire vs Durham
2022-06-23 - club - NTB - male - 1297890 - Worcestershire vs Yorkshire
2022-06-23 - club - NTB - male - 1297889 - Essex vs Middlesex
2022-06-22 - club - NTB - male - 1297888 - Northamptonshire vs Birmingham Bears
2022-06-21 - club - NTB - male - 1297887 - Leicestershire vs Nottinghamshire
2022-06-21 - club - NTB - male - 1297886 - Northamptonshire vs Derbyshire
2022-06-21 - club - NTB - male - 1297885 - Middlesex vs Glamorgan
2022-06-21 - club - NTB - male - 1297884 - Somerset vs Surrey
2022-06-21 - club - NTB - male - 1297883 - Gloucestershire vs Kent
2022-06-19 - club - NTB - male - 1297882 - Essex vs Somerset
2022-06-19 - club - NTB - male - 1297881 - Nottinghamshire vs Lancashire
2022-06-19 - club - NTB - male - 1297880 - Sussex vs Glamorgan
2022-06-19 - club - NTB - male - 1297879 - Leicestershire vs Durham
2022-06-19 - club - NTB - male - 1297878 - Kent vs Middlesex
2022-06-19 - club - NTB - male - 1297877 - Birmingham Bears vs Derbyshire
2022-06-19 - club - NTB - male - 1297876 - Hampshire vs Surrey
2022-06-18 - club - NTB - male - 1297874 - Yorkshire vs Derbyshire
2022-06-17 - club - NTB - male - 1297872 - Worcestershire vs Leicestershire
2022-06-17 - club - NTB - male - 1297871 - Birmingham Bears vs Nottinghamshire
2022-06-17 - club - NTB - male - 1297870 - Lancashire vs Northamptonshire
2022-06-17 - club - NTB - male - 1297869 - Somerset vs Gloucestershire
2022-06-17 - club - NTB - male - 1297868 - Essex vs Sussex
2022-06-17 - club - NTB - male - 1297867 - Yorkshire vs Durham
2022-06-17 - club - NTB - male - 1297866 - Middlesex vs Surrey
2022-06-17 - club - NTB - male - 1297865 - Hampshire vs Kent
2022-06-10 - club - NTB - male - 1297864 - Leicestershire vs Nottinghamshire
2022-06-10 - club - NTB - male - 1297863 - Kent vs Somerset
2022-06-10 - club - NTB - male - 1297862 - Essex vs Middlesex
2022-06-10 - club - NTB - male - 1297861 - Gloucestershire vs Sussex
2022-06-10 - club - NTB - male - 1297860 - Hampshire vs Glamorgan
2022-06-10 - club - NTB - male - 1297859 - Lancashire vs Durham
2022-06-10 - club - NTB - male - 1297858 - Derbyshire vs Worcestershire
2022-06-10 - club - NTB - male - 1297857 - Birmingham Bears vs Yorkshire
2022-06-09 - club - NTB - male - 1297856 - Leicestershire vs Derbyshire
2022-06-09 - club - NTB - male - 1297855 - Northamptonshire vs Worcestershire
2022-06-09 - club - NTB - male - 1297854 - Surrey vs Middlesex
2022-06-09 - club - NTB - male - 1297853 - Gloucestershire vs Somerset
2022-06-09 - club - NTB - male - 1297852 - Hampshire vs Essex
2022-06-08 - club - NTB - male - 1297851 - Durham vs Birmingham Bears
2022-06-08 - club - NTB - male - 1297850 - Sussex vs Surrey
2022-06-08 - club - NTB - male - 1297849 - Lancashire vs Yorkshire
2022-06-07 - club - NTB - male - 1297848 - Leicestershire vs Lancashire
2022-06-07 - club - NTB - male - 1297847 - Derbyshire vs Northamptonshire
2022-06-07 - club - NTB - male - 1297846 - Kent vs Essex
2022-06-07 - club - NTB - male - 1297845 - Glamorgan vs Gloucestershire
2022-06-07 - club - NTB - male - 1297844 - Middlesex vs Hampshire
2022-06-06 - club - NTB - male - 1297843 - Yorkshire vs Nottinghamshire
2022-06-05 - club - NTB - male - 1297842 - Surrey vs Glamorgan
2022-06-05 - club - NTB - male - 1297841 - Durham vs Northamptonshire
2022-06-05 - club - NTB - male - 1297840 - Leicestershire vs Worcestershire
2022-06-05 - club - NTB - male - 1297839 - Birmingham Bears vs Nottinghamshire
2022-06-05 - club - NTB - male - 1297838 - Kent vs Middlesex
2022-06-04 - club - NTB - male - 1297837 - Hampshire vs Sussex
2022-06-03 - club - NTB - male - 1297836 - Derbyshire vs Nottinghamshire
2022-06-03 - club - NTB - male - 1297835 - Glamorgan vs Somerset
2022-06-03 - club - NTB - male - 1297834 - Middlesex vs Sussex
2022-06-03 - club - NTB - male - 1297833 - Worcestershire vs Birmingham Bears
2022-06-03 - club - NTB - male - 1297832 - Durham vs Yorkshire
2022-06-03 - club - NTB - male - 1297831 - Northamptonshire vs Lancashire
2022-06-03 - club - NTB - male - 1297830 - Surrey vs Kent
2022-06-02 - club - NTB - male - 1297828 - Essex vs Glamorgan
2022-06-02 - club - NTB - male - 1297827 - Surrey vs Hampshire
2022-06-02 - club - NTB - male - 1297826 - Leicestershire vs Birmingham Bears
2022-06-01 - club - NTB - male - 1297825 - Northamptonshire vs Leicestershire
2022-06-01 - club - NTB - male - 1297824 - Sussex vs Somerset
2022-06-01 - club - NTB - male - 1297823 - Durham vs Worcestershire
2022-06-01 - club - NTB - male - 1297822 - Lancashire vs Derbyshire
2022-06-01 - club - NTB - male - 1297821 - Kent vs Gloucestershire
2022-05-31 - club - NTB - male - 1297820 - Lancashire vs Nottinghamshire
2022-05-31 - club - NTB - male - 1297819 - Hampshire vs Essex
2022-05-31 - club - NTB - male - 1297818 - Surrey vs Gloucestershire
2022-05-31 - club - NTB - male - 1297817 - Yorkshire vs Derbyshire
2022-05-30 - club - NTB - male - 1297816 - Hampshire vs Somerset
2022-05-30 - club - NTB - male - 1297815 - Nottinghamshire vs Northamptonshire
2022-05-29 - club - NTB - male - 1297814 - Essex vs Somerset
2022-05-29 - club - NTB - male - 1297813 - Sussex vs Kent
2022-05-29 - club - NTB - male - 1297812 - Glamorgan vs Middlesex
2022-05-29 - club - NTB - male - 1297811 - Leicestershire vs Yorkshire
2022-05-29 - club - NTB - male - 1297810 - Lancashire vs Worcestershire
2022-05-29 - club - NTB - male - 1297809 - Durham vs Birmingham Bears
2022-05-28 - club - NTB - male - 1297808 - Derbyshire vs Leicestershire
2022-05-27 - club - NTB - male - 1297807 - Worcestershire vs Nottinghamshire
2022-05-27 - club - NTB - male - 1297806 - Birmingham Bears vs Derbyshire
2022-05-27 - club - NTB - male - 1297805 - Northamptonshire vs Durham
2022-05-27 - club - NTB - male - 1297804 - Glamorgan vs Surrey
2022-05-27 - club - NTB - male - 1297803 - Lancashire vs Yorkshire
2022-05-27 - club - NTB - male - 1297802 - Kent vs Essex
2022-05-27 - club - NTB - male - 1297801 - Gloucestershire vs Sussex
2022-05-27 - club - NTB - male - 1297800 - Middlesex vs Hampshire
2022-05-26 - club - NTB - male - 1297799 - Durham vs Leicestershire
2022-05-26 - club - NTB - male - 1297798 - Sussex vs Glamorgan
2022-05-26 - club - NTB - male - 1297797 - Middlesex vs Gloucestershire
2022-05-26 - club - NTB - male - 1297796 - Birmingham Bears vs Northamptonshire
2022-05-25 - club - NTB - male - 1297795 - Worcestershire vs Yorkshire
2022-05-25 - club - NTB - male - 1297794 - Kent vs Somerset
2021-09-18 - club - NTB - male - 1250368 - Kent vs Somerset
2021-09-18 - club - NTB - male - 1250367 - Kent vs Sussex
2021-09-18 - club - NTB - male - 1250366 - Hampshire vs Somerset
2021-08-27 - club - NTB - male - 1250365 - Kent vs Birmingham Bears
2021-08-26 - club - NTB - male - 1250364 - Lancashire vs Somerset
2021-08-25 - club - NTB - male - 1250363 - Hampshire vs Nottinghamshire
2021-08-24 - club - NTB - male - 1250362 - Yorkshire vs Sussex
2021-07-18 - club - NTB - male - 1269930 - Nottinghamshire vs Durham
2021-07-18 - club - NTB - male - 1250361 - Worcestershire vs Leicestershire
2021-07-18 - club - NTB - male - 1250359 - Somerset vs Gloucestershire
2021-07-18 - club - NTB - male - 1250358 - Middlesex vs Essex
2021-07-18 - club - NTB - male - 1250357 - Birmingham Bears vs Northamptonshire
2021-07-18 - club - NTB - male - 1250355 - Kent vs Sussex
2021-07-18 - club - NTB - male - 1250354 - Glamorgan vs Hampshire
2021-07-17 - club - NTB - male - 1250353 - Yorkshire vs Lancashire
2021-07-16 - club - NTB - male - 1269929 - Lancashire vs Durham
2021-07-16 - club - NTB - male - 1250352 - Nottinghamshire vs Leicestershire
2021-07-16 - club - NTB - male - 1250350 - Somerset vs Glamorgan
2021-07-16 - club - NTB - male - 1250349 - Kent vs Middlesex
2021-07-16 - club - NTB - male - 1250347 - Birmingham Bears vs Worcestershire
2021-07-16 - club - NTB - male - 1250346 - Gloucestershire vs Surrey
2021-07-16 - club - NTB - male - 1250345 - Sussex vs Hampshire
2021-07-16 - club - NTB - male - 1250344 - Hampshire vs Essex
2021-07-09 - club - NTB - male - 1250343 - Yorkshire vs Nottinghamshire
2021-07-09 - club - NTB - male - 1250342 - Essex vs Sussex
2021-07-09 - club - NTB - male - 1250341 - Worcestershire vs Birmingham Bears
2021-07-09 - club - NTB - male - 1250340 - Surrey vs Kent
2021-07-09 - club - NTB - male - 1250339 - Durham vs Derbyshire
2021-07-09 - club - NTB - male - 1250338 - Northamptonshire vs Lancashire
2021-07-09 - club - NTB - male - 1250337 - Gloucestershire vs Middlesex
2021-07-09 - club - NTB - male - 1250336 - Hampshire vs Somerset
2021-07-02 - club - NTB - male - 1250335 - Derbyshire vs Worcestershire
2021-07-02 - club - NTB - male - 1250334 - Somerset vs Middlesex
2021-07-02 - club - NTB - male - 1250333 - Sussex vs Glamorgan
2021-07-02 - club - NTB - male - 1250332 - Durham vs Leicestershire
2021-07-02 - club - NTB - male - 1250331 - Yorkshire vs Lancashire
2021-07-02 - club - NTB - male - 1250330 - Nottinghamshire vs Birmingham Bears
2021-07-02 - club - NTB - male - 1250329 - Kent vs Surrey
2021-07-02 - club - NTB - male - 1250328 - Hampshire vs Gloucestershire
2021-07-01 - club - NTB - male - 1250327 - Leicestershire vs Nottinghamshire
2021-07-01 - club - NTB - male - 1250326 - Glamorgan vs Essex
2021-07-01 - club - NTB - male - 1250325 - Middlesex vs Sussex
2021-07-01 - club - NTB - male - 1250324 - Lancashire vs Worcestershire
2021-07-01 - club - NTB - male - 1250323 - Gloucestershire vs Somerset
2021-06-30 - club - NTB - male - 1250322 - Northamptonshire vs Durham
2021-06-30 - club - NTB - male - 1250321 - Yorkshire vs Birmingham Bears
2021-06-30 - club - NTB - male - 1250320 - Surrey vs Hampshire
2021-06-29 - club - NTB - male - 1250319 - Leicestershire vs Northamptonshire
2021-06-29 - club - NTB - male - 1250318 - Somerset vs Essex
2021-06-29 - club - NTB - male - 1250316 - Glamorgan vs Surrey
2021-06-28 - club - NTB - male - 1250315 - Kent vs Somerset
2021-06-27 - club - NTB - male - 1250313 - Surrey vs Sussex
2021-06-27 - club - NTB - male - 1250312 - Glamorgan vs Middlesex
2021-06-27 - club - NTB - male - 1250311 - Leicestershire vs Worcestershire
2021-06-26 - club - NTB - male - 1250310 - Nottinghamshire vs Lancashire
2021-06-26 - club - NTB - male - 1250309 - Yorkshire vs Northamptonshire
2021-06-26 - club - NTB - male - 1250308 - Durham vs Birmingham Bears
2021-06-25 - club - NTB - male - 1250307 - Leicestershire vs Yorkshire
2021-06-25 - club - NTB - male - 1250306 - Nottinghamshire vs Derbyshire
2021-06-25 - club - NTB - male - 1250305 - Lancashire vs Northamptonshire
2021-06-25 - club - NTB - male - 1250304 - Somerset vs Hampshire
2021-06-25 - club - NTB - male - 1250303 - Kent vs Essex
2021-06-25 - club - NTB - male - 1250302 - Gloucestershire vs Sussex
2021-06-25 - club - NTB - male - 1250301 - Durham vs Worcestershire
2021-06-25 - club - NTB - male - 1250300 - Middlesex vs Surrey
2021-06-24 - club - NTB - male - 1250299 - Gloucestershire vs Glamorgan
2021-06-24 - club - NTB - male - 1250298 - Middlesex vs Essex
2021-06-24 - club - NTB - male - 1250297 - Birmingham Bears vs Derbyshire
2021-06-23 - club - NTB - male - 1250296 - Surrey vs Somerset
2021-06-23 - club - NTB - male - 1250295 - Durham vs Northamptonshire
2021-06-23 - club - NTB - male - 1250294 - Yorkshire vs Worcestershire
2021-06-22 - club - NTB - male - 1250293 - Worcestershire vs Nottinghamshire
2021-06-22 - club - NTB - male - 1250292 - Leicestershire vs Derbyshire
2021-06-22 - club - NTB - male - 1250290 - Kent vs Gloucestershire
2021-06-21 - club - NTB - male - 1250289 - Surrey vs Essex
2021-06-20 - club - NTB - male - 1250288 - Leicestershire vs Northamptonshire
2021-06-20 - club - NTB - male - 1250287 - Nottinghamshire vs Lancashire
2021-06-20 - club - NTB - male - 1250286 - Durham vs Birmingham Bears
2021-06-20 - club - NTB - male - 1250285 - Yorkshire vs Derbyshire
2021-06-20 - club - NTB - male - 1250284 - Kent vs Essex
2021-06-18 - club - NTB - male - 1250281 - Nottinghamshire vs Derbyshire
2021-06-18 - club - NTB - male - 1250278 - Glamorgan vs Middlesex
2021-06-17 - club - NTB - male - 1250273 - Northamptonshire vs Derbyshire
2021-06-17 - club - NTB - male - 1250272 - Middlesex vs Gloucestershire
2021-06-17 - club - NTB - male - 1250271 - Surrey vs Sussex
2021-06-17 - club - NTB - male - 1250270 - Lancashire vs Durham
2021-06-16 - club - NTB - male - 1250269 - Birmingham Bears vs Leicestershire
2021-06-16 - club - NTB - male - 1250268 - Kent vs Glamorgan
2021-06-16 - club - NTB - male - 1250267 - Yorkshire vs Worcestershire
2021-06-15 - club - NTB - male - 1250266 - Derbyshire vs Lancashire
2021-06-15 - club - NTB - male - 1250265 - Birmingham Bears vs Northamptonshire
2021-06-15 - club - NTB - male - 1250264 - Somerset vs Kent
2021-06-15 - club - NTB - male - 1250263 - Essex vs Sussex
2021-06-15 - club - NTB - male - 1250262 - Hampshire vs Middlesex
2021-06-15 - club - NTB - male - 1250261 - Nottinghamshire vs Durham
2021-06-15 - club - NTB - male - 1250260 - Yorkshire vs Leicestershire
2021-06-14 - club - NTB - male - 1250259 - Glamorgan vs Surrey
2021-06-13 - club - NTB - male - 1250258 - Leicestershire vs Durham
2021-06-13 - club - NTB - male - 1250257 - Derbyshire vs Birmingham Bears
2021-06-13 - club - NTB - male - 1250256 - Nottinghamshire vs Northamptonshire
2021-06-13 - club - NTB - male - 1250255 - Essex vs Glamorgan
2021-06-13 - club - NTB - male - 1250254 - Lancashire vs Worcestershire
2021-06-13 - club - NTB - male - 1250253 - Kent vs Gloucestershire
2021-06-12 - club - NTB - male - 1250252 - Hampshire vs Sussex
2021-06-11 - club - NTB - male - 1250251 - Derbyshire vs Leicestershire
2021-06-11 - club - NTB - male - 1250250 - Birmingham Bears vs Nottinghamshire
2021-06-11 - club - NTB - male - 1250249 - Worcestershire vs Northamptonshire
2021-06-11 - club - NTB - male - 1250248 - Somerset vs Surrey
2021-06-11 - club - NTB - male - 1250247 - Hampshire vs Essex
2021-06-11 - club - NTB - male - 1250246 - Durham vs Yorkshire
2021-06-11 - club - NTB - male - 1250245 - Kent vs Middlesex
2021-06-11 - club - NTB - male - 1250244 - Gloucestershire vs Sussex
2021-06-10 - club - NTB - male - 1250243 - Gloucestershire vs Glamorgan
2021-06-10 - club - NTB - male - 1250242 - Surrey vs Middlesex
2021-06-10 - club - NTB - male - 1250241 - Lancashire vs Leicestershire
2021-06-10 - club - NTB - male - 1250240 - Birmingham Bears vs Yorkshire
2021-06-09 - club - NTB - male - 1250239 - Somerset vs Essex
2021-06-09 - club - NTB - male - 1250238 - Worcestershire vs Nottinghamshire
2021-06-09 - club - NTB - male - 1250237 - Derbyshire vs Lancashire
2021-06-09 - club - NTB - male - 1250236 - Kent vs Hampshire
2020-10-04 - club - NTB - male - 1229399 - Surrey vs Nottinghamshire
2020-10-04 - club - NTB - male - 1229398 - Lancashire vs Nottinghamshire
2020-10-03 - club - NTB - male - 1229397 - Gloucestershire vs Surrey
2020-10-01 - club - NTB - male - 1229396 - Lancashire vs Sussex
2020-10-01 - club - NTB - male - 1229395 - Surrey vs Kent
2020-10-01 - club - NTB - male - 1207789 - Leicestershire vs Nottinghamshire
2020-10-01 - club - NTB - male - 1207788 - Northamptonshire vs Gloucestershire
2020-09-20 - club - NTB - male - 1207787 - Somerset vs Gloucestershire
2020-09-20 - club - NTB - male - 1207786 - Essex vs Sussex
2020-09-20 - club - NTB - male - 1207785 - Nottinghamshire vs Durham
2020-09-20 - club - NTB - male - 1207784 - Leicestershire vs Lancashire
2020-09-20 - club - NTB - male - 1207783 - Derbyshire vs Yorkshire
2020-09-20 - club - NTB - male - 1207782 - Worcestershire vs Glamorgan
2020-09-20 - club - NTB - male - 1207781 - Birmingham Bears vs Northamptonshire
2020-09-20 - club - NTB - male - 1207780 - Hampshire vs Middlesex
2020-09-20 - club - NTB - male - 1207779 - Kent vs Surrey
2020-09-18 - club - NTB - male - 1207778 - Nottinghamshire vs Leicestershire
2020-09-18 - club - NTB - male - 1207777 - Hampshire vs Surrey
2020-09-18 - club - NTB - male - 1207776 - Durham vs Lancashire
2020-09-18 - club - NTB - male - 1207775 - Glamorgan vs Gloucestershire
2020-09-18 - club - NTB - male - 1207774 - Northamptonshire vs Somerset
2020-09-18 - club - NTB - male - 1207773 - Birmingham Bears vs Worcestershire
2020-09-18 - club - NTB - male - 1207772 - Middlesex vs Sussex
2020-09-18 - club - NTB - male - 1207771 - Essex vs Kent
2020-09-17 - club - NTB - male - 1207770 - Derbyshire vs Nottinghamshire
2020-09-17 - club - NTB - male - 1207769 - Lancashire vs Yorkshire
2020-09-16 - club - NTB - male - 1207768 - Durham vs Yorkshire
2020-09-16 - club - NTB - male - 1207767 - Sussex vs Surrey
2020-09-16 - club - NTB - male - 1207766 - Middlesex vs Kent
2020-09-16 - club - NTB - male - 1207765 - Somerset vs Glamorgan
2020-09-16 - club - NTB - male - 1207764 - Essex vs Hampshire
2020-09-15 - club - NTB - male - 1207763 - Worcestershire vs Northamptonshire
2020-09-15 - club - NTB - male - 1207762 - Gloucestershire vs Birmingham Bears
2020-09-15 - club - NTB - male - 1207761 - Derbyshire vs Leicestershire
2020-09-14 - club - NTB - male - 1207760 - Hampshire vs Kent
2020-09-14 - club - NTB - male - 1207759 - Essex vs Sussex
2020-09-14 - club - NTB - male - 1207758 - Surrey vs Middlesex
2020-09-14 - club - NTB - male - 1207757 - Yorkshire vs Lancashire
2020-09-13 - club - NTB - male - 1207756 - Leicestershire vs Durham
2020-09-13 - club - NTB - male - 1207755 - Nottinghamshire vs Derbyshire
2020-09-13 - club - NTB - male - 1207754 - Worcestershire vs Birmingham Bears
2020-09-13 - club - NTB - male - 1207753 - Gloucestershire vs Somerset
2020-09-13 - club - NTB - male - 1207752 - Northamptonshire vs Glamorgan
2020-09-12 - club - NTB - male - 1207751 - Middlesex vs Hampshire
2020-09-12 - club - NTB - male - 1207750 - Kent vs Sussex
2020-09-11 - club - NTB - male - 1207749 - Durham vs Derbyshire
2020-09-11 - club - NTB - male - 1207748 - Gloucestershire vs Northamptonshire
2020-09-11 - club - NTB - male - 1207747 - Birmingham Bears vs Glamorgan
2020-09-11 - club - NTB - male - 1207746 - Yorkshire vs Leicestershire
2020-09-11 - club - NTB - male - 1207745 - Essex vs Surrey
2020-09-11 - club - NTB - male - 1207744 - Lancashire vs Nottinghamshire
2020-09-11 - club - NTB - male - 1207743 - Worcestershire vs Somerset
2020-09-10 - club - NTB - male - 1207742 - Sussex vs Hampshire
2020-09-05 - club - NTB - male - 1207741 - Kent vs Essex
2020-09-05 - club - NTB - male - 1207740 - Middlesex vs Surrey
2020-09-04 - club - NTB - male - 1207739 - Leicestershire vs Nottinghamshire
2020-09-04 - club - NTB - male - 1207738 - Derbyshire vs Lancashire
2020-09-04 - club - NTB - male - 1207737 - Yorkshire vs Durham
2020-09-04 - club - NTB - male - 1207736 - Birmingham Bears vs Somerset
2020-09-04 - club - NTB - male - 1207735 - Gloucestershire vs Worcestershire
2020-09-03 - club - NTB - male - 1207734 - Hampshire vs Surrey
2020-09-03 - club - NTB - male - 1207733 - Kent vs Sussex
2020-09-03 - club - NTB - male - 1207732 - Glamorgan vs Northamptonshire
2020-09-03 - club - NTB - male - 1207731 - Somerset vs Worcestershire
2020-09-03 - club - NTB - male - 1207730 - Middlesex vs Essex
2020-09-02 - club - NTB - male - 1207729 - Gloucestershire vs Birmingham Bears
2020-09-01 - club - NTB - male - 1207725 - Essex vs Hampshire
2020-09-01 - club - NTB - male - 1207724 - Surrey vs Kent
2020-09-01 - club - NTB - male - 1207723 - Northamptonshire vs Birmingham Bears
2020-09-01 - club - NTB - male - 1207722 - Middlesex vs Sussex
2020-09-01 - club - NTB - male - 1207721 - Glamorgan vs Somerset
2020-08-31 - club - NTB - male - 1207720 - Gloucestershire vs Worcestershire
2020-08-31 - club - NTB - male - 1207719 - Yorkshire vs Nottinghamshire
2020-08-31 - club - NTB - male - 1207718 - Lancashire vs Derbyshire
2020-08-31 - club - NTB - male - 1207717 - Leicestershire vs Durham
2020-08-30 - club - NTB - male - 1207716 - Glamorgan vs Birmingham Bears
2020-08-30 - club - NTB - male - 1207715 - Northamptonshire vs Somerset
2020-08-30 - club - NTB - male - 1207714 - Yorkshire vs Derbyshire
2020-08-30 - club - NTB - male - 1207713 - Essex vs Surrey
2020-08-30 - club - NTB - male - 1207712 - Hampshire vs Sussex
2020-08-29 - club - NTB - male - 1207711 - Glamorgan vs Gloucestershire
2020-08-29 - club - NTB - male - 1207710 - Worcestershire vs Northamptonshire
2020-08-29 - club - NTB - male - 1207709 - Middlesex vs Kent
2020-08-29 - club - NTB - male - 1207708 - Leicestershire vs Lancashire
2020-08-29 - club - NTB - male - 1207707 - Durham vs Nottinghamshire
2020-08-28 - club - NTB - male - 1207706 - Sussex vs Surrey
2020-08-27 - club - NTB - male - 1207704 - Middlesex vs Essex
2020-08-27 - club - NTB - male - 1207702 - Lancashire vs Durham
2020-08-27 - club - NTB - male - 1207698 - Hampshire vs Kent
2019-09-21 - club - NTB - male - 1167259 - Worcestershire vs Essex
2019-09-21 - club - NTB - male - 1167258 - Derbyshire vs Essex
2019-09-21 - club - NTB - male - 1167257 - Nottinghamshire vs Worcestershire
2019-09-07 - club - NTB - male - 1167256 - Gloucestershire vs Derbyshire
2019-09-06 - club - NTB - male - 1167255 - Sussex vs Worcestershire
2019-09-05 - club - NTB - male - 1167254 - Nottinghamshire vs Middlesex
2019-09-04 - club - NTB - male - 1167253 - Lancashire vs Essex
2019-08-30 - club - NTB - male - 1167252 - Northamptonshire vs Worcestershire
2019-08-30 - club - NTB - male - 1167251 - Essex vs Kent
2019-08-30 - club - NTB - male - 1167250 - Birmingham Bears vs Yorkshire
2019-08-30 - club - NTB - male - 1167249 - Sussex vs Gloucestershire
2019-08-30 - club - NTB - male - 1167248 - Somerset vs Middlesex
2019-08-30 - club - NTB - male - 1167247 - Lancashire vs Leicestershire
2019-08-30 - club - NTB - male - 1167246 - Nottinghamshire vs Durham
2019-08-30 - club - NTB - male - 1167245 - Glamorgan vs Hampshire
2019-08-29 - club - NTB - male - 1167244 - Hampshire vs Middlesex
2019-08-29 - club - NTB - male - 1167243 - Yorkshire vs Northamptonshire
2019-08-29 - club - NTB - male - 1167242 - Surrey vs Essex
2019-08-29 - club - NTB - male - 1167241 - Kent vs Gloucestershire
2019-08-27 - club - NTB - male - 1167239 - Durham vs Birmingham Bears
2019-08-27 - club - NTB - male - 1167238 - Surrey vs Somerset
2019-08-26 - club - NTB - male - 1167237 - Lancashire vs Derbyshire
2019-08-26 - club - NTB - male - 1167236 - Glamorgan vs Sussex
2019-08-25 - club - NTB - male - 1167235 - Nottinghamshire vs Yorkshire
2019-08-25 - club - NTB - male - 1167234 - Birmingham Bears vs Northamptonshire
2019-08-25 - club - NTB - male - 1167233 - Worcestershire vs Lancashire
2019-08-25 - club - NTB - male - 1167232 - Hampshire vs Essex
2019-08-25 - club - NTB - male - 1167231 - Leicestershire vs Derbyshire
2019-08-24 - club - NTB - male - 1167230 - Middlesex vs Sussex
2019-08-24 - club - NTB - male - 1167229 - Somerset vs Glamorgan
2019-08-23 - club - NTB - male - 1167228 - Gloucestershire vs Somerset
2019-08-23 - club - NTB - male - 1167227 - Leicestershire vs Nottinghamshire
2019-08-23 - club - NTB - male - 1167226 - Derbyshire vs Northamptonshire
2019-08-23 - club - NTB - male - 1167225 - Birmingham Bears vs Worcestershire
2019-08-23 - club - NTB - male - 1167224 - Durham vs Yorkshire
2019-08-23 - club - NTB - male - 1167223 - Kent vs Surrey
2019-08-22 - club - NTB - male - 1167222 - Middlesex vs Hampshire
2019-08-22 - club - NTB - male - 1167221 - Sussex vs Essex
2019-08-15 - club - NTB - male - 1167212 - Derbyshire vs Leicestershire
2019-08-15 - club - NTB - male - 1167211 - Surrey vs Sussex
2019-08-15 - club - NTB - male - 1167210 - Durham vs Worcestershire
2019-08-14 - club - NTB - male - 1167209 - Northamptonshire vs Lancashire
2019-08-13 - club - NTB - male - 1167206 - Derbyshire vs Worcestershire
2019-08-13 - club - NTB - male - 1167205 - Gloucestershire vs Hampshire
2019-08-11 - club - NTB - male - 1167204 - Yorkshire vs Derbyshire
2019-08-11 - club - NTB - male - 1167203 - Glamorgan vs Surrey
2019-08-11 - club - NTB - male - 1167202 - Middlesex vs Gloucestershire
2019-08-11 - club - NTB - male - 1167201 - Birmingham Bears vs Lancashire
2019-08-10 - club - NTB - male - 1167198 - Somerset vs Kent
2019-08-09 - club - NTB - male - 1167197 - Leicestershire vs Northamptonshire
2019-08-09 - club - NTB - male - 1167196 - Birmingham Bears vs Nottinghamshire
2019-08-09 - club - NTB - male - 1167195 - Sussex vs Middlesex
2019-08-09 - club - NTB - male - 1167194 - Surrey vs Gloucestershire
2019-08-09 - club - NTB - male - 1167193 - Hampshire vs Somerset
2019-08-09 - club - NTB - male - 1167192 - Glamorgan vs Essex
2019-08-09 - club - NTB - male - 1167191 - Derbyshire vs Durham
2019-08-08 - club - NTB - male - 1167189 - Middlesex vs Surrey
2019-08-07 - club - NTB - male - 1167188 - Leicestershire vs Birmingham Bears
2019-08-07 - club - NTB - male - 1167187 - Northamptonshire vs Durham
2019-08-07 - club - NTB - male - 1167186 - Essex vs Somerset
2019-08-07 - club - NTB - male - 1167185 - Gloucestershire vs Kent
2019-08-06 - club - NTB - male - 1167184 - Sussex vs Glamorgan
2019-08-04 - club - NTB - male - 1167183 - Worcestershire vs Leicestershire
2019-08-04 - club - NTB - male - 1167182 - Yorkshire vs Birmingham Bears
2019-08-04 - club - NTB - male - 1167181 - Gloucestershire vs Sussex
2019-08-04 - club - NTB - male - 1167180 - Middlesex vs Somerset
2019-08-04 - club - NTB - male - 1167179 - Kent vs Hampshire
2019-08-03 - club - NTB - male - 1167178 - Lancashire vs Nottinghamshire
2019-08-02 - club - NTB - male - 1167177 - Nottinghamshire vs Birmingham Bears
2019-08-02 - club - NTB - male - 1167176 - Hampshire vs Glamorgan
2019-08-02 - club - NTB - male - 1167175 - Durham vs Lancashire
2019-08-02 - club - NTB - male - 1167174 - Gloucestershire vs Essex
2019-08-02 - club - NTB - male - 1167173 - Northamptonshire vs Derbyshire
2019-08-02 - club - NTB - male - 1167172 - Somerset vs Surrey
2019-08-02 - club - NTB - male - 1167171 - Sussex vs Kent
2019-08-02 - club - NTB - male - 1167170 - Yorkshire vs Worcestershire
2019-08-01 - club - NTB - male - 1167169 - Glamorgan vs Gloucestershire
2019-08-01 - club - NTB - male - 1167168 - Middlesex vs Kent
2019-08-01 - club - NTB - male - 1167167 - Essex vs Hampshire
2019-07-31 - club - NTB - male - 1167166 - Durham vs Leicestershire
2019-07-31 - club - NTB - male - 1167165 - Worcestershire vs Derbyshire
2019-07-30 - club - NTB - male - 1167164 - Surrey vs Kent
2019-07-28 - club - NTB - male - 1167161 - Somerset vs Sussex
2019-07-28 - club - NTB - male - 1167160 - Worcestershire vs Durham
2019-07-27 - club - NTB - male - 1167159 - Nottinghamshire vs Leicestershire
2019-07-26 - club - NTB - male - 1167157 - Glamorgan vs Middlesex
2019-07-26 - club - NTB - male - 1167156 - Sussex vs Surrey
2019-07-26 - club - NTB - male - 1167155 - Derbyshire vs Nottinghamshire
2019-07-26 - club - NTB - male - 1167154 - Kent vs Essex
2019-07-26 - club - NTB - male - 1167153 - Lancashire vs Worcestershire
2019-07-26 - club - NTB - male - 1167152 - Leicestershire vs Durham
2019-07-26 - club - NTB - male - 1167151 - Somerset vs Hampshire
2019-07-26 - club - NTB - male - 1167150 - Northamptonshire vs Birmingham Bears
2019-07-25 - club - NTB - male - 1167149 - Surrey vs Glamorgan
2019-07-25 - club - NTB - male - 1167148 - Gloucestershire vs Middlesex
2019-07-25 - club - NTB - male - 1167147 - Yorkshire vs Lancashire
2019-07-24 - club - NTB - male - 1167146 - Nottinghamshire vs Northamptonshire
2019-07-24 - club - NTB - male - 1167145 - Sussex vs Hampshire
2019-07-24 - club - NTB - male - 1167142 - Birmingham Bears vs Derbyshire
2019-07-23 - club - NTB - male - 1167144 - Surrey vs Middlesex
2019-07-23 - club - NTB - male - 1167143 - Leicestershire vs Yorkshire
2019-07-21 - club - NTB - male - 1167141 - Hampshire vs Kent
2019-07-21 - club - NTB - male - 1167140 - Birmingham Bears vs Leicestershire
2019-07-21 - club - NTB - male - 1167139 - Lancashire vs Durham
2019-07-20 - club - NTB - male - 1167138 - Derbyshire vs Yorkshire
2019-07-20 - club - NTB - male - 1167137 - Kent vs Somerset
2019-07-19 - club - NTB - male - 1167133 - Gloucestershire vs Glamorgan
2019-07-19 - club - NTB - male - 1167131 - Essex vs Surrey
2019-07-19 - club - NTB - male - 1167130 - Durham vs Northamptonshire
2019-07-18 - club - NTB - male - 1167129 - Glamorgan vs Somerset
2019-07-18 - club - NTB - male - 1167128 - Nottinghamshire vs Worcestershire
2019-07-18 - club - NTB - male - 1167127 - Middlesex vs Essex
2018-09-15 - club - NTB - male - 1127580 - Sussex vs Worcestershire
2018-09-15 - club - NTB - male - 1127579 - Worcestershire vs Lancashire
2018-09-15 - club - NTB - male - 1127578 - Sussex vs Somerset
2018-08-26 - club - NTB - male - 1127577 - Somerset vs Nottinghamshire
2018-08-25 - club - NTB - male - 1127576 - Gloucestershire vs Worcestershire
2018-08-24 - club - NTB - male - 1127575 - Durham vs Sussex
2018-08-23 - club - NTB - male - 1127574 - Kent vs Lancashire
2018-08-17 - club - NTB - male - 1127573 - Leicestershire vs Northamptonshire
2018-08-17 - club - NTB - male - 1127572 - Sussex vs Middlesex
2018-08-17 - club - NTB - male - 1127571 - Glamorgan vs Surrey
2018-08-17 - club - NTB - male - 1127569 - Yorkshire vs Nottinghamshire
2018-08-17 - club - NTB - male - 1127568 - Worcestershire vs Birmingham Bears
2018-08-17 - club - NTB - male - 1127567 - Essex vs Kent
2018-08-17 - club - NTB - male - 1127566 - Gloucestershire vs Hampshire
2018-08-16 - club - NTB - male - 1127565 - Gloucestershire vs Sussex
2018-08-16 - club - NTB - male - 1127564 - Northamptonshire vs Yorkshire
2018-08-16 - club - NTB - male - 1127563 - Middlesex vs Essex
2018-08-16 - club - NTB - male - 1127562 - Kent vs Somerset
2018-08-15 - club - NTB - male - 1127561 - Hampshire vs Surrey
2018-08-15 - club - NTB - male - 1127560 - Lancashire vs Birmingham Bears
2018-08-14 - club - NTB - male - 1127559 - Sussex vs Glamorgan
2018-08-12 - club - NTB - male - 1127558 - Somerset vs Glamorgan
2018-08-12 - club - NTB - male - 1127557 - Gloucestershire vs Surrey
2018-08-12 - club - NTB - male - 1127556 - Worcestershire vs Nottinghamshire
2018-08-12 - club - NTB - male - 1127555 - Lancashire vs Durham
2018-08-12 - club - NTB - male - 1127554 - Middlesex vs Kent
2018-08-12 - club - NTB - male - 1127553 - Essex vs Hampshire
2018-08-11 - club - NTB - male - 1127552 - Leicestershire vs Derbyshire
2018-08-10 - club - NTB - male - 1127551 - Nottinghamshire vs Yorkshire
2018-08-10 - club - NTB - male - 1127550 - Leicestershire vs Worcestershire
2018-08-10 - club - NTB - male - 1127549 - Surrey vs Somerset
2018-08-10 - club - NTB - male - 1127547 - Hampshire vs Glamorgan
2018-08-10 - club - NTB - male - 1127546 - Durham vs Northamptonshire
2018-08-10 - club - NTB - male - 1127545 - Lancashire vs Birmingham Bears
2018-08-09 - club - NTB - male - 1127543 - Gloucestershire vs Middlesex
2018-08-09 - club - NTB - male - 1127542 - Worcestershire vs Derbyshire
2018-08-09 - club - NTB - male - 1127541 - Sussex vs Surrey
2018-08-09 - club - NTB - male - 1127540 - Yorkshire vs Lancashire
2018-08-09 - club - NTB - male - 1127539 - Nottinghamshire vs Birmingham Bears
2018-08-08 - club - NTB - male - 1127538 - Derbyshire vs Northamptonshire
2018-08-08 - club - NTB - male - 1127537 - Durham vs Leicestershire
2018-08-08 - club - NTB - male - 1127536 - Hampshire vs Somerset
2018-08-07 - club - NTB - male - 1127535 - Glamorgan vs Essex
2018-08-07 - club - NTB - male - 1127534 - Durham vs Lancashire
2018-08-05 - club - NTB - male - 1127533 - Sussex vs Somerset
2018-08-05 - club - NTB - male - 1127532 - Middlesex vs Glamorgan
2018-08-05 - club - NTB - male - 1127531 - Birmingham Bears vs Northamptonshire
2018-08-05 - club - NTB - male - 1127530 - Essex vs Surrey
2018-08-05 - club - NTB - male - 1127529 - Kent vs Gloucestershire
2018-08-04 - club - NTB - male - 1127528 - Worcestershire vs Nottinghamshire
2018-08-03 - club - NTB - male - 1127527 - Essex vs Somerset
2018-08-03 - club - NTB - male - 1127526 - Derbyshire vs Birmingham Bears
2018-08-03 - club - NTB - male - 1127524 - Durham vs Worcestershire
2018-08-03 - club - NTB - male - 1127523 - Middlesex vs Surrey
2018-08-03 - club - NTB - male - 1127522 - Lancashire vs Leicestershire
2018-08-03 - club - NTB - male - 1127521 - Northamptonshire vs Yorkshire
2018-08-03 - club - NTB - male - 1127520 - Kent vs Hampshire
2018-08-02 - club - NTB - male - 1127519 - Nottinghamshire vs Derbyshire
2018-08-02 - club - NTB - male - 1127518 - Leicestershire vs Birmingham Bears
2018-08-02 - club - NTB - male - 1127517 - Sussex vs Middlesex
2018-08-02 - club - NTB - male - 1127516 - Durham vs Northamptonshire
2018-08-02 - club - NTB - male - 1127515 - Kent vs Essex
2018-08-01 - club - NTB - male - 1127514 - Somerset vs Hampshire
2018-08-01 - club - NTB - male - 1127513 - Sussex vs Gloucestershire
2018-07-31 - club - NTB - male - 1127512 - Surrey vs Glamorgan
2018-07-31 - club - NTB - male - 1127511 - Yorkshire vs Leicestershire
2018-07-30 - club - NTB - male - 1127469 - Derbyshire vs Yorkshire
2018-07-29 - club - NTB - male - 1127510 - Somerset vs Middlesex
2018-07-28 - club - NTB - male - 1127506 - Nottinghamshire vs Durham
2018-07-28 - club - NTB - male - 1127505 - Yorkshire vs Derbyshire
2018-07-27 - club - NTB - male - 1127504 - Nottinghamshire vs Lancashire
2018-07-27 - club - NTB - male - 1127503 - Leicestershire vs Derbyshire
2018-07-27 - club - NTB - male - 1127502 - Northamptonshire vs Worcestershire
2018-07-27 - club - NTB - male - 1127501 - Somerset vs Surrey
2018-07-27 - club - NTB - male - 1127500 - Yorkshire vs Birmingham Bears
2018-07-27 - club - NTB - male - 1127499 - Gloucestershire vs Glamorgan
2018-07-27 - club - NTB - male - 1127498 - Kent vs Sussex
2018-07-26 - club - NTB - male - 1127497 - Middlesex vs Hampshire
2018-07-21 - club - NTB - male - 1127496 - Hampshire vs Essex
2018-07-20 - club - NTB - male - 1127495 - Leicestershire vs Nottinghamshire
2018-07-20 - club - NTB - male - 1127494 - Somerset vs Glamorgan
2018-07-20 - club - NTB - male - 1127493 - Worcestershire vs Durham
2018-07-20 - club - NTB - male - 1127492 - Lancashire vs Yorkshire
2018-07-20 - club - NTB - male - 1127491 - Northamptonshire vs Birmingham Bears
2018-07-20 - club - NTB - male - 1127490 - Essex vs Gloucestershire
2018-07-20 - club - NTB - male - 1127489 - Surrey vs Kent
2018-07-20 - club - NTB - male - 1127488 - Hampshire vs Middlesex
2018-07-19 - club - NTB - male - 1127487 - Derbyshire vs Northamptonshire
2018-07-19 - club - NTB - male - 1127486 - Middlesex vs Somerset
2018-07-18 - club - NTB - male - 1127485 - Leicestershire vs Lancashire
2018-07-17 - club - NTB - male - 1127484 - Durham vs Nottinghamshire
2018-07-15 - club - NTB - male - 1127483 - Yorkshire vs Worcestershire
2018-07-15 - club - NTB - male - 1127482 - Durham vs Birmingham Bears
2018-07-14 - club - NTB - male - 1127481 - Lancashire vs Derbyshire
2018-07-13 - club - NTB - male - 1127480 - Somerset vs Gloucestershire
2018-07-13 - club - NTB - male - 1127479 - Nottinghamshire vs Derbyshire
2018-07-13 - club - NTB - male - 1127478 - Surrey vs Sussex
2018-07-13 - club - NTB - male - 1127477 - Worcestershire vs Northamptonshire
2018-07-13 - club - NTB - male - 1127476 - Yorkshire vs Durham
2018-07-13 - club - NTB - male - 1127475 - Leicestershire vs Birmingham Bears
2018-07-13 - club - NTB - male - 1127474 - Essex vs Glamorgan
2018-07-13 - club - NTB - male - 1127473 - Kent vs Hampshire
2018-07-12 - club - NTB - male - 1127472 - Surrey vs Essex
2018-07-12 - club - NTB - male - 1127471 - Hampshire vs Sussex
2018-07-11 - club - NTB - male - 1127470 - Gloucestershire vs Kent
2018-07-08 - club - NTB - male - 1127468 - Nottinghamshire vs Leicestershire
2018-07-08 - club - NTB - male - 1127467 - Somerset vs Kent
2018-07-08 - club - NTB - male - 1127466 - Derbyshire vs Worcestershire
2018-07-08 - club - NTB - male - 1127465 - Middlesex vs Gloucestershire
2018-07-08 - club - NTB - male - 1127464 - Glamorgan vs Sussex
2018-07-08 - club - NTB - male - 1127463 - Northamptonshire vs Lancashire
2018-07-08 - club - NTB - male - 1127462 - Yorkshire vs Birmingham Bears
2018-07-06 - club - NTB - male - 1127461 - Durham vs Leicestershire
2018-07-06 - club - NTB - male - 1127460 - Gloucestershire vs Somerset
2018-07-06 - club - NTB - male - 1127459 - Derbyshire vs Lancashire
2018-07-06 - club - NTB - male - 1127458 - Nottinghamshire vs Northamptonshire
2018-07-06 - club - NTB - male - 1127457 - Worcestershire vs Birmingham Bears
2018-07-06 - club - NTB - male - 1127456 - Kent vs Surrey
2018-07-06 - club - NTB - male - 1127455 - Middlesex vs Essex
2018-07-06 - club - NTB - male - 1127454 - Glamorgan vs Hampshire
2018-07-05 - club - NTB - male - 1127453 - Surrey vs Middlesex
2018-07-05 - club - NTB - male - 1127452 - Lancashire vs Worcestershire
2018-07-05 - club - NTB - male - 1127451 - Yorkshire vs Durham
2018-07-04 - club - NTB - male - 1127450 - Nottinghamshire vs Birmingham Bears
2018-07-04 - club - NTB - male - 1127449 - Northamptonshire vs Leicestershire
2018-07-04 - club - NTB - male - 1127448 - Sussex vs Essex
2017-09-02 - club - NTB - male - 1086737 - Nottinghamshire vs Warwickshire
2017-09-02 - club - NTB - male - 1086736 - Nottinghamshire vs Hampshire
2017-09-02 - club - NTB - male - 1068428 - Warwickshire vs Glamorgan
2017-08-25 - club - NTB - male - 1068427 - Surrey vs Warwickshire
2017-08-24 - club - NTB - male - 1068426 - Somerset vs Nottinghamshire
2017-08-23 - club - NTB - male - 1068425 - Leicestershire vs Glamorgan
2017-08-22 - club - NTB - male - 1068424 - Hampshire vs Derbyshire
2017-08-18 - club - NTB - male - 1068423 - Leicestershire vs Nottinghamshire
2017-08-18 - club - NTB - male - 1068422 - Durham vs Northamptonshire
2017-08-18 - club - NTB - male - 1068421 - Lancashire vs Warwickshire
2017-08-18 - club - NTB - male - 1068420 - Somerset vs Hampshire
2017-08-18 - club - NTB - male - 1068419 - Derbyshire vs Worcestershire
2017-08-18 - club - NTB - male - 1068418 - Middlesex vs Glamorgan
2017-08-18 - club - NTB - male - 1068417 - Sussex vs Essex
2017-08-18 - club - NTB - male - 1068416 - Surrey vs Kent
2017-08-17 - club - NTB - male - 1068415 - Yorkshire vs Northamptonshire
2017-08-17 - club - NTB - male - 1068414 - Gloucestershire vs Surrey
2017-08-17 - club - NTB - male - 1068413 - Derbyshire vs Leicestershire
2017-08-17 - club - NTB - male - 1068412 - Kent vs Essex
2017-08-16 - club - NTB - male - 1068411 - Worcestershire vs Lancashire
2017-08-15 - club - NTB - male - 1068410 - Durham vs Derbyshire
2017-08-15 - club - NTB - male - 1068409 - Middlesex vs Gloucestershire
2017-08-13 - club - NTB - male - 1068408 - Glamorgan vs Somerset
2017-08-13 - club - NTB - male - 1068407 - Durham vs Warwickshire
2017-08-13 - club - NTB - male - 1068406 - Gloucestershire vs Essex
2017-08-13 - club - NTB - male - 1068405 - Surrey vs Sussex
2017-08-13 - club - NTB - male - 1068404 - Nottinghamshire vs Worcestershire
2017-08-12 - club - NTB - male - 1068403 - Yorkshire vs Leicestershire
2017-08-12 - club - NTB - male - 1068402 - Somerset vs Kent
2017-08-11 - club - NTB - male - 1068401 - Yorkshire vs Lancashire
2017-08-11 - club - NTB - male - 1068400 - Gloucestershire vs Sussex
2017-08-11 - club - NTB - male - 1068399 - Leicestershire vs Northamptonshire
2017-08-11 - club - NTB - male - 1068398 - Essex vs Middlesex
2017-08-11 - club - NTB - male - 1068397 - Durham vs Worcestershire
2017-08-11 - club - NTB - male - 1068396 - Warwickshire vs Nottinghamshire
2017-08-11 - club - NTB - male - 1068395 - Kent vs Hampshire
2017-08-10 - club - NTB - male - 1068394 - Middlesex vs Sussex
2017-08-10 - club - NTB - male - 1068393 - Glamorgan vs Hampshire
2017-08-06 - club - NTB - male - 1068392 - Surrey vs Somerset
2017-08-05 - club - NTB - male - 1068391 - Northamptonshire vs Worcestershire
2017-08-05 - club - NTB - male - 1068390 - Durham vs Nottinghamshire
2017-08-04 - club - NTB - male - 1068389 - Hampshire vs Essex
2017-08-04 - club - NTB - male - 1068388 - Worcestershire vs Warwickshire
2017-08-04 - club - NTB - male - 1068387 - Glamorgan vs Surrey
2017-08-04 - club - NTB - male - 1068386 - Kent vs Sussex
2017-08-04 - club - NTB - male - 1068385 - Somerset vs Gloucestershire
2017-08-04 - club - NTB - male - 1068384 - Durham vs Yorkshire
2017-08-04 - club - NTB - male - 1068383 - Nottinghamshire vs Derbyshire
2017-08-04 - club - NTB - male - 1068382 - Lancashire vs Leicestershire
2017-08-03 - club - NTB - male - 1068381 - Middlesex vs Hampshire
2017-08-03 - club - NTB - male - 1068380 - Yorkshire vs Derbyshire
2017-08-03 - club - NTB - male - 1068379 - Surrey vs Sussex
2017-08-03 - club - NTB - male - 1068378 - Northamptonshire vs Lancashire
2017-08-03 - club - NTB - male - 1068377 - Gloucestershire vs Glamorgan
2017-08-02 - club - NTB - male - 1068376 - Nottinghamshire vs Leicestershire
2017-08-01 - club - NTB - male - 1068375 - Kent vs Hampshire
2017-08-01 - club - NTB - male - 1068374 - Warwickshire vs Northamptonshire
2017-07-30 - club - NTB - male - 1068373 - Lancashire vs Warwickshire
2017-07-30 - club - NTB - male - 1068372 - Somerset vs Sussex
2017-07-30 - club - NTB - male - 1068371 - Glamorgan vs Kent
2017-07-30 - club - NTB - male - 1068370 - Leicestershire vs Derbyshire
2017-07-30 - club - NTB - male - 1068369 - Durham vs Worcestershire
2017-07-30 - club - NTB - male - 1068368 - Yorkshire vs Nottinghamshire
2017-07-28 - club - NTB - male - 1068364 - Gloucestershire vs Hampshire
2017-07-28 - club - NTB - male - 1068362 - Leicestershire vs Durham
2017-07-28 - club - NTB - male - 1068361 - Middlesex vs Sussex
2017-07-27 - club - NTB - male - 1068359 - Worcestershire vs Northamptonshire
2017-07-27 - club - NTB - male - 1068358 - Middlesex vs Essex
2017-07-27 - club - NTB - male - 1068357 - Somerset vs Kent
2017-07-26 - club - NTB - male - 1068356 - Worcestershire vs Nottinghamshire
2017-07-26 - club - NTB - male - 1068355 - Somerset vs Hampshire
2017-07-26 - club - NTB - male - 1068354 - Yorkshire vs Durham
2017-07-25 - club - NTB - male - 1068353 - Durham vs Nottinghamshire
2017-07-25 - club - NTB - male - 1068352 - Glamorgan vs Gloucestershire
2017-07-23 - club - NTB - male - 1068349 - Warwickshire vs Derbyshire
2017-07-23 - club - NTB - male - 1068348 - Kent vs Sussex
2017-07-23 - club - NTB - male - 1068347 - Middlesex vs Somerset
2017-07-23 - club - NTB - male - 1068346 - Lancashire vs Durham
2017-07-23 - club - NTB - male - 1068343 - Yorkshire vs Worcestershire
2017-07-22 - club - NTB - male - 1068342 - Northamptonshire vs Nottinghamshire
2017-07-21 - club - NTB - male - 1068340 - Sussex vs Glamorgan
2017-07-21 - club - NTB - male - 1068339 - Hampshire vs Essex
2017-07-21 - club - NTB - male - 1068338 - Nottinghamshire vs Derbyshire
2017-07-21 - club - NTB - male - 1068336 - Surrey vs Middlesex
2017-07-21 - club - NTB - male - 1068335 - Yorkshire vs Warwickshire
2017-07-21 - club - NTB - male - 1068334 - Northamptonshire vs Leicestershire
2017-07-20 - club - NTB - male - 1068333 - Hampshire vs Sussex
2017-07-20 - club - NTB - male - 1068332 - Leicestershire vs Durham
2017-07-20 - club - NTB - male - 1068331 - Middlesex vs Kent
2017-07-19 - club - NTB - male - 1068330 - Surrey vs Essex
2017-07-19 - club - NTB - male - 1068329 - Worcestershire vs Derbyshire
2017-07-18 - club - NTB - male - 1068328 - Gloucestershire vs Kent
2017-07-16 - club - NTB - male - 1068327 - Somerset vs Middlesex
2017-07-16 - club - NTB - male - 1068326 - Sussex vs Gloucestershire
2017-07-16 - club - NTB - male - 1068325 - Essex vs Glamorgan
2017-07-16 - club - NTB - male - 1068324 - Derbyshire vs Lancashire
2017-07-16 - club - NTB - male - 1068323 - Leicestershire vs Warwickshire
2017-07-15 - club - NTB - male - 1068322 - Glamorgan vs Somerset
2017-07-14 - club - NTB - male - 1068321 - Worcestershire vs Leicestershire
2017-07-14 - club - NTB - male - 1068320 - Warwickshire vs Northamptonshire
2017-07-14 - club - NTB - male - 1068319 - Surrey vs Kent
2017-07-14 - club - NTB - male - 1068318 - Lancashire vs Yorkshire
2017-07-14 - club - NTB - male - 1068317 - Hampshire vs Middlesex
2017-07-13 - club - NTB - male - 1068316 - Kent vs Gloucestershire
2017-07-13 - club - NTB - male - 1068315 - Surrey vs Middlesex
2017-07-13 - club - NTB - male - 1068314 - Essex vs Somerset
2017-07-12 - club - NTB - male - 1068313 - Hampshire vs Sussex
2017-07-09 - club - NTB - male - 1068311 - Essex vs Kent
2017-07-09 - club - NTB - male - 1068310 - Lancashire vs Leicestershire
2017-07-09 - club - NTB - male - 1068309 - Surrey vs Somerset
2017-07-09 - club - NTB - male - 1068308 - Glamorgan vs Sussex
2017-07-09 - club - NTB - male - 1068307 - Durham vs Northamptonshire
2017-07-08 - club - NTB - male - 1068306 - Nottinghamshire vs Warwickshire
2017-07-08 - club - NTB - male - 1068305 - Derbyshire vs Yorkshire
2017-07-07 - club - NTB - male - 1068304 - Northamptonshire vs Derbyshire
2017-07-07 - club - NTB - male - 1068303 - Worcestershire vs Warwickshire
2017-07-07 - club - NTB - male - 1068302 - Gloucestershire vs Middlesex
2017-07-07 - club - NTB - male - 1068301 - Hampshire vs Glamorgan
2017-07-07 - club - NTB - male - 1068300 - Lancashire vs Durham
2017-07-07 - club - NTB - male - 1068299 - Surrey vs Essex
2017-07-07 - club - NTB - male - 1068298 - Yorkshire vs Nottinghamshire
2016-08-20 - club - NTB - male - 947355 - Durham vs Northamptonshire
2016-08-20 - club - NTB - male - 947353 - Durham vs Yorkshire
2016-08-20 - club - NTB - male - 947351 - Nottinghamshire vs Northamptonshire
2016-08-11 - club - NTB - male - 947349 - Glamorgan vs Yorkshire
2016-08-10 - club - NTB - male - 947347 - Gloucestershire vs Durham
2016-08-09 - club - NTB - male - 947345 - Northamptonshire vs Middlesex
2016-08-08 - club - NTB - male - 947343 - Nottinghamshire vs Essex
2016-07-29 - club - NTB - male - 947341 - Northamptonshire vs Yorkshire
2016-07-29 - club - NTB - male - 947339 - Hampshire vs Somerset
2016-07-29 - club - NTB - male - 947337 - Gloucestershire vs Middlesex
2016-07-29 - club - NTB - male - 947335 - Nottinghamshire vs Leicestershire
2016-07-29 - club - NTB - male - 947333 - Surrey vs Kent
2016-07-29 - club - NTB - male - 947331 - Essex vs Glamorgan
2016-07-29 - club - NTB - male - 947329 - Durham vs Derbyshire
2016-07-29 - club - NTB - male - 947327 - Lancashire vs Warwickshire
2016-07-28 - club - NTB - male - 947325 - Sussex vs Glamorgan
2016-07-28 - club - NTB - male - 947323 - Middlesex vs Essex
2016-07-22 - club - NTB - male - 947321 - Derbyshire vs Worcestershire
2016-07-22 - club - NTB - male - 947319 - Surrey vs Sussex
2016-07-22 - club - NTB - male - 947317 - Glamorgan vs Somerset
2016-07-22 - club - NTB - male - 947315 - Warwickshire vs Nottinghamshire
2016-07-22 - club - NTB - male - 947313 - Yorkshire vs Northamptonshire
2016-07-22 - club - NTB - male - 947311 - Hampshire vs Middlesex
2016-07-22 - club - NTB - male - 947309 - Durham vs Lancashire
2016-07-22 - club - NTB - male - 947307 - Kent vs Essex
2016-07-21 - club - NTB - male - 947305 - Essex vs Sussex
2016-07-21 - club - NTB - male - 947303 - Middlesex vs Surrey
2016-07-20 - club - NTB - male - 947301 - Yorkshire vs Durham
2016-07-19 - club - NTB - male - 947299 - Northamptonshire vs Warwickshire
2016-07-17 - club - NTB - male - 947297 - Warwickshire vs Leicestershire
2016-07-17 - club - NTB - male - 947295 - Gloucestershire vs Essex
2016-07-15 - club - NTB - male - 947293 - Nottinghamshire vs Yorkshire
2016-07-15 - club - NTB - male - 947291 - Kent vs Surrey
2016-07-15 - club - NTB - male - 947289 - Durham vs Northamptonshire
2016-07-15 - club - NTB - male - 947287 - Somerset vs Middlesex
2016-07-15 - club - NTB - male - 947285 - Leicestershire vs Lancashire
2016-07-15 - club - NTB - male - 947283 - Sussex vs Hampshire
2016-07-15 - club - NTB - male - 947281 - Worcestershire vs Warwickshire
2016-07-14 - club - NTB - male - 947279 - Hampshire vs Glamorgan
2016-07-13 - club - NTB - male - 947277 - Derbyshire vs Lancashire
2016-07-10 - club - NTB - male - 947273 - Derbyshire vs Yorkshire
2016-07-10 - club - NTB - male - 947271 - Durham vs Leicestershire
2016-07-10 - club - NTB - male - 947269 - Glamorgan vs Gloucestershire
2016-07-09 - club - NTB - male - 947267 - Nottinghamshire vs Worcestershire
2016-07-08 - club - NTB - male - 947265 - Surrey vs Somerset
2016-07-08 - club - NTB - male - 947263 - Northamptonshire vs Nottinghamshire
2016-07-08 - club - NTB - male - 947261 - Worcestershire vs Lancashire
2016-07-08 - club - NTB - male - 947259 - Gloucestershire vs Kent
2016-07-08 - club - NTB - male - 947257 - Middlesex vs Glamorgan
2016-07-08 - club - NTB - male - 947255 - Hampshire vs Essex
2016-07-08 - club - NTB - male - 947253 - Leicestershire vs Derbyshire
2016-07-08 - club - NTB - male - 947251 - Yorkshire vs Warwickshire
2016-07-07 - club - NTB - male - 947249 - Glamorgan vs Sussex
2016-07-07 - club - NTB - male - 947247 - Somerset vs Kent
2016-07-06 - club - NTB - male - 947245 - Gloucestershire vs Surrey
2016-07-01 - club - NTB - male - 947241 - Warwickshire vs Northamptonshire
2016-07-01 - club - NTB - male - 947239 - Sussex vs Middlesex
2016-07-01 - club - NTB - male - 947237 - Yorkshire vs Lancashire
2016-07-01 - club - NTB - male - 947235 - Essex vs Kent
2016-07-01 - club - NTB - male - 947231 - Somerset vs Gloucestershire
2016-07-01 - club - NTB - male - 947227 - Worcestershire vs Derbyshire
2016-06-30 - club - NTB - male - 947225 - Kent vs Sussex
2016-06-30 - club - NTB - male - 947223 - Durham vs Worcestershire
2016-06-26 - club - NTB - male - 947221 - Northamptonshire vs Leicestershire
2016-06-26 - club - NTB - male - 947219 - Sussex vs Gloucestershire
2016-06-25 - club - NTB - male - 947215 - Surrey vs Essex
2016-06-24 - club - NTB - male - 947213 - Durham vs Yorkshire
2016-06-24 - club - NTB - male - 947211 - Lancashire vs Worcestershire
2016-06-24 - club - NTB - male - 947209 - Glamorgan vs Surrey
2016-06-24 - club - NTB - male - 947207 - Derbyshire vs Nottinghamshire
2016-06-24 - club - NTB - male - 947205 - Kent vs Middlesex
2016-06-24 - club - NTB - male - 947203 - Essex vs Hampshire
2016-06-24 - club - NTB - male - 947201 - Leicestershire vs Warwickshire
2016-06-23 - club - NTB - male - 947199 - Middlesex vs Somerset
2016-06-19 - club - NTB - male - 947197 - Warwickshire vs Lancashire
2016-06-19 - club - NTB - male - 947195 - Somerset vs Hampshire
2016-06-19 - club - NTB - male - 947193 - Yorkshire vs Derbyshire
2016-06-18 - club - NTB - male - 947191 - Worcestershire vs Nottinghamshire
2016-06-17 - club - NTB - male - 947185 - Gloucestershire vs Somerset
2016-06-17 - club - NTB - male - 947181 - Surrey vs Middlesex
2016-06-17 - club - NTB - male - 947179 - Glamorgan vs Kent
2016-06-17 - club - NTB - male - 947177 - Northamptonshire vs Durham
2016-06-17 - club - NTB - male - 947175 - Derbyshire vs Warwickshire
2016-06-16 - club - NTB - male - 947169 - Essex vs Gloucestershire
2016-06-10 - club - NTB - male - 947163 - Somerset vs Surrey
2016-06-10 - club - NTB - male - 947161 - Worcestershire vs Northamptonshire
2016-06-10 - club - NTB - male - 947159 - Essex vs Middlesex
2016-06-10 - club - NTB - male - 947157 - Lancashire vs Leicestershire
2016-06-10 - club - NTB - male - 947155 - Sussex vs Kent
2016-06-10 - club - NTB - male - 947153 - Gloucestershire vs Glamorgan
2016-06-09 - club - NTB - male - 947233 - Surrey vs Hampshire
2016-06-08 - club - NTB - male - 947149 - Kent vs Hampshire
2016-06-04 - club - NTB - male - 947147 - Nottinghamshire vs Lancashire
2016-06-04 - club - NTB - male - 947145 - Leicestershire vs Durham
2016-06-03 - club - NTB - male - 947143 - Lancashire vs Yorkshire
2016-06-03 - club - NTB - male - 947141 - Northamptonshire vs Worcestershire
2016-06-03 - club - NTB - male - 947139 - Sussex vs Surrey
2016-06-03 - club - NTB - male - 947137 - Derbyshire vs Leicestershire
2016-06-03 - club - NTB - male - 947135 - Glamorgan vs Hampshire
2016-06-03 - club - NTB - male - 947133 - Kent vs Gloucestershire
2016-06-03 - club - NTB - male - 947131 - Somerset vs Essex
2016-06-03 - club - NTB - male - 947129 - Warwickshire vs Durham
2016-06-02 - club - NTB - male - 947127 - Worcestershire vs Yorkshire
2016-06-02 - club - NTB - male - 947125 - Hampshire vs Kent
2016-06-02 - club - NTB - male - 947123 - Middlesex vs Gloucestershire
2016-06-01 - club - NTB - male - 947121 - Sussex vs Somerset
2016-06-01 - club - NTB - male - 947119 - Durham vs Nottinghamshire
2016-06-01 - club - NTB - male - 947117 - Glamorgan vs Essex
2016-05-27 - club - NTB - male - 947115 - Warwickshire vs Worcestershire
2016-05-27 - club - NTB - male - 947113 - Yorkshire vs Leicestershire
2016-05-27 - club - NTB - male - 947111 - Lancashire vs Durham
2016-05-27 - club - NTB - male - 947109 - Northamptonshire vs Derbyshire
2016-05-27 - club - NTB - male - 947107 - Middlesex vs Hampshire
2016-05-26 - club - NTB - male - 947105 - Surrey vs Glamorgan
2016-05-21 - club - NTB - male - 947103 - Lancashire vs Derbyshire
2016-05-20 - club - NTB - male - 947101 - Gloucestershire vs Sussex
2016-05-20 - club - NTB - male - 947099 - Essex vs Surrey
2016-05-20 - club - NTB - male - 947097 - Kent vs Somerset
2016-05-20 - club - NTB - male - 947095 - Leicestershire vs Northamptonshire
2016-05-20 - club - NTB - male - 947093 - Worcestershire vs Durham
2016-05-20 - club - NTB - male - 947091 - Nottinghamshire vs Warwickshire
2015-08-29 - club - NTB - male - 804711 - Lancashire vs Northamptonshire
2015-08-29 - club - NTB - male - 804709 - Hampshire vs Lancashire
2015-08-29 - club - NTB - male - 804707 - Warwickshire vs Northamptonshire
2015-08-15 - club - NTB - male - 804705 - Kent vs Lancashire
2015-08-14 - club - NTB - male - 804703 - Hampshire vs Worcestershire
2015-08-12 - club - NTB - male - 804699 - Sussex vs Northamptonshire
2015-07-24 - club - NTB - male - 804697 - Warwickshire vs Yorkshire
2015-07-24 - club - NTB - male - 804685 - Glamorgan vs Gloucestershire
2015-07-23 - club - NTB - male - 804681 - Middlesex vs Surrey
2015-07-23 - club - NTB - male - 804679 - Hampshire vs Somerset
2015-07-22 - club - NTB - male - 804677 - Warwickshire vs Northamptonshire
2015-07-17 - club - NTB - male - 804675 - Hampshire vs Sussex
2015-07-17 - club - NTB - male - 804673 - Surrey vs Somerset
2015-07-17 - club - NTB - male - 804671 - Yorkshire vs Northamptonshire
2015-07-17 - club - NTB - male - 804669 - Glamorgan vs Kent
2015-07-17 - club - NTB - male - 804667 - Middlesex vs Essex
2015-07-17 - club - NTB - male - 804665 - Nottinghamshire vs Durham
2015-07-17 - club - NTB - male - 804663 - Derbyshire vs Worcestershire
2015-07-17 - club - NTB - male - 804661 - Lancashire vs Warwickshire
2015-07-15 - club - NTB - male - 804659 - Lancashire vs Nottinghamshire
2015-07-14 - club - NTB - male - 804657 - Worcestershire vs Yorkshire
2015-07-14 - club - NTB - male - 804655 - Hampshire vs Gloucestershire
2015-07-12 - club - NTB - male - 804653 - Leicestershire vs Northamptonshire
2015-07-12 - club - NTB - male - 804651 - Gloucestershire vs Kent
2015-07-12 - club - NTB - male - 804649 - Yorkshire vs Derbyshire
2015-07-10 - club - NTB - male - 804647 - Durham vs Yorkshire
2015-07-10 - club - NTB - male - 804645 - Worcestershire vs Warwickshire
2015-07-10 - club - NTB - male - 804643 - Glamorgan vs Sussex
2015-07-10 - club - NTB - male - 804641 - Nottinghamshire vs Derbyshire
2015-07-10 - club - NTB - male - 804639 - Essex vs Middlesex
2015-07-10 - club - NTB - male - 804637 - Lancashire vs Leicestershire
2015-07-10 - club - NTB - male - 804635 - Kent vs Somerset
2015-07-10 - club - NTB - male - 804633 - Hampshire vs Surrey
2015-07-05 - club - NTB - male - 804631 - Durham vs Worcestershire
2015-07-05 - club - NTB - male - 804629 - Northamptonshire vs Derbyshire
2015-07-04 - club - NTB - male - 804627 - Warwickshire vs Leicestershire
2015-07-03 - club - NTB - male - 804625 - Sussex vs Kent
2015-07-03 - club - NTB - male - 804623 - Middlesex vs Surrey
2015-07-03 - club - NTB - male - 804621 - Somerset vs Gloucestershire
2015-07-03 - club - NTB - male - 804619 - Worcestershire vs Nottinghamshire
2015-07-03 - club - NTB - male - 804617 - Lancashire vs Yorkshire
2015-07-03 - club - NTB - male - 804615 - Glamorgan vs Hampshire
2015-07-03 - club - NTB - male - 804613 - Durham vs Leicestershire
2015-07-03 - club - NTB - male - 804611 - Warwickshire vs Derbyshire
2015-07-02 - club - NTB - male - 804609 - Middlesex vs Sussex
2015-07-01 - club - NTB - male - 804607 - Gloucestershire vs Surrey
2015-06-28 - club - NTB - male - 804605 - Glamorgan vs Somerset
2015-06-27 - club - NTB - male - 804603 - Northamptonshire vs Nottinghamshire
2015-06-26 - club - NTB - male - 804601 - Northamptonshire vs Worcestershire
2015-06-26 - club - NTB - male - 804599 - Middlesex vs Somerset
2015-06-26 - club - NTB - male - 804597 - Leicestershire vs Yorkshire
2015-06-26 - club - NTB - male - 804595 - Warwickshire vs Lancashire
2015-06-26 - club - NTB - male - 804593 - Gloucestershire vs Sussex
2015-06-26 - club - NTB - male - 804591 - Surrey vs Glamorgan
2015-06-26 - club - NTB - male - 804589 - Essex vs Hampshire
2015-06-26 - club - NTB - male - 804587 - Derbyshire vs Nottinghamshire
2015-06-25 - club - NTB - male - 804585 - Durham vs Lancashire
2015-06-21 - club - NTB - male - 804583 - Glamorgan vs Sussex
2015-06-21 - club - NTB - male - 804581 - Yorkshire vs Warwickshire
2015-06-19 - club - NTB - male - 804579 - Yorkshire vs Nottinghamshire
2015-06-19 - club - NTB - male - 804577 - Derbyshire vs Worcestershire
2015-06-19 - club - NTB - male - 804575 - Kent vs Surrey
2015-06-19 - club - NTB - male - 804573 - Northamptonshire vs Lancashire
2015-06-19 - club - NTB - male - 804571 - Hampshire vs Sussex
2015-06-19 - club - NTB - male - 804569 - Gloucestershire vs Somerset
2015-06-19 - club - NTB - male - 804567 - Essex vs Glamorgan
2015-06-19 - club - NTB - male - 804565 - Warwickshire vs Leicestershire
2015-06-18 - club - NTB - male - 804563 - Hampshire vs Middlesex
2015-06-18 - club - NTB - male - 804561 - Lancashire vs Worcestershire
2015-06-18 - club - NTB - male - 804559 - Essex vs Kent
2015-06-18 - club - NTB - male - 804557 - Derbyshire vs Leicestershire
2015-06-14 - club - NTB - male - 804555 - Yorkshire vs Northamptonshire
2015-06-14 - club - NTB - male - 804553 - Sussex vs Surrey
2015-06-14 - club - NTB - male - 804551 - Gloucestershire vs Middlesex
2015-06-13 - club - NTB - male - 804549 - Somerset vs Glamorgan
2015-06-12 - club - NTB - male - 804547 - Sussex vs Essex
2015-06-12 - club - NTB - male - 804543 - Northamptonshire vs Leicestershire
2015-06-12 - club - NTB - male - 804541 - Lancashire vs Derbyshire
2015-06-12 - club - NTB - male - 804539 - Kent vs Hampshire
2015-06-12 - club - NTB - male - 804537 - Glamorgan vs Gloucestershire
2015-06-12 - club - NTB - male - 804535 - Worcestershire vs Durham
2015-06-12 - club - NTB - male - 804533 - Nottinghamshire vs Warwickshire
2015-06-11 - club - NTB - male - 804531 - Derbyshire vs Northamptonshire
2015-06-11 - club - NTB - male - 804529 - Essex vs Gloucestershire
2015-06-07 - club - NTB - male - 804527 - Nottinghamshire vs Worcestershire
2015-06-06 - club - NTB - male - 804525 - Durham vs Warwickshire
2015-06-05 - club - NTB - male - 804523 - Yorkshire vs Lancashire
2015-06-05 - club - NTB - male - 804521 - Surrey vs Essex
2015-06-05 - club - NTB - male - 804519 - Hampshire vs Somerset
2015-06-05 - club - NTB - male - 804517 - Nottinghamshire vs Leicestershire
2015-06-05 - club - NTB - male - 804515 - Worcestershire vs Northamptonshire
2015-06-05 - club - NTB - male - 804513 - Kent vs Gloucestershire
2015-06-05 - club - NTB - male - 804511 - Glamorgan vs Middlesex
2015-06-05 - club - NTB - male - 804509 - Durham vs Derbyshire
2015-06-04 - club - NTB - male - 804507 - Hampshire vs Middlesex
2015-05-31 - club - NTB - male - 804505 - Kent vs Somerset
2015-05-31 - club - NTB - male - 804503 - Nottinghamshire vs Durham
2015-05-29 - club - NTB - male - 804501 - Leicestershire vs Worcestershire
2015-05-29 - club - NTB - male - 804499 - Middlesex vs Sussex
2015-05-29 - club - NTB - male - 804497 - Northamptonshire vs Warwickshire
2015-05-29 - club - NTB - male - 804495 - Kent vs Surrey
2015-05-29 - club - NTB - male - 804493 - Hampshire vs Glamorgan
2015-05-29 - club - NTB - male - 804491 - Essex vs Somerset
2015-05-29 - club - NTB - male - 804489 - Durham vs Yorkshire
2015-05-29 - club - NTB - male - 804487 - Lancashire vs Derbyshire
2015-05-28 - club - NTB - male - 804485 - Middlesex vs Kent
2015-05-28 - club - NTB - male - 804483 - Durham vs Leicestershire
2015-05-24 - club - NTB - male - 804481 - Gloucestershire vs Essex
2015-05-22 - club - NTB - male - 804477 - Nottinghamshire vs Yorkshire
2015-05-22 - club - NTB - male - 804475 - Derbyshire vs Leicestershire
2015-05-22 - club - NTB - male - 804473 - Durham vs Lancashire
2015-05-22 - club - NTB - male - 804471 - Hampshire vs Kent
2015-05-22 - club - NTB - male - 804469 - Glamorgan vs Essex
2015-05-22 - club - NTB - male - 804467 - Warwickshire vs Worcestershire
2015-05-17 - club - NTB - male - 804465 - Sussex vs Gloucestershire
2015-05-16 - club - NTB - male - 804463 - Surrey vs Essex
2015-05-15 - club - NTB - male - 804461 - Derbyshire vs Yorkshire
2015-05-15 - club - NTB - male - 804459 - Glamorgan vs Surrey
2015-05-15 - club - NTB - male - 804457 - Warwickshire vs Nottinghamshire
2015-05-15 - club - NTB - male - 804455 - Leicestershire vs Lancashire
2015-05-15 - club - NTB - male - 804453 - Kent vs Sussex
2015-05-15 - club - NTB - male - 804451 - Hampshire vs Essex
2015-05-15 - club - NTB - male - 804449 - Middlesex vs Gloucestershire
2015-05-15 - club - NTB - male - 804447 - Durham vs Northamptonshire
2014-08-23 - club - NTB - male - 693273 - Warwickshire vs Lancashire
2014-08-23 - club - NTB - male - 693271 - Lancashire vs Hampshire
2014-08-23 - club - NTB - male - 693269 - Warwickshire vs Surrey
2014-08-03 - club - NTB - male - 693267 - Nottinghamshire vs Hampshire
2014-08-02 - club - NTB - male - 693265 - Warwickshire vs Essex
2014-08-02 - club - NTB - male - 693263 - Worcestershire vs Surrey
2014-08-01 - club - NTB - male - 693261 - Lancashire vs Glamorgan
2014-07-25 - club - NTB - male - 693259 - Kent vs Surrey
2014-07-25 - club - NTB - male - 693257 - Essex vs Sussex
2014-07-25 - club - NTB - male - 693255 - Warwickshire vs Leicestershire
2014-07-25 - club - NTB - male - 693253 - Northamptonshire vs Durham
2014-07-25 - club - NTB - male - 693251 - Yorkshire vs Nottinghamshire
2014-07-25 - club - NTB - male - 693249 - Worcestershire vs Derbyshire
2014-07-25 - club - NTB - male - 693247 - Gloucestershire vs Glamorgan
2014-07-25 - club - NTB - male - 693245 - Somerset vs Middlesex
2014-07-24 - club - NTB - male - 693243 - Lancashire vs Durham
2014-07-24 - club - NTB - male - 693241 - Middlesex vs Surrey
2014-07-23 - club - NTB - male - 693239 - Nottinghamshire vs Northamptonshire
2014-07-22 - club - NTB - male - 693237 - Essex vs Hampshire
2014-07-20 - club - NTB - male - 693235 - Essex vs Gloucestershire
2014-07-20 - club - NTB - male - 693233 - Nottinghamshire vs Leicestershire
2014-07-18 - club - NTB - male - 693231 - Hampshire vs Sussex
2014-07-18 - club - NTB - male - 693229 - Kent vs Somerset
2014-07-18 - club - NTB - male - 693227 - Surrey vs Gloucestershire
2014-07-18 - club - NTB - male - 693225 - Lancashire vs Derbyshire
2014-07-18 - club - NTB - male - 693223 - Durham vs Leicestershire
2014-07-18 - club - NTB - male - 693221 - Yorkshire vs Warwickshire
2014-07-18 - club - NTB - male - 693219 - Worcestershire vs Northamptonshire
2014-07-18 - club - NTB - male - 693217 - Glamorgan vs Essex
2014-07-16 - club - NTB - male - 693215 - Somerset vs Surrey
2014-07-15 - club - NTB - male - 693213 - Glamorgan vs Sussex
2014-07-13 - club - NTB - male - 693211 - Yorkshire vs Derbyshire
2014-07-12 - club - NTB - male - 693209 - Essex vs Kent
2014-07-11 - club - NTB - male - 693207 - Middlesex vs Hampshire
2014-07-11 - club - NTB - male - 693205 - Worcestershire vs Warwickshire
2014-07-11 - club - NTB - male - 693203 - Yorkshire vs Durham
2014-07-11 - club - NTB - male - 693201 - Lancashire vs Leicestershire
2014-07-11 - club - NTB - male - 693199 - Kent vs Sussex
2014-07-11 - club - NTB - male - 693197 - Glamorgan vs Surrey
2014-07-11 - club - NTB - male - 693195 - Derbyshire vs Northamptonshire
2014-07-11 - club - NTB - male - 693193 - Somerset vs Gloucestershire
2014-07-08 - club - NTB - male - 693191 - Nottinghamshire vs Warwickshire
2014-07-06 - club - NTB - male - 693189 - Derbyshire vs Leicestershire
2014-07-06 - club - NTB - male - 693187 - Lancashire vs Worcestershire
2014-07-06 - club - NTB - male - 693185 - Somerset vs Hampshire
2014-07-04 - club - NTB - male - 693183 - Gloucestershire vs Sussex
2014-07-04 - club - NTB - male - 693181 - Hampshire vs Kent
2014-07-04 - club - NTB - male - 693179 - Surrey vs Essex
2014-07-04 - club - NTB - male - 693173 - Northamptonshire vs Leicestershire
2014-07-03 - club - NTB - male - 693167 - Northamptonshire vs Warwickshire
2014-07-03 - club - NTB - male - 693165 - Middlesex vs Glamorgan
2014-07-02 - club - NTB - male - 693163 - Durham vs Yorkshire
2014-07-02 - club - NTB - male - 693161 - Kent vs Surrey
2014-07-01 - club - NTB - male - 693159 - Yorkshire vs Leicestershire
2014-06-29 - club - NTB - male - 693157 - Derbyshire vs Durham
2014-06-28 - club - NTB - male - 693155 - Nottinghamshire vs Yorkshire
2014-06-27 - club - NTB - male - 693153 - Kent vs Gloucestershire
2014-06-27 - club - NTB - male - 693151 - Warwickshire vs Derbyshire
2014-06-27 - club - NTB - male - 693147 - Middlesex vs Sussex
2014-06-27 - club - NTB - male - 693145 - Hampshire vs Surrey
2014-06-27 - club - NTB - male - 693141 - Durham vs Northamptonshire
2014-06-27 - club - NTB - male - 693139 - Somerset vs Essex
2014-06-26 - club - NTB - male - 693137 - Gloucestershire vs Middlesex
2014-06-25 - club - NTB - male - 693135 - Hampshire vs Glamorgan
2014-06-20 - club - NTB - male - 693133 - Hampshire vs Gloucestershire
2014-06-20 - club - NTB - male - 693131 - Sussex vs Kent
2014-06-20 - club - NTB - male - 693129 - Middlesex vs Essex
2014-06-20 - club - NTB - male - 693127 - Durham vs Leicestershire
2014-06-20 - club - NTB - male - 693125 - Lancashire vs Northamptonshire
2014-06-20 - club - NTB - male - 693123 - Warwickshire vs Worcestershire
2014-06-20 - club - NTB - male - 693121 - Surrey vs Glamorgan
2014-06-20 - club - NTB - male - 693119 - Nottinghamshire vs Derbyshire
2014-06-19 - club - NTB - male - 693117 - Northamptonshire vs Warwickshire
2014-06-19 - club - NTB - male - 693115 - Nottinghamshire vs Leicestershire
2014-06-18 - club - NTB - male - 693113 - Somerset vs Middlesex
2014-06-15 - club - NTB - male - 693111 - Somerset vs Sussex
2014-06-13 - club - NTB - male - 693109 - Gloucestershire vs Essex
2014-06-13 - club - NTB - male - 693107 - Worcestershire vs Derbyshire
2014-06-13 - club - NTB - male - 693105 - Lancashire vs Leicestershire
2014-06-13 - club - NTB - male - 693103 - Sussex vs Surrey
2014-06-13 - club - NTB - male - 693101 - Yorkshire vs Northamptonshire
2014-06-13 - club - NTB - male - 693099 - Glamorgan vs Kent
2014-06-13 - club - NTB - male - 693097 - Somerset vs Hampshire
2014-06-13 - club - NTB - male - 693095 - Warwickshire vs Nottinghamshire
2014-06-11 - club - NTB - male - 693093 - Kent vs Essex
2014-06-08 - club - NTB - male - 693091 - Gloucestershire vs Glamorgan
2014-06-07 - club - NTB - male - 693089 - Durham vs Worcestershire
2014-06-06 - club - NTB - male - 693087 - Kent vs Middlesex
2014-06-06 - club - NTB - male - 693085 - Derbyshire vs Nottinghamshire
2014-06-06 - club - NTB - male - 693081 - Lancashire vs Yorkshire
2014-06-06 - club - NTB - male - 693079 - Leicestershire vs Worcestershire
2014-06-06 - club - NTB - male - 693077 - Gloucestershire vs Sussex
2014-06-06 - club - NTB - male - 693075 - Surrey vs Essex
2014-06-06 - club - NTB - male - 693073 - Glamorgan vs Somerset
2014-06-05 - club - NTB - male - 693071 - Hampshire vs Kent
2014-06-01 - club - NTB - male - 693069 - Warwickshire vs Leicestershire
2014-05-30 - club - NTB - male - 693067 - Essex vs Hampshire
2014-05-30 - club - NTB - male - 693065 - Lancashire vs Warwickshire
2014-05-30 - club - NTB - male - 693063 - Derbyshire vs Yorkshire
2014-05-30 - club - NTB - male - 693061 - Middlesex vs Surrey
2014-05-30 - club - NTB - male - 693059 - Northamptonshire vs Worcestershire
2014-05-30 - club - NTB - male - 693057 - Sussex vs Glamorgan
2014-05-30 - club - NTB - male - 693055 - Durham vs Nottinghamshire
2014-05-30 - club - NTB - male - 693053 - Kent vs Gloucestershire
2014-05-29 - club - NTB - male - 693049 - Lancashire vs Durham
2014-05-25 - club - NTB - male - 693047 - Hampshire vs Middlesex
2014-05-23 - club - NTB - male - 693045 - Middlesex vs Gloucestershire
2014-05-23 - club - NTB - male - 693043 - Glamorgan vs Essex
2014-05-23 - club - NTB - male - 693041 - Lancashire vs Derbyshire
2014-05-23 - club - NTB - male - 693037 - Hampshire vs Sussex
2014-05-23 - club - NTB - male - 693035 - Leicestershire vs Northamptonshire
2014-05-23 - club - NTB - male - 693033 - Kent vs Somerset
2014-05-23 - club - NTB - male - 693031 - Worcestershire vs Nottinghamshire
2014-05-18 - club - NTB - male - 693029 - Surrey vs Somerset
2014-05-17 - club - NTB - male - 693027 - Lancashire vs Worcestershire
2014-05-17 - club - NTB - male - 693025 - Sussex vs Middlesex
2014-05-17 - club - NTB - male - 693023 - Middlesex vs Essex
2014-05-16 - club - NTB - male - 693021 - Glamorgan vs Hampshire
2014-05-16 - club - NTB - male - 693017 - Durham vs Worcestershire
2014-05-16 - club - NTB - male - 693015 - Leicestershire vs Derbyshire
2014-05-16 - club - NTB - male - 693013 - Yorkshire vs Northamptonshire
2014-05-16 - club - NTB - male - 693009 - Nottinghamshire vs Lancashire

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
