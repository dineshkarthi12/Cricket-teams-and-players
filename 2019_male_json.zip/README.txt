This zip archive contains data files from Cricsheet in JSON format. This
archive contains 1358 matches of all types from 2019. A further 33 matches
have been withheld due to either featuring the Afghanistan men's team or being
played in the Afghanistan Premier League, due to the Cricsheet policy to no
longer feature matches involving Afghanistan men or played in Afghanistan
Premier League (see https://cricsheet.org/withheld-matches for more
information).


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/2019_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2019-12-31 - club - BPL - male - 1208094 - Rangpur Rangers vs Rajshahi Royals
2019-12-31 - club - BPL - male - 1208093 - Chattogram Challengers vs Cumilla Warriors
2019-12-31 - club - BBL - male - 1195589 - Adelaide Strikers vs Sydney Thunder
2019-12-30 - club - SSM - male - 1197756 - Otago vs Canterbury
2019-12-30 - club - SSM - male - 1197755 - Auckland vs Wellington
2019-12-30 - club - BPL - male - 1208092 - Dhaka Platoon vs Rajshahi Royals
2019-12-30 - club - BPL - male - 1208091 - Sylhet Thunder vs Rangpur Rangers
2019-12-30 - club - BBL - male - 1195588 - Hobart Hurricanes vs Melbourne Stars
2019-12-29 - club - SSM - male - 1197754 - Northern Districts vs Otago
2019-12-29 - club - BBL - male - 1195587 - Melbourne Renegades vs Adelaide Strikers
2019-12-28 - club - SSM - male - 1197753 - Auckland vs Central Districts
2019-12-28 - club - BPL - male - 1208090 - Sylhet Thunder vs Khulna Tigers
2019-12-28 - club - BPL - male - 1208089 - Rajshahi Royals vs Cumilla Warriors
2019-12-28 - club - BBL - male - 1195586 - Sydney Sixers vs Sydney Thunder
2019-12-27 - club - SSM - male - 1197752 - Wellington vs Central Districts
2019-12-27 - club - BPL - male - 1208088 - Khulna Tigers vs Rangpur Rangers
2019-12-27 - club - BPL - male - 1208087 - Dhaka Platoon vs Chattogram Challengers
2019-12-27 - club - BBL - male - 1195585 - Melbourne Stars vs Adelaide Strikers
2019-12-26 - international - Test - male - 1185304 - South Africa vs England
2019-12-26 - international - Test - male - 1183533 - Australia vs New Zealand
2019-12-26 - club - BBL - male - 1195584 - Perth Scorchers vs Sydney Sixers
2019-12-24 - club - BPL - male - 1208086 - Cumilla Warriors vs Rajshahi Royals
2019-12-24 - club - BPL - male - 1208085 - Sylhet Thunder vs Dhaka Platoon
2019-12-24 - club - BBL - male - 1195583 - Hobart Hurricanes vs Melbourne Renegades
2019-12-23 - club - SSM - male - 1197751 - Canterbury vs Central Districts
2019-12-23 - club - BPL - male - 1208084 - Khulna Tigers vs Rajshahi Royals
2019-12-23 - club - BPL - male - 1208083 - Cumilla Warriors vs Dhaka Platoon
2019-12-23 - club - BBL - male - 1195582 - Adelaide Strikers vs Perth Scorchers
2019-12-22 - international - ODI - male - 1187023 - India vs West Indies
2019-12-22 - club - SSM - male - 1197750 - Northern Districts vs Auckland
2019-12-22 - club - BBL - male - 1195581 - Sydney Sixers vs Brisbane Heat
2019-12-22 - club - BBL - male - 1195580 - Melbourne Stars vs Hobart Hurricanes
2019-12-21 - club - SSM - male - 1197749 - Wellington vs Otago
2019-12-21 - club - BPL - male - 1208082 - Chattogram Challengers vs Rangpur Rangers
2019-12-21 - club - BPL - male - 1208081 - Sylhet Thunder vs Khulna Tigers
2019-12-21 - club - BBL - male - 1195579 - Perth Scorchers vs Melbourne Renegades
2019-12-21 - club - BBL - male - 1195578 - Sydney Thunder vs Adelaide Strikers
2019-12-20 - club - SSM - male - 1197748 - Central Districts vs Northern Districts
2019-12-20 - club - BPL - male - 1208080 - Chattogram Challengers vs Cumilla Warriors
2019-12-20 - club - BPL - male - 1208079 - Rangpur Rangers vs Khulna Tigers
2019-12-20 - club - BBL - male - 1195577 - Brisbane Heat vs Melbourne Stars
2019-12-20 - club - BBL - male - 1195576 - Hobart Hurricanes vs Sydney Sixers
2019-12-19 - international - Test - male - 1206636 - Pakistan vs Sri Lanka
2019-12-19 - club - SSM - male - 1197747 - Otago vs Auckland
2019-12-19 - club - BBL - male - 1195575 - Melbourne Renegades vs Sydney Thunder
2019-12-18 - international - ODI - male - 1187022 - India vs West Indies
2019-12-18 - club - SSM - male - 1197746 - Central Districts vs Wellington
2019-12-18 - club - BPL - male - 1208078 - Chattogram Challengers vs Dhaka Platoon
2019-12-18 - club - BPL - male - 1208077 - Rangpur Rangers vs Cumilla Warriors
2019-12-18 - club - BBL - male - 1195574 - Sydney Sixers vs Perth Scorchers
2019-12-17 - club - SSM - male - 1197745 - Canterbury vs Auckland
2019-12-17 - club - BPL - male - 1208076 - Sylhet Thunder vs Chattogram Challengers
2019-12-17 - club - BPL - male - 1208075 - Rajshahi Royals vs Khulna Tigers
2019-12-17 - club - BBL - male - 1195573 - Brisbane Heat vs Sydney Thunder
2019-12-16 - club - SSM - male - 1197744 - Otago vs Northern Districts
2019-12-16 - club - MSL - male - 1202001 - Tshwane Spartans vs Paarl Rocks
2019-12-15 - international - ODI - male - 1206064 - United Arab Emirates vs Scotland
2019-12-15 - international - ODI - male - 1187021 - India vs West Indies
2019-12-15 - club - SSM - male - 1197743 - Canterbury vs Wellington
2019-12-14 - international - ODI - male - 1206063 - Scotland vs United States of America
2019-12-14 - club - SSM - male - 1197742 - Otago vs Auckland
2019-12-14 - club - BPL - male - 1208074 - Dhaka Platoon vs Sylhet Thunder
2019-12-14 - club - BPL - male - 1208073 - Rangpur Rangers vs Chattogram Challengers
2019-12-13 - club - SSM - male - 1197741 - Central Districts vs Northern Districts
2019-12-13 - club - MSL - male - 1202000 - Tshwane Spartans vs Nelson Mandela Bay Giants
2019-12-13 - club - BPL - male - 1208072 - Dhaka Platoon vs Cumilla Warriors
2019-12-13 - club - BPL - male - 1208071 - Sylhet Thunder vs Rajshahi Royals
2019-12-12 - international - Test - male - 1183532 - Australia vs New Zealand
2019-12-12 - international - ODI - male - 1206062 - United Arab Emirates vs United States of America
2019-12-12 - club - BPL - male - 1208070 - Chattogram Challengers vs Khulna Tigers
2019-12-12 - club - BPL - male - 1208069 - Dhaka Platoon vs Rajshahi Royals
2019-12-11 - international - Test - male - 1206635 - Pakistan vs Sri Lanka
2019-12-11 - international - T20 - male - 1187020 - India vs West Indies
2019-12-11 - club - BPL - male - 1208068 - Cumilla Warriors vs Rangpur Rangers
2019-12-11 - club - BPL - male - 1208067 - Sylhet Thunder vs Chattogram Challengers
2019-12-09 - international - T20 - male - 1208613 - Nepal vs Maldives
2019-12-09 - international - ODI - male - 1206060 - Scotland vs United States of America
2019-12-08 - international - T20 - male - 1187019 - India vs West Indies
2019-12-08 - international - ODI - male - 1206059 - United Arab Emirates vs United States of America
2019-12-08 - club - MSL - male - 1201997 - Paarl Rocks vs Nelson Mandela Bay Giants
2019-12-07 - international - T20 - male - 1208612 - Bhutan vs Maldives
2019-12-07 - club - SSH - male - 1196131 - Tasmania vs South Australia
2019-12-07 - club - SSH - male - 1196129 - Western Australia vs Victoria
2019-12-06 - international - T20 - male - 1208609 - Nepal vs Maldives
2019-12-06 - international - T20 - male - 1187018 - India vs West Indies
2019-12-06 - club - MSL - male - 1201995 - Nelson Mandela Bay Giants vs Cape Town Blitz
2019-12-05 - international - T20 - male - 1208606 - Nepal vs Bhutan
2019-12-04 - club - MSL - male - 1201993 - Paarl Rocks vs Durban Heat
2019-12-03 - club - MSL - male - 1201992 - Tshwane Spartans vs Nelson Mandela Bay Giants
2019-12-01 - club - SMA - male - 1205862 - Karnataka vs Tamil Nadu
2019-12-01 - club - MSL - male - 1201991 - Cape Town Blitz vs Tshwane Spartans
2019-12-01 - club - MSL - male - 1201990 - Jozi Stars vs Paarl Rocks
2019-11-30 - club - MSL - male - 1201989 - Nelson Mandela Bay Giants vs Durban Heat
2019-11-29 - international - Test - male - 1187672 - New Zealand vs England
2019-11-29 - international - Test - male - 1183531 - Australia vs Pakistan
2019-11-29 - club - SMA - male - 1205861 - Haryana vs Karnataka
2019-11-29 - club - MSL - male - 1201988 - Paarl Rocks vs Tshwane Spartans
2019-11-28 - club - MSL - male - 1201987 - Cape Town Blitz vs Durban Heat
2019-11-27 - club - SMA - male - 1205859 - Mumbai vs Punjab
2019-11-27 - club - SMA - male - 1205858 - Jharkhand vs Tamil Nadu
2019-11-27 - club - SMA - male - 1205857 - Maharashtra vs Haryana
2019-11-27 - club - SMA - male - 1205856 - Rajasthan vs Delhi
2019-11-27 - club - MSL - male - 1201986 - Paarl Rocks vs Nelson Mandela Bay Giants
2019-11-25 - club - SMA - male - 1205855 - Punjab vs Tamil Nadu
2019-11-25 - club - SMA - male - 1205854 - Karnataka vs Mumbai
2019-11-25 - club - SMA - male - 1205853 - Maharashtra vs Rajasthan
2019-11-25 - club - SMA - male - 1205852 - Baroda vs Haryana
2019-11-24 - club - SMA - male - 1205851 - Jharkhand vs Mumbai
2019-11-24 - club - SMA - male - 1205850 - Punjab vs Karnataka
2019-11-24 - club - SMA - male - 1205849 - Haryana vs Delhi
2019-11-24 - club - SMA - male - 1205848 - Maharashtra vs Baroda
2019-11-24 - club - MSL - male - 1201985 - Tshwane Spartans vs Jozi Stars
2019-11-24 - club - MSL - male - 1201984 - Paarl Rocks vs Cape Town Blitz
2019-11-23 - club - MSL - male - 1201983 - Durban Heat vs Nelson Mandela Bay Giants
2019-11-22 - international - Test - male - 1187017 - India vs Bangladesh
2019-11-22 - club - SMA - male - 1205847 - Mumbai vs Tamil Nadu
2019-11-22 - club - SMA - male - 1205846 - Karnataka vs Jharkhand
2019-11-22 - club - SMA - male - 1205845 - Rajasthan vs Haryana
2019-11-22 - club - SMA - male - 1205844 - Baroda vs Delhi
2019-11-22 - club - MSL - male - 1201982 - Jozi Stars vs Paarl Rocks
2019-11-21 - international - Test - male - 1187671 - New Zealand vs England
2019-11-21 - international - Test - male - 1183530 - Australia vs Pakistan
2019-11-21 - club - SMA - male - 1205842 - Tamil Nadu vs Karnataka
2019-11-21 - club - SMA - male - 1205841 - Delhi vs Maharashtra
2019-11-21 - club - MSL - male - 1201981 - Tshwane Spartans vs Durban Heat
2019-11-20 - club - MSL - male - 1201980 - Cape Town Blitz vs Nelson Mandela Bay Giants
2019-11-18 - club - SMA - male - 1205835 - Himachal vs Railways
2019-11-18 - club - SMA - male - 1205827 - Maharashtra vs Punjab
2019-11-18 - club - SMA - male - 1205741 - Jammu & Kashmir vs Gujarat
2019-11-18 - club - SMA - male - 1205729 - Assam vs Bengal
2019-11-18 - club - SMA - male - 1205728 - Madhya Pradesh vs Puducherry
2019-11-18 - club - SMA - male - 1205720 - Haryana vs Meghalaya
2019-11-17 - club - SMA - male - 1205839 - Odisha vs Nagaland
2019-11-17 - club - SMA - male - 1205837 - Madhya Pradesh vs Haryana
2019-11-17 - club - SMA - male - 1205836 - Meghalaya vs Mizoram
2019-11-17 - club - SMA - male - 1205833 - Tamil Nadu vs Vidarbha
2019-11-17 - club - SMA - male - 1205832 - Andhra vs Services
2019-11-17 - club - SMA - male - 1205831 - Saurashtra vs Jammu & Kashmir
2019-11-17 - club - SMA - male - 1205830 - Sikkim vs Delhi
2019-11-17 - club - SMA - male - 1205829 - Bengal vs Puducherry
2019-11-17 - club - SMA - male - 1205828 - Mumbai vs Assam
2019-11-17 - club - SMA - male - 1205826 - Arunachal Pradesh vs Chandigarh
2019-11-17 - club - SMA - male - 1205825 - Tripura vs Rajasthan
2019-11-17 - club - SMA - male - 1205824 - Kerala vs Uttar Pradesh
2019-11-17 - club - SMA - male - 1205823 - Karnataka vs Goa
2019-11-17 - club - SMA - male - 1205822 - Bihar vs Uttarakhand
2019-11-17 - club - MSL - male - 1201979 - Paarl Rocks vs Tshwane Spartans
2019-11-17 - club - MSL - male - 1201978 - Cape Town Blitz vs Durban Heat
2019-11-16 - club - MSL - male - 1201977 - Jozi Stars vs Nelson Mandela Bay Giants
2019-11-15 - club - SMA - male - 1205821 - Sikkim vs Saurashtra
2019-11-15 - club - SMA - male - 1205820 - Nagaland vs Jammu & Kashmir
2019-11-15 - club - SMA - male - 1205819 - Assam vs Puducherry
2019-11-15 - club - SMA - male - 1205818 - Mumbai vs Meghalaya
2019-11-15 - club - SMA - male - 1205817 - Railways vs Chandigarh
2019-11-15 - club - SMA - male - 1205816 - Himachal vs Maharashtra
2019-11-15 - club - SMA - male - 1205815 - Tripura vs Tamil Nadu
2019-11-15 - club - SMA - male - 1205814 - Bihar vs Karnataka
2019-11-15 - club - SMA - male - 1205813 - Odisha vs Gujarat
2019-11-15 - club - SMA - male - 1205812 - Delhi vs Jharkhand
2019-11-15 - club - SMA - male - 1205811 - Madhya Pradesh vs Bengal
2019-11-15 - club - SMA - male - 1205810 - Mizoram vs Haryana
2019-11-15 - club - SMA - male - 1205809 - Punjab vs Chhattisgarh
2019-11-15 - club - SMA - male - 1205808 - Arunachal Pradesh vs Hyderabad (India)
2019-11-15 - club - SMA - male - 1205807 - Manipur vs Uttar Pradesh
2019-11-15 - club - SMA - male - 1205806 - Kerala vs Rajasthan
2019-11-15 - club - SMA - male - 1205805 - Baroda vs Services
2019-11-15 - club - SMA - male - 1205804 - Goa vs Andhra
2019-11-14 - international - Test - male - 1187016 - India vs Bangladesh
2019-11-14 - club - SMA - male - 1205802 - Nagaland vs Jharkhand
2019-11-14 - club - SMA - male - 1205801 - Madhya Pradesh vs Meghalaya
2019-11-14 - club - SMA - male - 1205800 - Mizoram vs Assam
2019-11-14 - club - SMA - male - 1205799 - Hyderabad (India) vs Maharashtra
2019-11-14 - club - SMA - male - 1205798 - Arunachal Pradesh vs Himachal
2019-11-14 - club - SMA - male - 1205797 - Manipur vs Tamil Nadu
2019-11-14 - club - SMA - male - 1205796 - Bihar vs Baroda
2019-11-14 - club - SMA - male - 1205795 - Sikkim vs Gujarat
2019-11-14 - club - SMA - male - 1205793 - Puducherry vs Haryana
2019-11-14 - club - SMA - male - 1205792 - Bengal vs Mumbai
2019-11-14 - club - SMA - male - 1205791 - Railways vs Punjab
2019-11-14 - club - SMA - male - 1205790 - Chhattisgarh vs Chandigarh
2019-11-14 - club - SMA - male - 1205788 - Kerala vs Vidarbha
2019-11-14 - club - SMA - male - 1205787 - Uttarakhand vs Andhra
2019-11-14 - club - SMA - male - 1205786 - Services vs Goa
2019-11-14 - club - MSL - male - 1201975 - Cape Town Blitz vs Jozi Stars
2019-11-13 - club - MSL - male - 1201974 - Tshwane Spartans vs Nelson Mandela Bay Giants
2019-11-12 - club - SSH - male - 1196125 - Queensland vs Victoria
2019-11-12 - club - SMA - male - 1205785 - Sikkim vs Jharkhand
2019-11-12 - club - SMA - male - 1205784 - Jammu & Kashmir vs Odisha
2019-11-12 - club - SMA - male - 1205783 - Mumbai vs Puducherry
2019-11-12 - club - SMA - male - 1205782 - Bengal vs Haryana
2019-11-12 - club - SMA - male - 1205781 - Chandigarh vs Hyderabad (India)
2019-11-12 - club - SMA - male - 1205780 - Himachal vs Punjab
2019-11-12 - club - SMA - male - 1205779 - Vidarbha vs Rajasthan
2019-11-12 - club - SMA - male - 1205778 - Goa vs Uttarakhand
2019-11-12 - club - SMA - male - 1205776 - Saurashtra vs Delhi
2019-11-12 - club - SMA - male - 1205775 - Madhya Pradesh vs Mizoram
2019-11-12 - club - SMA - male - 1205774 - Assam vs Meghalaya
2019-11-12 - club - SMA - male - 1205773 - Chhattisgarh vs Maharashtra
2019-11-12 - club - SMA - male - 1205772 - Arunachal Pradesh vs Railways
2019-11-12 - club - SMA - male - 1205771 - Tripura vs Uttar Pradesh
2019-11-12 - club - SMA - male - 1205770 - Kerala vs Manipur
2019-11-12 - club - SMA - male - 1205769 - Karnataka vs Services
2019-11-12 - club - SMA - male - 1205768 - Andhra vs Baroda
2019-11-11 - club - SMA - male - 1205767 - Sikkim vs Odisha
2019-11-11 - club - SMA - male - 1205765 - Assam vs Haryana
2019-11-11 - club - SMA - male - 1205764 - Madhya Pradesh vs Mumbai
2019-11-11 - club - SMA - male - 1205763 - Chandigarh vs Punjab
2019-11-11 - club - SMA - male - 1205762 - Arunachal Pradesh vs Maharashtra
2019-11-11 - club - SMA - male - 1205761 - Kerala vs Tripura
2019-11-11 - club - SMA - male - 1205759 - Saurashtra vs Gujarat
2019-11-11 - club - SMA - male - 1205758 - Nagaland vs Delhi
2019-11-11 - club - SMA - male - 1205757 - Puducherry vs Mizoram
2019-11-11 - club - SMA - male - 1205756 - Bengal vs Meghalaya
2019-11-11 - club - SMA - male - 1205755 - Himachal vs Hyderabad (India)
2019-11-11 - club - SMA - male - 1205754 - Chhattisgarh vs Railways
2019-11-11 - club - SMA - male - 1205753 - Tamil Nadu vs Uttar Pradesh
2019-11-11 - club - SMA - male - 1205752 - Vidarbha vs Manipur
2019-11-11 - club - SMA - male - 1205751 - Services vs Bihar
2019-11-11 - club - SMA - male - 1205750 - Baroda vs Uttarakhand
2019-11-10 - international - T20 - male - 1187669 - New Zealand vs England
2019-11-10 - international - T20 - male - 1187015 - India vs Bangladesh
2019-11-10 - club - MSL - male - 1201973 - Nelson Mandela Bay Giants vs Jozi Stars
2019-11-10 - club - MSL - male - 1201972 - Paarl Rocks vs Cape Town Blitz
2019-11-09 - club - SMA - male - 1205749 - Sikkim vs Nagaland
2019-11-09 - club - SMA - male - 1205748 - Saurashtra vs Jharkhand
2019-11-09 - club - SMA - male - 1205747 - Haryana vs Mumbai
2019-11-09 - club - SMA - male - 1205746 - Mizoram vs Bengal
2019-11-09 - club - SMA - male - 1205745 - Hyderabad (India) vs Railways
2019-11-09 - club - SMA - male - 1205743 - Uttar Pradesh vs Vidarbha
2019-11-09 - club - SMA - male - 1205742 - Uttarakhand vs Services
2019-11-09 - club - SMA - male - 1205739 - Puducherry vs Meghalaya
2019-11-09 - club - SMA - male - 1205737 - Himachal vs Chhattisgarh
2019-11-09 - club - SMA - male - 1205736 - Arunachal Pradesh vs Punjab
2019-11-09 - club - SMA - male - 1205735 - Tamil Nadu vs Rajasthan
2019-11-09 - club - SMA - male - 1205734 - Manipur vs Tripura
2019-11-09 - club - SMA - male - 1205733 - Goa vs Bihar
2019-11-09 - club - SMA - male - 1205732 - Baroda vs Karnataka
2019-11-08 - international - T20 - male - 1187668 - New Zealand vs England
2019-11-08 - international - T20 - male - 1183529 - Australia vs Pakistan
2019-11-08 - club - SMA - male - 1205731 - Nagaland vs Saurashtra
2019-11-08 - club - SMA - male - 1205727 - Maharashtra vs Railways
2019-11-08 - club - SMA - male - 1205725 - Rajasthan vs Manipur
2019-11-08 - club - SMA - male - 1205724 - Baroda vs Goa
2019-11-08 - club - SMA - male - 1205721 - Mizoram vs Mumbai
2019-11-08 - club - SMA - male - 1205719 - Hyderabad (India) vs Punjab
2019-11-08 - club - SMA - male - 1205718 - Arunachal Pradesh vs Chhattisgarh
2019-11-08 - club - SMA - male - 1205717 - Tripura vs Vidarbha
2019-11-08 - club - SMA - male - 1205716 - Tamil Nadu vs Kerala
2019-11-08 - club - SMA - male - 1205715 - Bihar vs Andhra
2019-11-08 - club - SMA - male - 1205714 - Uttarakhand vs Karnataka
2019-11-08 - club - PKS - male - 1197587 - Wellington Firebirds vs Auckland Aces
2019-11-08 - club - PKS - male - 1197586 - Central Stags vs Canterbury
2019-11-08 - club - PKS - male - 1197585 - Otago Volts vs Northern Districts
2019-11-08 - club - MSL - male - 1201970 - Cape Town Blitz vs Jozi Stars
2019-11-07 - international - T20 - male - 1187014 - India vs Bangladesh
2019-11-05 - international - T20 - male - 1187667 - New Zealand vs England
2019-11-05 - international - T20 - male - 1183528 - Australia vs Pakistan
2019-11-03 - international - T20 - male - 1187666 - New Zealand vs England
2019-11-03 - international - T20 - male - 1187013 - India vs Bangladesh
2019-11-03 - international - T20 - male - 1183527 - Australia vs Pakistan
2019-11-02 - international - T20 - male - 1199549 - Netherlands vs Papua New Guinea
2019-11-02 - international - T20 - male - 1199548 - Ireland vs Namibia
2019-11-02 - club - SSH - male - 1196122 - Western Australia vs Queensland
2019-11-01 - international - T20 - male - 1199547 - Namibia vs Papua New Guinea
2019-11-01 - international - T20 - male - 1199546 - Ireland vs Netherlands
2019-11-01 - international - T20 - male - 1187665 - New Zealand vs England
2019-11-01 - international - T20 - male - 1183526 - Australia vs Sri Lanka
2019-11-01 - club - SSH - male - 1196121 - New South Wales vs South Australia
2019-10-31 - international - T20 - male - 1199545 - Oman vs Scotland
2019-10-30 - international - T20 - male - 1199544 - Hong Kong vs Oman
2019-10-30 - international - T20 - male - 1199543 - United Arab Emirates vs Scotland
2019-10-30 - international - T20 - male - 1183525 - Australia vs Sri Lanka
2019-10-30 - club - PKS - male - 1197584 - Northern Districts vs Central Stags
2019-10-29 - international - T20 - male - 1199542 - Namibia vs Oman
2019-10-29 - international - T20 - male - 1199541 - United Arab Emirates vs Netherlands
2019-10-29 - club - PKS - male - 1197582 - Wellington Firebirds vs Canterbury
2019-10-27 - international - T20 - male - 1201673 - Spain vs Gibraltar
2019-10-27 - international - T20 - male - 1199540 - United Arab Emirates vs Canada
2019-10-27 - international - T20 - male - 1199539 - Netherlands vs Scotland
2019-10-27 - international - T20 - male - 1199538 - Jersey vs Oman
2019-10-27 - international - T20 - male - 1199537 - Hong Kong vs Nigeria
2019-10-27 - international - T20 - male - 1199536 - Kenya vs Papua New Guinea
2019-10-27 - international - T20 - male - 1183524 - Australia vs Sri Lanka
2019-10-26 - international - T20 - male - 1201671 - Spain vs Portugal
2019-10-26 - international - T20 - male - 1201670 - Spain vs Gibraltar
2019-10-26 - international - T20 - male - 1201669 - Gibraltar vs Portugal
2019-10-26 - international - T20 - male - 1199535 - Namibia vs Singapore
2019-10-26 - international - T20 - male - 1199534 - Bermuda vs Netherlands
2019-10-26 - international - T20 - male - 1199533 - Ireland vs Nigeria
2019-10-25 - international - T20 - male - 1201668 - Spain vs Portugal
2019-10-25 - international - T20 - male - 1199532 - Canada vs Oman
2019-10-25 - international - T20 - male - 1199531 - Kenya vs Namibia
2019-10-25 - international - T20 - male - 1199530 - Ireland vs Jersey
2019-10-25 - international - T20 - male - 1199529 - Papua New Guinea vs Singapore
2019-10-24 - international - T20 - male - 1199528 - Bermuda vs Scotland
2019-10-24 - international - T20 - male - 1199527 - Canada vs Hong Kong
2019-10-24 - international - T20 - male - 1199526 - United Arab Emirates vs Nigeria
2019-10-24 - international - T20 - male - 1199525 - Netherlands vs Papua New Guinea
2019-10-23 - international - T20 - male - 1199524 - Hong Kong vs Jersey
2019-10-23 - international - T20 - male - 1199523 - Canada vs Ireland
2019-10-23 - international - T20 - male - 1199522 - Kenya vs Singapore
2019-10-23 - international - T20 - male - 1199521 - Nigeria vs Oman
2019-10-23 - international - T20 - male - 1199520 - Bermuda vs Namibia
2019-10-22 - international - T20 - male - 1199519 - United Arab Emirates vs Jersey
2019-10-22 - international - T20 - male - 1199518 - Netherlands vs Singapore
2019-10-22 - international - T20 - male - 1199517 - Namibia vs Scotland
2019-10-21 - international - T20 - male - 1199516 - Canada vs Nigeria
2019-10-21 - international - T20 - male - 1199515 - Bermuda vs Kenya
2019-10-21 - international - T20 - male - 1199514 - Ireland vs Oman
2019-10-21 - international - T20 - male - 1199513 - United Arab Emirates vs Hong Kong
2019-10-21 - international - T20 - male - 1199512 - Papua New Guinea vs Scotland
2019-10-21 - club - PKS - male - 1197581 - Auckland Aces vs Central Stags
2019-10-21 - club - PKS - male - 1197580 - Canterbury vs Northern Districts
2019-10-21 - club - PKS - male - 1197579 - Wellington Firebirds vs Otago Volts
2019-10-20 - international - T20 - male - 1199511 - Hong Kong vs Oman
2019-10-20 - international - T20 - male - 1199510 - Bermuda vs Singapore
2019-10-20 - international - T20 - male - 1199509 - Canada vs Jersey
2019-10-20 - international - T20 - male - 1199508 - Namibia vs Papua New Guinea
2019-10-19 - international - Test - male - 1187009 - India vs South Africa
2019-10-19 - international - T20 - male - 1199507 - United Arab Emirates vs Ireland
2019-10-19 - international - T20 - male - 1199506 - Kenya vs Scotland
2019-10-19 - international - T20 - male - 1199505 - Namibia vs Netherlands
2019-10-19 - international - T20 - male - 1199504 - Jersey vs Nigeria
2019-10-19 - international - T20 - male - 1199503 - Bermuda vs Papua New Guinea
2019-10-18 - international - T20 - male - 1199502 - United Arab Emirates vs Oman
2019-10-18 - international - T20 - male - 1199501 - Kenya vs Netherlands
2019-10-18 - international - T20 - male - 1199500 - Hong Kong vs Ireland
2019-10-18 - international - T20 - male - 1199499 - Scotland vs Singapore
2019-10-18 - club - SSH - male - 1196119 - Victoria vs Western Australia
2019-10-18 - club - SSH - male - 1196118 - South Australia vs Queensland
2019-10-18 - club - SSH - male - 1196117 - Tasmania vs New South Wales
2019-10-12 - club - CPL - male - 1185870 - Barbados Tridents vs Guyana Amazon Warriors
2019-10-10 - international - Test - male - 1187008 - India vs South Africa
2019-10-10 - international - T20 - male - 1197529 - Oman vs Nepal
2019-10-10 - international - T20 - male - 1197528 - Hong Kong vs Netherlands
2019-10-10 - club - SSH - male - 1196115 - Queensland vs New South Wales
2019-10-10 - club - SSH - male - 1196114 - Victoria vs South Australia
2019-10-10 - club - CPL - male - 1185869 - Barbados Tridents vs Trinbago Knight Riders
2019-10-09 - international - T20 - male - 1198491 - Pakistan vs Sri Lanka
2019-10-09 - international - T20 - male - 1197527 - Oman vs Netherlands
2019-10-09 - international - T20 - male - 1197526 - Ireland vs Nepal
2019-10-07 - international - T20 - male - 1198490 - Pakistan vs Sri Lanka
2019-10-07 - international - T20 - male - 1197525 - Hong Kong vs Ireland
2019-10-07 - international - T20 - male - 1197524 - Nepal vs Netherlands
2019-10-06 - international - T20 - male - 1197523 - Hong Kong vs Nepal
2019-10-06 - international - T20 - male - 1197522 - Oman vs Ireland
2019-10-06 - club - CPL - male - 1185868 - St Kitts and Nevis Patriots vs Trinbago Knight Riders
2019-10-06 - club - CPL - male - 1185867 - Guyana Amazon Warriors vs Barbados Tridents
2019-10-05 - international - T20 - male - 1198489 - Pakistan vs Sri Lanka
2019-10-05 - international - T20 - male - 1197521 - Ireland vs Netherlands
2019-10-04 - international - T20 - male - 1202011 - Malaysia vs Vanuatu
2019-10-04 - club - CPL - male - 1185866 - Trinbago Knight Riders vs Guyana Amazon Warriors
2019-10-03 - international - T20 - male - 1202010 - Malaysia vs Vanuatu
2019-10-03 - international - T20 - male - 1201685 - Singapore vs Zimbabwe
2019-10-03 - club - CPL - male - 1185865 - Guyana Amazon Warriors vs Jamaica Tallawahs
2019-10-02 - international - Test - male - 1187007 - India vs South Africa
2019-10-02 - international - T20 - male - 1202009 - Malaysia vs Vanuatu
2019-10-02 - international - ODI - male - 1198488 - Pakistan vs Sri Lanka
2019-10-02 - club - CPL - male - 1185864 - Trinbago Knight Riders vs Barbados Tridents
2019-10-01 - international - T20 - male - 1202008 - Malaysia vs Vanuatu
2019-10-01 - international - T20 - male - 1201683 - Nepal vs Zimbabwe
2019-09-30 - international - ODI - male - 1198487 - Pakistan vs Sri Lanka
2019-09-30 - club - CPL - male - 1185863 - Guyana Amazon Warriors vs Trinbago Knight Riders
2019-09-29 - international - T20 - male - 1202007 - Malaysia vs Vanuatu
2019-09-29 - international - T20 - male - 1201682 - Singapore vs Zimbabwe
2019-09-29 - club - CPL - male - 1185862 - Barbados Tridents vs St Lucia Zouks
2019-09-28 - international - T20 - male - 1201681 - Singapore vs Nepal
2019-09-28 - club - CPL - male - 1185861 - St Kitts and Nevis Patriots vs Barbados Tridents
2019-09-27 - international - T20 - male - 1201680 - Nepal vs Zimbabwe
2019-09-27 - club - CPL - male - 1185860 - Jamaica Tallawahs vs St Lucia Zouks
2019-09-26 - international - ODM - male - 1200452 - Canada vs Singapore
2019-09-26 - international - ODM - male - 1200451 - Qatar vs Vanuatu
2019-09-26 - club - CPL - male - 1185859 - Barbados Tridents vs Trinbago Knight Riders
2019-09-25 - international - ODM - male - 1200450 - Malaysia vs Vanuatu
2019-09-25 - international - ODM - male - 1200449 - Canada vs Denmark
2019-09-25 - club - CPL - male - 1185858 - St Lucia Zouks vs Guyana Amazon Warriors
2019-09-24 - club - CPL - male - 1185857 - St Lucia Zouks vs St Kitts and Nevis Patriots
2019-09-23 - international - ODM - male - 1200448 - Denmark vs Qatar
2019-09-23 - international - ODM - male - 1200447 - Malaysia vs Singapore
2019-09-23 - international - ODI - male - 1199230 - Namibia vs Papua New Guinea
2019-09-23 - club - CPL - male - 1185856 - Jamaica Tallawahs vs Barbados Tridents
2019-09-23 - club - CCH - male - 1167038 - Sussex vs Worcestershire
2019-09-23 - club - CCH - male - 1167037 - Middlesex vs Derbyshire
2019-09-23 - club - CCH - male - 1167036 - Leicestershire vs Lancashire
2019-09-23 - club - CCH - male - 1167035 - Gloucestershire vs Northamptonshire
2019-09-23 - club - CCH - male - 1167034 - Durham vs Glamorgan
2019-09-23 - club - CCH - male - 1166968 - Yorkshire vs Warwickshire
2019-09-23 - club - CCH - male - 1166967 - Surrey vs Nottinghamshire
2019-09-23 - club - CCH - male - 1166966 - Somerset vs Essex
2019-09-23 - club - CCH - male - 1166965 - Kent vs Hampshire
2019-09-22 - international - T20 - male - 1187006 - India vs South Africa
2019-09-22 - international - ODM - male - 1200446 - Singapore vs Vanuatu
2019-09-22 - international - ODM - male - 1200445 - Canada vs Qatar
2019-09-22 - international - ODI - male - 1199229 - Namibia vs Papua New Guinea
2019-09-22 - club - CPL - male - 1185855 - Barbados Tridents vs Guyana Amazon Warriors
2019-09-21 - club - NTB - male - 1167259 - Worcestershire vs Essex
2019-09-21 - club - NTB - male - 1167258 - Derbyshire vs Essex
2019-09-21 - club - NTB - male - 1167257 - Nottinghamshire vs Worcestershire
2019-09-21 - club - CPL - male - 1185854 - St Lucia Zouks vs Trinbago Knight Riders
2019-09-20 - international - ODM - male - 1200444 - Malaysia vs Qatar
2019-09-20 - international - ODM - male - 1200443 - Denmark vs Vanuatu
2019-09-20 - club - CPL - male - 1185853 - Barbados Tridents vs St Lucia Zouks
2019-09-19 - international - T20 - male - 1200428 - Netherlands vs Scotland
2019-09-19 - international - ODM - male - 1200442 - Denmark vs Singapore
2019-09-19 - international - ODM - male - 1200441 - Malaysia vs Canada
2019-09-19 - international - ODI - male - 1199227 - United States of America vs Papua New Guinea
2019-09-19 - club - CPL - male - 1185852 - St Kitts and Nevis Patriots vs Jamaica Tallawahs
2019-09-18 - international - T20 - male - 1200427 - Ireland vs Netherlands
2019-09-18 - international - T20 - male - 1197143 - Bangladesh vs Zimbabwe
2019-09-18 - international - T20 - male - 1187005 - India vs South Africa
2019-09-18 - club - CPL - male - 1185851 - Guyana Amazon Warriors vs Jamaica Tallawahs
2019-09-17 - international - T20 - male - 1200426 - Ireland vs Scotland
2019-09-17 - international - ODM - male - 1200440 - Canada vs Vanuatu
2019-09-17 - international - ODM - male - 1200439 - Qatar vs Singapore
2019-09-17 - international - ODI - male - 1199226 - United States of America vs Namibia
2019-09-17 - club - CPL - male - 1185850 - Trinbago Knight Riders vs St Kitts and Nevis Patriots
2019-09-16 - international - T20 - male - 1200425 - Netherlands vs Scotland
2019-09-16 - international - ODM - male - 1200438 - Malaysia vs Denmark
2019-09-16 - club - CCH - male - 1167033 - Worcestershire vs Gloucestershire
2019-09-16 - club - CCH - male - 1167032 - Northamptonshire vs Durham
2019-09-16 - club - CCH - male - 1167031 - Lancashire vs Middlesex
2019-09-16 - club - CCH - male - 1167030 - Glamorgan vs Leicestershire
2019-09-16 - club - CCH - male - 1167029 - Derbyshire vs Sussex
2019-09-16 - club - CCH - male - 1166964 - Kent vs Yorkshire
2019-09-16 - club - CCH - male - 1166962 - Hampshire vs Somerset
2019-09-16 - club - CCH - male - 1166961 - Surrey vs Essex
2019-09-15 - club - CPL - male - 1185849 - St Lucia Zouks vs St Kitts and Nevis Patriots
2019-09-15 - club - CPL - male - 1185848 - Barbados Tridents vs Jamaica Tallawahs
2019-09-14 - club - CPL - male - 1185847 - St Kitts and Nevis Patriots vs Guyana Amazon Warriors
2019-09-13 - international - T20 - male - 1197140 - Bangladesh vs Zimbabwe
2019-09-13 - international - ODI - male - 1199225 - United States of America vs Papua New Guinea
2019-09-13 - club - CPL - male - 1185846 - Trinbago Knight Riders vs Jamaica Tallawahs
2019-09-12 - international - Test - male - 1152850 - England vs Australia
2019-09-12 - club - CPL - male - 1185845 - Jamaica Tallawahs vs St Lucia Zouks
2019-09-11 - club - CPL - male - 1185844 - Barbados Tridents vs St Kitts and Nevis Patriots
2019-09-10 - club - CPL - male - 1185843 - Jamaica Tallawahs vs St Kitts and Nevis Patriots
2019-09-10 - club - CCH - male - 1167028 - Worcestershire vs Glamorgan
2019-09-10 - club - CCH - male - 1167027 - Durham vs Middlesex
2019-09-10 - club - CCH - male - 1167026 - Leicestershire vs Northamptonshire
2019-09-10 - club - CCH - male - 1167025 - Derbyshire vs Lancashire
2019-09-10 - club - CCH - male - 1167024 - Gloucestershire vs Sussex
2019-09-10 - club - CCH - male - 1166960 - Somerset vs Yorkshire
2019-09-10 - club - CCH - male - 1166959 - Kent vs Nottinghamshire
2019-09-10 - club - CCH - male - 1166957 - Warwickshire vs Essex
2019-09-08 - club - CPL - male - 1185842 - Guyana Amazon Warriors vs Barbados Tridents
2019-09-08 - club - CPL - male - 1185841 - St Lucia Zouks vs Trinbago Knight Riders
2019-09-07 - club - NTB - male - 1167256 - Gloucestershire vs Derbyshire
2019-09-07 - club - CPL - male - 1185840 - St Kitts and Nevis Patriots vs Guyana Amazon Warriors
2019-09-06 - international - T20 - male - 1192877 - Sri Lanka vs New Zealand
2019-09-06 - club - NTB - male - 1167255 - Sussex vs Worcestershire
2019-09-06 - club - CPL - male - 1185839 - Trinbago Knight Riders vs Jamaica Tallawahs
2019-09-05 - club - NTB - male - 1167254 - Nottinghamshire vs Middlesex
2019-09-05 - club - CPL - male - 1185838 - Guyana Amazon Warriors vs St Lucia Zouks
2019-09-04 - international - Test - male - 1152849 - England vs Australia
2019-09-04 - club - NTB - male - 1167253 - Lancashire vs Essex
2019-09-04 - club - CPL - male - 1185837 - Trinbago Knight Riders vs St Kitts and Nevis Patriots
2019-09-03 - international - T20 - male - 1192876 - Sri Lanka vs New Zealand
2019-09-01 - international - T20 - male - 1192875 - Sri Lanka vs New Zealand
2019-08-30 - international - Test - male - 1188629 - West Indies vs India
2019-08-30 - club - NTB - male - 1167252 - Northamptonshire vs Worcestershire
2019-08-30 - club - NTB - male - 1167251 - Essex vs Kent
2019-08-30 - club - NTB - male - 1167250 - Birmingham Bears vs Yorkshire
2019-08-30 - club - NTB - male - 1167249 - Sussex vs Gloucestershire
2019-08-30 - club - NTB - male - 1167248 - Somerset vs Middlesex
2019-08-30 - club - NTB - male - 1167247 - Lancashire vs Leicestershire
2019-08-30 - club - NTB - male - 1167246 - Nottinghamshire vs Durham
2019-08-30 - club - NTB - male - 1167245 - Glamorgan vs Hampshire
2019-08-29 - club - NTB - male - 1167244 - Hampshire vs Middlesex
2019-08-29 - club - NTB - male - 1167243 - Yorkshire vs Northamptonshire
2019-08-29 - club - NTB - male - 1167242 - Surrey vs Essex
2019-08-29 - club - NTB - male - 1167241 - Kent vs Gloucestershire
2019-08-27 - club - NTB - male - 1167239 - Durham vs Birmingham Bears
2019-08-27 - club - NTB - male - 1167238 - Surrey vs Somerset
2019-08-26 - club - NTB - male - 1167237 - Lancashire vs Derbyshire
2019-08-26 - club - NTB - male - 1167236 - Glamorgan vs Sussex
2019-08-26 - club - IPO - male - 1178137 - Northern Knights vs North-West Warriors
2019-08-25 - international - T20 - male - 1197407 - Bermuda vs Cayman Islands
2019-08-25 - international - T20 - male - 1197406 - Canada vs United States of America
2019-08-25 - club - NTB - male - 1167235 - Nottinghamshire vs Yorkshire
2019-08-25 - club - NTB - male - 1167234 - Birmingham Bears vs Northamptonshire
2019-08-25 - club - NTB - male - 1167233 - Worcestershire vs Lancashire
2019-08-25 - club - NTB - male - 1167232 - Hampshire vs Essex
2019-08-25 - club - NTB - male - 1167231 - Leicestershire vs Derbyshire
2019-08-24 - international - T20 - male - 1197404 - Cayman Islands vs United States of America
2019-08-24 - club - NTB - male - 1167230 - Middlesex vs Sussex
2019-08-24 - club - NTB - male - 1167229 - Somerset vs Glamorgan
2019-08-23 - international - T20 - male - 1197510 - Namibia vs Botswana
2019-08-23 - club - NTB - male - 1167228 - Gloucestershire vs Somerset
2019-08-23 - club - NTB - male - 1167227 - Leicestershire vs Nottinghamshire
2019-08-23 - club - NTB - male - 1167226 - Derbyshire vs Northamptonshire
2019-08-23 - club - NTB - male - 1167225 - Birmingham Bears vs Worcestershire
2019-08-23 - club - NTB - male - 1167224 - Durham vs Yorkshire
2019-08-23 - club - NTB - male - 1167223 - Kent vs Surrey
2019-08-22 - international - Test - male - 1192874 - Sri Lanka vs New Zealand
2019-08-22 - international - Test - male - 1188628 - West Indies vs India
2019-08-22 - international - Test - male - 1152848 - England vs Australia
2019-08-22 - international - T20 - male - 1197509 - Namibia vs Botswana
2019-08-22 - international - T20 - male - 1197403 - United States of America vs Bermuda
2019-08-22 - international - T20 - male - 1197402 - Canada vs Cayman Islands
2019-08-22 - club - NTB - male - 1167222 - Middlesex vs Hampshire
2019-08-22 - club - NTB - male - 1167221 - Sussex vs Essex
2019-08-21 - international - T20 - male - 1197401 - Canada vs United States of America
2019-08-21 - international - T20 - male - 1197400 - Bermuda vs Cayman Islands
2019-08-21 - international - ODI - male - 1196675 - Oman vs Papua New Guinea
2019-08-20 - international - T20 - male - 1197508 - Namibia vs Botswana
2019-08-20 - international - ODI - male - 1196674 - Scotland vs Papua New Guinea
2019-08-20 - club - IPO - male - 1178135 - Northern Knights vs Leinster Lightning
2019-08-19 - international - T20 - male - 1197507 - Namibia vs Botswana
2019-08-19 - international - T20 - male - 1197399 - Cayman Islands vs United States of America
2019-08-19 - international - T20 - male - 1197398 - Bermuda vs Canada
2019-08-18 - international - T20 - male - 1197397 - Canada vs Cayman Islands
2019-08-18 - international - T20 - male - 1197396 - Bermuda vs United States of America
2019-08-18 - international - ODI - male - 1196673 - Scotland vs Oman
2019-08-18 - club - CCH - male - 1167023 - Middlesex vs Sussex
2019-08-18 - club - CCH - male - 1167022 - Worcestershire vs Northamptonshire
2019-08-18 - club - CCH - male - 1167021 - Glamorgan vs Lancashire
2019-08-18 - club - CCH - male - 1167020 - Durham vs Leicestershire
2019-08-18 - club - CCH - male - 1167019 - Derbyshire vs Gloucestershire
2019-08-18 - club - CCH - male - 1166956 - Yorkshire vs Nottinghamshire
2019-08-18 - club - CCH - male - 1166955 - Warwickshire vs Somerset
2019-08-18 - club - CCH - male - 1166953 - Kent vs Essex
2019-08-17 - international - ODI - male - 1196672 - Scotland vs Papua New Guinea
2019-08-15 - international - ODI - male - 1196671 - Scotland vs Oman
2019-08-15 - club - NTB - male - 1167212 - Derbyshire vs Leicestershire
2019-08-15 - club - NTB - male - 1167211 - Surrey vs Sussex
2019-08-15 - club - NTB - male - 1167210 - Durham vs Worcestershire
2019-08-14 - international - Test - male - 1192873 - Sri Lanka vs New Zealand
2019-08-14 - international - Test - male - 1152847 - England vs Australia
2019-08-14 - international - ODI - male - 1196670 - Oman vs Papua New Guinea
2019-08-14 - international - ODI - male - 1188626 - West Indies vs India
2019-08-14 - club - NTB - male - 1167209 - Northamptonshire vs Lancashire
2019-08-13 - club - NTB - male - 1167206 - Derbyshire vs Worcestershire
2019-08-13 - club - NTB - male - 1167205 - Gloucestershire vs Hampshire
2019-08-11 - international - ODI - male - 1188625 - West Indies vs India
2019-08-11 - club - NTB - male - 1167204 - Yorkshire vs Derbyshire
2019-08-11 - club - NTB - male - 1167203 - Glamorgan vs Surrey
2019-08-11 - club - NTB - male - 1167202 - Middlesex vs Gloucestershire
2019-08-11 - club - NTB - male - 1167201 - Birmingham Bears vs Lancashire
2019-08-10 - club - NTB - male - 1167198 - Somerset vs Kent
2019-08-09 - club - NTB - male - 1167197 - Leicestershire vs Northamptonshire
2019-08-09 - club - NTB - male - 1167196 - Birmingham Bears vs Nottinghamshire
2019-08-09 - club - NTB - male - 1167195 - Sussex vs Middlesex
2019-08-09 - club - NTB - male - 1167194 - Surrey vs Gloucestershire
2019-08-09 - club - NTB - male - 1167193 - Hampshire vs Somerset
2019-08-09 - club - NTB - male - 1167192 - Glamorgan vs Essex
2019-08-09 - club - NTB - male - 1167191 - Derbyshire vs Durham
2019-08-08 - international - T20 - male - 1191008 - Netherlands vs United Arab Emirates
2019-08-08 - international - ODI - male - 1188624 - West Indies vs India
2019-08-08 - club - NTB - male - 1167189 - Middlesex vs Surrey
2019-08-07 - club - NTB - male - 1167188 - Leicestershire vs Birmingham Bears
2019-08-07 - club - NTB - male - 1167187 - Northamptonshire vs Durham
2019-08-07 - club - NTB - male - 1167186 - Essex vs Somerset
2019-08-07 - club - NTB - male - 1167185 - Gloucestershire vs Kent
2019-08-06 - international - T20 - male - 1188623 - West Indies vs India
2019-08-06 - club - NTB - male - 1167184 - Sussex vs Glamorgan
2019-08-05 - international - T20 - male - 1191006 - Netherlands vs United Arab Emirates
2019-08-04 - international - T20 - male - 1188622 - India vs West Indies
2019-08-04 - club - NTB - male - 1167183 - Worcestershire vs Leicestershire
2019-08-04 - club - NTB - male - 1167182 - Yorkshire vs Birmingham Bears
2019-08-04 - club - NTB - male - 1167181 - Gloucestershire vs Sussex
2019-08-04 - club - NTB - male - 1167180 - Middlesex vs Somerset
2019-08-04 - club - NTB - male - 1167179 - Kent vs Hampshire
2019-08-03 - international - T20 - male - 1188621 - India vs West Indies
2019-08-03 - club - NTB - male - 1167178 - Lancashire vs Nottinghamshire
2019-08-02 - club - NTB - male - 1167177 - Nottinghamshire vs Birmingham Bears
2019-08-02 - club - NTB - male - 1167176 - Hampshire vs Glamorgan
2019-08-02 - club - NTB - male - 1167175 - Durham vs Lancashire
2019-08-02 - club - NTB - male - 1167174 - Gloucestershire vs Essex
2019-08-02 - club - NTB - male - 1167173 - Northamptonshire vs Derbyshire
2019-08-02 - club - NTB - male - 1167172 - Somerset vs Surrey
2019-08-02 - club - NTB - male - 1167171 - Sussex vs Kent
2019-08-02 - club - NTB - male - 1167170 - Yorkshire vs Worcestershire
2019-08-01 - international - Test - male - 1152846 - England vs Australia
2019-08-01 - club - NTB - male - 1167169 - Glamorgan vs Gloucestershire
2019-08-01 - club - NTB - male - 1167168 - Middlesex vs Kent
2019-08-01 - club - NTB - male - 1167167 - Essex vs Hampshire
2019-07-31 - international - ODI - male - 1193506 - Sri Lanka vs Bangladesh
2019-07-31 - club - NTB - male - 1167166 - Durham vs Leicestershire
2019-07-31 - club - NTB - male - 1167165 - Worcestershire vs Derbyshire
2019-07-30 - club - NTB - male - 1167164 - Surrey vs Kent
2019-07-28 - international - T20 - male - 1190776 - Singapore vs Nepal
2019-07-28 - international - ODI - male - 1193505 - Sri Lanka vs Bangladesh
2019-07-28 - club - NTB - male - 1167161 - Somerset vs Sussex
2019-07-28 - club - NTB - male - 1167160 - Worcestershire vs Durham
2019-07-27 - international - T20 - male - 1190775 - Malaysia vs Qatar
2019-07-27 - international - T20 - male - 1190774 - Kuwait vs Nepal
2019-07-27 - club - NTB - male - 1167159 - Nottinghamshire vs Leicestershire
2019-07-26 - international - T20 - male - 1190773 - Singapore vs Malaysia
2019-07-26 - international - T20 - male - 1190772 - Kuwait vs Qatar
2019-07-26 - international - ODI - male - 1193504 - Sri Lanka vs Bangladesh
2019-07-26 - club - NTB - male - 1167157 - Glamorgan vs Middlesex
2019-07-26 - club - NTB - male - 1167156 - Sussex vs Surrey
2019-07-26 - club - NTB - male - 1167155 - Derbyshire vs Nottinghamshire
2019-07-26 - club - NTB - male - 1167154 - Kent vs Essex
2019-07-26 - club - NTB - male - 1167153 - Lancashire vs Worcestershire
2019-07-26 - club - NTB - male - 1167152 - Leicestershire vs Durham
2019-07-26 - club - NTB - male - 1167151 - Somerset vs Hampshire
2019-07-26 - club - NTB - male - 1167150 - Northamptonshire vs Birmingham Bears
2019-07-25 - club - NTB - male - 1167149 - Surrey vs Glamorgan
2019-07-25 - club - NTB - male - 1167148 - Gloucestershire vs Middlesex
2019-07-25 - club - NTB - male - 1167147 - Yorkshire vs Lancashire
2019-07-24 - international - Test - male - 1152839 - England vs Ireland
2019-07-24 - international - T20 - male - 1190771 - Malaysia vs Nepal
2019-07-24 - club - NTB - male - 1167146 - Nottinghamshire vs Northamptonshire
2019-07-24 - club - NTB - male - 1167145 - Sussex vs Hampshire
2019-07-24 - club - NTB - male - 1167142 - Birmingham Bears vs Derbyshire
2019-07-23 - international - T20 - male - 1190769 - Nepal vs Qatar
2019-07-23 - club - NTB - male - 1167144 - Surrey vs Middlesex
2019-07-23 - club - NTB - male - 1167143 - Leicestershire vs Yorkshire
2019-07-22 - international - T20 - male - 1190768 - Kuwait vs Malaysia
2019-07-22 - international - T20 - male - 1190767 - Singapore vs Qatar
2019-07-21 - club - NTB - male - 1167141 - Hampshire vs Kent
2019-07-21 - club - NTB - male - 1167140 - Birmingham Bears vs Leicestershire
2019-07-21 - club - NTB - male - 1167139 - Lancashire vs Durham
2019-07-21 - club - CCH - male - 1167018 - Gloucestershire vs Worcestershire
2019-07-20 - club - NTB - male - 1167138 - Derbyshire vs Yorkshire
2019-07-20 - club - NTB - male - 1167137 - Kent vs Somerset
2019-07-19 - club - NTB - male - 1167133 - Gloucestershire vs Glamorgan
2019-07-19 - club - NTB - male - 1167131 - Essex vs Surrey
2019-07-19 - club - NTB - male - 1167130 - Durham vs Northamptonshire
2019-07-18 - club - NTB - male - 1167129 - Glamorgan vs Somerset
2019-07-18 - club - NTB - male - 1167128 - Nottinghamshire vs Worcestershire
2019-07-18 - club - NTB - male - 1167127 - Middlesex vs Essex
2019-07-15 - club - CCH - male - 1167017 - Leicestershire vs Gloucestershire
2019-07-14 - international - T20 - male - 1192224 - Malaysia vs Nepal
2019-07-14 - international - T20 - male - 1168522 - Ireland vs Zimbabwe
2019-07-14 - international - ODI - male - 1144530 - England vs New Zealand
2019-07-14 - club - CCH - male - 1167016 - Northamptonshire vs Derbyshire
2019-07-13 - international - T20 - male - 1192223 - Malaysia vs Nepal
2019-07-13 - club - CCH - male - 1167015 - Sussex vs Lancashire
2019-07-13 - club - CCH - male - 1167013 - Durham vs Worcestershire
2019-07-13 - club - CCH - male - 1166952 - Yorkshire vs Somerset
2019-07-13 - club - CCH - male - 1166951 - Essex vs Warwickshire
2019-07-13 - club - CCH - male - 1166950 - Surrey vs Nottinghamshire
2019-07-13 - club - CCH - male - 1166949 - Hampshire vs Kent
2019-07-12 - international - T20 - male - 1168521 - Ireland vs Zimbabwe
2019-07-11 - international - ODI - male - 1144529 - Australia vs England
2019-07-09 - international - ODI - male - 1144528 - India vs New Zealand
2019-07-07 - international - ODI - male - 1168519 - Ireland vs Zimbabwe
2019-07-07 - club - CCH - male - 1167012 - Derbyshire vs Worcestershire
2019-07-07 - club - CCH - male - 1167011 - Northamptonshire vs Lancashire
2019-07-07 - club - CCH - male - 1167010 - Middlesex vs Gloucestershire
2019-07-07 - club - CCH - male - 1167009 - Durham vs Leicestershire
2019-07-07 - club - CCH - male - 1166948 - Surrey vs Kent
2019-07-07 - club - CCH - male - 1166947 - Somerset vs Nottinghamshire
2019-07-07 - club - CCH - male - 1166945 - Yorkshire vs Essex
2019-07-06 - international - ODI - male - 1144527 - Australia vs South Africa
2019-07-06 - international - ODI - male - 1144526 - India vs Sri Lanka
2019-07-05 - international - ODI - male - 1144525 - Bangladesh vs Pakistan
2019-07-04 - international - ODI - male - 1168518 - Ireland vs Zimbabwe
2019-07-03 - international - ODI - male - 1144523 - England vs New Zealand
2019-07-02 - international - ODI - male - 1144522 - Bangladesh vs India
2019-07-01 - international - ODI - male - 1168517 - Ireland vs Zimbabwe
2019-07-01 - international - ODI - male - 1144521 - Sri Lanka vs West Indies
2019-06-30 - international - ODI - male - 1144520 - England vs India
2019-06-30 - club - CCH - male - 1167008 - Northamptonshire vs Sussex
2019-06-30 - club - CCH - male - 1167007 - Lancashire vs Durham
2019-06-30 - club - CCH - male - 1167005 - Derbyshire vs Middlesex
2019-06-30 - club - CCH - male - 1166944 - Yorkshire vs Surrey
2019-06-30 - club - CCH - male - 1166943 - Nottinghamshire vs Essex
2019-06-30 - club - CCH - male - 1166942 - Somerset vs Hampshire
2019-06-30 - club - CCH - male - 1166941 - Kent vs Warwickshire
2019-06-29 - international - T20 - male - 1186493 - Maldives vs Thailand
2019-06-29 - international - ODI - male - 1144519 - Australia vs New Zealand
2019-06-28 - international - T20 - male - 1186492 - Malaysia vs Maldives
2019-06-28 - international - ODI - male - 1144517 - South Africa vs Sri Lanka
2019-06-27 - international - T20 - male - 1186491 - Malaysia vs Thailand
2019-06-27 - international - ODI - male - 1144516 - India vs West Indies
2019-06-27 - club - IPO - male - 1178134 - Leinster Lightning vs Northern Knights
2019-06-26 - international - T20 - male - 1186490 - Maldives vs Thailand
2019-06-26 - international - ODI - male - 1144515 - New Zealand vs Pakistan
2019-06-25 - international - T20 - male - 1188380 - Netherlands vs Zimbabwe
2019-06-25 - international - ODI - male - 1144514 - England vs Australia
2019-06-24 - international - T20 - male - 1186488 - Malaysia vs Thailand
2019-06-24 - club - IPT - male - 1178143 - Northern Knights vs Leinster Lightning
2019-06-24 - club - CCH - male - 1167004 - Durham vs Sussex
2019-06-24 - club - CCH - male - 1167003 - Northamptonshire vs Leicestershire
2019-06-23 - international - T20 - male - 1188379 - Netherlands vs Zimbabwe
2019-06-23 - international - ODI - male - 1144512 - Pakistan vs South Africa
2019-06-23 - club - IPT - male - 1178140 - Northern Knights vs Munster Reds
2019-06-23 - club - CCH - male - 1167002 - Gloucestershire vs Glamorgan
2019-06-23 - club - CCH - male - 1166940 - Surrey vs Warwickshire
2019-06-23 - club - CCH - male - 1166939 - Essex vs Somerset
2019-06-22 - international - ODI - male - 1144511 - New Zealand vs West Indies
2019-06-22 - club - IPT - male - 1178139 - Munster Reds vs Leinster Lightning
2019-06-22 - club - IPT - male - 1178138 - North-West Warriors vs Northern Knights
2019-06-21 - international - ODI - male - 1188378 - Netherlands vs Zimbabwe
2019-06-21 - international - ODI - male - 1144509 - England vs Sri Lanka
2019-06-20 - international - T20 - male - 1189744 - Denmark vs Italy
2019-06-20 - international - T20 - male - 1189743 - Guernsey vs Denmark
2019-06-20 - international - T20 - male - 1185190 - Germany vs Jersey
2019-06-20 - international - T20 - male - 1185188 - Germany vs Norway
2019-06-20 - international - ODI - male - 1144508 - Australia vs Bangladesh
2019-06-19 - international - T20 - male - 1185193 - Denmark vs Germany
2019-06-19 - international - T20 - male - 1185192 - Italy vs Jersey
2019-06-19 - international - T20 - male - 1185191 - Guernsey vs Norway
2019-06-19 - international - ODI - male - 1188377 - Netherlands vs Zimbabwe
2019-06-19 - international - ODI - male - 1144507 - New Zealand vs South Africa
2019-06-18 - international - T20 - male - 1185187 - Guernsey vs Denmark
2019-06-18 - club - CCH - male - 1167001 - Sussex vs Worcestershire
2019-06-17 - international - T20 - male - 1185182 - Denmark vs Norway
2019-06-17 - international - ODI - male - 1144505 - Bangladesh vs West Indies
2019-06-17 - club - CCH - male - 1166999 - Leicestershire vs Gloucestershire
2019-06-17 - club - CCH - male - 1166938 - Yorkshire vs Warwickshire
2019-06-17 - club - CCH - male - 1166937 - Kent vs Nottinghamshire
2019-06-16 - international - T20 - male - 1185186 - Jersey vs Norway
2019-06-16 - international - T20 - male - 1185185 - Guernsey vs Italy
2019-06-16 - international - T20 - male - 1185184 - Denmark vs Jersey
2019-06-16 - international - ODI - male - 1144504 - India vs Pakistan
2019-06-16 - club - CCH - male - 1167000 - Middlesex vs Glamorgan
2019-06-16 - club - CCH - male - 1166936 - Hampshire vs Essex
2019-06-15 - international - T20 - male - 1185181 - Guernsey vs Germany
2019-06-15 - international - ODI - male - 1144502 - Australia vs Sri Lanka
2019-06-14 - international - ODI - male - 1144501 - England vs West Indies
2019-06-12 - international - ODI - male - 1144499 - Australia vs Pakistan
2019-06-11 - club - CCH - male - 1166997 - Sussex vs Gloucestershire
2019-06-11 - club - CCH - male - 1166994 - Glamorgan vs Derbyshire
2019-06-10 - international - ODI - male - 1144497 - South Africa vs West Indies
2019-06-10 - club - CCH - male - 1166996 - Worcestershire vs Lancashire
2019-06-10 - club - CCH - male - 1166995 - Leicestershire vs Middlesex
2019-06-10 - club - CCH - male - 1166993 - Durham vs Northamptonshire
2019-06-10 - club - CCH - male - 1166935 - Surrey vs Yorkshire
2019-06-09 - international - ODI - male - 1144496 - Australia vs India
2019-06-09 - club - CCH - male - 1166933 - Nottinghamshire vs Hampshire
2019-06-08 - international - ODI - male - 1144494 - England vs Bangladesh
2019-06-06 - international - ODI - male - 1144492 - Australia vs West Indies
2019-06-05 - international - ODI - male - 1144491 - Bangladesh vs New Zealand
2019-06-05 - international - ODI - male - 1144490 - India vs South Africa
2019-06-03 - international - ODI - male - 1144488 - England vs Pakistan
2019-06-03 - club - CCH - male - 1166989 - Durham vs Derbyshire
2019-06-03 - club - CCH - male - 1166932 - Yorkshire vs Essex
2019-06-03 - club - CCH - male - 1166931 - Warwickshire vs Nottinghamshire
2019-06-02 - international - ODI - male - 1144487 - Bangladesh vs South Africa
2019-06-02 - club - CCH - male - 1166991 - Middlesex vs Sussex
2019-06-01 - international - ODI - male - 1144485 - New Zealand vs Sri Lanka
2019-05-31 - international - ODI - male - 1144484 - Pakistan vs West Indies
2019-05-30 - international - ODI - male - 1144483 - England vs South Africa
2019-05-27 - club - IPO - male - 1178133 - North-West Warriors vs Northern Knights
2019-05-27 - club - CCH - male - 1166988 - Middlesex vs Worcestershire
2019-05-27 - club - CCH - male - 1166987 - Glamorgan vs Sussex
2019-05-27 - club - CCH - male - 1166985 - Gloucestershire vs Lancashire
2019-05-27 - club - CCH - male - 1166929 - Yorkshire vs Hampshire
2019-05-27 - club - CCH - male - 1166928 - Warwickshire vs Surrey
2019-05-27 - club - CCH - male - 1166927 - Essex vs Kent
2019-05-25 - international - T20 - male - 1178996 - Germany vs Italy
2019-05-25 - club - RLC - male - 1167125 - Hampshire vs Somerset
2019-05-23 - international - T20 - male - 1184266 - Uganda vs Ghana
2019-05-23 - club - IPO - male - 1178132 - Leinster Lightning vs North-West Warriors
2019-05-22 - international - T20 - male - 1184902 - Uganda vs Kenya
2019-05-22 - international - T20 - male - 1184901 - Botswana vs Namibia
2019-05-22 - international - T20 - male - 1184900 - Ghana vs Nigeria
2019-05-21 - international - T20 - male - 1184263 - Botswana vs Nigeria
2019-05-21 - international - T20 - male - 1184262 - Uganda vs Namibia
2019-05-21 - international - T20 - male - 1184261 - Ghana vs Kenya
2019-05-21 - international - ODI - male - 1169332 - Scotland vs Sri Lanka
2019-05-20 - international - T20 - male - 1184260 - Uganda vs Botswana
2019-05-20 - international - T20 - male - 1184258 - Ghana vs Namibia
2019-05-20 - club - CCH - male - 1166984 - Sussex vs Northamptonshire
2019-05-20 - club - CCH - male - 1166983 - Worcestershire vs Lancashire
2019-05-20 - club - CCH - male - 1166982 - Durham vs Gloucestershire
2019-05-20 - club - CCH - male - 1166926 - Somerset vs Warwickshire
2019-05-20 - club - CCH - male - 1166925 - Surrey vs Kent
2019-05-20 - club - CCH - male - 1166924 - Hampshire vs Nottinghamshire
2019-05-19 - international - ODI - male - 1152845 - England vs Pakistan
2019-05-19 - club - CCH - male - 1166981 - Derbyshire vs Glamorgan
2019-05-17 - international - ODI - male - 1168514 - Bangladesh vs West Indies
2019-05-17 - international - ODI - male - 1152844 - England vs Pakistan
2019-05-15 - international - ODI - male - 1168513 - Ireland vs Bangladesh
2019-05-14 - international - ODI - male - 1152843 - England vs Pakistan
2019-05-14 - club - CCH - male - 1166980 - Durham vs Worcestershire
2019-05-14 - club - CCH - male - 1166979 - Middlesex vs Leicestershire
2019-05-14 - club - CCH - male - 1166978 - Northamptonshire vs Lancashire
2019-05-14 - club - CCH - male - 1166977 - Gloucestershire vs Glamorgan
2019-05-14 - club - CCH - male - 1166923 - Hampshire vs Warwickshire
2019-05-14 - club - CCH - male - 1166922 - Surrey vs Somerset
2019-05-14 - club - CCH - male - 1166921 - Yorkshire vs Kent
2019-05-14 - club - CCH - male - 1166920 - Nottinghamshire vs Essex
2019-05-13 - international - ODI - male - 1168512 - Bangladesh vs West Indies
2019-05-12 - club - RLC - male - 1167124 - Somerset vs Nottinghamshire
2019-05-12 - club - RLC - male - 1167123 - Lancashire vs Hampshire
2019-05-12 - club - IPL - male - 1181768 - Mumbai Indians vs Chennai Super Kings
2019-05-11 - international - ODI - male - 1168511 - Ireland vs West Indies
2019-05-11 - international - ODI - male - 1152842 - England vs Pakistan
2019-05-10 - club - RLC - male - 1167122 - Lancashire vs Middlesex
2019-05-10 - club - RLC - male - 1167121 - Somerset vs Worcestershire
2019-05-10 - club - IPL - male - 1181767 - Chennai Super Kings vs Delhi Capitals
2019-05-08 - international - ODI - male - 1152841 - England vs Pakistan
2019-05-08 - club - IPL - male - 1181766 - Delhi Capitals vs Sunrisers Hyderabad
2019-05-07 - international - ODI - male - 1168509 - Bangladesh vs West Indies
2019-05-07 - club - RLC - male - 1167120 - Essex vs Gloucestershire
2019-05-07 - club - RLC - male - 1167119 - Middlesex vs Kent
2019-05-07 - club - RLC - male - 1167118 - Sussex vs Glamorgan
2019-05-07 - club - RLC - male - 1167117 - Surrey vs Somerset
2019-05-07 - club - IPL - male - 1181764 - Mumbai Indians vs Chennai Super Kings
2019-05-06 - club - RLC - male - 1167116 - Durham vs Yorkshire
2019-05-06 - club - RLC - male - 1167115 - Northamptonshire vs Nottinghamshire
2019-05-06 - club - RLC - male - 1167114 - Leicestershire vs Warwickshire
2019-05-06 - club - RLC - male - 1167113 - Derbyshire vs Worcestershire
2019-05-05 - international - T20 - male - 1152840 - England vs Pakistan
2019-05-05 - international - ODI - male - 1168508 - Ireland vs West Indies
2019-05-05 - club - RLC - male - 1167112 - Gloucestershire vs Sussex
2019-05-05 - club - RLC - male - 1167111 - Somerset vs Hampshire
2019-05-05 - club - RLC - male - 1167110 - Glamorgan vs Middlesex
2019-05-05 - club - RLC - male - 1167109 - Essex vs Kent
2019-05-05 - club - IPL - male - 1178431 - Mumbai Indians vs Kolkata Knight Riders
2019-05-05 - club - IPL - male - 1178430 - Kings XI Punjab vs Chennai Super Kings
2019-05-05 - club - CTC - male - 1157256 - Lions vs Warriors
2019-05-04 - club - RLC - male - 1167108 - Worcestershire vs Yorkshire
2019-05-04 - club - RLC - male - 1167107 - Lancashire vs Warwickshire
2019-05-04 - club - RLC - male - 1167106 - Northamptonshire vs Leicestershire
2019-05-04 - club - IPL - male - 1178429 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2019-05-04 - club - IPL - male - 1178428 - Delhi Capitals vs Rajasthan Royals
2019-05-03 - international - ODI - male - 1161014 - Ireland vs England
2019-05-03 - club - IPL - male - 1178427 - Kings XI Punjab vs Kolkata Knight Riders
2019-05-02 - club - RLC - male - 1167103 - Surrey vs Kent
2019-05-02 - club - RLC - male - 1167102 - Lancashire vs Derbyshire
2019-05-02 - club - IPL - male - 1178426 - Mumbai Indians vs Sunrisers Hyderabad
2019-05-01 - club - RLC - male - 1167101 - Middlesex vs Somerset
2019-05-01 - club - RLC - male - 1167100 - Northamptonshire vs Yorkshire
2019-05-01 - club - RLC - male - 1167099 - Nottinghamshire vs Worcestershire
2019-05-01 - club - IPL - male - 1178425 - Chennai Super Kings vs Delhi Capitals
2019-05-01 - club - CTC - male - 1157255 - Warriors vs Cape Cobras
2019-05-01 - club - CTC - male - 1157254 - Dolphins vs Lions
2019-04-30 - club - RLC - male - 1167098 - Hampshire vs Surrey
2019-04-30 - club - RLC - male - 1167097 - Warwickshire vs Derbyshire
2019-04-30 - club - RLC - male - 1167096 - Durham vs Lancashire
2019-04-30 - club - RLC - male - 1167095 - Essex vs Sussex
2019-04-30 - club - RLC - male - 1167094 - Glamorgan vs Gloucestershire
2019-04-30 - club - IPL - male - 1178424 - Royal Challengers Bangalore vs Rajasthan Royals
2019-04-29 - club - IPL - male - 1178423 - Sunrisers Hyderabad vs Kings XI Punjab
2019-04-28 - club - RLC - male - 1167093 - Derbyshire vs Durham
2019-04-28 - club - RLC - male - 1167092 - Essex vs Hampshire
2019-04-28 - club - RLC - male - 1167090 - Somerset vs Gloucestershire
2019-04-28 - club - RLC - male - 1167089 - Leicestershire vs Lancashire
2019-04-28 - club - RLC - male - 1167088 - Yorkshire vs Nottinghamshire
2019-04-28 - club - RLC - male - 1167087 - Warwickshire vs Worcestershire
2019-04-28 - club - IPL - male - 1178422 - Kolkata Knight Riders vs Mumbai Indians
2019-04-28 - club - IPL - male - 1178421 - Delhi Capitals vs Royal Challengers Bangalore
2019-04-28 - club - CTC - male - 1157253 - Titans vs Lions
2019-04-28 - club - CTC - male - 1157252 - Cape Cobras vs Dolphins
2019-04-27 - international - ODM - male - 1174843 - Canada vs Hong Kong
2019-04-27 - international - ODI - male - 1174845 - Namibia vs Oman
2019-04-27 - international - ODI - male - 1174844 - Papua New Guinea vs United States of America
2019-04-27 - club - RLC - male - 1167086 - Sussex vs Middlesex
2019-04-27 - club - IPL - male - 1178420 - Rajasthan Royals vs Sunrisers Hyderabad
2019-04-26 - international - ODM - male - 1174842 - Oman vs Papua New Guinea
2019-04-26 - international - ODM - male - 1174841 - Namibia vs Hong Kong
2019-04-26 - international - ODM - male - 1174840 - Canada vs United States of America
2019-04-26 - club - RLC - male - 1167085 - Yorkshire vs Derbyshire
2019-04-26 - club - RLC - male - 1167084 - Warwickshire vs Durham
2019-04-26 - club - RLC - male - 1167083 - Somerset vs Essex
2019-04-26 - club - RLC - male - 1167082 - Nottinghamshire vs Leicestershire
2019-04-26 - club - RLC - male - 1167081 - Worcestershire vs Northamptonshire
2019-04-26 - club - RLC - male - 1167080 - Hampshire vs Gloucestershire
2019-04-26 - club - IPL - male - 1178419 - Chennai Super Kings vs Mumbai Indians
2019-04-26 - club - CTC - male - 1157250 - Knights vs Titans
2019-04-26 - club - CTC - male - 1157249 - Warriors vs Dolphins
2019-04-26 - club - CTC - male - 1157248 - Cape Cobras vs Lions
2019-04-25 - club - RLC - male - 1167079 - Middlesex vs Surrey
2019-04-25 - club - RLC - male - 1167078 - Glamorgan vs Kent
2019-04-25 - club - IPO - male - 1178131 - Northern Knights vs Leinster Lightning
2019-04-25 - club - IPL - male - 1178418 - Kolkata Knight Riders vs Rajasthan Royals
2019-04-24 - international - ODM - male - 1174839 - Hong Kong vs United States of America
2019-04-24 - international - ODM - male - 1174838 - Namibia vs Oman
2019-04-24 - international - ODM - male - 1174837 - Canada vs Papua New Guinea
2019-04-24 - club - RLC - male - 1167077 - Durham vs Worcestershire
2019-04-24 - club - RLC - male - 1167076 - Northamptonshire vs Lancashire
2019-04-24 - club - RLC - male - 1167075 - Leicestershire vs Derbyshire
2019-04-24 - club - RLC - male - 1167074 - Somerset vs Sussex
2019-04-24 - club - IPO - male - 1178130 - Northern Knights vs North-West Warriors
2019-04-24 - club - IPL - male - 1178417 - Royal Challengers Bangalore vs Kings XI Punjab
2019-04-24 - club - CTC - male - 1157247 - Lions vs Warriors
2019-04-24 - club - CTC - male - 1157245 - Titans vs Cape Cobras
2019-04-23 - international - ODM - male - 1174836 - Namibia vs Canada
2019-04-23 - international - ODM - male - 1174835 - Papua New Guinea vs United States of America
2019-04-23 - international - ODM - male - 1174834 - Hong Kong vs Oman
2019-04-23 - club - RLC - male - 1167073 - Nottinghamshire vs Warwickshire
2019-04-23 - club - RLC - male - 1167072 - Kent vs Gloucestershire
2019-04-23 - club - RLC - male - 1167071 - Hampshire vs Middlesex
2019-04-23 - club - RLC - male - 1167070 - Surrey vs Essex
2019-04-23 - club - IPL - male - 1178416 - Chennai Super Kings vs Sunrisers Hyderabad
2019-04-22 - club - IPL - male - 1178415 - Rajasthan Royals vs Delhi Capitals
2019-04-21 - international - ODM - male - 1174833 - Hong Kong vs Papua New Guinea
2019-04-21 - international - ODM - male - 1174832 - Canada vs Oman
2019-04-21 - international - ODM - male - 1174831 - Namibia vs United States of America
2019-04-21 - club - RLC - male - 1167069 - Derbyshire vs Nottinghamshire
2019-04-21 - club - RLC - male - 1167068 - Lancashire vs Yorkshire
2019-04-21 - club - RLC - male - 1167067 - Gloucestershire vs Middlesex
2019-04-21 - club - RLC - male - 1167066 - Leicestershire vs Worcestershire
2019-04-21 - club - RLC - male - 1167065 - Kent vs Sussex
2019-04-21 - club - RLC - male - 1167064 - Northamptonshire vs Warwickshire
2019-04-21 - club - RLC - male - 1167063 - Somerset vs Glamorgan
2019-04-21 - club - IPL - male - 1178414 - Royal Challengers Bangalore vs Chennai Super Kings
2019-04-21 - club - IPL - male - 1178413 - Sunrisers Hyderabad vs Kolkata Knight Riders
2019-04-20 - international - ODM - male - 1174830 - Oman vs United States of America
2019-04-20 - international - ODM - male - 1174829 - Canada vs Hong Kong
2019-04-20 - international - ODM - male - 1174828 - Namibia vs Papua New Guinea
2019-04-20 - club - IPL - male - 1178412 - Delhi Capitals vs Kings XI Punjab
2019-04-20 - club - IPL - male - 1178411 - Rajasthan Royals vs Mumbai Indians
2019-04-20 - club - CTC - male - 1157240 - Dolphins vs Titans
2019-04-19 - club - RLC - male - 1167062 - Middlesex vs Essex
2019-04-19 - club - RLC - male - 1167061 - Surrey vs Sussex
2019-04-19 - club - RLC - male - 1167059 - Nottinghamshire vs Lancashire
2019-04-19 - club - RLC - male - 1167058 - Glamorgan vs Hampshire
2019-04-19 - club - RLC - male - 1167057 - Leicestershire vs Durham
2019-04-19 - club - RLC - male - 1167056 - Warwickshire vs Yorkshire
2019-04-19 - club - RLC - male - 1167055 - Derbyshire vs Northamptonshire
2019-04-19 - club - IPL - male - 1178410 - Kolkata Knight Riders vs Royal Challengers Bangalore
2019-04-18 - club - IPL - male - 1178409 - Delhi Capitals vs Mumbai Indians
2019-04-18 - club - CTC - male - 1157238 - Lions vs Titans
2019-04-17 - club - RLC - male - 1167054 - Durham vs Northamptonshire
2019-04-17 - club - RLC - male - 1167053 - Essex vs Glamorgan
2019-04-17 - club - RLC - male - 1167052 - Gloucestershire vs Surrey
2019-04-17 - club - RLC - male - 1167051 - Hampshire vs Kent
2019-04-17 - club - RLC - male - 1167050 - Worcestershire vs Lancashire
2019-04-17 - club - RLC - male - 1167049 - Yorkshire vs Leicestershire
2019-04-17 - club - IPL - male - 1178408 - Sunrisers Hyderabad vs Chennai Super Kings
2019-04-16 - international - ODI - male - 1179275 - Zimbabwe vs United Arab Emirates
2019-04-16 - club - IPL - male - 1178407 - Kings XI Punjab vs Rajasthan Royals
2019-04-16 - club - CTC - male - 1157236 - Cape Cobras vs Knights
2019-04-15 - club - IPL - male - 1178406 - Mumbai Indians vs Royal Challengers Bangalore
2019-04-14 - club - IPL - male - 1178405 - Sunrisers Hyderabad vs Delhi Capitals
2019-04-14 - club - IPL - male - 1178404 - Kolkata Knight Riders vs Chennai Super Kings
2019-04-14 - club - CTC - male - 1157234 - Warriors vs Lions
2019-04-14 - club - CTC - male - 1157233 - Cape Cobras vs Dolphins
2019-04-13 - club - IPL - male - 1178403 - Kings XI Punjab vs Royal Challengers Bangalore
2019-04-13 - club - IPL - male - 1178402 - Mumbai Indians vs Rajasthan Royals
2019-04-12 - international - ODI - male - 1179273 - Zimbabwe vs United Arab Emirates
2019-04-12 - club - IPL - male - 1178401 - Kolkata Knight Riders vs Delhi Capitals
2019-04-12 - club - CTC - male - 1157231 - Lions vs Knights
2019-04-12 - club - CTC - male - 1157230 - Warriors vs Cape Cobras
2019-04-11 - club - IPL - male - 1178400 - Rajasthan Royals vs Chennai Super Kings
2019-04-11 - club - CCH - male - 1166976 - Middlesex vs Lancashire
2019-04-11 - club - CCH - male - 1166975 - Worcestershire vs Leicestershire
2019-04-11 - club - CCH - male - 1166974 - Derbyshire vs Gloucestershire
2019-04-11 - club - CCH - male - 1166973 - Glamorgan vs Northamptonshire
2019-04-11 - club - CCH - male - 1166972 - Durham vs Sussex
2019-04-11 - club - CCH - male - 1166919 - Kent vs Warwickshire
2019-04-11 - club - CCH - male - 1166918 - Surrey vs Essex
2019-04-11 - club - CCH - male - 1166917 - Nottinghamshire vs Somerset
2019-04-11 - club - CCH - male - 1166916 - Yorkshire vs Hampshire
2019-04-10 - international - ODI - male - 1179272 - Zimbabwe vs United Arab Emirates
2019-04-10 - club - IPL - male - 1178399 - Mumbai Indians vs Kings XI Punjab
2019-04-10 - club - CTC - male - 1157229 - Cape Cobras vs Titans
2019-04-10 - club - CTC - male - 1157227 - Lions vs Dolphins
2019-04-09 - club - IPL - male - 1178398 - Chennai Super Kings vs Kolkata Knight Riders
2019-04-08 - club - IPL - male - 1178397 - Kings XI Punjab vs Sunrisers Hyderabad
2019-04-07 - club - IPL - male - 1178396 - Rajasthan Royals vs Kolkata Knight Riders
2019-04-07 - club - IPL - male - 1178395 - Royal Challengers Bangalore vs Delhi Capitals
2019-04-07 - club - CTC - male - 1157226 - Cape Cobras vs Lions
2019-04-06 - club - IPL - male - 1178394 - Sunrisers Hyderabad vs Mumbai Indians
2019-04-06 - club - IPL - male - 1178393 - Chennai Super Kings vs Kings XI Punjab
2019-04-06 - club - CTC - male - 1157225 - Knights vs Dolphins
2019-04-05 - club - IPL - male - 1175372 - Royal Challengers Bangalore vs Kolkata Knight Riders
2019-04-05 - club - CTC - male - 1157224 - Titans vs Warriors
2019-04-05 - club - CCH - male - 1166971 - Sussex vs Leicestershire
2019-04-05 - club - CCH - male - 1166970 - Northamptonshire vs Middlesex
2019-04-05 - club - CCH - male - 1166969 - Derbyshire vs Durham
2019-04-05 - club - CCH - male - 1166915 - Somerset vs Kent
2019-04-05 - club - CCH - male - 1166914 - Nottinghamshire vs Yorkshire
2019-04-05 - club - CCH - male - 1166913 - Hampshire vs Essex
2019-04-04 - club - IPL - male - 1175371 - Delhi Capitals vs Sunrisers Hyderabad
2019-04-03 - club - IPL - male - 1175370 - Mumbai Indians vs Chennai Super Kings
2019-04-02 - club - IPL - male - 1175369 - Rajasthan Royals vs Royal Challengers Bangalore
2019-04-01 - club - IPL - male - 1175368 - Kings XI Punjab vs Delhi Capitals
2019-03-31 - international - ODI - male - 1174242 - Australia vs Pakistan
2019-03-31 - club - IPL - male - 1175367 - Chennai Super Kings vs Rajasthan Royals
2019-03-31 - club - IPL - male - 1175366 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2019-03-30 - club - IPL - male - 1175365 - Delhi Capitals vs Kolkata Knight Riders
2019-03-30 - club - IPL - male - 1175364 - Kings XI Punjab vs Mumbai Indians
2019-03-29 - international - ODI - male - 1174241 - Australia vs Pakistan
2019-03-29 - club - IPL - male - 1175363 - Sunrisers Hyderabad vs Rajasthan Royals
2019-03-28 - club - IPL - male - 1175362 - Royal Challengers Bangalore vs Mumbai Indians
2019-03-27 - international - ODI - male - 1174240 - Australia vs Pakistan
2019-03-27 - club - IPL - male - 1175361 - Kolkata Knight Riders vs Kings XI Punjab
2019-03-26 - club - IPL - male - 1175360 - Delhi Capitals vs Chennai Super Kings
2019-03-25 - club - IPL - male - 1175359 - Rajasthan Royals vs Kings XI Punjab
2019-03-24 - international - T20 - male - 1176797 - Papua New Guinea vs Vanuatu
2019-03-24 - international - T20 - male - 1176796 - Philippines vs Vanuatu
2019-03-24 - international - T20 - male - 1144174 - South Africa vs Sri Lanka
2019-03-24 - international - ODI - male - 1174239 - Australia vs Pakistan
2019-03-24 - club - IPL - male - 1175358 - Mumbai Indians vs Delhi Capitals
2019-03-24 - club - IPL - male - 1175357 - Kolkata Knight Riders vs Sunrisers Hyderabad
2019-03-23 - international - T20 - male - 1176795 - Papua New Guinea vs Philippines
2019-03-23 - international - T20 - male - 1176794 - Philippines vs Vanuatu
2019-03-23 - club - IPL - male - 1175356 - Chennai Super Kings vs Royal Challengers Bangalore
2019-03-22 - international - T20 - male - 1176793 - Papua New Guinea vs Vanuatu
2019-03-22 - international - T20 - male - 1176792 - Papua New Guinea vs Philippines
2019-03-22 - international - T20 - male - 1144173 - South Africa vs Sri Lanka
2019-03-22 - international - ODI - male - 1174238 - Australia vs Pakistan
2019-03-20 - club - SSH - male - 1150137 - Western Australia vs Queensland
2019-03-20 - club - SSH - male - 1150136 - South Australia vs Victoria
2019-03-20 - club - SSH - male - 1150135 - New South Wales vs Tasmania
2019-03-19 - international - T20 - male - 1144172 - South Africa vs Sri Lanka
2019-03-17 - club - PSL - male - 1168853 - Quetta Gladiators vs Peshawar Zalmi
2019-03-17 - club - PKS - male - 1160302 - Otago Volts vs Auckland Aces
2019-03-17 - club - PKS - male - 1160301 - Northern Districts vs Central Stags
2019-03-16 - international - T20 - male - 1177485 - United Arab Emirates vs United States of America
2019-03-16 - international - ODI - male - 1144171 - South Africa vs Sri Lanka
2019-03-15 - international - T20 - male - 1177484 - United Arab Emirates vs United States of America
2019-03-15 - club - PSL - male - 1168852 - Islamabad United vs Peshawar Zalmi
2019-03-14 - club - SMA - male - 1175045 - Maharashtra vs Karnataka
2019-03-14 - club - PSL - male - 1168850 - Islamabad United vs Karachi Kings
2019-03-13 - international - ODI - male - 1168246 - India vs Australia
2019-03-13 - international - ODI - male - 1144170 - South Africa vs Sri Lanka
2019-03-13 - club - PSL - male - 1168851 - Peshawar Zalmi vs Quetta Gladiators
2019-03-12 - club - SSH - male - 1150134 - Western Australia vs Tasmania
2019-03-12 - club - SMA - male - 1175044 - Vidarbha vs Karnataka
2019-03-12 - club - SMA - male - 1175043 - Gujarat vs Bengal
2019-03-12 - club - SMA - male - 1175042 - Mumbai vs Uttar Pradesh
2019-03-11 - club - SMA - male - 1175040 - Uttar Pradesh vs Delhi
2019-03-11 - club - SMA - male - 1175038 - Vidarbha vs Mumbai
2019-03-11 - club - SMA - male - 1175037 - Railways vs Gujarat
2019-03-11 - club - PSL - male - 1168849 - Lahore Qalandars vs Multan Sultans
2019-03-11 - club - PSL - male - 1168846 - Karachi Kings vs Peshawar Zalmi
2019-03-10 - international - T20 - male - 1158073 - West Indies vs England
2019-03-10 - international - ODI - male - 1168245 - India vs Australia
2019-03-10 - international - ODI - male - 1144169 - South Africa vs Sri Lanka
2019-03-10 - club - SMA - male - 1175036 - Gujarat vs Maharashtra
2019-03-10 - club - SMA - male - 1175035 - Jharkhand vs Bengal
2019-03-10 - club - SMA - male - 1175034 - Vidarbha vs Uttar Pradesh
2019-03-10 - club - SMA - male - 1175033 - Delhi vs Karnataka
2019-03-10 - club - PSL - male - 1168848 - Karachi Kings vs Quetta Gladiators
2019-03-09 - club - SMA - male - 1175032 - Karnataka vs Uttar Pradesh
2019-03-09 - club - SMA - male - 1175031 - Railways vs Jharkhand
2019-03-09 - club - SMA - male - 1175030 - Delhi vs Mumbai
2019-03-09 - club - SMA - male - 1175029 - Bengal vs Maharashtra
2019-03-09 - club - PSL - male - 1168847 - Lahore Qalandars vs Islamabad United
2019-03-09 - club - PKS - male - 1160300 - Otago Volts vs Wellington Firebirds
2019-03-09 - club - PKS - male - 1160299 - Central Stags vs Northern Districts
2019-03-09 - club - PKS - male - 1160298 - Canterbury vs Auckland Aces
2019-03-08 - international - Test - male - 1153848 - New Zealand vs Bangladesh
2019-03-08 - international - T20 - male - 1158072 - West Indies vs England
2019-03-08 - international - ODI - male - 1168244 - India vs Australia
2019-03-08 - club - SMA - male - 1175028 - Mumbai vs Karnataka
2019-03-08 - club - SMA - male - 1175027 - Railways vs Bengal
2019-03-08 - club - SMA - male - 1175026 - Delhi vs Vidarbha
2019-03-08 - club - SMA - male - 1175025 - Jharkhand vs Gujarat
2019-03-06 - international - ODI - male - 1144168 - South Africa vs Sri Lanka
2019-03-05 - international - T20 - male - 1158071 - West Indies vs England
2019-03-05 - international - ODI - male - 1168243 - India vs Australia
2019-03-05 - club - SSH - male - 1150129 - Victoria vs Tasmania
2019-03-05 - club - PSL - male - 1168845 - Islamabad United vs Quetta Gladiators
2019-03-05 - club - PSL - male - 1168844 - Lahore Qalandars vs Peshawar Zalmi
2019-03-04 - club - PSL - male - 1168843 - Karachi Kings vs Multan Sultans
2019-03-04 - club - PSL - male - 1168842 - Peshawar Zalmi vs Quetta Gladiators
2019-03-03 - international - ODI - male - 1144167 - South Africa vs Sri Lanka
2019-03-03 - club - SSH - male - 1150131 - South Australia vs Western Australia
2019-03-03 - club - SSH - male - 1150130 - New South Wales vs Queensland
2019-03-02 - international - ODI - male - 1168242 - India vs Australia
2019-03-02 - international - ODI - male - 1158070 - West Indies vs England
2019-03-02 - club - SMA - male - 1157209 - Services vs Puducherry
2019-03-02 - club - SMA - male - 1157208 - Maharashtra vs Tripura
2019-03-02 - club - SMA - male - 1157207 - Hyderabad (India) vs Uttarakhand
2019-03-02 - club - SMA - male - 1157206 - Baroda vs Uttar Pradesh
2019-03-02 - club - SMA - male - 1157205 - Odisha vs Bengal
2019-03-02 - club - SMA - male - 1157204 - Karnataka vs Haryana
2019-03-02 - club - SMA - male - 1157203 - Chhattisgarh vs Mizoram
2019-03-02 - club - SMA - male - 1157202 - Arunachal Pradesh vs Assam
2019-03-02 - club - SMA - male - 1157201 - Goa vs Saurashtra
2019-03-02 - club - SMA - male - 1157200 - Railways vs Punjab
2019-03-02 - club - SMA - male - 1157199 - Madhya Pradesh vs Sikkim
2019-03-02 - club - SMA - male - 1157197 - Tamil Nadu vs Meghalaya
2019-03-02 - club - SMA - male - 1157196 - Gujarat vs Vidarbha
2019-03-02 - club - SMA - male - 1157195 - Andhra vs Manipur
2019-03-02 - club - SMA - male - 1157194 - Kerala vs Jharkhand
2019-03-02 - club - SMA - male - 1157193 - Nagaland vs Delhi
2019-03-01 - club - PSL - male - 1168841 - Multan Sultans vs Quetta Gladiators
2019-03-01 - club - PSL - male - 1168840 - Islamabad United vs Peshawar Zalmi
2019-03-01 - club - PKS - male - 1160297 - Northern Districts vs Auckland Aces
2019-03-01 - club - PKS - male - 1160296 - Central Stags vs Otago Volts
2019-03-01 - club - PKS - male - 1160295 - Canterbury vs Wellington Firebirds
2019-02-28 - international - Test - male - 1153847 - New Zealand vs Bangladesh
2019-02-28 - club - SMA - male - 1157192 - Uttar Pradesh vs Uttarakhand
2019-02-28 - club - SMA - male - 1157191 - Puducherry vs Tripura
2019-02-28 - club - SMA - male - 1157190 - Hyderabad (India) vs Services
2019-02-28 - club - SMA - male - 1157189 - Baroda vs Maharashtra
2019-02-28 - club - SMA - male - 1157188 - Mizoram vs Arunachal Pradesh
2019-02-28 - club - SMA - male - 1157187 - Karnataka vs Odisha
2019-02-28 - club - SMA - male - 1157186 - Bengal vs Chhattisgarh
2019-02-28 - club - SMA - male - 1157185 - Assam vs Haryana
2019-02-28 - club - SMA - male - 1157183 - Sikkim vs Railways
2019-02-28 - club - SMA - male - 1157182 - Punjab vs Goa
2019-02-28 - club - SMA - male - 1157181 - Himachal vs Rajasthan
2019-02-28 - club - SMA - male - 1157180 - Vidarbha vs Tamil Nadu
2019-02-28 - club - SMA - male - 1157179 - Meghalaya vs Bihar
2019-02-28 - club - SMA - male - 1157178 - Manipur vs Jammu & Kashmir
2019-02-28 - club - SMA - male - 1157177 - Nagaland vs Kerala
2019-02-28 - club - SMA - male - 1157176 - Andhra vs Jharkhand
2019-02-28 - club - PSL - male - 1168839 - Karachi Kings vs Lahore Qalandars
2019-02-28 - club - PSL - male - 1168838 - Multan Sultans vs Peshawar Zalmi
2019-02-27 - international - T20 - male - 1168248 - India vs Australia
2019-02-27 - international - ODI - male - 1158069 - West Indies vs England
2019-02-27 - club - SMA - male - 1157175 - Uttar Pradesh vs Services
2019-02-27 - club - SMA - male - 1157174 - Uttarakhand vs Maharashtra
2019-02-27 - club - SMA - male - 1157172 - Puducherry vs Baroda
2019-02-27 - club - SMA - male - 1157171 - Bengal vs Arunachal Pradesh
2019-02-27 - club - SMA - male - 1157170 - Haryana vs Mizoram
2019-02-27 - club - SMA - male - 1157169 - Chhattisgarh vs Karnataka
2019-02-27 - club - SMA - male - 1157168 - Assam vs Odisha
2019-02-27 - club - SMA - male - 1157167 - Railways vs Mumbai
2019-02-27 - club - SMA - male - 1157166 - Sikkim vs Punjab
2019-02-27 - club - SMA - male - 1157165 - Goa vs Madhya Pradesh
2019-02-27 - club - SMA - male - 1157164 - Tamil Nadu vs Himachal
2019-02-27 - club - SMA - male - 1157163 - Vidarbha vs Meghalaya
2019-02-27 - club - SMA - male - 1157162 - Gujarat vs Bihar
2019-02-27 - club - SMA - male - 1157161 - Kerala vs Jammu & Kashmir
2019-02-27 - club - SMA - male - 1157160 - Jharkhand vs Nagaland
2019-02-27 - club - SMA - male - 1157159 - Delhi vs Andhra
2019-02-27 - club - PSL - male - 1168837 - Islamabad United vs Karachi Kings
2019-02-27 - club - PSL - male - 1168836 - Lahore Qalandars vs Quetta Gladiators
2019-02-26 - club - PSL - male - 1168835 - Islamabad United vs Multan Sultans
2019-02-25 - club - SMA - male - 1157158 - Uttarakhand vs Tripura
2019-02-25 - club - SMA - male - 1157157 - Uttar Pradesh vs Puducherry
2019-02-25 - club - SMA - male - 1157156 - Hyderabad (India) vs Maharashtra
2019-02-25 - club - SMA - male - 1157155 - Baroda vs Services
2019-02-25 - club - SMA - male - 1157154 - Karnataka vs Mizoram
2019-02-25 - club - SMA - male - 1157153 - Arunachal Pradesh vs Odisha
2019-02-25 - club - SMA - male - 1157152 - Haryana vs Chhattisgarh
2019-02-25 - club - SMA - male - 1157151 - Assam vs Bengal
2019-02-25 - club - SMA - male - 1157150 - Sikkim vs Saurashtra
2019-02-25 - club - SMA - male - 1157149 - Goa vs Mumbai
2019-02-25 - club - SMA - male - 1157148 - Madhya Pradesh vs Railways
2019-02-25 - club - SMA - male - 1157147 - Vidarbha vs Rajasthan
2019-02-25 - club - SMA - male - 1157146 - Bihar vs Himachal
2019-02-25 - club - SMA - male - 1157145 - Tamil Nadu vs Gujarat
2019-02-25 - club - SMA - male - 1157144 - Nagaland vs Manipur
2019-02-25 - club - SMA - male - 1157143 - Andhra vs Jammu & Kashmir
2019-02-25 - club - SMA - male - 1157142 - Kerala vs Delhi
2019-02-24 - international - T20 - male - 1168247 - India vs Australia
2019-02-24 - club - SMA - male - 1157141 - Uttar Pradesh vs Tripura
2019-02-24 - club - SMA - male - 1157140 - Uttarakhand vs Puducherry
2019-02-24 - club - SMA - male - 1157139 - Maharashtra vs Services
2019-02-24 - club - SMA - male - 1157138 - Hyderabad (India) vs Baroda
2019-02-24 - club - SMA - male - 1157137 - Karnataka vs Arunachal Pradesh
2019-02-24 - club - SMA - male - 1157136 - Mizoram vs Odisha
2019-02-24 - club - SMA - male - 1157135 - Haryana vs Bengal
2019-02-24 - club - SMA - male - 1157134 - Chhattisgarh vs Assam
2019-02-24 - club - SMA - male - 1157133 - Goa vs Railways
2019-02-24 - club - SMA - male - 1157132 - Punjab vs Saurashtra
2019-02-24 - club - SMA - male - 1157131 - Madhya Pradesh vs Mumbai
2019-02-24 - club - SMA - male - 1157130 - Bihar vs Tamil Nadu
2019-02-24 - club - SMA - male - 1157129 - Rajasthan vs Meghalaya
2019-02-24 - club - SMA - male - 1157128 - Gujarat vs Himachal
2019-02-24 - club - SMA - male - 1157127 - Kerala vs Andhra
2019-02-24 - club - SMA - male - 1157126 - Jharkhand vs Manipur
2019-02-24 - club - SMA - male - 1157125 - Jammu & Kashmir vs Delhi
2019-02-24 - club - PSL - male - 1168834 - Karachi Kings vs Quetta Gladiators
2019-02-24 - club - PSL - male - 1168833 - Multan Sultans vs Peshawar Zalmi
2019-02-23 - club - SSH - male - 1150128 - South Australia vs Tasmania
2019-02-23 - club - SSH - male - 1150126 - Queensland vs Victoria
2019-02-23 - club - PSL - male - 1168832 - Islamabad United vs Karachi Kings
2019-02-23 - club - PSL - male - 1168831 - Lahore Qalandars vs Quetta Gladiators
2019-02-22 - international - ODI - male - 1158067 - West Indies vs England
2019-02-22 - club - SMA - male - 1157124 - Tripura vs Services
2019-02-22 - club - SMA - male - 1157123 - Puducherry vs Maharashtra
2019-02-22 - club - SMA - male - 1157122 - Hyderabad (India) vs Uttar Pradesh
2019-02-22 - club - SMA - male - 1157121 - Baroda vs Uttarakhand
2019-02-22 - club - SMA - male - 1157120 - Bengal vs Karnataka
2019-02-22 - club - SMA - male - 1157119 - Haryana vs Odisha
2019-02-22 - club - SMA - male - 1157117 - Assam vs Mizoram
2019-02-22 - club - SMA - male - 1157116 - Sikkim vs Goa
2019-02-22 - club - SMA - male - 1157115 - Mumbai vs Punjab
2019-02-22 - club - SMA - male - 1157114 - Madhya Pradesh vs Saurashtra
2019-02-22 - club - SMA - male - 1157113 - Bihar vs Vidarbha
2019-02-22 - club - SMA - male - 1157112 - Himachal vs Meghalaya
2019-02-22 - club - SMA - male - 1157110 - Andhra vs Nagaland
2019-02-22 - club - SMA - male - 1157109 - Jammu & Kashmir vs Jharkhand
2019-02-22 - club - SMA - male - 1157108 - Manipur vs Delhi
2019-02-22 - club - PSL - male - 1168830 - Islamabad United vs Peshawar Zalmi
2019-02-22 - club - PSL - male - 1168829 - Lahore Qalandars vs Multan Sultans
2019-02-21 - international - Test - male - 1144165 - South Africa vs Sri Lanka
2019-02-21 - club - SMA - male - 1157107 - Services vs Uttarakhand
2019-02-21 - club - SMA - male - 1157106 - Maharashtra vs Uttar Pradesh
2019-02-21 - club - SMA - male - 1157105 - Puducherry vs Hyderabad (India)
2019-02-21 - club - SMA - male - 1157104 - Tripura vs Baroda
2019-02-21 - club - SMA - male - 1157103 - Bengal vs Mizoram
2019-02-21 - club - SMA - male - 1157102 - Arunachal Pradesh vs Haryana
2019-02-21 - club - SMA - male - 1157101 - Odisha vs Chhattisgarh
2019-02-21 - club - SMA - male - 1157099 - Mumbai vs Sikkim
2019-02-21 - club - SMA - male - 1157098 - Saurashtra vs Railways
2019-02-21 - club - SMA - male - 1157095 - Rajasthan vs Tamil Nadu
2019-02-21 - club - SMA - male - 1157094 - Gujarat vs Meghalaya
2019-02-21 - club - SMA - male - 1157093 - Nagaland vs Jammu & Kashmir
2019-02-21 - club - SMA - male - 1157092 - Kerala vs Manipur
2019-02-21 - club - SMA - male - 1157091 - Jharkhand vs Delhi
2019-02-21 - club - PSL - male - 1168828 - Karachi Kings vs Peshawar Zalmi
2019-02-21 - club - PKS - male - 1160294 - Wellington Firebirds vs Northern Districts
2019-02-21 - club - PKS - male - 1160293 - Canterbury vs Central Stags
2019-02-21 - club - PKS - male - 1160292 - Auckland Aces vs Otago Volts
2019-02-20 - international - ODI - male - 1158066 - West Indies vs England
2019-02-20 - international - ODI - male - 1153846 - New Zealand vs Bangladesh
2019-02-20 - club - PSL - male - 1168827 - Multan Sultans vs Quetta Gladiators
2019-02-17 - international - T20 - male - 1172510 - Oman vs Scotland
2019-02-17 - international - T20 - male - 1172509 - Ireland vs Netherlands
2019-02-17 - club - SSM - male - 1160528 - Central Districts vs Northern Districts
2019-02-17 - club - PSL - male - 1168826 - Lahore Qalandars vs Peshawar Zalmi
2019-02-17 - club - PSL - male - 1168825 - Islamabad United vs Quetta Gladiators
2019-02-17 - club - BBL - male - 1152569 - Melbourne Stars vs Melbourne Renegades
2019-02-16 - international - ODI - male - 1153845 - New Zealand vs Bangladesh
2019-02-16 - club - PSL - male - 1168824 - Karachi Kings vs Lahore Qalandars
2019-02-16 - club - PSL - male - 1168823 - Islamabad United vs Multan Sultans
2019-02-15 - international - T20 - male - 1172508 - Ireland vs Scotland
2019-02-15 - international - T20 - male - 1172507 - Oman vs Netherlands
2019-02-15 - club - SSM - male - 1160527 - Central Districts vs Auckland
2019-02-15 - club - PSL - male - 1168822 - Peshawar Zalmi vs Quetta Gladiators
2019-02-15 - club - PSL - male - 1168821 - Karachi Kings vs Multan Sultans
2019-02-15 - club - BBL - male - 1152568 - Melbourne Renegades vs Sydney Sixers
2019-02-14 - club - PSL - male - 1168820 - Islamabad United vs Lahore Qalandars
2019-02-14 - club - BBL - male - 1152567 - Hobart Hurricanes vs Melbourne Stars
2019-02-13 - international - Test - male - 1144164 - South Africa vs Sri Lanka
2019-02-13 - international - T20 - male - 1172506 - Oman vs Ireland
2019-02-13 - international - T20 - male - 1172505 - Netherlands vs Scotland
2019-02-13 - international - ODI - male - 1153844 - New Zealand vs Bangladesh
2019-02-10 - international - T20 - male - 1153698 - New Zealand vs India
2019-02-10 - club - BBL - male - 1152566 - Melbourne Stars vs Sydney Sixers
2019-02-09 - international - Test - male - 1158064 - West Indies vs England
2019-02-09 - club - SSM - male - 1160526 - Central Districts vs Auckland
2019-02-09 - club - SSM - male - 1160525 - Wellington vs Canterbury
2019-02-09 - club - SSM - male - 1160524 - Northern Districts vs Otago
2019-02-09 - club - BBL - male - 1152565 - Sydney Thunder vs Hobart Hurricanes
2019-02-09 - club - BBL - male - 1152564 - Adelaide Strikers vs Perth Scorchers
2019-02-08 - international - T20 - male - 1153697 - New Zealand vs India
2019-02-08 - club - BPL - male - 1169424 - Comilla Victorians vs Dhaka Dynamites
2019-02-08 - club - BBL - male - 1152563 - Brisbane Heat vs Melbourne Stars
2019-02-07 - club - BBL - male - 1152562 - Hobart Hurricanes vs Melbourne Renegades
2019-02-06 - international - T20 - male - 1153696 - New Zealand vs India
2019-02-06 - international - T20 - male - 1144163 - South Africa vs Pakistan
2019-02-06 - club - BPL - male - 1169423 - Rangpur Riders vs Dhaka Dynamites
2019-02-04 - club - BPL - male - 1169422 - Rangpur Riders vs Comilla Victorians
2019-02-04 - club - BPL - male - 1169421 - Chittagong Vikings vs Dhaka Dynamites
2019-02-03 - international - T20 - male - 1170459 - United Arab Emirates vs Nepal
2019-02-03 - international - T20 - male - 1144162 - South Africa vs Pakistan
2019-02-03 - international - ODI - male - 1153695 - New Zealand vs India
2019-02-03 - club - BBL - male - 1152561 - Perth Scorchers vs Melbourne Stars
2019-02-03 - club - BBL - male - 1152560 - Adelaide Strikers vs Brisbane Heat
2019-02-02 - club - SSM - male - 1160523 - Northern Districts vs Auckland
2019-02-02 - club - SSM - male - 1160522 - Canterbury vs Otago
2019-02-02 - club - BPL - male - 1169420 - Khulna Titans vs Dhaka Dynamites
2019-02-02 - club - BPL - male - 1169419 - Comilla Victorians vs Rangpur Riders
2019-02-02 - club - BBL - male - 1152559 - Sydney Sixers vs Sydney Thunder
2019-02-01 - international - Test - male - 1145001 - Australia vs Sri Lanka
2019-02-01 - international - T20 - male - 1170458 - United Arab Emirates vs Nepal
2019-02-01 - international - T20 - male - 1144161 - South Africa vs Pakistan
2019-02-01 - club - SSM - male - 1160521 - Central Districts vs Wellington
2019-02-01 - club - BPL - male - 1169418 - Sylhet Sixers vs Chittagong Vikings
2019-02-01 - club - BPL - male - 1169417 - Comilla Victorians vs Dhaka Dynamites
2019-02-01 - club - BBL - male - 1152558 - Brisbane Heat vs Perth Scorchers
2019-01-31 - international - Test - male - 1158063 - West Indies vs England
2019-01-31 - international - T20 - male - 1170457 - United Arab Emirates vs Nepal
2019-01-31 - international - ODI - male - 1153694 - New Zealand vs India
2019-01-31 - club - BBL - male - 1152557 - Hobart Hurricanes vs Adelaide Strikers
2019-01-30 - international - ODI - male - 1144160 - South Africa vs Pakistan
2019-01-30 - club - BPL - male - 1169416 - Sylhet Sixers vs Rajshahi Kings
2019-01-30 - club - BPL - male - 1169415 - Chittagong Vikings vs Dhaka Dynamites
2019-01-30 - club - BBL - male - 1152556 - Melbourne Renegades vs Sydney Thunder
2019-01-29 - club - BPL - male - 1169414 - Rajshahi Kings vs Rangpur Riders
2019-01-29 - club - BPL - male - 1169413 - Chittagong Vikings vs Comilla Victorians
2019-01-29 - club - BBL - male - 1152555 - Sydney Sixers vs Adelaide Strikers
2019-01-29 - club - BBL - male - 1152554 - Hobart Hurricanes vs Brisbane Heat
2019-01-28 - international - ODI - male - 1170456 - United Arab Emirates vs Nepal
2019-01-28 - international - ODI - male - 1153693 - New Zealand vs India
2019-01-28 - club - BPL - male - 1169412 - Dhaka Dynamites vs Rangpur Riders
2019-01-28 - club - BPL - male - 1169411 - Comilla Victorians vs Khulna Titans
2019-01-28 - club - BBL - male - 1152553 - Perth Scorchers vs Melbourne Renegades
2019-01-27 - international - ODI - male - 1144159 - South Africa vs Pakistan
2019-01-27 - club - SSM - male - 1160520 - Wellington vs Otago
2019-01-27 - club - BBL - male - 1152552 - Melbourne Stars vs Brisbane Heat
2019-01-26 - international - ODI - male - 1170455 - United Arab Emirates vs Nepal
2019-01-26 - international - ODI - male - 1153692 - New Zealand vs India
2019-01-26 - club - SSM - male - 1160519 - Canterbury vs Auckland
2019-01-26 - club - BPL - male - 1169410 - Rajshahi Kings vs Chittagong Vikings
2019-01-26 - club - BPL - male - 1169409 - Sylhet Sixers vs Khulna Titans
2019-01-25 - international - ODI - male - 1170454 - United Arab Emirates vs Nepal
2019-01-25 - international - ODI - male - 1144158 - South Africa vs Pakistan
2019-01-25 - club - SSM - male - 1160518 - Northern Districts vs Central Districts
2019-01-25 - club - BPL - male - 1169408 - Rangpur Riders vs Chittagong Vikings
2019-01-25 - club - BPL - male - 1169407 - Sylhet Sixers vs Rajshahi Kings
2019-01-24 - international - Test - male - 1145000 - Australia vs Sri Lanka
2019-01-24 - club - BBL - male - 1152551 - Perth Scorchers vs Sydney Thunder
2019-01-23 - international - Test - male - 1158062 - West Indies vs England
2019-01-23 - international - ODI - male - 1153691 - New Zealand vs India
2019-01-23 - club - BPL - male - 1169406 - Khulna Titans vs Sylhet Sixers
2019-01-23 - club - BPL - male - 1169405 - Rajshahi Kings vs Chittagong Vikings
2019-01-23 - club - BBL - male - 1152550 - Sydney Sixers vs Hobart Hurricanes
2019-01-23 - club - BBL - male - 1152549 - Melbourne Stars vs Adelaide Strikers
2019-01-22 - international - ODI - male - 1144157 - South Africa vs Pakistan
2019-01-22 - club - BPL - male - 1169404 - Comilla Victorians vs Dhaka Dynamites
2019-01-22 - club - BPL - male - 1169403 - Khulna Titans vs Rangpur Riders
2019-01-22 - club - BBL - male - 1152548 - Sydney Thunder vs Melbourne Renegades
2019-01-21 - club - BPL - male - 1169402 - Dhaka Dynamites vs Chittagong Vikings
2019-01-21 - club - BPL - male - 1169401 - Rajshahi Kings vs Comilla Victorians
2019-01-21 - club - BBL - male - 1152547 - Adelaide Strikers vs Hobart Hurricanes
2019-01-20 - club - SSM - male - 1160517 - Auckland vs Otago
2019-01-20 - club - BBL - male - 1152546 - Sydney Sixers vs Brisbane Heat
2019-01-19 - international - ODI - male - 1144156 - South Africa vs Pakistan
2019-01-19 - club - SSM - male - 1160516 - Central Districts vs Canterbury
2019-01-19 - club - BPL - male - 1169400 - Chittagong Vikings vs Khulna Titans
2019-01-19 - club - BPL - male - 1169399 - Sylhet Sixers vs Rangpur Riders
2019-01-19 - club - BBL - male - 1152545 - Melbourne Renegades vs Melbourne Stars
2019-01-18 - international - ODI - male - 1144999 - Australia vs India
2019-01-18 - club - SSM - male - 1160515 - Wellington vs Auckland
2019-01-18 - club - BPL - male - 1169398 - Khulna Titans vs Comilla Victorians
2019-01-18 - club - BPL - male - 1169397 - Sylhet Sixers vs Dhaka Dynamites
2019-01-18 - club - BBL - male - 1152544 - Perth Scorchers vs Hobart Hurricanes
2019-01-17 - club - BBL - male - 1152543 - Brisbane Heat vs Sydney Thunder
2019-01-16 - club - SSM - male - 1160514 - Northern Districts vs Canterbury
2019-01-16 - club - BPL - male - 1169396 - Sylhet Sixers vs Rangpur Riders
2019-01-16 - club - BPL - male - 1169395 - Rajshahi Kings vs Dhaka Dynamites
2019-01-16 - club - BBL - male - 1152542 - Sydney Sixers vs Melbourne Renegades
2019-01-15 - international - ODI - male - 1144998 - Australia vs India
2019-01-15 - club - BPL - male - 1169394 - Sylhet Sixers vs Comilla Victorians
2019-01-15 - club - BPL - male - 1169393 - Khulna Titans vs Rajshahi Kings
2019-01-14 - club - BBL - male - 1152541 - Melbourne Stars vs Hobart Hurricanes
2019-01-13 - club - SSM - male - 1160513 - Canterbury vs Central Districts
2019-01-13 - club - SSM - male - 1160512 - Auckland vs Otago
2019-01-13 - club - BPL - male - 1169392 - Comilla Victorians vs Chittagong Vikings
2019-01-13 - club - BBL - male - 1152540 - Perth Scorchers vs Sydney Sixers
2019-01-13 - club - BBL - male - 1152539 - Melbourne Renegades vs Brisbane Heat
2019-01-13 - club - BBL - male - 1152538 - Sydney Thunder vs Adelaide Strikers
2019-01-12 - international - ODI - male - 1144997 - Australia vs India
2019-01-12 - club - SSM - male - 1160511 - Northern Districts vs Wellington
2019-01-12 - club - BPL - male - 1169390 - Dhaka Dynamites vs Sylhet Sixers
2019-01-12 - club - BPL - male - 1169389 - Khulna Titans vs Chittagong Vikings
2019-01-11 - international - Test - male - 1144155 - South Africa vs Pakistan
2019-01-11 - international - T20 - male - 1153843 - New Zealand vs Sri Lanka
2019-01-11 - club - BPL - male - 1169388 - Rajshahi Kings vs Comilla Victorians
2019-01-11 - club - BPL - male - 1169387 - Dhaka Dynamites vs Rangpur Riders
2019-01-11 - club - BBL - male - 1152537 - Adelaide Strikers vs Melbourne Stars
2019-01-10 - club - SSM - male - 1160510 - Central Districts vs Otago
2019-01-10 - club - BBL - male - 1152536 - Brisbane Heat vs Melbourne Renegades
2019-01-09 - club - BPL - male - 1169386 - Khulna Titans vs Rajshahi Kings
2019-01-09 - club - BPL - male - 1169385 - Sylhet Sixers vs Chittagong Vikings
2019-01-09 - club - BBL - male - 1152535 - Melbourne Stars vs Perth Scorchers
2019-01-08 - international - ODI - male - 1153842 - New Zealand vs Sri Lanka
2019-01-08 - club - BPL - male - 1169384 - Comilla Victorians vs Rangpur Riders
2019-01-08 - club - BPL - male - 1169383 - Dhaka Dynamites vs Khulna Titans
2019-01-08 - club - BBL - male - 1152534 - Sydney Thunder vs Brisbane Heat
2019-01-07 - club - BBL - male - 1152533 - Melbourne Renegades vs Hobart Hurricanes
2019-01-06 - club - SSM - male - 1160508 - Wellington vs Canterbury
2019-01-06 - club - SSM - male - 1160506 - Northern Districts vs Auckland
2019-01-06 - club - BPL - male - 1169382 - Rangpur Riders vs Khulna Titans
2019-01-06 - club - BPL - male - 1169381 - Sylhet Sixers vs Comilla Victorians
2019-01-06 - club - BBL - male - 1152532 - Adelaide Strikers vs Sydney Sixers
2019-01-05 - international - ODI - male - 1153841 - New Zealand vs Sri Lanka
2019-01-05 - club - BPL - male - 1169380 - Dhaka Dynamites vs Rajshahi Kings
2019-01-05 - club - BPL - male - 1169379 - Rangpur Riders vs Chittagong Vikings
2019-01-05 - club - BBL - male - 1152531 - Perth Scorchers vs Brisbane Heat
2019-01-05 - club - BBL - male - 1152530 - Melbourne Stars vs Sydney Thunder
2019-01-04 - club - BBL - male - 1152529 - Hobart Hurricanes vs Sydney Sixers
2019-01-03 - international - Test - male - 1144996 - Australia vs India
2019-01-03 - international - Test - male - 1144154 - South Africa vs Pakistan
2019-01-03 - international - ODI - male - 1153840 - New Zealand vs Sri Lanka
2019-01-03 - club - BBL - male - 1152528 - Melbourne Renegades vs Adelaide Strikers
2019-01-02 - club - BBL - male - 1152527 - Sydney Thunder vs Perth Scorchers
2019-01-01 - club - SSM - male - 1160505 - Auckland vs Canterbury
2019-01-01 - club - BBL - male - 1152526 - Melbourne Stars vs Melbourne Renegades
2019-01-01 - club - BBL - male - 1152525 - Brisbane Heat vs Sydney Sixers
