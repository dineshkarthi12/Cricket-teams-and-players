This zip archive contains data files from Cricsheet in JSON format. This
archive contains 40 Haryana matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/haryana_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-23 - club - SMA - male - 1383507 - Haryana vs Mizoram
2023-10-17 - club - SMA - male - 1383453 - Haryana vs Chhattisgarh
2023-10-16 - club - SMA - male - 1383434 - Haryana vs Mumbai
2022-10-30 - club - SMA - male - 1333046 - Punjab vs Haryana
2021-11-09 - club - SMA - male - 1280281 - Rajasthan vs Haryana
2021-11-06 - club - SMA - male - 1280242 - Haryana vs Jammu & Kashmir
2021-11-05 - club - SMA - male - 1280225 - Andhra vs Haryana
2021-11-04 - club - SMA - male - 1280204 - Himachal vs Haryana
2021-01-27 - club - SMA - male - 1244403 - Haryana vs Baroda
2021-01-19 - club - SMA - male - 1244394 - Haryana vs Kerala
2021-01-17 - club - SMA - male - 1244377 - Delhi vs Haryana
2021-01-15 - club - SMA - male - 1244357 - Mumbai vs Haryana
2021-01-13 - club - SMA - male - 1244338 - Puducherry vs Haryana
2021-01-11 - club - SMA - male - 1244318 - Andhra vs Haryana
2019-11-29 - club - SMA - male - 1205861 - Haryana vs Karnataka
2019-11-27 - club - SMA - male - 1205857 - Maharashtra vs Haryana
2019-11-25 - club - SMA - male - 1205852 - Baroda vs Haryana
2019-11-24 - club - SMA - male - 1205849 - Haryana vs Delhi
2019-11-22 - club - SMA - male - 1205845 - Rajasthan vs Haryana
2019-11-18 - club - SMA - male - 1205720 - Haryana vs Meghalaya
2019-11-17 - club - SMA - male - 1205837 - Madhya Pradesh vs Haryana
2019-11-15 - club - SMA - male - 1205810 - Mizoram vs Haryana
2019-11-14 - club - SMA - male - 1205793 - Puducherry vs Haryana
2019-11-12 - club - SMA - male - 1205782 - Bengal vs Haryana
2019-11-11 - club - SMA - male - 1205765 - Assam vs Haryana
2019-11-09 - club - SMA - male - 1205747 - Haryana vs Mumbai
2019-03-02 - club - SMA - male - 1157204 - Karnataka vs Haryana
2019-02-28 - club - SMA - male - 1157185 - Assam vs Haryana
2019-02-27 - club - SMA - male - 1157170 - Haryana vs Mizoram
2019-02-25 - club - SMA - male - 1157152 - Haryana vs Chhattisgarh
2019-02-24 - club - SMA - male - 1157135 - Haryana vs Bengal
2019-02-22 - club - SMA - male - 1157119 - Haryana vs Odisha
2019-02-21 - club - SMA - male - 1157102 - Arunachal Pradesh vs Haryana
2018-01-15 - club - SMA - male - 1130718 - Services vs Haryana
2018-01-12 - club - SMA - male - 1130699 - Punjab vs Haryana
2018-01-08 - club - SMA - male - 1130664 - Himachal vs Haryana
2016-01-10 - club - SMA - male - 902225 - Haryana vs Gujarat
2016-01-09 - club - SMA - male - 902209 - Haryana vs Bengal
2016-01-04 - club - SMA - male - 902135 - Haryana vs Vidarbha
2016-01-02 - club - SMA - male - 902091 - Haryana vs Tamil Nadu
