This zip archive contains data files from Cricsheet in JSON format. This
archive contains 26 Uttarakhand matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/uttarakhand_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2022-10-20 - club - SMA - male - 1333017 - Uttarakhand vs Mizoram
2022-10-18 - club - SMA - male - 1332999 - Vidarbha vs Uttarakhand
2022-10-16 - club - SMA - male - 1332978 - Rajasthan vs Uttarakhand
2022-10-11 - club - SMA - male - 1332927 - Railways vs Uttarakhand
2021-11-09 - club - SMA - male - 1280286 - Uttarakhand vs Chandigarh
2021-11-06 - club - SMA - male - 1280250 - Saurashtra vs Uttarakhand
2021-11-05 - club - SMA - male - 1280230 - Hyderabad (India) vs Uttarakhand
2021-11-04 - club - SMA - male - 1280212 - Delhi vs Uttarakhand
2021-01-18 - club - SMA - male - 1244389 - Uttarakhand vs Chhattisgarh
2021-01-16 - club - SMA - male - 1244369 - Uttarakhand vs Himachal
2021-01-14 - club - SMA - male - 1244352 - Maharashtra vs Uttarakhand
2021-01-12 - club - SMA - male - 1244332 - Gujarat vs Uttarakhand
2021-01-10 - club - SMA - male - 1244314 - Baroda vs Uttarakhand
2019-11-17 - club - SMA - male - 1205822 - Bihar vs Uttarakhand
2019-11-14 - club - SMA - male - 1205787 - Uttarakhand vs Andhra
2019-11-12 - club - SMA - male - 1205778 - Goa vs Uttarakhand
2019-11-11 - club - SMA - male - 1205750 - Baroda vs Uttarakhand
2019-11-09 - club - SMA - male - 1205742 - Uttarakhand vs Services
2019-11-08 - club - SMA - male - 1205714 - Uttarakhand vs Karnataka
2019-03-02 - club - SMA - male - 1157207 - Hyderabad (India) vs Uttarakhand
2019-02-28 - club - SMA - male - 1157192 - Uttar Pradesh vs Uttarakhand
2019-02-27 - club - SMA - male - 1157174 - Uttarakhand vs Maharashtra
2019-02-25 - club - SMA - male - 1157158 - Uttarakhand vs Tripura
2019-02-24 - club - SMA - male - 1157140 - Uttarakhand vs Puducherry
2019-02-22 - club - SMA - male - 1157121 - Baroda vs Uttarakhand
2019-02-21 - club - SMA - male - 1157107 - Services vs Uttarakhand
