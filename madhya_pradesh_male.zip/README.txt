This zip archive contains data files from Cricsheet in YAML format. This
archive contains 41 Madhya Pradesh matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/madhya_pradesh_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2024-12-15 - club - SMA - male - 1446107 - Madhya Pradesh vs Mumbai
2024-12-13 - club - SMA - male - 1446106 - Delhi vs Madhya Pradesh
2024-12-11 - club - SMA - male - 1446103 - Saurashtra vs Madhya Pradesh
2023-10-25 - club - SMA - male - 1383541 - Tamil Nadu vs Madhya Pradesh
2023-10-19 - club - SMA - male - 1383485 - Madhya Pradesh vs Karnataka
2023-10-17 - club - SMA - male - 1383467 - Madhya Pradesh vs Delhi
2022-10-22 - club - SMA - male - 1333033 - Madhya Pradesh vs Assam
2022-10-18 - club - SMA - male - 1332997 - Mizoram vs Madhya Pradesh
2022-10-12 - club - SMA - male - 1332943 - Madhya Pradesh vs Mumbai
2021-11-09 - club - SMA - male - 1280284 - Madhya Pradesh vs Kerala
2021-11-08 - club - SMA - male - 1280266 - Bihar vs Madhya Pradesh
2021-11-06 - club - SMA - male - 1280247 - Gujarat vs Madhya Pradesh
2021-11-05 - club - SMA - male - 1280226 - Railways vs Madhya Pradesh
2021-11-04 - club - SMA - male - 1280207 - Assam vs Madhya Pradesh
2021-01-19 - club - SMA - male - 1244391 - Madhya Pradesh vs Services
2021-01-17 - club - SMA - male - 1244373 - Saurashtra vs Madhya Pradesh
2021-01-15 - club - SMA - male - 1244353 - Madhya Pradesh vs Vidarbha
2021-01-13 - club - SMA - male - 1244336 - Rajasthan vs Madhya Pradesh
2021-01-11 - club - SMA - male - 1244317 - Madhya Pradesh vs Goa
2019-11-18 - club - SMA - male - 1205728 - Madhya Pradesh vs Puducherry
2019-11-17 - club - SMA - male - 1205837 - Madhya Pradesh vs Haryana
2019-11-15 - club - SMA - male - 1205811 - Madhya Pradesh vs Bengal
2019-11-14 - club - SMA - male - 1205801 - Madhya Pradesh vs Meghalaya
2019-11-12 - club - SMA - male - 1205775 - Madhya Pradesh vs Mizoram
2019-11-11 - club - SMA - male - 1205764 - Madhya Pradesh vs Mumbai
2019-03-02 - club - SMA - male - 1157199 - Madhya Pradesh vs Sikkim
2019-02-27 - club - SMA - male - 1157165 - Goa vs Madhya Pradesh
2019-02-25 - club - SMA - male - 1157148 - Madhya Pradesh vs Railways
2019-02-24 - club - SMA - male - 1157131 - Madhya Pradesh vs Mumbai
2019-02-22 - club - SMA - male - 1157114 - Madhya Pradesh vs Saurashtra
2018-01-15 - club - SMA - male - 1130717 - Madhya Pradesh vs Railways
2018-01-14 - club - SMA - male - 1130709 - Chhattisgarh vs Madhya Pradesh
2018-01-12 - club - SMA - male - 1130694 - Vidarbha vs Madhya Pradesh
2018-01-10 - club - SMA - male - 1130681 - Uttar Pradesh vs Madhya Pradesh
2018-01-08 - club - SMA - male - 1130663 - Rajasthan vs Madhya Pradesh
2016-01-10 - club - SMA - male - 902237 - Assam vs Madhya Pradesh
2016-01-07 - club - SMA - male - 902197 - Baroda vs Madhya Pradesh
2016-01-06 - club - SMA - male - 902173 - Railways vs Madhya Pradesh
2016-01-04 - club - SMA - male - 902149 - Madhya Pradesh vs Delhi
2016-01-03 - club - SMA - male - 902123 - Goa vs Madhya Pradesh
2016-01-02 - club - SMA - male - 902099 - Andhra vs Madhya Pradesh
