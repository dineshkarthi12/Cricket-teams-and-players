This zip archive contains data files from Cricsheet in JSON format. This
archive contains 40 Maharashtra matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/maharashtra_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2021-11-16 - club - SMA - male - 1280293 - Maharashtra vs Vidarbha
2021-11-09 - club - SMA - male - 1280275 - Maharashtra vs Goa
2021-11-08 - club - SMA - male - 1280257 - Maharashtra vs Puducherry
2021-11-06 - club - SMA - male - 1280238 - Maharashtra vs Odisha
2021-11-05 - club - SMA - male - 1280217 - Punjab vs Maharashtra
2021-11-04 - club - SMA - male - 1280198 - Tamil Nadu vs Maharashtra
2021-01-18 - club - SMA - male - 1244390 - Maharashtra vs Himachal
2021-01-16 - club - SMA - male - 1244370 - Baroda vs Maharashtra
2021-01-14 - club - SMA - male - 1244352 - Maharashtra vs Uttarakhand
2021-01-12 - club - SMA - male - 1244331 - Chhattisgarh vs Maharashtra
2021-01-10 - club - SMA - male - 1244312 - Gujarat vs Maharashtra
2019-11-27 - club - SMA - male - 1205857 - Maharashtra vs Haryana
2019-11-25 - club - SMA - male - 1205853 - Maharashtra vs Rajasthan
2019-11-24 - club - SMA - male - 1205848 - Maharashtra vs Baroda
2019-11-21 - club - SMA - male - 1205841 - Delhi vs Maharashtra
2019-11-18 - club - SMA - male - 1205827 - Maharashtra vs Punjab
2019-11-15 - club - SMA - male - 1205816 - Himachal vs Maharashtra
2019-11-14 - club - SMA - male - 1205799 - Hyderabad (India) vs Maharashtra
2019-11-12 - club - SMA - male - 1205773 - Chhattisgarh vs Maharashtra
2019-11-11 - club - SMA - male - 1205762 - Arunachal Pradesh vs Maharashtra
2019-11-08 - club - SMA - male - 1205727 - Maharashtra vs Railways
2019-03-14 - club - SMA - male - 1175045 - Maharashtra vs Karnataka
2019-03-10 - club - SMA - male - 1175036 - Gujarat vs Maharashtra
2019-03-09 - club - SMA - male - 1175029 - Bengal vs Maharashtra
2019-03-02 - club - SMA - male - 1157208 - Maharashtra vs Tripura
2019-02-28 - club - SMA - male - 1157189 - Baroda vs Maharashtra
2019-02-27 - club - SMA - male - 1157174 - Uttarakhand vs Maharashtra
2019-02-25 - club - SMA - male - 1157156 - Hyderabad (India) vs Maharashtra
2019-02-24 - club - SMA - male - 1157139 - Maharashtra vs Services
2019-02-22 - club - SMA - male - 1157123 - Puducherry vs Maharashtra
2019-02-21 - club - SMA - male - 1157106 - Maharashtra vs Uttar Pradesh
2018-01-13 - club - SMA - male - 1130708 - Maharashtra vs Baroda
2018-01-11 - club - SMA - male - 1130690 - Maharashtra vs Mumbai
2018-01-08 - club - SMA - male - 1130667 - Saurashtra vs Maharashtra
2018-01-07 - club - SMA - male - 1130662 - Gujarat vs Maharashtra
2016-01-08 - club - SMA - male - 902181 - Maharashtra vs Mumbai
2016-01-07 - club - SMA - male - 902205 - Maharashtra vs Karnataka
2016-01-04 - club - SMA - male - 902157 - Odisha vs Maharashtra
2016-01-03 - club - SMA - male - 902133 - Maharashtra vs Services
2016-01-02 - club - SMA - male - 902109 - Maharashtra vs Uttar Pradesh
