This zip archive contains data files from Cricsheet in JSON format. This
archive contains 319 Ireland matches of all types. A further 62 matches have
been withheld due to either featuring the Afghanistan men's team or being
played in the Afghanistan Premier League, due to the Cricsheet policy to no
longer feature matches involving Afghanistan men or played in Afghanistan
Premier League (see https://cricsheet.org/withheld-matches for more
information).


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/ireland_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-06-28 - international - T20 - male - 1528549 - Ireland vs India
2026-06-26 - international - T20 - male - 1528548 - Ireland vs India
2026-05-27 - international - Test - male - 1528547 - New Zealand vs Ireland
2026-02-14 - international - T20 - male - 1512740 - Ireland vs Oman
2026-02-11 - international - T20 - male - 1512732 - Australia vs Ireland
2026-02-08 - international - T20 - male - 1512724 - Sri Lanka vs Ireland
2026-01-31 - international - T20 - male - 1519140 - Ireland vs United Arab Emirates
2026-01-29 - international - T20 - male - 1519139 - Ireland vs United Arab Emirates
2026-01-26 - international - T20 - male - 1519138 - Ireland vs Italy
2026-01-25 - international - T20 - male - 1519137 - Ireland vs Italy
2026-01-23 - international - T20 - male - 1519136 - Italy vs Ireland
2025-12-02 - international - T20 - male - 1506016 - Ireland vs Bangladesh
2025-11-29 - international - T20 - male - 1506015 - Ireland vs Bangladesh
2025-11-27 - international - T20 - male - 1506014 - Ireland vs Bangladesh
2025-11-19 - international - Test - male - 1506013 - Bangladesh vs Ireland
2025-11-11 - international - Test - male - 1506012 - Ireland vs Bangladesh
2025-09-21 - international - T20 - male - 1448362 - Ireland vs England
2025-09-17 - international - T20 - male - 1448360 - Ireland vs England
2025-06-15 - international - T20 - male - 1472516 - West Indies vs Ireland
2025-05-25 - international - ODI - male - 1472513 - West Indies vs Ireland
2025-05-23 - international - ODI - male - 1472512 - West Indies vs Ireland
2025-05-21 - international - ODI - male - 1472511 - Ireland vs West Indies
2025-02-25 - international - T20 - male - 1467706 - Zimbabwe vs Ireland
2025-02-23 - international - T20 - male - 1467705 - Ireland vs Zimbabwe
2025-02-22 - international - T20 - male - 1467704 - Zimbabwe vs Ireland
2025-02-18 - international - ODI - male - 1467703 - Ireland vs Zimbabwe
2025-02-16 - international - ODI - male - 1467702 - Zimbabwe vs Ireland
2025-02-14 - international - ODI - male - 1467701 - Zimbabwe vs Ireland
2025-02-06 - international - Test - male - 1467700 - Ireland vs Zimbabwe
2024-10-07 - international - ODI - male - 1431090 - Ireland vs South Africa
2024-10-04 - international - ODI - male - 1431089 - South Africa vs Ireland
2024-10-02 - international - ODI - male - 1431088 - South Africa vs Ireland
2024-09-29 - international - T20 - male - 1431087 - Ireland vs South Africa
2024-09-27 - international - T20 - male - 1431086 - Ireland vs South Africa
2024-07-25 - international - Test - male - 1431085 - Zimbabwe vs Ireland
2024-06-16 - international - T20 - male - 1415736 - Ireland vs Pakistan
2024-06-07 - international - T20 - male - 1415713 - Canada vs Ireland
2024-06-05 - international - T20 - male - 1415708 - Ireland vs India
2024-05-24 - international - T20 - male - 1428156 - Ireland vs Netherlands
2024-05-23 - international - T20 - male - 1428155 - Scotland vs Ireland
2024-05-19 - international - T20 - male - 1428152 - Ireland vs Netherlands
2024-05-14 - international - T20 - male - 1426832 - Ireland vs Pakistan
2024-05-12 - international - T20 - male - 1426831 - Ireland vs Pakistan
2024-05-10 - international - T20 - male - 1426830 - Pakistan vs Ireland
2023-12-17 - international - ODI - male - 1408108 - Zimbabwe vs Ireland
2023-12-15 - international - ODI - male - 1408107 - Zimbabwe vs Ireland
2023-12-13 - international - ODI - male - 1408106 - Zimbabwe vs Ireland
2023-12-10 - international - T20 - male - 1408105 - Zimbabwe vs Ireland
2023-12-09 - international - T20 - male - 1408104 - Zimbabwe vs Ireland
2023-12-07 - international - T20 - male - 1408103 - Ireland vs Zimbabwe
2023-09-26 - international - ODI - male - 1336130 - England vs Ireland
2023-09-23 - international - ODI - male - 1336129 - England vs Ireland
2023-08-20 - international - T20 - male - 1384637 - India vs Ireland
2023-08-18 - international - T20 - male - 1384634 - Ireland vs India
2023-07-28 - international - T20 - male - 1383088 - Scotland vs Ireland
2023-07-24 - international - T20 - male - 1383079 - Jersey vs Ireland
2023-07-23 - international - T20 - male - 1383074 - Ireland vs Austria
2023-07-21 - international - T20 - male - 1383071 - Denmark vs Ireland
2023-07-20 - international - T20 - male - 1383069 - Ireland vs Italy
2023-07-04 - international - ODI - male - 1377774 - Nepal vs Ireland
2023-06-30 - international - ODI - male - 1377768 - United States of America vs Ireland
2023-06-27 - international - ODI - male - 1377765 - Ireland vs United Arab Emirates
2023-06-25 - international - ODI - male - 1377760 - Sri Lanka vs Ireland
2023-06-21 - international - ODI - male - 1377752 - Ireland vs Scotland
2023-06-19 - international - ODI - male - 1377749 - Ireland vs Oman
2023-06-01 - international - Test - male - 1336127 - Ireland vs England
2023-05-14 - international - ODI - male - 1365552 - Bangladesh vs Ireland
2023-05-12 - international - ODI - male - 1364125 - Ireland vs Bangladesh
2023-05-09 - international - ODI - male - 1364124 - Bangladesh vs Ireland
2023-04-24 - international - Test - male - 1363448 - Ireland vs Sri Lanka
2023-04-16 - international - Test - male - 1363447 - Sri Lanka vs Ireland
2023-04-04 - international - Test - male - 1355723 - Ireland vs Bangladesh
2023-03-31 - international - T20 - male - 1355722 - Bangladesh vs Ireland
2023-03-29 - international - T20 - male - 1355721 - Bangladesh vs Ireland
2023-03-27 - international - T20 - male - 1355720 - Bangladesh vs Ireland
2023-03-23 - international - ODI - male - 1355719 - Ireland vs Bangladesh
2023-03-20 - international - ODI - male - 1355718 - Bangladesh vs Ireland
2023-03-18 - international - ODI - male - 1355717 - Bangladesh vs Ireland
2023-01-23 - international - ODI - male - 1348328 - Zimbabwe vs Ireland
2023-01-21 - international - ODI - male - 1348327 - Ireland vs Zimbabwe
2023-01-18 - international - ODI - male - 1348326 - Ireland vs Zimbabwe
2023-01-15 - international - T20 - male - 1348325 - Ireland vs Zimbabwe
2023-01-14 - international - T20 - male - 1348324 - Zimbabwe vs Ireland
2023-01-12 - international - T20 - male - 1348323 - Ireland vs Zimbabwe
2022-11-04 - international - T20 - male - 1298171 - New Zealand vs Ireland
2022-10-31 - international - T20 - male - 1298165 - Australia vs Ireland
2022-10-26 - international - T20 - male - 1298154 - Ireland vs England
2022-10-23 - international - T20 - male - 1298149 - Ireland vs Sri Lanka
2022-10-21 - international - T20 - male - 1298145 - West Indies vs Ireland
2022-10-19 - international - T20 - male - 1298141 - Scotland vs Ireland
2022-10-17 - international - T20 - male - 1298138 - Zimbabwe vs Ireland
2022-08-05 - international - T20 - male - 1303316 - South Africa vs Ireland
2022-08-03 - international - T20 - male - 1303315 - South Africa vs Ireland
2022-07-22 - international - T20 - male - 1303314 - Ireland vs New Zealand
2022-07-20 - international - T20 - male - 1303313 - New Zealand vs Ireland
2022-07-18 - international - T20 - male - 1303312 - New Zealand vs Ireland
2022-07-15 - international - ODI - male - 1303311 - New Zealand vs Ireland
2022-07-12 - international - ODI - male - 1303310 - Ireland vs New Zealand
2022-07-10 - international - ODI - male - 1303309 - Ireland vs New Zealand
2022-06-28 - international - T20 - male - 1303308 - India vs Ireland
2022-06-26 - international - T20 - male - 1303307 - Ireland vs India
2022-02-24 - international - T20 - male - 1299585 - Ireland vs United Arab Emirates
2022-02-22 - international - T20 - male - 1299581 - Ireland vs Oman
2022-02-21 - international - T20 - male - 1299574 - Germany vs Ireland
2022-02-19 - international - T20 - male - 1299573 - Ireland vs Bahrain
2022-02-18 - international - T20 - male - 1299568 - United Arab Emirates vs Ireland
2022-02-14 - international - T20 - male - 1299596 - Ireland vs Nepal
2022-02-13 - international - T20 - male - 1299592 - United Arab Emirates vs Ireland
2022-02-12 - international - T20 - male - 1299594 - Oman vs Ireland
2022-01-16 - international - ODI - male - 1277087 - West Indies vs Ireland
2022-01-13 - international - ODI - male - 1277086 - West Indies vs Ireland
2022-01-08 - international - ODI - male - 1277085 - West Indies vs Ireland
2021-12-23 - international - T20 - male - 1291188 - Ireland vs United States of America
2021-12-22 - international - T20 - male - 1291187 - United States of America vs Ireland
2021-10-22 - international - T20 - male - 1273722 - Ireland vs Namibia
2021-10-20 - international - T20 - male - 1273719 - Sri Lanka vs Ireland
2021-10-18 - international - T20 - male - 1273714 - Netherlands vs Ireland
2021-10-10 - international - T20 - male - 1280062 - Ireland vs United Arab Emirates
2021-10-08 - international - T20 - male - 1280061 - United Arab Emirates vs Ireland
2021-10-07 - international - T20 - male - 1280060 - United Arab Emirates vs Ireland
2021-09-13 - international - ODI - male - 1272381 - Zimbabwe vs Ireland
2021-09-10 - international - ODI - male - 1272380 - Ireland vs Zimbabwe
2021-09-08 - international - ODI - male - 1272379 - Zimbabwe vs Ireland
2021-09-04 - international - T20 - male - 1272377 - Zimbabwe vs Ireland
2021-09-02 - international - T20 - male - 1272376 - Ireland vs Zimbabwe
2021-09-01 - international - T20 - male - 1272375 - Ireland vs Zimbabwe
2021-08-29 - international - T20 - male - 1272374 - Zimbabwe vs Ireland
2021-08-27 - international - T20 - male - 1272373 - Zimbabwe vs Ireland
2021-07-24 - international - T20 - male - 1251955 - South Africa vs Ireland
2021-07-22 - international - T20 - male - 1251954 - South Africa vs Ireland
2021-07-19 - international - T20 - male - 1251953 - South Africa vs Ireland
2021-07-16 - international - ODI - male - 1251952 - South Africa vs Ireland
2021-07-13 - international - ODI - male - 1251951 - Ireland vs South Africa
2021-07-11 - international - ODI - male - 1251950 - Ireland vs South Africa
2021-06-07 - international - ODI - male - 1251964 - Ireland vs Netherlands
2021-06-04 - international - ODI - male - 1251963 - Netherlands vs Ireland
2021-06-02 - international - ODI - male - 1251962 - Netherlands vs Ireland
2021-01-18 - international - ODI - male - 1244525 - Ireland vs United Arab Emirates
2021-01-08 - international - ODI - male - 1244524 - Ireland vs United Arab Emirates
2020-08-04 - international - ODI - male - 1198249 - England vs Ireland
2020-08-01 - international - ODI - male - 1198248 - Ireland vs England
2020-07-30 - international - ODI - male - 1198247 - Ireland vs England
2020-01-19 - international - T20 - male - 1203678 - West Indies vs Ireland
2020-01-18 - international - T20 - male - 1203677 - West Indies vs Ireland
2020-01-15 - international - T20 - male - 1203676 - West Indies vs Ireland
2020-01-12 - international - ODI - male - 1203675 - West Indies vs Ireland
2020-01-09 - international - ODI - male - 1203674 - West Indies vs Ireland
2020-01-07 - international - ODI - male - 1203673 - West Indies vs Ireland
2019-11-02 - international - T20 - male - 1199548 - Ireland vs Namibia
2019-11-01 - international - T20 - male - 1199546 - Ireland vs Netherlands
2019-10-26 - international - T20 - male - 1199533 - Ireland vs Nigeria
2019-10-25 - international - T20 - male - 1199530 - Ireland vs Jersey
2019-10-23 - international - T20 - male - 1199523 - Canada vs Ireland
2019-10-21 - international - T20 - male - 1199514 - Ireland vs Oman
2019-10-19 - international - T20 - male - 1199507 - United Arab Emirates vs Ireland
2019-10-18 - international - T20 - male - 1199500 - Hong Kong vs Ireland
2019-10-09 - international - T20 - male - 1197526 - Ireland vs Nepal
2019-10-07 - international - T20 - male - 1197525 - Hong Kong vs Ireland
2019-10-06 - international - T20 - male - 1197522 - Oman vs Ireland
2019-10-05 - international - T20 - male - 1197521 - Ireland vs Netherlands
2019-09-18 - international - T20 - male - 1200427 - Ireland vs Netherlands
2019-09-17 - international - T20 - male - 1200426 - Ireland vs Scotland
2019-07-24 - international - Test - male - 1152839 - England vs Ireland
2019-07-14 - international - T20 - male - 1168522 - Ireland vs Zimbabwe
2019-07-12 - international - T20 - male - 1168521 - Ireland vs Zimbabwe
2019-07-07 - international - ODI - male - 1168519 - Ireland vs Zimbabwe
2019-07-04 - international - ODI - male - 1168518 - Ireland vs Zimbabwe
2019-07-01 - international - ODI - male - 1168517 - Ireland vs Zimbabwe
2019-05-15 - international - ODI - male - 1168513 - Ireland vs Bangladesh
2019-05-11 - international - ODI - male - 1168511 - Ireland vs West Indies
2019-05-05 - international - ODI - male - 1168508 - Ireland vs West Indies
2019-05-03 - international - ODI - male - 1161014 - Ireland vs England
2019-02-17 - international - T20 - male - 1172509 - Ireland vs Netherlands
2019-02-15 - international - T20 - male - 1172508 - Ireland vs Scotland
2019-02-13 - international - T20 - male - 1172506 - Oman vs Ireland
2018-06-29 - international - T20 - male - 1140993 - India vs Ireland
2018-06-27 - international - T20 - male - 1140992 - India vs Ireland
2018-06-17 - international - T20 - male - 1142504 - Scotland vs Ireland
2018-06-16 - international - T20 - male - 1142503 - Ireland vs Scotland
2018-06-13 - international - T20 - male - 1142502 - Ireland vs Netherlands
2018-06-12 - international - T20 - male - 1142501 - Netherlands vs Ireland
2018-05-11 - international - Test - male - 1127284 - Ireland vs Pakistan
2018-03-18 - international - ODI - male - 1133025 - Ireland vs Scotland
2018-03-16 - international - ODI - male - 1133022 - Zimbabwe vs Ireland
2018-03-12 - international - ODI - male - 1133015 - Ireland vs United Arab Emirates
2018-03-10 - international - ODI - male - 1133010 - West Indies vs Ireland
2018-03-06 - international - ODI - male - 1133002 - Papua New Guinea vs Ireland
2018-03-04 - international - ODM - male - 1132999 - Ireland vs Netherlands
2018-01-18 - international - ODI - male - 1131277 - Ireland vs Scotland
2018-01-16 - international - ODI - male - 1131276 - Scotland vs Ireland
2018-01-13 - international - ODI - male - 1131275 - Ireland vs United Arab Emirates
2018-01-11 - international - ODI - male - 1131274 - United Arab Emirates vs Ireland
2017-11-29 - international - MDM - male - 1125471 - Ireland vs Scotland
2017-08-15 - international - MDM - male - 1105000 - Ireland vs Netherlands
2017-05-21 - international - ODI - male - 1033369 - Ireland vs New Zealand
2017-05-19 - international - ODI - male - 1033367 - Ireland vs Bangladesh
2017-05-14 - international - ODI - male - 1033363 - Ireland vs New Zealand
2017-05-12 - international - ODI - male - 1033361 - Ireland vs Bangladesh
2017-05-07 - international - ODI - male - 1029003 - England vs Ireland
2017-05-05 - international - ODI - male - 1029001 - England vs Ireland
2017-03-04 - international - ODI - male - 1080631 - United Arab Emirates vs Ireland
2017-03-02 - international - ODI - male - 1080630 - United Arab Emirates vs Ireland
2017-01-20 - international - T20 - male - 1074970 - Ireland vs Scotland
2017-01-18 - international - T20 - male - 1074965 - United Arab Emirates vs Ireland
2017-01-17 - international - IT20 - male - 1074963 - Ireland vs Namibia
2016-09-27 - international - ODI - male - 936133 - Australia vs Ireland
2016-09-25 - international - ODI - male - 936131 - South Africa vs Ireland
2016-09-05 - international - T20 - male - 1004729 - Ireland vs Hong Kong
2016-08-18 - international - ODI - male - 913649 - Ireland vs Pakistan
2016-06-18 - international - ODI - male - 913621 - Ireland vs Sri Lanka
2016-03-13 - international - T20 - male - 951325 - Ireland vs Netherlands
2016-03-11 - international - T20 - male - 951319 - Bangladesh vs Ireland
2016-03-09 - international - T20 - male - 951311 - Ireland vs Oman
2016-02-16 - international - T20 - male - 954743 - United Arab Emirates vs Ireland
2016-02-14 - international - T20 - male - 954741 - United Arab Emirates vs Ireland
2016-02-09 - international - T20 - male - 954737 - Ireland vs Papua New Guinea
2016-02-07 - international - T20 - male - 954735 - Ireland vs Papua New Guinea
2016-01-31 - international - MDM - male - 952193 - Papua New Guinea vs Ireland
2015-10-24 - international - MDM - male - 911041 - Namibia vs Ireland
2015-10-13 - international - ODI - male - 919617 - Zimbabwe vs Ireland
2015-10-11 - international - ODI - male - 919615 - Zimbabwe vs Ireland
2015-10-09 - international - ODI - male - 919613 - Zimbabwe vs Ireland
2015-08-27 - international - ODI - male - 743973 - Ireland vs Australia
2015-07-25 - international - T20 - male - 875553 - Ireland vs Netherlands
2015-07-19 - international - IT20 - male - 875535 - Ireland vs Jersey
2015-07-17 - international - T20 - male - 875521 - Ireland vs Hong Kong
2015-07-15 - international - T20 - male - 875501 - Ireland vs Papua New Guinea
2015-07-13 - international - T20 - male - 875491 - Nepal vs Ireland
2015-07-12 - international - IT20 - male - 875477 - Ireland vs United States of America
2015-07-10 - international - IT20 - male - 875461 - Ireland vs Namibia
2015-06-20 - international - T20 - male - 889463 - Ireland vs Scotland
2015-05-08 - international - ODI - male - 760889 - Ireland vs England
2015-03-15 - international - ODI - male - 656481 - Ireland vs Pakistan
2015-03-10 - international - ODI - male - 656465 - India vs Ireland
2015-03-07 - international - ODI - male - 656457 - Ireland vs Zimbabwe
2015-03-03 - international - ODI - male - 656445 - Ireland vs South Africa
2015-02-25 - international - ODI - male - 656429 - Ireland vs United Arab Emirates
2015-02-16 - international - ODI - male - 656407 - Ireland vs West Indies
2015-01-12 - international - ODI - male - 810829 - Ireland vs Scotland
2014-09-12 - international - ODI - male - 727939 - Ireland vs Scotland
2014-09-10 - international - ODI - male - 727937 - Ireland vs Scotland
2014-09-08 - international - ODI - male - 727935 - Ireland vs Scotland
2014-05-06 - international - ODI - male - 706767 - Sri Lanka vs Ireland
2014-03-21 - international - T20 - male - 682919 - Ireland vs Netherlands
2014-03-19 - international - T20 - male - 682911 - Ireland vs United Arab Emirates
2014-03-17 - international - T20 - male - 682901 - Ireland vs Zimbabwe
2014-02-23 - international - ODI - male - 702139 - West Indies vs Ireland
2014-02-21 - international - T20 - male - 702143 - West Indies vs Ireland
2014-02-19 - international - T20 - male - 702141 - West Indies vs Ireland
2013-11-29 - international - IT20 - male - 660231 - United Arab Emirates vs Ireland
2013-11-24 - international - IT20 - male - 660197 - Hong Kong vs Ireland
2013-11-22 - international - IT20 - male - 660177 - Ireland vs Uganda
2013-11-20 - international - IT20 - male - 660153 - Ireland vs United States of America
2013-11-17 - international - IT20 - male - 660127 - Ireland vs United Arab Emirates
2013-11-16 - international - T20 - male - 660113 - Canada vs Ireland
2013-11-15 - international - IT20 - male - 660093 - Ireland vs Namibia
2013-09-11 - international - MDM - male - 516863 - Scotland vs Ireland
2013-09-06 - international - ODI - male - 660837 - Ireland vs Scotland
2013-09-03 - international - ODI - male - 566940 - Ireland vs England
2013-07-07 - international - ODI - male - 631138 - Netherlands vs Ireland
2013-05-26 - international - ODI - male - 601613 - Ireland vs Pakistan
2013-05-23 - international - ODI - male - 601612 - Ireland vs Pakistan
2013-03-20 - international - ODM - male - 592264 - United Arab Emirates vs Ireland
2013-03-18 - international - ODM - male - 592263 - United Arab Emirates vs Ireland
2012-09-24 - international - T20 - male - 533282 - Ireland vs West Indies
2012-09-19 - international - T20 - male - 533273 - Australia vs Ireland
2012-07-18 - international - T20 - male - 567071 - Ireland vs Bangladesh
2012-06-23 - international - ODI - male - 534214 - Ireland vs Australia
2012-03-23 - international - T20 - male - 546470 - Ireland vs Netherlands
2012-03-22 - international - T20 - male - 546462 - Canada vs Ireland
2012-03-18 - international - T20 - male - 546442 - Ireland vs Scotland
2012-03-14 - international - T20 - male - 546414 - Ireland vs Kenya
2012-02-24 - international - T20 - male - 543885 - Kenya vs Ireland
2012-02-23 - international - T20 - male - 543884 - Kenya vs Ireland
2012-02-22 - international - T20 - male - 543883 - Kenya vs Ireland
2012-02-20 - international - ODI - male - 543882 - Kenya vs Ireland
2012-02-18 - international - ODI - male - 543881 - Kenya vs Ireland
2011-09-20 - international - ODI - male - 523805 - Ireland vs Canada
2011-09-19 - international - ODI - male - 523804 - Ireland vs Canada
2011-08-25 - international - ODI - male - 483126 - Ireland vs England
2011-03-18 - international - ODI - male - 433595 - Ireland vs Netherlands
2011-03-15 - international - ODI - male - 433591 - Ireland vs South Africa
2011-03-11 - international - ODI - male - 433584 - Ireland vs West Indies
2011-03-06 - international - ODI - male - 433578 - India vs Ireland
2011-03-02 - international - ODI - male - 433572 - England vs Ireland
2011-02-25 - international - ODI - male - 433566 - Bangladesh vs Ireland
2010-09-06 - international - ODI - male - 464723 - Canada vs Ireland
2010-08-18 - international - ODI - male - 464720 - Ireland vs Netherlands
2010-07-16 - international - ODI - male - 450107 - Ireland vs Bangladesh
2010-07-07 - international - ODI - male - 450379 - Canada vs Ireland
2010-06-17 - international - ODI - male - 426384 - Ireland vs Australia
2010-05-04 - international - T20 - male - 412681 - England vs Ireland
2010-04-30 - international - T20 - male - 412677 - West Indies vs Ireland
2010-02-13 - international - T20 - male - 439510 - Ireland vs Netherlands
2010-02-11 - international - T20 - male - 439505 - Ireland vs Scotland
2009-08-27 - international - ODI - male - 383275 - Ireland vs England
2009-06-15 - international - T20 - male - 356012 - Ireland vs Pakistan
2009-06-14 - international - T20 - male - 356009 - Ireland vs Sri Lanka
2009-06-11 - international - T20 - male - 356003 - Ireland vs New Zealand
2009-06-10 - international - T20 - male - 356001 - India vs Ireland
2009-06-08 - international - T20 - male - 355997 - Bangladesh vs Ireland
2009-04-01 - international - ODI - male - 390204 - Ireland vs Scotland
2008-10-17 - international - ODI - male - 325581 - Ireland vs Zimbabwe
2008-08-25 - international - ODI - male - 325576 - Ireland vs Kenya
2008-08-04 - international - T20 - male - 361530 - Ireland vs Kenya
2008-07-31 - international - ODI - male - 325580 - Ireland vs Scotland
2007-07-14 - international - ODI - male - 295788 - Ireland vs West Indies
2007-06-24 - international - ODI - male - 293072 - Ireland vs South Africa
2007-06-23 - international - ODI - male - 293071 - Ireland vs India
2007-04-18 - international - ODI - male - 247501 - Ireland vs Sri Lanka
2007-04-15 - international - ODI - male - 247498 - Bangladesh vs Ireland
2007-04-13 - international - ODI - male - 247496 - Australia vs Ireland
2007-04-09 - international - ODI - male - 247492 - Ireland vs New Zealand
2007-04-03 - international - ODI - male - 247488 - Ireland vs South Africa
2007-03-30 - international - ODI - male - 247484 - England vs Ireland
2007-03-23 - international - ODI - male - 247477 - West Indies vs Ireland
2007-03-17 - international - ODI - male - 247465 - Ireland vs Pakistan
2007-03-15 - international - ODI - male - 247461 - Ireland vs Zimbabwe
2006-06-13 - international - ODI - male - 225171 - Ireland vs England
