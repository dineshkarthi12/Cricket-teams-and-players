This zip archive contains data files from Cricsheet in JSON format. This
archive contains 5 Himachal Pradesh matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/himachal_pradesh_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2022-11-05 - club - SMA - male - 1333055 - Himachal Pradesh vs Mumbai
2022-11-03 - club - SMA - male - 1333053 - Himachal Pradesh vs Punjab
2022-10-22 - club - SMA - male - 1333041 - Nagaland vs Himachal Pradesh
2022-10-20 - club - SMA - male - 1333024 - Baroda vs Himachal Pradesh
2022-10-18 - club - SMA - male - 1333005 - Himachal Pradesh vs Saurashtra
