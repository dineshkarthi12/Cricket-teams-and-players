This zip archive contains data files from Cricsheet in YAML format. This
archive contains 44 Bengal matches.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/bengal_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2024-12-11 - club - SMA - male - 1446101 - Baroda vs Bengal
2024-12-09 - club - SMA - male - 1446099 - Bengal vs Chandigarh
2023-10-31 - club - SMA - male - 1383561 - Bengal vs Assam
2021-11-18 - club - SMA - male - 1280297 - Karnataka vs Bengal
2021-11-09 - club - SMA - male - 1280279 - Karnataka vs Bengal
2021-11-08 - club - SMA - male - 1280258 - Services vs Bengal
2021-11-06 - club - SMA - male - 1280240 - Mumbai vs Bengal
2021-11-05 - club - SMA - male - 1280221 - Bengal vs Baroda
2021-11-04 - club - SMA - male - 1280201 - Chhattisgarh vs Bengal
2021-01-18 - club - SMA - male - 1244387 - Bengal vs Tamil Nadu
2021-01-16 - club - SMA - male - 1244367 - Assam vs Bengal
2021-01-14 - club - SMA - male - 1244349 - Hyderabad (India) vs Bengal
2021-01-10 - club - SMA - male - 1244309 - Odisha vs Bengal
2019-11-18 - club - SMA - male - 1205729 - Assam vs Bengal
2019-11-17 - club - SMA - male - 1205829 - Bengal vs Puducherry
2019-11-15 - club - SMA - male - 1205811 - Madhya Pradesh vs Bengal
2019-11-14 - club - SMA - male - 1205792 - Bengal vs Mumbai
2019-11-12 - club - SMA - male - 1205782 - Bengal vs Haryana
2019-11-11 - club - SMA - male - 1205756 - Bengal vs Meghalaya
2019-11-09 - club - SMA - male - 1205746 - Mizoram vs Bengal
2019-03-12 - club - SMA - male - 1175043 - Gujarat vs Bengal
2019-03-10 - club - SMA - male - 1175035 - Jharkhand vs Bengal
2019-03-09 - club - SMA - male - 1175029 - Bengal vs Maharashtra
2019-03-08 - club - SMA - male - 1175027 - Railways vs Bengal
2019-03-02 - club - SMA - male - 1157205 - Odisha vs Bengal
2019-02-28 - club - SMA - male - 1157186 - Bengal vs Chhattisgarh
2019-02-27 - club - SMA - male - 1157171 - Bengal vs Arunachal Pradesh
2019-02-25 - club - SMA - male - 1157151 - Assam vs Bengal
2019-02-24 - club - SMA - male - 1157135 - Haryana vs Bengal
2019-02-22 - club - SMA - male - 1157120 - Bengal vs Karnataka
2019-02-21 - club - SMA - male - 1157103 - Bengal vs Mizoram
2018-01-24 - club - SMA - male - 1133416 - Tamil Nadu vs Bengal
2018-01-22 - club - SMA - male - 1133407 - Uttar Pradesh vs Bengal
2018-01-21 - club - SMA - male - 1133404 - Baroda vs Bengal
2018-01-16 - club - SMA - male - 1130697 - Assam vs Bengal
2018-01-14 - club - SMA - male - 1130688 - Tripura vs Bengal
2018-01-12 - club - SMA - male - 1130711 - Jharkhand vs Bengal
2018-01-08 - club - SMA - male - 1130672 - Odisha vs Bengal
2016-01-09 - club - SMA - male - 902209 - Haryana vs Bengal
2016-01-07 - club - SMA - male - 902183 - Bengal vs Vidarbha
2016-01-06 - club - SMA - male - 902161 - Bengal vs Gujarat
2016-01-04 - club - SMA - male - 902139 - Bengal vs Himachal
2016-01-03 - club - SMA - male - 902115 - Tamil Nadu vs Bengal
2016-01-02 - club - SMA - male - 902089 - Bengal vs Hyderabad (India)
