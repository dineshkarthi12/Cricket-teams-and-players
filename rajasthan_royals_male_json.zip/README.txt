This zip archive contains data files from Cricsheet in JSON format. This
archive contains 251 Rajasthan Royals matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/rajasthan_royals_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-05-29 - club - IPL - male - 1535464 - Rajasthan Royals vs Gujarat Titans
2026-05-27 - club - IPL - male - 1535463 - Rajasthan Royals vs Sunrisers Hyderabad
2026-05-24 - club - IPL - male - 1529312 - Rajasthan Royals vs Mumbai Indians
2026-05-19 - club - IPL - male - 1529307 - Lucknow Super Giants vs Rajasthan Royals
2026-05-17 - club - IPL - male - 1529305 - Rajasthan Royals vs Delhi Capitals
2026-05-09 - club - IPL - male - 1529295 - Gujarat Titans vs Rajasthan Royals
2026-05-01 - club - IPL - male - 1529286 - Rajasthan Royals vs Delhi Capitals
2026-04-28 - club - IPL - male - 1529283 - Punjab Kings vs Rajasthan Royals
2026-04-25 - club - IPL - male - 1529279 - Rajasthan Royals vs Sunrisers Hyderabad
2026-04-22 - club - IPL - male - 1529275 - Rajasthan Royals vs Lucknow Super Giants
2026-04-19 - club - IPL - male - 1529271 - Rajasthan Royals vs Kolkata Knight Riders
2026-04-13 - club - IPL - male - 1529264 - Sunrisers Hyderabad vs Rajasthan Royals
2026-04-10 - club - IPL - male - 1527689 - Royal Challengers Bengaluru vs Rajasthan Royals
2026-04-07 - club - IPL - male - 1527686 - Rajasthan Royals vs Mumbai Indians
2026-04-04 - club - IPL - male - 1527682 - Rajasthan Royals vs Gujarat Titans
2026-03-30 - club - IPL - male - 1527676 - Chennai Super Kings vs Rajasthan Royals
2025-05-20 - club - IPL - male - 1473500 - Chennai Super Kings vs Rajasthan Royals
2025-05-18 - club - IPL - male - 1473497 - Punjab Kings vs Rajasthan Royals
2025-05-04 - club - IPL - male - 1473490 - Kolkata Knight Riders vs Rajasthan Royals
2025-05-01 - club - IPL - male - 1473487 - Mumbai Indians vs Rajasthan Royals
2025-04-28 - club - IPL - male - 1473484 - Gujarat Titans vs Rajasthan Royals
2025-04-24 - club - IPL - male - 1473479 - Royal Challengers Bengaluru vs Rajasthan Royals
2025-04-19 - club - IPL - male - 1473473 - Lucknow Super Giants vs Rajasthan Royals
2025-04-16 - club - IPL - male - 1473469 - Delhi Capitals vs Rajasthan Royals
2025-04-13 - club - IPL - male - 1473465 - Rajasthan Royals vs Royal Challengers Bengaluru
2025-04-09 - club - IPL - male - 1473460 - Gujarat Titans vs Rajasthan Royals
2025-04-05 - club - IPL - male - 1473455 - Rajasthan Royals vs Punjab Kings
2025-03-30 - club - IPL - male - 1473448 - Rajasthan Royals vs Chennai Super Kings
2025-03-26 - club - IPL - male - 1473443 - Rajasthan Royals vs Kolkata Knight Riders
2025-03-23 - club - IPL - male - 1473439 - Sunrisers Hyderabad vs Rajasthan Royals
2024-05-24 - club - IPL - male - 1426311 - Sunrisers Hyderabad vs Rajasthan Royals
2024-05-22 - club - IPL - male - 1426310 - Royal Challengers Bengaluru vs Rajasthan Royals
2024-05-15 - club - IPL - male - 1426303 - Rajasthan Royals vs Punjab Kings
2024-05-12 - club - IPL - male - 1426299 - Rajasthan Royals vs Chennai Super Kings
2024-05-07 - club - IPL - male - 1426294 - Delhi Capitals vs Rajasthan Royals
2024-05-02 - club - IPL - male - 1426288 - Sunrisers Hyderabad vs Rajasthan Royals
2024-04-27 - club - IPL - male - 1426282 - Lucknow Super Giants vs Rajasthan Royals
2024-04-22 - club - IPL - male - 1426276 - Mumbai Indians vs Rajasthan Royals
2024-04-16 - club - IPL - male - 1426269 - Kolkata Knight Riders vs Rajasthan Royals
2024-04-13 - club - IPL - male - 1426265 - Punjab Kings vs Rajasthan Royals
2024-04-10 - club - IPL - male - 1426262 - Rajasthan Royals vs Gujarat Titans
2024-04-06 - club - IPL - male - 1422137 - Royal Challengers Bengaluru vs Rajasthan Royals
2024-04-01 - club - IPL - male - 1422132 - Mumbai Indians vs Rajasthan Royals
2024-03-28 - club - IPL - male - 1422127 - Rajasthan Royals vs Delhi Capitals
2024-03-24 - club - IPL - male - 1422122 - Rajasthan Royals vs Lucknow Super Giants
2023-05-19 - club - IPL - male - 1359540 - Punjab Kings vs Rajasthan Royals
2023-05-14 - club - IPL - male - 1359534 - Royal Challengers Bangalore vs Rajasthan Royals
2023-05-11 - club - IPL - male - 1359530 - Kolkata Knight Riders vs Rajasthan Royals
2023-05-07 - club - IPL - male - 1359526 - Rajasthan Royals vs Sunrisers Hyderabad
2023-05-05 - club - IPL - male - 1359522 - Rajasthan Royals vs Gujarat Titans
2023-04-30 - club - IPL - male - 1359516 - Rajasthan Royals vs Mumbai Indians
2023-04-27 - club - IPL - male - 1359511 - Rajasthan Royals vs Chennai Super Kings
2023-04-23 - club - IPL - male - 1359506 - Royal Challengers Bangalore vs Rajasthan Royals
2023-04-19 - club - IPL - male - 1359500 - Lucknow Super Giants vs Rajasthan Royals
2023-04-16 - club - IPL - male - 1359497 - Gujarat Titans vs Rajasthan Royals
2023-04-12 - club - IPL - male - 1359491 - Rajasthan Royals vs Chennai Super Kings
2023-04-08 - club - IPL - male - 1359485 - Rajasthan Royals vs Delhi Capitals
2023-04-05 - club - IPL - male - 1359482 - Punjab Kings vs Rajasthan Royals
2023-04-02 - club - IPL - male - 1359478 - Rajasthan Royals vs Sunrisers Hyderabad
2022-05-29 - club - IPL - male - 1312200 - Rajasthan Royals vs Gujarat Titans
2022-05-27 - club - IPL - male - 1312199 - Royal Challengers Bangalore vs Rajasthan Royals
2022-05-24 - club - IPL - male - 1312197 - Rajasthan Royals vs Gujarat Titans
2022-05-20 - club - IPL - male - 1304114 - Chennai Super Kings vs Rajasthan Royals
2022-05-15 - club - IPL - male - 1304109 - Rajasthan Royals vs Lucknow Super Giants
2022-05-11 - club - IPL - male - 1304104 - Rajasthan Royals vs Delhi Capitals
2022-05-07 - club - IPL - male - 1304098 - Punjab Kings vs Rajasthan Royals
2022-05-02 - club - IPL - male - 1304093 - Rajasthan Royals vs Kolkata Knight Riders
2022-04-30 - club - IPL - male - 1304090 - Rajasthan Royals vs Mumbai Indians
2022-04-26 - club - IPL - male - 1304085 - Rajasthan Royals vs Royal Challengers Bangalore
2022-04-22 - club - IPL - male - 1304080 - Rajasthan Royals vs Delhi Capitals
2022-04-18 - club - IPL - male - 1304076 - Rajasthan Royals vs Kolkata Knight Riders
2022-04-14 - club - IPL - male - 1304070 - Gujarat Titans vs Rajasthan Royals
2022-04-10 - club - IPL - male - 1304066 - Rajasthan Royals vs Lucknow Super Giants
2022-04-05 - club - IPL - male - 1304059 - Rajasthan Royals vs Royal Challengers Bangalore
2022-04-02 - club - IPL - male - 1304055 - Rajasthan Royals vs Mumbai Indians
2022-03-29 - club - IPL - male - 1304051 - Rajasthan Royals vs Sunrisers Hyderabad
2021-10-07 - club - IPL - male - 1254106 - Kolkata Knight Riders vs Rajasthan Royals
2021-10-05 - club - IPL - male - 1254093 - Rajasthan Royals vs Mumbai Indians
2021-10-02 - club - IPL - male - 1254089 - Chennai Super Kings vs Rajasthan Royals
2021-09-29 - club - IPL - male - 1254103 - Rajasthan Royals vs Royal Challengers Bangalore
2021-09-27 - club - IPL - male - 1254100 - Rajasthan Royals vs Sunrisers Hyderabad
2021-09-25 - club - IPL - male - 1254097 - Delhi Capitals vs Rajasthan Royals
2021-09-21 - club - IPL - male - 1254111 - Rajasthan Royals vs Punjab Kings
2021-05-02 - club - IPL - male - 1254085 - Rajasthan Royals vs Sunrisers Hyderabad
2021-04-29 - club - IPL - male - 1254081 - Rajasthan Royals vs Mumbai Indians
2021-04-24 - club - IPL - male - 1254075 - Kolkata Knight Riders vs Rajasthan Royals
2021-04-22 - club - IPL - male - 1254073 - Rajasthan Royals vs Royal Challengers Bangalore
2021-04-19 - club - IPL - male - 1254069 - Chennai Super Kings vs Rajasthan Royals
2021-04-15 - club - IPL - male - 1254064 - Delhi Capitals vs Rajasthan Royals
2021-04-12 - club - IPL - male - 1254061 - Punjab Kings vs Rajasthan Royals
2020-11-01 - club - IPL - male - 1216530 - Kolkata Knight Riders vs Rajasthan Royals
2020-10-30 - club - IPL - male - 1216537 - Kings XI Punjab vs Rajasthan Royals
2020-10-25 - club - IPL - male - 1216541 - Mumbai Indians vs Rajasthan Royals
2020-10-22 - club - IPL - male - 1216518 - Rajasthan Royals vs Sunrisers Hyderabad
2020-10-19 - club - IPL - male - 1216533 - Chennai Super Kings vs Rajasthan Royals
2020-10-17 - club - IPL - male - 1216522 - Rajasthan Royals vs Royal Challengers Bangalore
2020-10-14 - club - IPL - male - 1216543 - Delhi Capitals vs Rajasthan Royals
2020-10-11 - club - IPL - male - 1216507 - Sunrisers Hyderabad vs Rajasthan Royals
2020-10-09 - club - IPL - male - 1216500 - Delhi Capitals vs Rajasthan Royals
2020-10-06 - club - IPL - male - 1216511 - Mumbai Indians vs Rajasthan Royals
2020-10-03 - club - IPL - male - 1216514 - Rajasthan Royals vs Royal Challengers Bangalore
2020-09-30 - club - IPL - male - 1216504 - Kolkata Knight Riders vs Rajasthan Royals
2020-09-27 - club - IPL - male - 1216527 - Kings XI Punjab vs Rajasthan Royals
2020-09-22 - club - IPL - male - 1216496 - Rajasthan Royals vs Chennai Super Kings
2019-05-04 - club - IPL - male - 1178428 - Delhi Capitals vs Rajasthan Royals
2019-04-30 - club - IPL - male - 1178424 - Royal Challengers Bangalore vs Rajasthan Royals
2019-04-27 - club - IPL - male - 1178420 - Rajasthan Royals vs Sunrisers Hyderabad
2019-04-25 - club - IPL - male - 1178418 - Kolkata Knight Riders vs Rajasthan Royals
2019-04-22 - club - IPL - male - 1178415 - Rajasthan Royals vs Delhi Capitals
2019-04-20 - club - IPL - male - 1178411 - Rajasthan Royals vs Mumbai Indians
2019-04-16 - club - IPL - male - 1178407 - Kings XI Punjab vs Rajasthan Royals
2019-04-13 - club - IPL - male - 1178402 - Mumbai Indians vs Rajasthan Royals
2019-04-11 - club - IPL - male - 1178400 - Rajasthan Royals vs Chennai Super Kings
2019-04-07 - club - IPL - male - 1178396 - Rajasthan Royals vs Kolkata Knight Riders
2019-04-02 - club - IPL - male - 1175369 - Rajasthan Royals vs Royal Challengers Bangalore
2019-03-31 - club - IPL - male - 1175367 - Chennai Super Kings vs Rajasthan Royals
2019-03-29 - club - IPL - male - 1175363 - Sunrisers Hyderabad vs Rajasthan Royals
2019-03-25 - club - IPL - male - 1175359 - Rajasthan Royals vs Kings XI Punjab
2018-05-23 - club - IPL - male - 1136618 - Kolkata Knight Riders vs Rajasthan Royals
2018-05-19 - club - IPL - male - 1136613 - Rajasthan Royals vs Royal Challengers Bangalore
2018-05-15 - club - IPL - male - 1136609 - Kolkata Knight Riders vs Rajasthan Royals
2018-05-13 - club - IPL - male - 1136607 - Mumbai Indians vs Rajasthan Royals
2018-05-11 - club - IPL - male - 1136603 - Rajasthan Royals vs Chennai Super Kings
2018-05-08 - club - IPL - male - 1136600 - Rajasthan Royals vs Kings XI Punjab
2018-05-06 - club - IPL - male - 1136598 - Kings XI Punjab vs Rajasthan Royals
2018-05-02 - club - IPL - male - 1136592 - Delhi Daredevils vs Rajasthan Royals
2018-04-29 - club - IPL - male - 1136588 - Rajasthan Royals vs Sunrisers Hyderabad
2018-04-22 - club - IPL - male - 1136581 - Rajasthan Royals vs Mumbai Indians
2018-04-20 - club - IPL - male - 1136577 - Chennai Super Kings vs Rajasthan Royals
2018-04-18 - club - IPL - male - 1136575 - Rajasthan Royals vs Kolkata Knight Riders
2018-04-15 - club - IPL - male - 1136571 - Royal Challengers Bangalore vs Rajasthan Royals
2018-04-11 - club - IPL - male - 1136566 - Rajasthan Royals vs Delhi Daredevils
2018-04-09 - club - IPL - male - 1136564 - Sunrisers Hyderabad vs Rajasthan Royals
2015-05-20 - club - IPL - male - 829819 - Royal Challengers Bangalore vs Rajasthan Royals
2015-05-16 - club - IPL - male - 829811 - Rajasthan Royals vs Kolkata Knight Riders
2015-05-10 - club - IPL - male - 829797 - Chennai Super Kings vs Rajasthan Royals
2015-05-07 - club - IPL - male - 829787 - Rajasthan Royals vs Sunrisers Hyderabad
2015-05-03 - club - IPL - male - 829777 - Rajasthan Royals vs Delhi Daredevils
2015-05-01 - club - IPL - male - 829769 - Mumbai Indians vs Rajasthan Royals
2015-04-29 - club - IPL - male - 829763 - Royal Challengers Bangalore vs Rajasthan Royals
2015-04-24 - club - IPL - male - 829749 - Rajasthan Royals vs Royal Challengers Bangalore
2015-04-21 - club - IPL - male - 829741 - Rajasthan Royals vs Kings XI Punjab
2015-04-19 - club - IPL - male - 829735 - Rajasthan Royals vs Chennai Super Kings
2015-04-16 - club - IPL - male - 829727 - Sunrisers Hyderabad vs Rajasthan Royals
2015-04-14 - club - IPL - male - 829721 - Rajasthan Royals vs Mumbai Indians
2015-04-12 - club - IPL - male - 829715 - Delhi Daredevils vs Rajasthan Royals
2015-04-10 - club - IPL - male - 829709 - Kings XI Punjab vs Rajasthan Royals
2014-05-25 - club - IPL - male - 734041 - Mumbai Indians vs Rajasthan Royals
2014-05-23 - club - IPL - male - 734033 - Kings XI Punjab vs Rajasthan Royals
2014-05-19 - club - IPL - male - 734017 - Rajasthan Royals vs Mumbai Indians
2014-05-15 - club - IPL - male - 734011 - Rajasthan Royals vs Delhi Daredevils
2014-05-13 - club - IPL - male - 734003 - Chennai Super Kings vs Rajasthan Royals
2014-05-11 - club - IPL - male - 733999 - Royal Challengers Bangalore vs Rajasthan Royals
2014-05-08 - club - IPL - male - 733989 - Rajasthan Royals vs Sunrisers Hyderabad
2014-05-05 - club - IPL - male - 733979 - Rajasthan Royals vs Kolkata Knight Riders
2014-05-03 - club - IPL - male - 733975 - Delhi Daredevils vs Rajasthan Royals
2014-04-29 - club - IPL - male - 729315 - Kolkata Knight Riders vs Rajasthan Royals
2014-04-26 - club - IPL - male - 729305 - Rajasthan Royals vs Royal Challengers Bangalore
2014-04-23 - club - IPL - male - 729297 - Rajasthan Royals vs Chennai Super Kings
2014-04-20 - club - IPL - male - 729291 - Rajasthan Royals vs Kings XI Punjab
2014-04-18 - club - IPL - male - 729285 - Sunrisers Hyderabad vs Rajasthan Royals
2013-05-24 - club - IPL - male - 598072 - Mumbai Indians vs Rajasthan Royals
2013-05-22 - club - IPL - male - 598071 - Rajasthan Royals vs Sunrisers Hyderabad
2013-05-17 - club - IPL - male - 598065 - Sunrisers Hyderabad vs Rajasthan Royals
2013-05-15 - club - IPL - male - 598063 - Mumbai Indians vs Rajasthan Royals
2013-05-12 - club - IPL - male - 598058 - Rajasthan Royals vs Chennai Super Kings
2013-05-09 - club - IPL - male - 598052 - Kings XI Punjab vs Rajasthan Royals
2013-05-07 - club - IPL - male - 598049 - Rajasthan Royals vs Delhi Daredevils
2013-05-05 - club - IPL - male - 598047 - Rajasthan Royals vs Pune Warriors
2013-05-03 - club - IPL - male - 598043 - Kolkata Knight Riders vs Rajasthan Royals
2013-04-29 - club - IPL - male - 598036 - Rajasthan Royals vs Royal Challengers Bangalore
2013-04-27 - club - IPL - male - 598032 - Rajasthan Royals vs Sunrisers Hyderabad
2013-04-22 - club - IPL - male - 598026 - Chennai Super Kings vs Rajasthan Royals
2013-04-20 - club - IPL - male - 598023 - Royal Challengers Bangalore vs Rajasthan Royals
2013-04-17 - club - IPL - male - 598019 - Rajasthan Royals vs Mumbai Indians
2013-04-14 - club - IPL - male - 598014 - Rajasthan Royals vs Kings XI Punjab
2013-04-11 - club - IPL - male - 598009 - Pune Warriors vs Rajasthan Royals
2013-04-08 - club - IPL - male - 598005 - Rajasthan Royals vs Kolkata Knight Riders
2013-04-06 - club - IPL - male - 598001 - Delhi Daredevils vs Rajasthan Royals
2012-05-20 - club - IPL - male - 548377 - Rajasthan Royals vs Mumbai Indians
2012-05-18 - club - IPL - male - 548373 - Deccan Chargers vs Rajasthan Royals
2012-05-13 - club - IPL - male - 548365 - Rajasthan Royals vs Pune Warriors
2012-05-10 - club - IPL - male - 548361 - Rajasthan Royals vs Chennai Super Kings
2012-05-08 - club - IPL - male - 548358 - Pune Warriors vs Rajasthan Royals
2012-05-05 - club - IPL - male - 548354 - Kings XI Punjab vs Rajasthan Royals
2012-05-01 - club - IPL - male - 548349 - Rajasthan Royals vs Delhi Daredevils
2012-04-29 - club - IPL - male - 548345 - Delhi Daredevils vs Rajasthan Royals
2012-04-23 - club - IPL - male - 548336 - Rajasthan Royals vs Royal Challengers Bangalore
2012-04-21 - club - IPL - male - 548332 - Chennai Super Kings vs Rajasthan Royals
2012-04-17 - club - IPL - male - 548326 - Rajasthan Royals vs Deccan Chargers
2012-04-15 - club - IPL - male - 548324 - Royal Challengers Bangalore vs Rajasthan Royals
2012-04-13 - club - IPL - male - 548320 - Kolkata Knight Riders vs Rajasthan Royals
2012-04-11 - club - IPL - male - 548317 - Mumbai Indians vs Rajasthan Royals
2012-04-08 - club - IPL - male - 548312 - Rajasthan Royals vs Kolkata Knight Riders
2012-04-06 - club - IPL - male - 548309 - Rajasthan Royals vs Kings XI Punjab
2011-05-20 - club - IPL - male - 501263 - Mumbai Indians vs Rajasthan Royals
2011-05-15 - club - IPL - male - 501258 - Kochi Tuskers Kerala vs Rajasthan Royals
2011-05-11 - club - IPL - male - 501252 - Rajasthan Royals vs Royal Challengers Bangalore
2011-05-09 - club - IPL - male - 501249 - Rajasthan Royals vs Chennai Super Kings
2011-05-04 - club - IPL - male - 501240 - Chennai Super Kings vs Rajasthan Royals
2011-05-01 - club - IPL - male - 501235 - Rajasthan Royals vs Pune Warriors
2011-04-29 - club - IPL - male - 501231 - Rajasthan Royals vs Mumbai Indians
2011-04-24 - club - IPL - male - 501225 - Rajasthan Royals vs Kochi Tuskers Kerala
2011-04-21 - club - IPL - male - 501220 - Kings XI Punjab vs Rajasthan Royals
2011-04-17 - club - IPL - male - 501214 - Kolkata Knight Riders vs Rajasthan Royals
2011-04-15 - club - IPL - male - 501209 - Rajasthan Royals vs Kolkata Knight Riders
2011-04-12 - club - IPL - male - 501204 - Rajasthan Royals vs Delhi Daredevils
2011-04-09 - club - IPL - male - 501199 - Deccan Chargers vs Rajasthan Royals
2010-04-17 - club - IPL - male - 419158 - Kolkata Knight Riders vs Rajasthan Royals
2010-04-14 - club - IPL - male - 419154 - Rajasthan Royals vs Royal Challengers Bangalore
2010-04-11 - club - IPL - male - 419150 - Rajasthan Royals vs Mumbai Indians
2010-04-07 - club - IPL - male - 419143 - Rajasthan Royals vs Kings XI Punjab
2010-04-05 - club - IPL - male - 419141 - Deccan Chargers vs Rajasthan Royals
2010-04-03 - club - IPL - male - 419137 - Chennai Super Kings vs Rajasthan Royals
2010-03-31 - club - IPL - male - 419134 - Delhi Daredevils vs Rajasthan Royals
2010-03-28 - club - IPL - male - 419129 - Rajasthan Royals vs Chennai Super Kings
2010-03-26 - club - IPL - male - 419126 - Rajasthan Royals vs Deccan Chargers
2010-03-24 - club - IPL - male - 419124 - Kings XI Punjab vs Rajasthan Royals
2010-03-20 - club - IPL - male - 419118 - Rajasthan Royals vs Kolkata Knight Riders
2010-03-18 - club - IPL - male - 419115 - Royal Challengers Bangalore vs Rajasthan Royals
2010-03-15 - club - IPL - male - 419111 - Rajasthan Royals vs Delhi Daredevils
2010-03-13 - club - IPL - male - 419107 - Mumbai Indians vs Rajasthan Royals
2009-05-20 - club - IPL - male - 392233 - Kolkata Knight Riders vs Rajasthan Royals
2009-05-17 - club - IPL - male - 392230 - Delhi Daredevils vs Rajasthan Royals
2009-05-14 - club - IPL - male - 392225 - Mumbai Indians vs Rajasthan Royals
2009-05-11 - club - IPL - male - 392220 - Deccan Chargers vs Rajasthan Royals
2009-05-09 - club - IPL - male - 392217 - Chennai Super Kings vs Rajasthan Royals
2009-05-07 - club - IPL - male - 392213 - Royal Challengers Bangalore vs Rajasthan Royals
2009-05-05 - club - IPL - male - 392210 - Kings XI Punjab vs Rajasthan Royals
2009-05-02 - club - IPL - male - 392205 - Deccan Chargers vs Rajasthan Royals
2009-04-30 - club - IPL - male - 392202 - Chennai Super Kings vs Rajasthan Royals
2009-04-28 - club - IPL - male - 392198 - Delhi Daredevils vs Rajasthan Royals
2009-04-26 - club - IPL - male - 392195 - Kings XI Punjab vs Rajasthan Royals
2009-04-23 - club - IPL - male - 392190 - Kolkata Knight Riders vs Rajasthan Royals
2009-04-18 - club - IPL - male - 392182 - Royal Challengers Bangalore vs Rajasthan Royals
2008-06-01 - club - IPL - male - 336040 - Chennai Super Kings vs Rajasthan Royals
2008-05-30 - club - IPL - male - 336038 - Delhi Daredevils vs Rajasthan Royals
2008-05-28 - club - IPL - male - 336019 - Kings XI Punjab vs Rajasthan Royals
2008-05-26 - club - IPL - male - 336036 - Rajasthan Royals vs Mumbai Indians
2008-05-24 - club - IPL - male - 336033 - Chennai Super Kings vs Rajasthan Royals
2008-05-20 - club - IPL - male - 336027 - Kolkata Knight Riders vs Rajasthan Royals
2008-05-17 - club - IPL - male - 336023 - Rajasthan Royals vs Royal Challengers Bangalore
2008-05-11 - club - IPL - male - 336015 - Rajasthan Royals vs Delhi Daredevils
2008-05-09 - club - IPL - male - 336011 - Rajasthan Royals vs Deccan Chargers
2008-05-07 - club - IPL - male - 336008 - Mumbai Indians vs Rajasthan Royals
2008-05-04 - club - IPL - male - 336005 - Rajasthan Royals vs Chennai Super Kings
2008-05-01 - club - IPL - male - 336000 - Rajasthan Royals vs Kolkata Knight Riders
2008-04-26 - club - IPL - male - 335992 - Royal Challengers Bangalore vs Rajasthan Royals
2008-04-24 - club - IPL - male - 335990 - Deccan Chargers vs Rajasthan Royals
2008-04-21 - club - IPL - male - 335987 - Rajasthan Royals vs Kings XI Punjab
2008-04-19 - club - IPL - male - 335984 - Delhi Daredevils vs Rajasthan Royals
