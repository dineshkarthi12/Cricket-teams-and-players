This zip archive contains data files from Cricsheet in JSON format. This
archive contains 21 Sikkim matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/sikkim_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2021-11-09 - club - SMA - male - 1280291 - Vidarbha vs Sikkim
2021-11-08 - club - SMA - male - 1280270 - Mizoram vs Sikkim
2021-11-05 - club - SMA - male - 1280232 - Sikkim vs Meghalaya
2021-11-04 - club - SMA - male - 1280214 - Tripura vs Sikkim
2021-01-19 - club - SMA - male - 1244398 - Sikkim vs Meghalaya
2021-01-17 - club - SMA - male - 1244380 - Chandigarh vs Sikkim
2021-01-15 - club - SMA - male - 1244361 - Nagaland vs Sikkim
2021-01-13 - club - SMA - male - 1244342 - Sikkim vs Bihar
2021-01-11 - club - SMA - male - 1244324 - Mizoram vs Sikkim
2019-11-17 - club - SMA - male - 1205830 - Sikkim vs Delhi
2019-11-15 - club - SMA - male - 1205821 - Sikkim vs Saurashtra
2019-11-14 - club - SMA - male - 1205795 - Sikkim vs Gujarat
2019-11-12 - club - SMA - male - 1205785 - Sikkim vs Jharkhand
2019-11-11 - club - SMA - male - 1205767 - Sikkim vs Odisha
2019-11-09 - club - SMA - male - 1205749 - Sikkim vs Nagaland
2019-03-02 - club - SMA - male - 1157199 - Madhya Pradesh vs Sikkim
2019-02-28 - club - SMA - male - 1157183 - Sikkim vs Railways
2019-02-27 - club - SMA - male - 1157166 - Sikkim vs Punjab
2019-02-25 - club - SMA - male - 1157150 - Sikkim vs Saurashtra
2019-02-22 - club - SMA - male - 1157116 - Sikkim vs Goa
2019-02-21 - club - SMA - male - 1157099 - Mumbai vs Sikkim
