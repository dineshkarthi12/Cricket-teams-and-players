This zip archive contains data files from Cricsheet in JSON format. This
archive contains 53 Punjab matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/punjab_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-11-06 - club - SMA - male - 1383568 - Punjab vs Baroda
2023-11-04 - club - SMA - male - 1383566 - Delhi vs Punjab
2023-11-02 - club - SMA - male - 1383562 - Uttar Pradesh vs Punjab
2023-10-21 - club - SMA - male - 1383496 - Manipur vs Punjab
2023-10-19 - club - SMA - male - 1383478 - Punjab vs Railways
2023-10-17 - club - SMA - male - 1383460 - Punjab vs Andhra
2023-10-16 - club - SMA - male - 1383442 - Saurashtra vs Punjab
2022-11-03 - club - SMA - male - 1333053 - Himachal Pradesh vs Punjab
2022-11-01 - club - SMA - male - 1333049 - Punjab vs Karnataka
2022-10-30 - club - SMA - male - 1333046 - Punjab vs Haryana
2022-10-22 - club - SMA - male - 1333029 - Uttar Pradesh vs Punjab
2022-10-18 - club - SMA - male - 1332993 - Manipur vs Punjab
2022-10-12 - club - SMA - male - 1332939 - Delhi vs Punjab
2022-10-11 - club - SMA - male - 1332920 - Punjab vs Hyderabad (India)
2021-11-09 - club - SMA - male - 1280276 - Punjab vs Tamil Nadu
2021-11-06 - club - SMA - male - 1280236 - Punjab vs Goa
2021-11-05 - club - SMA - male - 1280217 - Punjab vs Maharashtra
2021-01-29 - club - SMA - male - 1244406 - Baroda vs Punjab
2021-01-26 - club - SMA - male - 1244401 - Karnataka vs Punjab
2021-01-18 - club - SMA - male - 1244383 - Punjab vs Tripura
2021-01-16 - club - SMA - male - 1244365 - Jammu & Kashmir vs Punjab
2021-01-14 - club - SMA - male - 1244344 - Punjab vs Railways
2021-01-12 - club - SMA - male - 1244325 - Karnataka vs Punjab
2021-01-10 - club - SMA - male - 1244307 - Punjab vs Uttar Pradesh
2019-11-27 - club - SMA - male - 1205859 - Mumbai vs Punjab
2019-11-25 - club - SMA - male - 1205855 - Punjab vs Tamil Nadu
2019-11-24 - club - SMA - male - 1205850 - Punjab vs Karnataka
2019-11-18 - club - SMA - male - 1205827 - Maharashtra vs Punjab
2019-11-15 - club - SMA - male - 1205809 - Punjab vs Chhattisgarh
2019-11-14 - club - SMA - male - 1205791 - Railways vs Punjab
2019-11-12 - club - SMA - male - 1205780 - Himachal vs Punjab
2019-11-11 - club - SMA - male - 1205763 - Chandigarh vs Punjab
2019-11-09 - club - SMA - male - 1205736 - Arunachal Pradesh vs Punjab
2019-11-08 - club - SMA - male - 1205719 - Hyderabad (India) vs Punjab
2019-03-02 - club - SMA - male - 1157200 - Railways vs Punjab
2019-02-28 - club - SMA - male - 1157182 - Punjab vs Goa
2019-02-27 - club - SMA - male - 1157166 - Sikkim vs Punjab
2019-02-24 - club - SMA - male - 1157132 - Punjab vs Saurashtra
2019-02-22 - club - SMA - male - 1157115 - Mumbai vs Punjab
2018-01-25 - club - SMA - male - 1133417 - Punjab vs Rajasthan
2018-01-22 - club - SMA - male - 1133406 - Mumbai vs Punjab
2018-01-21 - club - SMA - male - 1133401 - Karnataka vs Punjab
2018-01-15 - club - SMA - male - 1130720 - Punjab vs Himachal
2018-01-14 - club - SMA - male - 1130713 - Jammu & Kashmir vs Punjab
2018-01-12 - club - SMA - male - 1130699 - Punjab vs Haryana
2018-01-10 - club - SMA - male - 1130686 - Services vs Punjab
2018-01-09 - club - SMA - male - 1130675 - Punjab vs Delhi
2016-01-10 - club - SMA - male - 902231 - Saurashtra vs Punjab
2016-01-09 - club - SMA - male - 902213 - Punjab vs Kerala
2016-01-07 - club - SMA - male - 902191 - Tripura vs Punjab
2016-01-06 - club - SMA - male - 902167 - Jharkhand vs Punjab
2016-01-03 - club - SMA - male - 902117 - Jammu & Kashmir vs Punjab
2016-01-02 - club - SMA - male - 902093 - Punjab vs Rajasthan
