This zip archive contains data files from Cricsheet in JSON format. This
archive contains 96 Lions matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/lions_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2024-10-27 - club - CTC - male - 1444796 - Titans vs Lions
2024-10-22 - club - CTC - male - 1444793 - Titans vs Lions
2024-10-19 - club - CTC - male - 1444792 - Lions vs North West
2024-10-16 - club - CTC - male - 1444787 - Lions vs Western Province
2024-10-12 - club - CTC - male - 1444781 - Boland vs Lions
2024-10-09 - club - CTC - male - 1444779 - Lions vs Knights
2024-10-06 - club - CTC - male - 1444774 - Lions vs Dolphins
2024-09-27 - club - CTC - male - 1444765 - Titans vs Lions
2024-03-08 - club - CTC - male - 1394573 - Lions vs Boland
2022-10-31 - club - CTC - male - 1334916 - Lions vs Western Province
2022-10-26 - club - CTC - male - 1334907 - Lions vs Dolphins
2022-10-23 - club - CTC - male - 1334903 - Knights vs Lions
2022-10-21 - club - CTC - male - 1334900 - Warriors vs Lions
2022-10-19 - club - CTC - male - 1334895 - Titans vs Lions
2022-10-17 - club - CTC - male - 1334892 - Lions vs North West
2022-02-20 - club - CTC - male - 1299625 - Knights vs Lions
2022-02-19 - club - CTC - male - 1299623 - Lions vs Warriors
2022-02-17 - club - CTC - male - 1299618 - Lions vs Titans
2022-02-15 - club - CTC - male - 1299616 - Boland vs Lions
2022-02-13 - club - CTC - male - 1299612 - Lions vs Western Province
2022-02-10 - club - CTC - male - 1299609 - Lions vs Dolphins
2022-02-08 - club - CTC - male - 1299604 - North West vs Lions
2021-02-28 - club - CTC - male - 1250547 - Dolphins vs Lions
2021-02-27 - club - CTC - male - 1250546 - Warriors vs Lions
2021-02-26 - club - CTC - male - 1235386 - Cape Cobras vs Lions
2021-02-24 - club - CTC - male - 1235375 - Dolphins vs Lions
2021-02-23 - club - CTC - male - 1235378 - Knights vs Lions
2021-02-22 - club - CTC - male - 1235384 - Lions vs Titans
2019-05-05 - club - CTC - male - 1157256 - Lions vs Warriors
2019-05-01 - club - CTC - male - 1157254 - Dolphins vs Lions
2019-04-28 - club - CTC - male - 1157253 - Titans vs Lions
2019-04-26 - club - CTC - male - 1157248 - Cape Cobras vs Lions
2019-04-24 - club - CTC - male - 1157247 - Lions vs Warriors
2019-04-18 - club - CTC - male - 1157238 - Lions vs Titans
2019-04-14 - club - CTC - male - 1157234 - Warriors vs Lions
2019-04-12 - club - CTC - male - 1157231 - Lions vs Knights
2019-04-10 - club - CTC - male - 1157227 - Lions vs Dolphins
2019-04-07 - club - CTC - male - 1157226 - Cape Cobras vs Lions
2017-12-10 - club - CTC - male - 1124687 - Lions vs Knights
2017-12-08 - club - CTC - male - 1124684 - Warriors vs Lions
2017-12-01 - club - CTC - male - 1124676 - Knights vs Lions
2017-11-26 - club - CTC - male - 1124671 - Lions vs Warriors
2017-11-24 - club - CTC - male - 1124668 - Cape Cobras vs Lions
2017-11-19 - club - CTC - male - 1124665 - Dolphins vs Lions
2017-11-17 - club - CTC - male - 1124664 - Cape Cobras vs Lions
2016-12-13 - club - CTC - male - 1003903 - Lions vs Warriors
2016-12-09 - club - CTC - male - 1003895 - Lions vs Knights
2016-12-07 - club - CTC - male - 1003891 - Titans vs Lions
2016-12-04 - club - CTC - male - 1003883 - Lions vs Warriors
2016-12-02 - club - CTC - male - 1003879 - Lions vs Knights
2016-11-27 - club - CTC - male - 1003873 - Lions vs Dolphins
2016-11-25 - club - CTC - male - 1003865 - Lions vs Warriors
2016-11-20 - club - CTC - male - 1003861 - Lions vs Cape Cobras
2016-11-12 - club - CTC - male - 1003845 - Titans vs Lions
2015-12-04 - club - CTC - male - 851983 - Titans vs Lions
2015-11-29 - club - CTC - male - 851975 - Lions vs Cape Cobras
2015-11-25 - club - CTC - male - 851969 - Knights vs Lions
2015-11-15 - club - CTC - male - 851957 - Lions vs Knights
2015-11-13 - club - CTC - male - 851949 - Warriors vs Lions
2014-12-07 - club - CTC - male - 736315 - Lions vs Knights
2014-12-03 - club - CTC - male - 736313 - Knights vs Lions
2014-11-30 - club - CTC - male - 736305 - Lions vs Dolphins
2014-11-28 - club - CTC - male - 736303 - Lions vs Titans
2014-11-23 - club - CTC - male - 736293 - Cape Cobras vs Lions
2014-11-21 - club - CTC - male - 736291 - Titans vs Lions
2014-11-16 - club - CTC - male - 736283 - Warriors vs Lions
2014-11-14 - club - CTC - male - 736279 - Lions vs Cape Cobras
2014-11-07 - club - CTC - male - 736265 - Warriors vs Lions
2014-11-02 - club - CTC - male - 736259 - Dolphins vs Lions
2014-02-02 - club - CTC - male - 652315 - Lions vs Dolphins
2014-01-31 - club - CTC - male - 652309 - Lions vs Cape Cobras
2014-01-19 - club - CTC - male - 652279 - Warriors vs Lions
2014-01-17 - club - CTC - male - 652277 - Titans vs Lions
2014-01-15 - club - CTC - male - 652269 - Cape Cobras vs Lions
2014-01-12 - club - CTC - male - 652267 - Lions vs Knights
2014-01-05 - club - CTC - male - 652303 - Warriors vs Lions
2013-04-07 - club - CTC - male - 575187 - Lions vs Titans
2013-03-28 - club - CTC - male - 575185 - Lions vs Dolphins
2013-03-22 - club - CTC - male - 575179 - Warriors vs Lions
2013-03-12 - club - CTC - male - 575175 - Knights vs Lions
2013-03-08 - club - CTC - male - 575171 - Cape Cobras vs Lions
2013-02-24 - club - CTC - male - 575164 - Lions vs Warriors
2013-02-20 - club - CTC - male - 575159 - Titans vs Lions
2013-02-17 - club - CTC - male - 575158 - Cape Cobras vs Lions
2012-04-01 - club - CTC - male - 530364 - Titans vs Lions
2012-03-21 - club - CTC - male - 530361 - Impi vs Lions
2012-03-16 - club - CTC - male - 530357 - Lions vs Dolphins
2012-03-14 - club - CTC - male - 530353 - Lions vs Warriors
2012-03-11 - club - CTC - male - 530351 - Lions vs Titans
2012-03-09 - club - CTC - male - 530346 - Cape Cobras vs Lions
2012-03-07 - club - CTC - male - 530345 - Knights vs Lions
2012-03-02 - club - CTC - male - 530340 - Titans vs Lions
2012-02-26 - club - CTC - male - 530334 - Lions vs Knights
2012-02-24 - club - CTC - male - 530332 - Cape Cobras vs Lions
2012-02-22 - club - CTC - male - 530328 - Warriors vs Lions
2012-02-17 - club - CTC - male - 530324 - Lions vs Impi
