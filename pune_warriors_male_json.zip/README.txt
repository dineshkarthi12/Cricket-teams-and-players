This zip archive contains data files from Cricsheet in JSON format. This
archive contains 46 Pune Warriors matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/pune_warriors_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2013-05-19 - club - IPL - male - 598067 - Pune Warriors vs Delhi Daredevils
2013-05-15 - club - IPL - male - 598061 - Kolkata Knight Riders vs Pune Warriors
2013-05-11 - club - IPL - male - 598055 - Pune Warriors vs Mumbai Indians
2013-05-09 - club - IPL - male - 598053 - Pune Warriors vs Kolkata Knight Riders
2013-05-05 - club - IPL - male - 598047 - Rajasthan Royals vs Pune Warriors
2013-05-02 - club - IPL - male - 598042 - Pune Warriors vs Royal Challengers Bangalore
2013-04-30 - club - IPL - male - 598038 - Pune Warriors vs Chennai Super Kings
2013-04-28 - club - IPL - male - 598035 - Delhi Daredevils vs Pune Warriors
2013-04-23 - club - IPL - male - 598027 - Royal Challengers Bangalore vs Pune Warriors
2013-04-21 - club - IPL - male - 598025 - Kings XI Punjab vs Pune Warriors
2013-04-17 - club - IPL - male - 598018 - Pune Warriors vs Sunrisers Hyderabad
2013-04-15 - club - IPL - male - 598015 - Chennai Super Kings vs Pune Warriors
2013-04-13 - club - IPL - male - 598011 - Mumbai Indians vs Pune Warriors
2013-04-11 - club - IPL - male - 598009 - Pune Warriors vs Rajasthan Royals
2013-04-07 - club - IPL - male - 598003 - Pune Warriors vs Kings XI Punjab
2013-04-05 - club - IPL - male - 598000 - Sunrisers Hyderabad vs Pune Warriors
2012-05-19 - club - IPL - male - 548375 - Pune Warriors vs Kolkata Knight Riders
2012-05-13 - club - IPL - male - 548365 - Rajasthan Royals vs Pune Warriors
2012-05-11 - club - IPL - male - 548362 - Pune Warriors vs Royal Challengers Bangalore
2012-05-08 - club - IPL - male - 548358 - Pune Warriors vs Rajasthan Royals
2012-05-05 - club - IPL - male - 548353 - Kolkata Knight Riders vs Pune Warriors
2012-05-03 - club - IPL - male - 548351 - Pune Warriors vs Mumbai Indians
2012-05-01 - club - IPL - male - 548348 - Deccan Chargers vs Pune Warriors
2012-04-26 - club - IPL - male - 548341 - Pune Warriors vs Deccan Chargers
2012-04-24 - club - IPL - male - 548337 - Pune Warriors vs Delhi Daredevils
2012-04-21 - club - IPL - male - 548333 - Delhi Daredevils vs Pune Warriors
2012-04-19 - club - IPL - male - 548330 - Chennai Super Kings vs Pune Warriors
2012-04-17 - club - IPL - male - 548327 - Royal Challengers Bangalore vs Pune Warriors
2012-04-14 - club - IPL - male - 548322 - Pune Warriors vs Chennai Super Kings
2012-04-12 - club - IPL - male - 548319 - Kings XI Punjab vs Pune Warriors
2012-04-08 - club - IPL - male - 548313 - Pune Warriors vs Kings XI Punjab
2012-04-06 - club - IPL - male - 548308 - Mumbai Indians vs Pune Warriors
2011-05-21 - club - IPL - male - 501265 - Delhi Daredevils vs Pune Warriors
2011-05-19 - club - IPL - male - 501262 - Pune Warriors vs Kolkata Knight Riders
2011-05-16 - club - IPL - male - 501259 - Pune Warriors vs Deccan Chargers
2011-05-10 - club - IPL - male - 501250 - Deccan Chargers vs Pune Warriors
2011-05-08 - club - IPL - male - 501248 - Kings XI Punjab vs Pune Warriors
2011-05-04 - club - IPL - male - 501241 - Pune Warriors vs Mumbai Indians
2011-05-01 - club - IPL - male - 501235 - Rajasthan Royals vs Pune Warriors
2011-04-29 - club - IPL - male - 501232 - Royal Challengers Bangalore vs Pune Warriors
2011-04-27 - club - IPL - male - 501228 - Pune Warriors vs Chennai Super Kings
2011-04-25 - club - IPL - male - 501226 - Chennai Super Kings vs Pune Warriors
2011-04-20 - club - IPL - male - 501218 - Mumbai Indians vs Pune Warriors
2011-04-17 - club - IPL - male - 501213 - Pune Warriors vs Delhi Daredevils
2011-04-13 - club - IPL - male - 501207 - Pune Warriors vs Kochi Tuskers Kerala
2011-04-10 - club - IPL - male - 501202 - Pune Warriors vs Kings XI Punjab
