This zip archive contains data files from Cricsheet in YAML format. This
archive contains 5 matches of all types from 2002.


The YAML data files contained in this zip file are version 0.93 files. You can
learn about the structure of these files at https://cricsheet.org/format/yaml/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/2002_male.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2002-12-29 - international - ODI - male - 64814 - New Zealand vs India
2002-12-26 - international - Test - male - 64022 - South Africa vs Pakistan
2002-12-26 - international - Test - male - 64012 - Australia vs England
2002-06-29 - international - ODI - male - 66284 - England vs India
2002-06-27 - international - ODI - male - 66283 - England vs Sri Lanka
