This zip archive contains data files from Cricsheet in JSON format. This
archive contains 120 Delhi Capitals matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/delhi_capitals_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-05-24 - club - IPL - male - 1529313 - Delhi Capitals vs Kolkata Knight Riders
2026-05-17 - club - IPL - male - 1529305 - Rajasthan Royals vs Delhi Capitals
2026-05-11 - club - IPL - male - 1529298 - Punjab Kings vs Delhi Capitals
2026-05-08 - club - IPL - male - 1529294 - Delhi Capitals vs Kolkata Knight Riders
2026-05-05 - club - IPL - male - 1529291 - Delhi Capitals vs Chennai Super Kings
2026-05-01 - club - IPL - male - 1529286 - Rajasthan Royals vs Delhi Capitals
2026-04-27 - club - IPL - male - 1529282 - Delhi Capitals vs Royal Challengers Bengaluru
2026-04-25 - club - IPL - male - 1529278 - Delhi Capitals vs Punjab Kings
2026-04-21 - club - IPL - male - 1529274 - Sunrisers Hyderabad vs Delhi Capitals
2026-04-18 - club - IPL - male - 1529269 - Royal Challengers Bengaluru vs Delhi Capitals
2026-04-11 - club - IPL - male - 1527691 - Chennai Super Kings vs Delhi Capitals
2026-04-08 - club - IPL - male - 1527687 - Gujarat Titans vs Delhi Capitals
2026-04-04 - club - IPL - male - 1527681 - Mumbai Indians vs Delhi Capitals
2026-04-01 - club - IPL - male - 1527678 - Lucknow Super Giants vs Delhi Capitals
2025-05-24 - club - IPL - male - 1485779 - Punjab Kings vs Delhi Capitals
2025-05-21 - club - IPL - male - 1473501 - Mumbai Indians vs Delhi Capitals
2025-05-18 - club - IPL - male - 1473498 - Delhi Capitals vs Gujarat Titans
2025-05-08 - club - IPL - male - 1473495 - Punjab Kings vs Delhi Capitals
2025-05-05 - club - IPL - male - 1473492 - Delhi Capitals vs Sunrisers Hyderabad
2025-04-29 - club - IPL - male - 1473485 - Kolkata Knight Riders vs Delhi Capitals
2025-04-27 - club - IPL - male - 1473483 - Delhi Capitals vs Royal Challengers Bengaluru
2025-04-22 - club - IPL - male - 1473477 - Lucknow Super Giants vs Delhi Capitals
2025-04-19 - club - IPL - male - 1473472 - Delhi Capitals vs Gujarat Titans
2025-04-16 - club - IPL - male - 1473469 - Delhi Capitals vs Rajasthan Royals
2025-04-13 - club - IPL - male - 1473466 - Mumbai Indians vs Delhi Capitals
2025-04-10 - club - IPL - male - 1473461 - Royal Challengers Bengaluru vs Delhi Capitals
2025-04-05 - club - IPL - male - 1473454 - Delhi Capitals vs Chennai Super Kings
2025-03-30 - club - IPL - male - 1473447 - Sunrisers Hyderabad vs Delhi Capitals
2025-03-24 - club - IPL - male - 1473441 - Lucknow Super Giants vs Delhi Capitals
2024-05-14 - club - IPL - male - 1426302 - Delhi Capitals vs Lucknow Super Giants
2024-05-12 - club - IPL - male - 1426300 - Royal Challengers Bengaluru vs Delhi Capitals
2024-05-07 - club - IPL - male - 1426294 - Delhi Capitals vs Rajasthan Royals
2024-04-29 - club - IPL - male - 1426285 - Delhi Capitals vs Kolkata Knight Riders
2024-04-27 - club - IPL - male - 1426281 - Delhi Capitals vs Mumbai Indians
2024-04-24 - club - IPL - male - 1426278 - Delhi Capitals vs Gujarat Titans
2024-04-20 - club - IPL - male - 1426273 - Sunrisers Hyderabad vs Delhi Capitals
2024-04-17 - club - IPL - male - 1426270 - Gujarat Titans vs Delhi Capitals
2024-04-12 - club - IPL - male - 1426264 - Lucknow Super Giants vs Delhi Capitals
2024-04-07 - club - IPL - male - 1422138 - Mumbai Indians vs Delhi Capitals
2024-04-03 - club - IPL - male - 1422134 - Kolkata Knight Riders vs Delhi Capitals
2024-03-31 - club - IPL - male - 1422131 - Delhi Capitals vs Chennai Super Kings
2024-03-28 - club - IPL - male - 1422127 - Rajasthan Royals vs Delhi Capitals
2024-03-23 - club - IPL - male - 1422120 - Delhi Capitals vs Punjab Kings
2023-05-20 - club - IPL - male - 1359541 - Chennai Super Kings vs Delhi Capitals
2023-05-17 - club - IPL - male - 1359538 - Delhi Capitals vs Punjab Kings
2023-05-13 - club - IPL - male - 1359533 - Punjab Kings vs Delhi Capitals
2023-05-10 - club - IPL - male - 1359529 - Chennai Super Kings vs Delhi Capitals
2023-05-06 - club - IPL - male - 1359524 - Royal Challengers Bangalore vs Delhi Capitals
2023-05-02 - club - IPL - male - 1359518 - Delhi Capitals vs Gujarat Titans
2023-04-29 - club - IPL - male - 1359514 - Sunrisers Hyderabad vs Delhi Capitals
2023-04-24 - club - IPL - male - 1359508 - Delhi Capitals vs Sunrisers Hyderabad
2023-04-20 - club - IPL - male - 1359502 - Kolkata Knight Riders vs Delhi Capitals
2023-04-15 - club - IPL - male - 1359494 - Royal Challengers Bangalore vs Delhi Capitals
2023-04-11 - club - IPL - male - 1359490 - Delhi Capitals vs Mumbai Indians
2023-04-08 - club - IPL - male - 1359485 - Rajasthan Royals vs Delhi Capitals
2023-04-04 - club - IPL - male - 1359481 - Delhi Capitals vs Gujarat Titans
2023-04-01 - club - IPL - male - 1359477 - Lucknow Super Giants vs Delhi Capitals
2022-05-21 - club - IPL - male - 1304115 - Delhi Capitals vs Mumbai Indians
2022-05-16 - club - IPL - male - 1304110 - Delhi Capitals vs Punjab Kings
2022-05-11 - club - IPL - male - 1304104 - Rajasthan Royals vs Delhi Capitals
2022-05-08 - club - IPL - male - 1304101 - Chennai Super Kings vs Delhi Capitals
2022-05-05 - club - IPL - male - 1304096 - Delhi Capitals vs Sunrisers Hyderabad
2022-05-01 - club - IPL - male - 1304091 - Lucknow Super Giants vs Delhi Capitals
2022-04-28 - club - IPL - male - 1304087 - Kolkata Knight Riders vs Delhi Capitals
2022-04-22 - club - IPL - male - 1304080 - Rajasthan Royals vs Delhi Capitals
2022-04-20 - club - IPL - male - 1304078 - Punjab Kings vs Delhi Capitals
2022-04-16 - club - IPL - male - 1304073 - Royal Challengers Bangalore vs Delhi Capitals
2022-04-10 - club - IPL - male - 1304065 - Delhi Capitals vs Kolkata Knight Riders
2022-04-07 - club - IPL - male - 1304061 - Delhi Capitals vs Lucknow Super Giants
2022-04-02 - club - IPL - male - 1304056 - Gujarat Titans vs Delhi Capitals
2022-03-27 - club - IPL - male - 1304048 - Mumbai Indians vs Delhi Capitals
2021-10-13 - club - IPL - male - 1254116 - Delhi Capitals vs Kolkata Knight Riders
2021-10-10 - club - IPL - male - 1254114 - Delhi Capitals vs Chennai Super Kings
2021-10-08 - club - IPL - male - 1254101 - Delhi Capitals vs Royal Challengers Bangalore
2021-10-04 - club - IPL - male - 1254110 - Chennai Super Kings vs Delhi Capitals
2021-10-02 - club - IPL - male - 1254112 - Mumbai Indians vs Delhi Capitals
2021-09-28 - club - IPL - male - 1254092 - Delhi Capitals vs Kolkata Knight Riders
2021-09-25 - club - IPL - male - 1254097 - Delhi Capitals vs Rajasthan Royals
2021-09-22 - club - IPL - male - 1254105 - Sunrisers Hyderabad vs Delhi Capitals
2021-05-02 - club - IPL - male - 1254086 - Punjab Kings vs Delhi Capitals
2021-04-29 - club - IPL - male - 1254082 - Kolkata Knight Riders vs Delhi Capitals
2021-04-27 - club - IPL - male - 1254079 - Royal Challengers Bangalore vs Delhi Capitals
2021-04-25 - club - IPL - male - 1254077 - Delhi Capitals vs Sunrisers Hyderabad
2021-04-20 - club - IPL - male - 1254070 - Mumbai Indians vs Delhi Capitals
2021-04-18 - club - IPL - male - 1254068 - Punjab Kings vs Delhi Capitals
2021-04-15 - club - IPL - male - 1254064 - Delhi Capitals vs Rajasthan Royals
2021-04-10 - club - IPL - male - 1254059 - Chennai Super Kings vs Delhi Capitals
2020-11-10 - club - IPL - male - 1237181 - Delhi Capitals vs Mumbai Indians
2020-11-08 - club - IPL - male - 1237180 - Delhi Capitals vs Sunrisers Hyderabad
2020-11-05 - club - IPL - male - 1237177 - Mumbai Indians vs Delhi Capitals
2020-11-02 - club - IPL - male - 1216505 - Royal Challengers Bangalore vs Delhi Capitals
2020-10-31 - club - IPL - male - 1216535 - Delhi Capitals vs Mumbai Indians
2020-10-27 - club - IPL - male - 1216524 - Sunrisers Hyderabad vs Delhi Capitals
2020-10-24 - club - IPL - male - 1216497 - Kolkata Knight Riders vs Delhi Capitals
2020-10-20 - club - IPL - male - 1216546 - Delhi Capitals vs Kings XI Punjab
2020-10-17 - club - IPL - male - 1216509 - Chennai Super Kings vs Delhi Capitals
2020-10-14 - club - IPL - male - 1216543 - Delhi Capitals vs Rajasthan Royals
2020-10-11 - club - IPL - male - 1216529 - Delhi Capitals vs Mumbai Indians
2020-10-09 - club - IPL - male - 1216500 - Delhi Capitals vs Rajasthan Royals
2020-10-05 - club - IPL - male - 1216519 - Delhi Capitals vs Royal Challengers Bangalore
2020-10-03 - club - IPL - male - 1216515 - Delhi Capitals vs Kolkata Knight Riders
2020-09-29 - club - IPL - male - 1216532 - Sunrisers Hyderabad vs Delhi Capitals
2020-09-25 - club - IPL - male - 1216539 - Delhi Capitals vs Chennai Super Kings
2020-09-20 - club - IPL - male - 1216493 - Delhi Capitals vs Kings XI Punjab
2019-05-10 - club - IPL - male - 1181767 - Chennai Super Kings vs Delhi Capitals
2019-05-08 - club - IPL - male - 1181766 - Delhi Capitals vs Sunrisers Hyderabad
2019-05-04 - club - IPL - male - 1178428 - Delhi Capitals vs Rajasthan Royals
2019-05-01 - club - IPL - male - 1178425 - Chennai Super Kings vs Delhi Capitals
2019-04-28 - club - IPL - male - 1178421 - Delhi Capitals vs Royal Challengers Bangalore
2019-04-22 - club - IPL - male - 1178415 - Rajasthan Royals vs Delhi Capitals
2019-04-20 - club - IPL - male - 1178412 - Delhi Capitals vs Kings XI Punjab
2019-04-18 - club - IPL - male - 1178409 - Delhi Capitals vs Mumbai Indians
2019-04-14 - club - IPL - male - 1178405 - Sunrisers Hyderabad vs Delhi Capitals
2019-04-12 - club - IPL - male - 1178401 - Kolkata Knight Riders vs Delhi Capitals
2019-04-07 - club - IPL - male - 1178395 - Royal Challengers Bangalore vs Delhi Capitals
2019-04-04 - club - IPL - male - 1175371 - Delhi Capitals vs Sunrisers Hyderabad
2019-04-01 - club - IPL - male - 1175368 - Kings XI Punjab vs Delhi Capitals
2019-03-30 - club - IPL - male - 1175365 - Delhi Capitals vs Kolkata Knight Riders
2019-03-26 - club - IPL - male - 1175360 - Delhi Capitals vs Chennai Super Kings
2019-03-24 - club - IPL - male - 1175358 - Mumbai Indians vs Delhi Capitals
