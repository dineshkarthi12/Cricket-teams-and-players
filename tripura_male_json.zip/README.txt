This zip archive contains data files from Cricsheet in JSON format. This
archive contains 37 Tripura matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/tripura_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2023-10-23 - club - SMA - male - 1383523 - Uttar Pradesh vs Tripura
2023-10-19 - club - SMA - male - 1383487 - Tripura vs Tamil Nadu
2023-10-17 - club - SMA - male - 1383469 - Nagaland vs Tripura
2022-10-20 - club - SMA - male - 1333013 - Manipur vs Tripura
2022-10-18 - club - SMA - male - 1332995 - Tripura vs Puducherry
2021-11-09 - club - SMA - male - 1280289 - Nagaland vs Tripura
2021-11-08 - club - SMA - male - 1280272 - Tripura vs Meghalaya
2021-11-06 - club - SMA - male - 1280251 - Tripura vs Manipur
2021-11-05 - club - SMA - male - 1280235 - Tripura vs Mizoram
2021-11-04 - club - SMA - male - 1280214 - Tripura vs Sikkim
2021-01-18 - club - SMA - male - 1244383 - Punjab vs Tripura
2021-01-16 - club - SMA - male - 1244363 - Tripura vs Uttar Pradesh
2021-01-14 - club - SMA - male - 1244346 - Karnataka vs Tripura
2021-01-12 - club - SMA - male - 1244326 - Tripura vs Jammu & Kashmir
2021-01-10 - club - SMA - male - 1244308 - Tripura vs Railways
2019-11-17 - club - SMA - male - 1205825 - Tripura vs Rajasthan
2019-11-15 - club - SMA - male - 1205815 - Tripura vs Tamil Nadu
2019-11-12 - club - SMA - male - 1205771 - Tripura vs Uttar Pradesh
2019-11-11 - club - SMA - male - 1205761 - Kerala vs Tripura
2019-11-09 - club - SMA - male - 1205734 - Manipur vs Tripura
2019-11-08 - club - SMA - male - 1205717 - Tripura vs Vidarbha
2019-03-02 - club - SMA - male - 1157208 - Maharashtra vs Tripura
2019-02-28 - club - SMA - male - 1157191 - Puducherry vs Tripura
2019-02-25 - club - SMA - male - 1157158 - Uttarakhand vs Tripura
2019-02-24 - club - SMA - male - 1157141 - Uttar Pradesh vs Tripura
2019-02-22 - club - SMA - male - 1157124 - Tripura vs Services
2019-02-21 - club - SMA - male - 1157104 - Tripura vs Baroda
2018-01-14 - club - SMA - male - 1130688 - Tripura vs Bengal
2018-01-12 - club - SMA - male - 1130723 - Odisha vs Tripura
2018-01-10 - club - SMA - male - 1130700 - Jharkhand vs Tripura
2018-01-08 - club - SMA - male - 1130666 - Tripura vs Assam
2016-01-09 - club - SMA - male - 902217 - Rajasthan vs Tripura
2016-01-07 - club - SMA - male - 902191 - Tripura vs Punjab
2016-01-06 - club - SMA - male - 902169 - Jammu & Kashmir vs Tripura
2016-01-04 - club - SMA - male - 902143 - Tripura vs Kerala
2016-01-03 - club - SMA - male - 902121 - Tripura vs Jharkhand
2016-01-02 - club - SMA - male - 902097 - Saurashtra vs Tripura
