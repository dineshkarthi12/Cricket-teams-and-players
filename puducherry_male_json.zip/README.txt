This zip archive contains data files from Cricsheet in JSON format. This
archive contains 26 Puducherry matches.


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/puducherry_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2022-10-22 - club - SMA - male - 1333031 - Puducherry vs Goa
2022-10-18 - club - SMA - male - 1332995 - Tripura vs Puducherry
2022-10-12 - club - SMA - male - 1332938 - Hyderabad (India) vs Puducherry
2021-11-09 - club - SMA - male - 1280274 - Odisha vs Puducherry
2021-11-08 - club - SMA - male - 1280257 - Maharashtra vs Puducherry
2021-11-06 - club - SMA - male - 1280237 - Puducherry vs Tamil Nadu
2021-11-05 - club - SMA - male - 1280219 - Goa vs Puducherry
2021-01-19 - club - SMA - male - 1244395 - Delhi vs Puducherry
2021-01-17 - club - SMA - male - 1244375 - Mumbai vs Puducherry
2021-01-15 - club - SMA - male - 1244358 - Andhra vs Puducherry
2021-01-13 - club - SMA - male - 1244338 - Puducherry vs Haryana
2021-01-11 - club - SMA - male - 1244320 - Puducherry vs Kerala
2019-11-18 - club - SMA - male - 1205728 - Madhya Pradesh vs Puducherry
2019-11-17 - club - SMA - male - 1205829 - Bengal vs Puducherry
2019-11-15 - club - SMA - male - 1205819 - Assam vs Puducherry
2019-11-14 - club - SMA - male - 1205793 - Puducherry vs Haryana
2019-11-12 - club - SMA - male - 1205783 - Mumbai vs Puducherry
2019-11-11 - club - SMA - male - 1205757 - Puducherry vs Mizoram
2019-11-09 - club - SMA - male - 1205739 - Puducherry vs Meghalaya
2019-03-02 - club - SMA - male - 1157209 - Services vs Puducherry
2019-02-28 - club - SMA - male - 1157191 - Puducherry vs Tripura
2019-02-27 - club - SMA - male - 1157172 - Puducherry vs Baroda
2019-02-25 - club - SMA - male - 1157157 - Uttar Pradesh vs Puducherry
2019-02-24 - club - SMA - male - 1157140 - Uttarakhand vs Puducherry
2019-02-22 - club - SMA - male - 1157123 - Puducherry vs Maharashtra
2019-02-21 - club - SMA - male - 1157105 - Puducherry vs Hyderabad (India)
